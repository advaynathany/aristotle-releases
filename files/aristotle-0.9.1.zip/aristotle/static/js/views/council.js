// Councils: one question to several people at once, side by side, then a round where each replies
// to the others from its own beliefs, then a summary of where they agree and differ.
//   #/c/new        pick members        #/c/<id>        talk to a council
import {$, $$, api, avatar, cap, esc, fmt, icon, plural, toast} from "../ui.js";

const threads = new Map();  // council id -> {session, html, turn}
const STARTERS = [
  "Is it right to leave a stable job to pursue something I care about more?",
  "How should I respond to someone who wronged me?",
  "How much should I worry about money?",
];

/* ---------- pick members ---------- */

export async function mountNew(main, {store, refreshLibrary, edit}) {
  const built = store.people.filter(p => p.built);
  const chosen = new Set(edit ? edit.members.map(m => m.slug) : []);
  main.innerHTML = `<header class="topbar"><button class="btn ghost icon menu-btn" id="menu" aria-label="Open navigation">${icon("panel-left")}</button>
      <div class="who"><span>${edit ? `Edit ${esc(edit.name)}` : "New council"}</span></div><div class="spacer"></div></header>
    <div class="page council-new">
      <div class="page-head"><h1>${edit ? "Change the council" : "Put one question to several minds."}</h1>
        <p>Pick 2 to 5 people. Each answers from their own sources. Then they can reply to each other, still citing only their own words.</p></div>
      <label class="lbl" for="cname">Name</label>
      <input class="input" id="cname" placeholder="Named after its members if left blank" value="${esc(edit?.name || "")}" maxlength="80">
      <div class="section-head" style="margin-top:var(--s-8)"><h2>Members</h2><p id="pickcount"></p></div>
      ${built.length >= 2 ? `<div class="pick-list">${built.map(p => `<label class="pick">
          <input type="checkbox" class="check" value="${esc(p.slug)}" ${chosen.has(p.slug) ? "checked" : ""}>
          ${avatar(p)}<span class="txt"><b>${esc(p.name)}</b><span>${esc(p.scripture || p.description || "")}</span></span>
          <span class="faint num">${fmt(p.nodes)} beliefs</span></label>`).join("")}</div>`
        : `<p class="empty">A council needs at least two people with a built map. Add someone from the <a href="#/" style="text-decoration:underline">library</a> and build their map first.</p>`}
      <div class="pick-actions"><button class="btn primary lg" id="create" disabled>${edit ? "Save" : "Create council"}</button>
        ${edit ? `<a class="btn lg ghost" href="#/c/${edit.id}">Cancel</a>` : ""}</div>
      <p class="fine">Each member costs about 3 plan calls per question, and about 2 more each time they reply to each other.</p>
    </div>`;
  $("#menu").onclick = () => $(".app").classList.add("nav-open");
  const boxes = $$(".pick input", main);
  const sync = () => {
    const n = boxes.filter(b => b.checked).length;
    $("#pickcount").textContent = `${n} chosen${n > 5 ? ", 5 at most" : ""}`;
    $("#create").disabled = n < 2 || n > 5;
    boxes.forEach(b => { if (!b.checked) b.disabled = n >= 5; });
  };
  boxes.forEach(b => b.onchange = sync);
  sync();
  $("#create").onclick = async () => {
    const body = {name: $("#cname").value, members: boxes.filter(b => b.checked).map(b => b.value)};
    $("#create").disabled = true;
    try {
      const c = edit ? await api(`/api/councils/${edit.id}`, body, "PATCH") : await api("/api/councils", body);
      if (edit) threads.delete(edit.id);
      await refreshLibrary();
      location.hash = `#/c/${c.id}`;
    } catch (e) { toast(e.message, "bad"); sync(); }
  };
}

/* ---------- a council ---------- */

const stack = members => `<span class="stack">${members.slice(0, 4).map(m => avatar(m, "sm")).join("")}</span>`;

export async function mount(main, {id, store, refreshLibrary}) {
  let c;
  try { c = await api(`/api/councils/${id}`); }
  catch { main.innerHTML = `<div class="page"><p class="empty">That council doesn't exist any more. <a href="#/" style="text-decoration:underline">Back to the library</a></p></div>`; return; }
  // the conversation as data: [{question, answers, rounds, summary, pending, error}], also saved on
  // the server, so clicking away (even mid-answer) or restarting never loses it
  const t = threads.get(id) || {session: null, turns: [], loaded: false};
  threads.set(id, t);
  let alive = true;
  const voices = c.members.map((m, i) => i ? m.voice.replace(/^The /, "the ") : m.voice).join(", ").replace(/, ([^,]*)$/, " and $1");
  const sacred = c.members.some(m => m.scripture);

  main.innerHTML = `<header class="topbar">
      <button class="btn ghost icon menu-btn" id="menu" aria-label="Open navigation">${icon("panel-left")}</button>
      <div class="who">${stack(c.members)}<span>${esc(c.name)}</span></div><div class="spacer"></div>
      <div id="topbar-actions">${store.guest ? "" : `<div class="hist-wrap"><button class="btn sm ghost" id="history" aria-haspopup="true" aria-expanded="false">${icon("history", "sm")} History</button></div>`}
        <button class="btn sm ghost hidden" id="newchat">${icon("plus", "sm")} New conversation</button>
        <a class="btn sm ghost" href="#/c/${id}/edit">${icon("pencil", "sm")} Members</a>
        <button class="btn sm ghost icon" id="del" aria-label="Delete council" title="Delete council">${icon("trash-2", "sm")}</button></div>
    </header>
    <div class="thread council" id="thread"></div>
    <div class="composer"><form id="askf"><div class="field">
      <textarea id="q" rows="1" placeholder="Ask ${esc(voices)}" aria-label="Your question"></textarea>
      <button class="send" id="send" disabled aria-label="Send">${icon("arrow-up")}</button></div>
      <div class="under"><span><em>Serif blue</em> is word for word from the sources. The rest is reasoning.</span><span>Shift + Enter for a new line</span></div>
    </form></div>`;
  $("#menu").onclick = () => $(".app").classList.add("nav-open");

  function intro() {
    return `<div class="ask-intro" id="intro">${stack(c.members)}
      <h1>${esc(c.name)}</h1>
      <p>${esc(voices)} each answer from their own sources. Then let them reply to each other, and see where they agree and where they don't.</p>
      <div class="starters">${STARTERS.map(s => `<button class="starter" type="button">${esc(s)}${icon("arrow-up", "sm")}</button>`).join("")}</div>
      <p class="fine">Models of published ideas, not the people themselves.${sacred ? " Scripture is read in translation, and traditions read these texts in many ways; this is not religious authority." : ""} Replies can only cite their own sources.</p></div>`;
  }

  const q = $("#q"), thread = $("#thread");
  const grow = () => { q.style.height = "auto"; q.style.height = q.scrollHeight + "px"; $("#send").disabled = !q.value.trim(); };
  q.addEventListener("input", grow);
  q.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); $("#askf").requestSubmit(); } });
  const starters = () => $$(".starter", main).forEach(b => b.onclick = () => { q.value = b.textContent.trim(); grow(); q.focus(); });
  $("#newchat").onclick = () => { t.session = null; t.turns = []; draw(); q.focus(); };
  $("#del").onclick = async () => {
    const b = $("#del");
    if (!b.classList.contains("confirm")) { b.classList.add("confirm"); b.innerHTML = `${icon("trash-2", "sm")} Delete?`; setTimeout(() => { if (b.isConnected) { b.classList.remove("confirm"); b.innerHTML = icon("trash-2", "sm"); } }, 3000); return; }
    await api(`/api/councils/${id}`, undefined, "DELETE");
    threads.delete(id);
    await refreshLibrary();
    location.hash = "#/";
  };

  // one member's reply: paragraphs with footnotes, the verbatim passages listed under them
  function card(m, r, key) {
    const nums = new Map(), notes = [];
    const fix = text => String(text || "")
      .replace(/\[\s*(n\d{4}(?:\s*[,;]\s*n\d{4})+)\s*\]/g, (_, g) => g.split(/\s*[,;]\s*/).map(x => `[${x}]`).join(""))
      .replace(/(^|[.!?]\s+|\s)(?<!\[)\b(n\d{4})\b(?!\])/g, (_, pre, nid) => `${pre}${/[.!?]\s+$|^$/.test(pre) ? "This" : "this"} belief [${nid}]`);
    const para = text => `<p>${esc(fix(text)).replace(/\s*((?:\[n\d{4}\])+)/g, (_, g) => `<sup class="fns">${g.match(/n\d{4}/g).map(nid => {
      if (!nums.has(nid)) { nums.set(nid, nums.size + 1); notes.push(nid); }
      return `<a class="fn" data-note="${key}-${nid}" role="button" tabindex="0" aria-label="Source ${nums.get(nid)}">${nums.get(nid)}</a>`;
    }).join("")}</sup>`)}</p>`;
    let body = String(r.answer || "").split(/\n\s*\n/).filter(p => p.trim()).map(para).join("");
    if (r.tension) body += `<h4>${icon("git-merge", "sm")} Where the beliefs pull apart</h4>` + para(r.tension);
    if (r.uncertainty) body += `<h4>${icon("circle-alert", "sm")} Not settled</h4>` + para(r.uncertainty);
    const list = notes.map(nid => {
      const s = r.sources?.[nid];
      if (!s) return "";
      const year = (s.date || "").slice(0, 4);
      return `<div class="note" id="${key}-${nid}"><span class="n">${nums.get(nid)}</span><blockquote title="Show the whole passage">${esc(s.quote)}</blockquote>
        <div class="src"><span>${cap(s.kind || "belief")}${s.origin || s.section ? `, ${esc(s.origin || s.section)}` : ""}${year ? `, ${year}` : ""}</span><a data-open="${m.slug}/${nid}">Open in map</a></div></div>`;
    }).join("");
    const coda = r.not_covered ? `<span class="faint">Nothing grounded to say here.</span>`
      : r.verified ? `<span class="badge ok">${icon("check", "sm")} ${plural((r.cited || []).length, "belief")} cited, quotes checked</span>`
        : `<span class="badge bad">${icon("circle-alert", "sm")} Some claims couldn't be verified</span>`;
    return `<section class="voice ${r.not_covered ? "quiet" : ""}"><header>${avatar(m, "sm")}<b>${esc(m.voice)}</b></header>
      <div class="vbody">${body}</div>${list ? `<div class="vnotes">${list}</div>` : ""}<div class="vcoda">${coda}</div></section>`;
  }

  const grid = (replies, key, label) => `<div class="round">${label ? `<div class="round-label">${label}</div>` : ""}
    <div class="voices" style="--n:${c.members.length}">${c.members.filter(m => replies[m.slug]).map(m => card(m, replies[m.slug], `${key}-${m.slug}`)).join("")}</div></div>`;

  const PHASES = {
    ask: [[0, `Asking ${c.members.length} members at once`], [5, "Each is reasoning from their own beliefs"], [14, "Checking every quote against its source"]],
    respond: [[0, "Each member is reading the others"], [5, "Finding what their own sources say back"], [14, "Checking every quote"]],
    summary: [[0, "Comparing what they said"]]};
  const thinking = x => `<div class="thinking" role="status" data-start="${x.started}" data-kind="${x.pending}">${icon("loader-circle", "spin")}
    <span class="shimmer">${PHASES[x.pending][0][1]}</span><span class="faint num secs"></span></div>`;
  const tick = setInterval(() => $$(".thinking[data-start]", main).forEach(el => {
    const sec = (Date.now() - +el.dataset.start) / 1000;
    el.querySelector(".shimmer").textContent = PHASES[el.dataset.kind].filter(([at]) => sec >= at).at(-1)[1];
    el.querySelector(".secs").textContent = `${Math.round(sec)}s`;
  }), 500);

  const summary = s => `<div class="council-summary"><div class="round-label">${icon("git-merge", "sm")} Where they agree and differ
      <span class="faint">A summary written from what they said above. Not their words, and not a verdict.</span></div>
    ${s.common?.length ? `<h4>Common ground</h4><ul>${s.common.map(x => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}
    ${s.differ?.length ? `<h4>Where they differ</h4>${s.differ.map(d => `<div class="differ"><b>${esc(d.point)}</b><dl>${Object.entries(d.positions).map(([who, pos]) =>
      `<dt>${esc(who)}</dt><dd>${esc(pos)}</dd>`).join("")}</dl></div>`).join("")}` : ""}
    ${s.open ? `<h4>Still yours to weigh</h4><p>${esc(s.open)}</p>` : ""}</div>`;

  function turnHTML(x, i) {
    const n = i + 1, rounds = x.rounds || [];
    let h = `<div class="question">${esc(x.question)}</div><div class="answers">${x.answers ? grid(x.answers, `t${n}a`, "")
      : x.pending === "ask" ? thinking(x) : x.error ? `<div class="callout bad">${icon("circle-alert", "sm")}<span>No answers came back: ${esc(x.error)}. Your question is back in the box.</span></div>` : ""}</div>`;
    rounds.forEach((r, k) => { h += grid(r, `t${n}r${k + 1}`, `Round ${k + 1}: replies to each other`); });
    if (x.summary) h += summary(x.summary);
    if (x.answers && x.pending) h += `<div>${thinking(x)}</div>`;
    if (x.answers && x.error) h += `<div class="callout bad">${icon("circle-alert", "sm")}<span>${esc(x.error)}</span></div>`;
    const bar = x.answers && !x.pending ? `${rounds.length < 3 ? `<button class="btn" data-act="respond">${icon("message-square-text", "sm")} ${rounds.length ? "Another round of replies" : "Let them respond to each other"}</button>` : ""}
      ${x.summary ? "" : `<button class="btn ghost" data-act="summary">${icon("git-merge", "sm")} Where they agree and differ</button>`}
      ${rounds.length ? `<span class="faint num">Round ${rounds.length} of 3</span>` : ""}` : "";
    return `<article class="turn" data-i="${i}">${h}<div class="council-actions">${i === t.turns.length - 1 ? bar : ""}</div></article>`;
  }

  function draw() {
    if (!alive) return;
    thread.innerHTML = t.turns.length ? t.turns.map(turnHTML).join("") : intro();
    if (!t.turns.length) starters();
    $("#newchat").classList.toggle("hidden", !t.turns.length);
  }
  t.draw = draw;
  const busy = () => t.turns.some(x => x.pending);

  async function act(i, kind) {
    const x = t.turns[i];
    if (busy()) return;
    x.pending = kind; x.started = Date.now(); delete x.error;
    draw();
    thread.lastElementChild?.lastElementChild?.scrollIntoView({behavior: "smooth", block: "end"});
    try {
      if (kind === "respond") {
        const r = await api(`/api/councils/${id}/respond`, {session: t.session});
        (x.rounds ||= []).push(r.replies);
      } else x.summary = await api(`/api/councils/${id}/summary`, {session: t.session});
    } catch (e) { x.error = e.message; }
    finally { delete x.pending; t.draw?.(); }
  }

  async function open(sid) {
    try {
      const chat = await api(`/api/councils/${id}/chats/${sid}`);
      t.session = chat.id;
      t.turns = chat.turns.map(x => ({question: x.question, answers: x.answers, rounds: x.rounds || [], summary: x.summary}));
      draw();
      thread.lastElementChild?.scrollIntoView({block: "start"});
    } catch (e) { toast(e.message, "bad"); }
  }

  const hist = $("#history");
  if (hist) hist.onclick = async () => {
    const wrap = hist.parentElement;
    if ($(".hist", wrap)) { $(".hist", wrap).remove(); hist.setAttribute("aria-expanded", "false"); return; }
    hist.setAttribute("aria-expanded", "true");
    const box = document.createElement("div");
    box.className = "hist"; box.setAttribute("role", "menu");
    box.innerHTML = `<p class="faint">${icon("loader-circle", "sm spin")} Loading</p>`;
    wrap.append(box);
    const list = await api(`/api/councils/${id}/chats`).catch(() => []);
    const when = ts => { const d = new Date(ts * 1000); return d.toDateString() === new Date().toDateString()
      ? d.toLocaleTimeString("en-US", {hour: "numeric", minute: "2-digit"}) : d.toLocaleDateString("en-US", {month: "short", day: "numeric"}); };
    box.innerHTML = list.length ? list.map(x => `<div class="hist-row ${x.id === t.session ? "on" : ""}">
        <button role="menuitem" data-chat="${x.id}"><b>${esc(x.title)}</b><span>${when(x.updated)} · ${plural(x.turns, "question")}</span></button>
        <button class="del" data-del="${x.id}" aria-label="Delete this conversation">${icon("trash-2", "sm")}</button></div>`).join("")
      : `<p class="faint">No saved conversations yet.</p>`;
    $$("[data-chat]", box).forEach(b => b.onclick = () => { box.remove(); hist.setAttribute("aria-expanded", "false"); open(b.dataset.chat); });
    $$("[data-del]", box).forEach(b => b.onclick = async () => {
      if (b.dataset.sure !== "1") { b.dataset.sure = "1"; b.classList.add("sure"); return; }
      await api(`/api/councils/${id}/chats/${b.dataset.del}`, undefined, "DELETE").catch(() => {});
      if (b.dataset.del === t.session) { t.session = null; t.turns = []; draw(); }
      b.closest(".hist-row").remove();
    });
  };
  const offHist = e => { if (!e.target.closest(".hist-wrap")) { $(".hist", main)?.remove(); hist?.setAttribute("aria-expanded", "false"); } };
  document.addEventListener("mousedown", offHist);

  draw();
  if (!t.loaded && !store.guest) {
    t.loaded = true;
    if (!t.turns.length && !t.session) api(`/api/councils/${id}/chats`).then(list => {
      if (list.length && !t.turns.length && !t.session) open(list[0].id);
    }).catch(() => {});
  }

  $("#askf").onsubmit = async e => {
    e.preventDefault();
    const text = q.value.trim();
    if (!text || $("#send").disabled || busy()) return;
    const x = {question: text, pending: "ask", started: Date.now(), rounds: []};
    t.turns.push(x);
    draw();
    thread.lastElementChild.scrollIntoView({behavior: "smooth", block: "start"});
    q.value = ""; grow(); $("#send").disabled = true;
    try {
      const r = await api(`/api/councils/${id}/ask`, {session: t.session, message: text});
      t.session = r.session;
      x.answers = r.answers;
    } catch (err) {
      x.error = err.message;
      if (alive) { q.value = text; grow(); }
    } finally {
      delete x.pending;
      t.draw?.();
      if (alive) { $("#send").disabled = !q.value.trim(); q.focus(); }
    }
  };

  const onClick = e => {
    const a = e.target.closest("[data-act]");
    if (a) { if (!t.session) return toast("That conversation has ended. Ask the council again.", "bad"); return act(+a.closest(".turn").dataset.i, a.dataset.act); }
    const fn = e.target.closest(".fn");
    if (fn) { const note = document.getElementById(fn.dataset.note); if (note) { note.scrollIntoView({behavior: "smooth", block: "center"}); note.classList.add("lit"); setTimeout(() => note.classList.remove("lit"), 1600); } return; }
    const bq = e.target.closest(".note blockquote");
    if (bq) { bq.parentElement.classList.toggle("open"); return; }
    const op = e.target.closest("[data-open]");
    if (op) { const [slug, nid] = op.dataset.open.split("/"); location.hash = `#/p/${slug}/map/${nid}`; }
  };
  const onOver = e => {
    $$(".note.hov, .fn.lit", main).forEach(x => x.classList.remove("lit", "hov"));
    const fn = e.target.closest(".fn");
    if (fn) { fn.classList.add("lit"); document.getElementById(fn.dataset.note)?.classList.add("lit", "hov"); }
  };
  main.addEventListener("click", onClick);
  main.addEventListener("mouseover", onOver);
  q.focus();
  return () => {
    alive = false; clearInterval(tick);
    if (t.draw === draw) t.draw = null;
    document.removeEventListener("mousedown", offHist);
    main.removeEventListener("click", onClick); main.removeEventListener("mouseover", onOver);
  };
}
