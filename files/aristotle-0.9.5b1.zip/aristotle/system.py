"""The few things that differ between macOS and Windows: hidden child processes, text encoding,
and moving a deleted person to the Trash (Mac) or the Recycle Bin (Windows)."""
from __future__ import annotations

import os
import shutil
import sys
import threading
import time
from pathlib import Path

WINDOWS = sys.platform == "win32"


def quiet() -> dict:
    """subprocess keyword arguments for a child process with no console window of its own (a
    windowed Windows app would flash one for every `claude -p` call otherwise) and UTF-8 text
    (Windows defaults to the ANSI code page, which can't decode most quotes)."""
    if WINDOWS:
        import subprocess
        return {"creationflags": subprocess.CREATE_NO_WINDOW, "encoding": "utf-8", "errors": "replace"}
    return {}


def to_trash(path: Path) -> bool:
    """Move a folder somewhere the user can restore it from. False when there's nowhere to put it
    (the caller then deletes it outright)."""
    stamp = time.strftime("%Y-%m-%d %H.%M.%S")
    trash = os.environ.get("ARISTOTLE_TRASH")
    if trash or sys.platform == "darwin":
        trash = Path(trash or Path.home() / ".Trash")
        if not trash.is_dir():
            return False
        shutil.move(str(path), str(trash / f"{path.name} (Aristotle {stamp})"))
        return True
    if WINDOWS:
        return _recycle(path)
    return False


def _recycle(path: Path) -> bool:
    import ctypes
    from ctypes import wintypes

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [("hwnd", wintypes.HWND), ("wFunc", wintypes.UINT), ("pFrom", wintypes.LPCWSTR),
                    ("pTo", wintypes.LPCWSTR), ("fFlags", ctypes.c_ushort), ("fAnyOperationsAborted", wintypes.BOOL),
                    ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", wintypes.LPCWSTR)]

    FO_DELETE, FOF_SILENT, FOF_NOCONFIRMATION, FOF_ALLOWUNDO, FOF_NOERRORUI = 3, 0x4, 0x10, 0x40, 0x400
    op = SHFILEOPSTRUCTW(wFunc=FO_DELETE, pFrom=str(Path(path).resolve()) + "\0",  # double-NUL list
                         fFlags=FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI)
    return ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op)) == 0 and not Path(path).exists()


def replace(src: Path, dest: Path) -> None:
    """os.replace, retried briefly: on Windows it fails while another thread has `dest` open for
    reading, which a reader holds only for a moment."""
    for i in range(40):
        try:
            os.replace(src, dest)
            return
        except PermissionError:
            if not WINDOWS or i == 39:
                raise
            time.sleep(0.025)


def read_text(path: Path) -> str:
    """Path.read_text, retried briefly: on Windows opening a file fails with PermissionError for
    the moment another thread is replacing it (see `replace`)."""
    for i in range(40):
        try:
            return Path(path).read_text(encoding="utf-8")
        except PermissionError:
            if not WINDOWS or i == 39:
                raise
            time.sleep(0.025)


def write_atomic(path: Path, text: str) -> None:
    """Write a whole file so readers see the old or the new contents, never a half-written one."""
    path = Path(path)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    tmp.write_text(text, encoding="utf-8")
    replace(tmp, path)
