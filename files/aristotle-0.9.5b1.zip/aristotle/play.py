"""Just for fun: playful answers that don't have to be grounded, for real people and for fictional
characters (who have no sources, so this is all they get).

Everything else in Aristotle is cited and verified. This isn't, so it says so on the page, it
never puts words in quotation marks as theirs, and it speaks about them in the third person
("Percy would..."), never as them.
"""
from __future__ import annotations

import re

PLAY_SYSTEM = """This is the "Just for fun" mode of an app that otherwise answers strictly from a \
person's published words. Here the user wants something light: playful questions, hypotheticals, \
advice on everyday things like dating or friends, silly what-ifs.

Who: {who}
{about}
Answer the way {name} plausibly would, from what's generally known about them: their personality, \
values, sense of humour, the way they talk about things. Be warm, specific and fun, not generic. \
Short: under about 150 words unless the user asks for more.

Rules:
- Third person, always: "{short} would probably...", "{short}'d tell you...". Never speak as {name}, \
never write "I" as them.
- No quotation marks around anything as if {name} said or wrote it. Paraphrase only.
- {fiction_rule}
- Keep it kind. If a question asks for something cruel, explicit or harmful, steer it somewhere \
fun instead.
- Plain text, no JSON, no headings."""

REAL_RULE = ("Don't state made-up facts about their real life (relationships, events, opinions on "
             "named people) as if true. Playful speculation is fine when it's clearly speculation.")
FICTION_RULE = ("Stay true to the character and their world. Don't reproduce passages from the "
                "books, films or shows; describe and paraphrase.")


def short_name(name: str) -> str:
    """'Percy Jackson' -> 'Percy'; 'the Buddha' and one-word names stay as they are."""
    parts = re.sub(r"\(.*?\)", "", name).split()
    return name if len(parts) < 2 or parts[0].lower() == "the" else parts[0]


class Play:
    def __init__(self, llm, cfg: dict, beliefs: list[str] | None = None):
        self.llm = llm
        name = cfg["name"]
        fiction = cfg.get("fictional")
        if fiction:
            who = f"{name}, a fictional character from {fiction['from']}." if fiction.get("from") else f"{name}, a fictional character."
            about = ""
        else:
            desc = (cfg.get("profile") or {}).get("description", "")
            who = f"{name}{f' ({desc})' if desc else ''}, a real person."
            ideas = (beliefs or [])[:12]
            about = ("\nIdeas they're known for (flavour, not a script):\n" + "\n".join(f"- {b}" for b in ideas) + "\n") if ideas else ""
        self.system = PLAY_SYSTEM.format(who=who, about=about, name=name, short=short_name(name),
                                         fiction_rule=FICTION_RULE if fiction else REAL_RULE)
        self.history: list[dict] = []

    def ask(self, message: str, on_text=None) -> dict:
        if on_text is not None and hasattr(self.llm, "stream"):
            text = self.llm.stream(self.system, message, on_text, history=self.history)
        else:
            text = self.llm.complete(self.system, message, history=self.history)
        text = text.strip()
        self.history += [{"role": "user", "content": message}, {"role": "assistant", "content": text}]
        return {"answer": text}
