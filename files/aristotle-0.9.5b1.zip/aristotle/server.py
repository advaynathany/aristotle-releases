"""Local web UI: the library of people, adding a person, chat with citations, map review and
blind A/B rating.

`make_app(path)` takes either thinkers/ (the whole library) or one person's folder (the library is
then its parent, opened on that person). Conversations live in memory and are never written to disk.

Guest mode (ARISTOTLE_GUEST=1) is the hosted copy for other people: they can add people, build
and ask, but not review, edit or merge beliefs, or see the blind test. ARISTOTLE_PASSWORD puts one
shared password in front of everything. `on_change(folder)` is called whenever a person's files
change, so the host can save them somewhere that outlives its disk.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import threading
import time
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import chats, council, discover, follow, packs, traditions, worldview
from .journal import Journal
from .chat import Thinker
from .embed import Embedder
from .jobs import Builder, estimate
from .library import built_ids, people, read_job, summary
from .llm import LLM, PROVIDERS, LLMError, claude_bin, claude_status, codex_bin, codex_status, gemini_check
from .paths import CACHE
from .play import Play
from .schema import REVIEW_STATES, EpistemeMap
from .system import read_text, write_atomic

STATIC = Path(__file__).resolve().parent / "static"
STARTER = 40
MAX_SESSIONS = 200  # per person; the oldest conversation goes first
GUEST_DENIED = re.compile(r"/(node/[^/]+|merge|rate|blind|follow|follow/check|pack|chats|chats/[^/]+)$|^/api/(journal|packs)")
# curating maps, the private journal, following (it spends plan) and packs stay with the owner


class Ask(BaseModel):
    session: str | None = None
    message: str


class Language(BaseModel):
    language: str


# what "Answer in" offers: English name -> the name in that language
LANGUAGES = {"English": "English", "Hindi": "हिन्दी", "Sanskrit": "संस्कृतम्", "Bengali": "বাংলা",
             "Marathi": "मराठी", "Gujarati": "ગુજરાતી", "Tamil": "தமிழ்", "Telugu": "తెలుగు", "Urdu": "اردو",
             "Arabic": "العربية", "Spanish": "Español", "French": "Français", "German": "Deutsch",
             "Portuguese": "Português", "Italian": "Italiano", "Greek": "Ελληνικά", "Chinese": "中文",
             "Japanese": "日本語", "Korean": "한국어"}


class Fictional(BaseModel):
    name: str
    source: str = ""  # the book, film or show they're from


class Review(BaseModel):
    review: str | None = None
    statement: str | None = None
    note: str | None = None


class Critique(BaseModel):
    draft: str
    about: str = ""


class Follow(BaseModel):
    on: bool
    auto_build: bool = True


class JournalIn(BaseModel):
    slug: str
    question: str
    answer: str
    cited: list[dict] = []
    plan: str = ""
    follow_up: str = ""


class JournalEdit(BaseModel):
    plan: str | None = None
    follow_up: str | None = None
    outcome: dict | None = None


class Merge(BaseModel):
    keep: str
    drop: str


class Rate(BaseModel):
    id: str
    choice: str  # A | B | tie


class Person(BaseModel):
    title: str
    auto_build: bool = False  # onboarding: start the starter build once sources are found


class Onboarding(BaseModel):
    done: bool


class Tradition(BaseModel):
    id: str


class CouncilIn(BaseModel):
    name: str = ""
    members: list[str] | None = None


class CouncilTurn(BaseModel):
    session: str | None = None
    message: str = ""


class Link(BaseModel):
    url: str


class Pick(BaseModel):
    id: str
    selected: bool


class Channel(BaseModel):
    channel: str  # stable | beta


class Appearance(BaseModel):
    mode: str = "system"     # system | light | dark
    surface: str = "neutral"
    accent: str = "graphite"
    size: str = "default"    # small | default | large


APPEARANCE = {"mode": ("system", "light", "dark"), "surface": ("neutral", "paper", "slate", "sage"),
              "accent": ("graphite", "forest", "clay", "plum", "teal"), "size": ("small", "default", "large")}


class ModelChoice(BaseModel):
    provider: str            # cli (Claude) | openai (Gemini) | codex
    model: str | None = None  # None: the one last chosen for this provider
    key: str | None = None    # a Gemini API key, when one is being added or replaced


class Feedback(BaseModel):
    kind: str = "bug"  # bug | idea
    message: str
    email: str = ""
    page: str = ""
    details: bool = True


class Build(BaseModel):
    passages: int | None = STARTER  # None reads every remaining passage


class Revalidated(StaticFiles):
    """Static files the browser must check before reuse (a cheap 304 when unchanged). Without it
    Chrome keeps the old JS after an update, so new features don't show until a hard reload."""

    def file_response(self, *args, **kwargs):
        r = super().file_response(*args, **kwargs)
        r.headers["Cache-Control"] = "no-cache"
        return r


class Person_:
    """One person's loaded state: map, retrieval index and chat sessions, all lazy."""

    def __init__(self, folder: Path):
        self.folder = folder
        self.lock = threading.Lock()
        self.reset()

    def reset(self) -> None:
        self._map, self._emb, self.sessions = None, None, {}

    @property
    def cfg(self) -> dict:
        return json.loads(read_text(self.folder / "config.json"))

    @property
    def map(self) -> EpistemeMap:
        if self._map is None:
            path = self.folder / "map.json"
            if not path.exists():
                raise HTTPException(409, f"{self.cfg['name']} has no map yet. Build one from Sources.")
            self._map = EpistemeMap.load(path)
        return self._map

    def embedder(self) -> Embedder:
        with self.lock:
            if self._emb is None:
                self._emb = Embedder([Thinker._doc(n) for n in self.map.live_nodes()])
            return self._emb

    @property
    def chats(self) -> "chats.Store":
        return chats.Store(self.folder / "chats")

    def thinker(self, llm) -> Thinker:
        cfg = self.cfg
        return Thinker(llm, self.map, voice=cfg.get("voice", "third"), embedder=self.embedder(),
                       signature=cfg.get("signature"), language=cfg.get("answer_language", "English"))

    def save(self) -> None:
        self.map.save(self.folder / "map.json")
        self._emb, self.sessions = None, {}  # live node set changed: rebuild retrieval lazily


def _apply_model(llm: LLM) -> None:
    """Point the shared LLM at the provider and model saved in settings.json."""
    from . import updater
    saved = updater.settings()
    chosen = saved.get("model") or {}
    backend = chosen.get("provider") if chosen.get("provider") in PROVIDERS else "cli"
    if backend == "openai" and not saved.get("gemini_key"):
        backend = "cli"
    models = [m for m, _, _ in PROVIDERS[backend]["models"]]
    model = chosen.get(backend) if chosen.get(backend) in models else models[0]
    llm.configure(backend, model, key=saved.get("gemini_key"))


def make_app(path: Path, llm=None, guest: bool | None = None, password: str | None = None,
             on_change=None) -> FastAPI:
    path = Path(path)
    root = path.parent if (path / "config.json").exists() else path
    default = path.name if (path / "config.json").exists() else None
    guest = os.environ.get("ARISTOTLE_GUEST") == "1" if guest is None else guest
    own_llm = llm is None
    llm = llm or LLM()
    password = os.environ.get("ARISTOTLE_PASSWORD") if password is None else password
    loaded: dict[str, Person_] = {}
    # the owner's Model settings pick the backend, unless the environment pins one (the guest copy, evals)
    choosable = own_llm and not guest and "ARISTOTLE_BACKEND" not in os.environ
    if choosable:
        _apply_model(llm)
    app = FastAPI(title="Aristotle", docs_url=None if guest else "/docs", redoc_url=None,
                  openapi_url=None if guest else "/openapi.json")

    changed = on_change or (lambda folder: None)

    def person(slug: str | None) -> Person_:
        slug = slug or default or next((p.name for p in people(root)), None)
        folder = root / (slug or "")
        if not slug or not (folder / "config.json").exists():
            raise HTTPException(404, "no such person")
        if slug not in loaded:
            loaded[slug] = Person_(folder)
        return loaded[slug]

    Builder.recover(root)

    def built(folder: Path) -> None:
        if folder.name in loaded:
            loaded[folder.name].reset()
        changed(folder)
    builder = Builder(llm, on_done=built)
    if not guest and os.environ.get("ARISTOTLE_FOLLOW", "1") == "1":
        follow.Follower(root, llm, builder, on_change=changed)
    journal = Journal(root)

    token = hashlib.sha256(f"aristotle:{password}".encode()).hexdigest() if password else None

    @app.middleware("http")
    async def gate(request: Request, call_next):
        route = request.url.path
        if token and route != "/login" and not hmac.compare_digest(request.cookies.get("aristotle", ""), token):
            if route.startswith("/api/"):
                return JSONResponse({"detail": "Enter the password first."}, status_code=401)
            if not route.startswith("/static/"):
                return RedirectResponse("/login", status_code=303)
        if guest and route.startswith("/api/") and GUEST_DENIED.search(route):
            return JSONResponse({"detail": "Only the owner can review or edit beliefs."}, status_code=403)
        if guest and request.method == "DELETE" and re.match(r"^/api/councils/[^/]+$", route):
            return JSONResponse({"detail": "Only the owner can delete councils."}, status_code=403)
        return await call_next(request)

    @app.get("/login")
    def login_page(wrong: int = 0):
        return HTMLResponse(LOGIN.replace("{{wrong}}", '<p class="wrong">That password isn\'t right.</p>' if wrong else ""))

    @app.post("/login")
    def login(password_: str = Form(..., alias="password")):
        if not token or not hmac.compare_digest(hashlib.sha256(f"aristotle:{password_}".encode()).hexdigest(), token):
            return RedirectResponse("/login?wrong=1", status_code=303)
        r = RedirectResponse("/", status_code=303)
        r.set_cookie("aristotle", token, max_age=60 * 60 * 24 * 90, httponly=True, samesite="lax",
                     secure=os.environ.get("ARISTOTLE_HTTPS") == "1")
        return r

    app.mount("/static", Revalidated(directory=STATIC), name="static")

    @app.get("/")
    def index():
        return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-store"})

    # ---------- bug reports and ideas, forwarded to the maker ----------

    @app.post("/api/feedback")
    def feedback(req: Feedback):
        from . import feedback as fb
        if not req.message.strip():
            raise HTTPException(400, "Write a sentence or two first.")
        return {"sent": fb.send(req.kind, req.message, req.email, req.page, req.details)}

    # ---------- updates (Mac app only) ----------

    @app.get("/api/update")
    def update_status():
        from . import updater
        if guest:
            return {"enabled": False}
        # an app bundle from before the native window shows the page in Chrome: offer the new download
        return {**updater.status(), "window": os.environ.get("ARISTOTLE_WINDOW", "")}

    @app.post("/api/update/check")
    def update_check():
        from . import updater
        if guest:
            raise HTTPException(403, "Not available here.")
        return updater.check()

    @app.post("/api/update/channel")
    def update_channel(req: Channel):
        from . import updater
        if guest:
            raise HTTPException(403, "Not available here.")
        try:
            updater.set_channel(req.channel)
        except ValueError as e:
            raise HTTPException(400, str(e))
        return updater.check()

    @app.post("/api/update/restart")
    def update_restart():
        from . import desktop
        if guest:
            raise HTTPException(403, "Not available here.")
        try:
            desktop.restart()
        except RuntimeError as e:
            raise HTTPException(400, str(e))
        return {"ok": True}

    # ---------- appearance: saved with the library, so it survives the app picking a new port ----------

    @app.get("/api/appearance")
    def appearance():
        from . import updater
        saved = {} if guest else updater.settings().get("appearance") or {}
        if not saved:
            return {}  # nothing chosen yet: the page keeps whatever it has
        default = Appearance().model_dump()
        return {k: saved[k] if saved.get(k) in ok else default[k] for k, ok in APPEARANCE.items()}

    @app.post("/api/appearance")
    def set_appearance(req: Appearance):
        from . import updater
        a = req.model_dump()
        bad = [k for k, ok in APPEARANCE.items() if a[k] not in ok]
        if bad:
            raise HTTPException(400, f"Unknown {', '.join(bad)}.")
        if not guest:  # guests share one server, so their choice stays in their own browser
            updater.save_setting("appearance", a)
        return a

    # ---------- connecting the user's own Claude account ----------

    @app.get("/api/claude")
    def claude():
        if guest or getattr(llm, "backend", "cli") != "cli":
            ready = codex_status()["logged_in"] if not guest and getattr(llm, "backend", "") == "codex" else True
            return {"backend": getattr(llm, "backend", "other"), "ready": ready}
        st = claude_status()
        return {"backend": "cli", "ready": st["logged_in"], **st}

    @app.post("/api/claude/login")
    def claude_login():
        """Starts the CLI's own sign-in, which opens claude.ai in the browser; the page polls
        /api/claude until it reports signed in."""
        if guest:
            raise HTTPException(403, "Not available here.")
        import subprocess

        from .system import quiet
        try:
            subprocess.Popen([claude_bin(), "auth", "login", "--claudeai"], stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True, **quiet())
        except FileNotFoundError:
            raise HTTPException(400, "Claude Code isn't installed yet.")
        return {"ok": True}

    # ---------- which model answers: Claude, Gemini's free tier, or Codex ----------

    def model_state() -> dict:
        from . import updater
        saved = updater.settings()
        key = saved.get("gemini_key") or ""
        st = {"cli": claude_status, "codex": codex_status}.get(llm.backend, lambda: {"installed": True, "logged_in": bool(llm.key)})()
        return {"choosable": choosable, "provider": llm.backend, "model": llm.models["strong"],
                "providers": {b: {"name": p["name"], "experimental": p.get("experimental", False), "models": [{"id": m, "label": l, "note": n} for m, l, n in p["models"]]}
                              for b, p in PROVIDERS.items()},
                "gemini_key": f"…{key[-4:]}" if key else "", "ready": st.get("logged_in", False), **st}

    @app.get("/api/model")
    def model_get():
        if not choosable:
            return {"choosable": False, "provider": llm.backend, "model": llm.models["strong"], "ready": True}
        return model_state()

    @app.post("/api/model")
    def model_set(req: ModelChoice):
        from . import updater
        if not choosable:
            raise HTTPException(403, "The model is fixed here.")
        if req.provider not in PROVIDERS:
            raise HTTPException(400, "Unknown provider.")
        saved = updater.settings()
        chosen = {**(saved.get("model") or {}), "provider": req.provider}
        if req.model is not None:
            if req.model not in [m for m, _, _ in PROVIDERS[req.provider]["models"]]:
                raise HTTPException(400, "Unknown model.")
            chosen[req.provider] = req.model
        if req.key is not None and req.key.strip():
            problem = gemini_check(req.key.strip())
            if problem:
                raise HTTPException(400, problem)
            updater.save_setting("gemini_key", req.key.strip())
        if req.provider == "openai" and not updater.settings().get("gemini_key"):
            raise HTTPException(400, "Add your free Gemini API key first.")
        updater.save_setting("model", chosen)
        _apply_model(llm)
        return model_state()

    @app.post("/api/codex/login")
    def codex_login():
        """`codex login` opens the ChatGPT sign-in in the browser; the page polls /api/model."""
        if not choosable:
            raise HTTPException(403, "Not available here.")
        import subprocess

        from .system import quiet
        try:
            subprocess.Popen([codex_bin(), "login"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True, **quiet())
        except FileNotFoundError:
            raise HTTPException(400, "Codex isn't installed yet.")
        return {"ok": True}

    # ---------- library ----------

    @app.get("/api/library")
    def library():
        return {"default": default, "guest": guest, "people": [summary(p) for p in people(root)],
                "journal_due": 0 if guest else journal.due()}

    trad_path = CACHE / "traditions.json"

    @app.get("/api/people")
    def search(q: str):
        sacred = traditions.matches(q)
        try:
            found = discover.search_people(q)
        except Exception as e:
            if not sacred:
                raise HTTPException(502, f"Wikipedia search failed: {e}")
            found = []
        # scripture entries first: Krishna isn't a "human" to Wikipedia search, and Jesus or the
        # Buddha sit among people who share the name
        images = json.loads(trad_path.read_text(encoding="utf-8")) if trad_path.exists() else {}
        titles = {t["wikipedia"] for t in sacred}
        found = [{"title": t["wikipedia"], "image": images.get(t["id"], "")} for t in sacred] + \
                [f for f in found if f["title"] not in titles]
        have = {json.loads((p / "config.json").read_text(encoding="utf-8")).get("profile", {}).get("title")
                or json.loads((p / "config.json").read_text(encoding="utf-8"))["name"]: p.name for p in people(root)}
        scripture = {t["wikipedia"]: t for t in traditions.TRADITIONS}
        for f in found:
            f["slug"] = have.get(f["title"])
            if f["title"] in scripture:  # same card as the shelf: name, no portrait of the Prophet
                f.update(traditions.card(scripture[f["title"]], f.get("image", "")), title=f["title"])
                f["slug"] = f["slug"] or have.get(scripture[f["title"]]["name"])
        return found

    @app.post("/api/people")
    def add_person(req: Person):
        try:
            # Jesus or Muhammad found by search: add them from their scripture, not Wikiquote
            t = next((t for t in traditions.TRADITIONS if t["wikipedia"] == req.title), None)
            after = (lambda f: (changed(f), starter(f))) if req.auto_build else changed
            slug = traditions.create(root, t["id"]) if t else discover.create_person(root, req.title, llm=llm, on_done=after)[0]
            if t and req.auto_build:
                starter(root / slug)
        except Exception as e:
            raise HTTPException(502, f"Couldn't set up {req.title}: {e}")
        changed(root / slug)
        return {"slug": slug}

    @app.post("/api/t/{slug}/language")
    def set_language(slug: str, req: Language):
        """Which language answers come in. Live conversations switch from their next answer."""
        if req.language not in LANGUAGES:
            raise HTTPException(400, "Unknown language.")
        p = person(slug)
        with discover.editing(p.folder) as cfg:
            cfg["answer_language"] = req.language
        for t in p.sessions.values():
            t.language = req.language
        return {"language": req.language}

    @app.post("/api/fictional")
    def add_fictional(req: Fictional):
        """A fictional character: no sources and no map, only Just for fun."""
        name, source = req.name.strip()[:80], req.source.strip()[:120]
        if not name:
            raise HTTPException(400, "Give the character a name.")
        base = discover.slugify(name) or "character"
        slug, n = base, 2
        while (root / slug).exists():
            slug, n = f"{base}-{n}", n + 1
        (root / slug).mkdir(parents=True)
        cfg = {"name": name, "fictional": {"from": source}, "sources": [], "candidates": [],
               "profile": {"title": name, "description": f"Fictional character{f', {source}' if source else ''}"}}
        write_atomic(root / slug / "config.json", json.dumps(cfg, indent=2, ensure_ascii=False))
        changed(root / slug)
        return {"slug": slug}

    def starter(folder: Path) -> None:
        """A first build for someone just added in onboarding, once their sources are in."""
        cfg = discover.load_cfg(folder)
        job = read_job(folder) or {}
        if (folder / "map.json").exists() or job.get("state") in ("queued", "running") or \
                not any(c.get("selected", True) and c.get("status") != "failed" for c in cfg.get("candidates", [])):
            return
        builder.submit(folder, STARTER)

    @app.get("/api/onboarding")
    def onboarding():
        """Show the first-run intro to a new owner: nobody in the library and never finished it.
        People who already have a library never see it (and are marked as done)."""
        from . import updater
        if guest:
            return {"show": False, "guest": True}
        s = updater.settings()
        if s.get("onboarded") is None and people(root):
            updater.save_setting("onboarded", True)
            return {"show": False}
        return {"show": not s.get("onboarded")}

    @app.post("/api/onboarding")
    def onboarding_done(req: Onboarding):
        from . import updater
        if not guest:
            updater.save_setting("onboarded", req.done)
        return {"show": not req.done}

    SUGGESTED = ["Marcus Aurelius", "Seneca the Younger", "Paul Graham (programmer)", "Charlie Munger",
                 "Richard Feynman", "Benjamin Franklin", "Epictetus", "Ralph Waldo Emerson"]
    sugg_path = CACHE / "suggestions.json"

    @app.get("/api/suggestions")
    def suggestions():
        """A starter shelf of people worth adding, with portraits; fetched once, then cached."""
        if sugg_path.exists():
            return json.loads(sugg_path.read_text(encoding="utf-8"))
        from concurrent.futures import ThreadPoolExecutor

        def one(t):
            try:
                p = discover.profile(t)
                return {"title": p["title"], "description": p["description"], "image": p["image"]}
            except Exception:
                return None
        with ThreadPoolExecutor(8) as pool:
            out = [x for x in pool.map(one, SUGGESTED) if x]
        if out:
            sugg_path.parent.mkdir(parents=True, exist_ok=True)
            sugg_path.write_text(json.dumps(out), encoding="utf-8")
        return out

    @app.get("/api/traditions")
    def list_traditions():
        """The sacred-texts shelf. Portraits come from Wikipedia once, then from the cache."""
        images = json.loads(trad_path.read_text(encoding="utf-8")) if trad_path.exists() else {}
        if not images:
            from concurrent.futures import ThreadPoolExecutor

            def img(t):
                try:
                    return t["id"], discover.profile(t["wikipedia"]).get("image", "")
                except Exception:
                    return t["id"], None
            with ThreadPoolExecutor(5) as pool:
                images = {k: v for k, v in pool.map(img, traditions.ALL) if v is not None}
            if images:
                trad_path.parent.mkdir(parents=True, exist_ok=True)
                trad_path.write_text(json.dumps(images), encoding="utf-8")
        have = {}
        for p in people(root):
            tid = (json.loads((p / "config.json").read_text(encoding="utf-8")).get("tradition") or {}).get("id")
            if tid:
                have[tid] = p.name
        return [{**traditions.card(t, images.get(t["id"]) or images.get(t.get("base", ""), "")), "slug": have.get(t["id"])}
                for t in traditions.ALL]

    @app.post("/api/traditions")
    def add_tradition(req: Tradition):
        if req.id not in traditions.BY_ID:
            raise HTTPException(404, "Unknown text")
        slug = traditions.create(root, req.id)
        changed(root / slug)
        return {"slug": slug}

    # ---------- councils: several people, one question ----------

    councils = council.Store(root)
    council_sessions: dict[str, tuple[str, council.Session]] = {}

    def voice_name(slug: str) -> str:
        """How a member is named in a council: "Krishna", but "The Quran" (see traditions.py)."""
        cfg = person(slug).cfg
        lens = (cfg.get("tradition") or {}).get("lens", "")
        return lens[0].upper() + lens[1:] if lens.startswith("the ") else cfg["name"]

    def council_out(c: dict) -> dict:
        members = [m for m in c["members"] if (root / m / "config.json").exists()]
        return {**c, "members": [{**summary(root / m), "voice": voice_name(m)} for m in members]}

    def council_or_404(cid: str) -> dict:
        c = councils.get(cid)
        if not c:
            raise HTTPException(404, "No such council")
        return c

    def checked(members: list[str]) -> list[str]:
        try:
            members = council.check_members(members)
        except ValueError as e:
            raise HTTPException(400, str(e))
        for m in members:
            if not (root / m / "map.json").exists():
                raise HTTPException(400, f"{person(m).cfg['name']} has no map yet. Build one first.")
        return members

    @app.get("/api/councils")
    def list_councils():
        return [council_out(c) for c in councils.all()]

    @app.post("/api/councils")
    def create_council(req: CouncilIn):
        members = checked(req.members or [])
        voices = [voice_name(m) for m in members]
        name = req.name.strip() or " & ".join([voices[0]] + [re.sub(r"^The ", "the ", v) for v in voices[1:]])
        return council_out(councils.create(name, members))

    @app.get("/api/councils/{cid}")
    def get_council(cid: str):
        return council_out(council_or_404(cid))

    @app.patch("/api/councils/{cid}")
    def edit_council(cid: str, req: CouncilIn):
        council_or_404(cid)
        members = checked(req.members) if req.members is not None else None
        for sid in [s for s, (c, _) in council_sessions.items() if c == cid and members is not None]:
            council_sessions.pop(sid)  # a new line-up starts a new conversation
        return council_out(councils.update(cid, name=req.name.strip() or None, members=members))

    @app.delete("/api/councils/{cid}")
    def delete_council(cid: str):
        councils.delete(cid)
        for c in council_chats.list(council=cid):
            council_chats.delete(c["id"])
        return {"ok": True}

    council_chats = chats.Store(root / "council_chats")

    def council_session(cid: str, sid: str | None, new: bool = False) -> tuple[str, council.Session]:
        if sid in council_sessions and council_sessions[sid][0] == cid:
            return sid, council_sessions[sid][1]
        c = council_or_404(cid)
        saved = council_chats.get(sid) if sid and not guest else None
        if saved and (saved.get("council") != cid or saved.get("members") != c["members"]):
            saved = None  # the line-up changed since: that conversation can't continue
        if not saved and not new:
            raise HTTPException(409, "That conversation has ended. Ask the council again.")
        members = []
        for m in checked(c["members"]):
            p = person(m)
            members.append((m, voice_name(m), p.thinker(llm)))
        while len(council_sessions) >= MAX_SESSIONS:
            council_sessions.pop(next(iter(council_sessions)))
        s = council.Session(llm, members)
        if saved:  # rebuilt after a restart: every member gets its own side of the conversation
            s.turns = saved["turns"]
            for slug, _, t in members:
                chats.restore(t, [{"question": x["question"], "reply": x["answers"].get(slug, {})} for x in s.turns])
        else:
            sid = uuid.uuid4().hex
        council_sessions[sid] = (cid, s)
        return sid, s

    def keep_council(cid: str, sid: str, s: council.Session) -> None:
        if guest or not s.turns:
            return
        c = council_chats.get(sid) or {"id": sid, "council": cid, "created": time.time(),
                                       "title": chats.title_of(s.turns[0]["question"]),
                                       "members": council_or_404(cid)["members"]}
        c["turns"] = s.turns
        council_chats.put(c)

    @app.get("/api/councils/{cid}/chats")
    def list_council_chats(cid: str):
        return [] if guest else council_chats.list(council=cid)

    @app.get("/api/councils/{cid}/chats/{sid}")
    def get_council_chat(cid: str, sid: str):
        c = None if guest else council_chats.get(sid)
        if not c or c.get("council") != cid:
            raise HTTPException(404, "That conversation isn't saved.")
        return c

    @app.delete("/api/councils/{cid}/chats/{sid}")
    def delete_council_chat(cid: str, sid: str):
        if not guest:
            council_chats.delete(sid)
        council_sessions.pop(sid, None)
        return {"ok": True}

    def council_call(fn):
        try:
            return fn()
        except LLMError as e:
            raise HTTPException(503, str(e))
        except ValueError as e:
            raise HTTPException(400, str(e))

    @app.post("/api/councils/{cid}/ask")
    def council_ask(cid: str, req: CouncilTurn):
        if not req.message.strip():
            raise HTTPException(400, "Ask a question.")
        sid, s = council_session(cid, req.session, new=True)
        answers = council_call(lambda: s.ask(req.message.strip()[:4000]))
        keep_council(cid, sid, s)
        return {"session": sid, "answers": answers}

    @app.post("/api/councils/{cid}/respond")
    def council_respond(cid: str, req: CouncilTurn):
        sid, s = council_session(cid, req.session)
        replies = council_call(s.respond)
        keep_council(cid, sid, s)
        return {"session": sid, "replies": replies, "round": len(s.turns[-1]["rounds"]),
                "max_rounds": council.MAX_ROUNDS}

    @app.post("/api/councils/{cid}/summary")
    def council_summary(cid: str, req: CouncilTurn):
        sid, s = council_session(cid, req.session)
        out = council_call(s.summarize)
        keep_council(cid, sid, s)
        return {"session": sid, **out}

    # ---------- one person ----------

    def info_for(slug: str | None) -> dict:
        p = person(slug)
        cfg = p.cfg
        s = summary(p.folder)
        built = built_ids(p.folder)
        chunks = p.folder / "chunks.json"
        available = len(json.loads(chunks.read_text(encoding="utf-8"))) if chunks.exists() else None
        selected = sum((c.get("est_passages") or 0) for c in cfg.get("candidates", []) if c.get("selected", True))
        files = [{"id": x["id"], "title": x.get("title") or x["id"], "date": x.get("date", ""),
                  "tier": x.get("tier", 1), "file": x["file"]} for x in cfg.get("sources", [])]
        return {**s, "thinker": cfg["name"], "source_files": files, "voice": cfg.get("voice", "third"), "profile": cfg.get("profile", {}),
                "tradition": cfg.get("tradition"), "fictional": cfg.get("fictional"),
                "answer_language": cfg.get("answer_language", "English"), "languages": LANGUAGES,
                "candidates": cfg.get("candidates", []), "built_passages": len(built),
                "available_passages": available, "selected_passages": selected,
                "starter": STARTER, "estimate": estimate(STARTER), "job": read_job(p.folder),
                "discovery": discover.status(p.folder),
                "follow": cfg.get("follow") or {"on": False}, "signature": cfg.get("signature") or [],
                "living": not (cfg.get("profile") or {}).get("died") and not cfg.get("tradition"),
                "shareable": packs.shareable(p.folder)[0],
                "web_search": not guest and getattr(llm, "backend", None) == "cli"}

    @app.get("/api/t/{slug}")
    def info(slug: str):
        p = person(slug)
        if not guest and discover.needs_web(p.folder, llm):
            discover.start(p.folder, llm, on_done=changed)  # once per person; the Sources page shows progress
        return info_for(slug)

    @app.post("/api/t/{slug}/candidates")
    def pick(slug: str, req: Pick):
        p = person(slug)
        with discover.editing(p.folder) as cfg:
            for c in cfg.get("candidates", []):
                if c["id"] == req.id:
                    c["selected"] = req.selected
        changed(p.folder)
        return info_for(slug)

    @app.post("/api/t/{slug}/links")
    def add_link(slug: str, req: Link):
        p = person(slug)
        try:
            added = discover.add_url(p.folder, req.url)
        except ValueError as e:
            raise HTTPException(400, str(e))
        except Exception as e:
            raise HTTPException(502, f"Couldn't read that link: {e}")
        changed(p.folder)
        return {"added": added, **info_for(slug)}

    @app.post("/api/t/{slug}/files")
    async def add_file(slug: str, file: UploadFile = File(...)):
        p = person(slug)
        try:
            cand = discover.add_file(p.folder, file.filename or "upload.txt", await file.read())
        except ValueError as e:
            raise HTTPException(400, str(e))
        changed(p.folder)
        return {"added": [cand], **info_for(slug)}

    @app.post("/api/t/{slug}/rediscover")
    def rediscover(slug: str):
        p = person(slug)
        cfg = p.cfg
        if cfg.get("tradition") or cfg.get("fictional"):  # scripture has its texts; Wikiquote would add hearsay
            return info_for(slug)
        try:  # refresh the profile too (portrait, website), keeping everything else
            fresh = discover.profile(cfg.get("profile", {}).get("title") or cfg["name"])
            with discover.editing(p.folder) as cfg:
                cfg["profile"] = {**cfg.get("profile", {}), **fresh}
        except Exception:
            pass
        discover.start(p.folder, llm, on_done=changed)  # in the background; the page polls discovery progress
        return info_for(slug)

    @app.post("/api/t/{slug}/build")
    def build(slug: str, req: Build):
        p = person(slug)
        j = read_job(p.folder)
        if j and j.get("state") in ("queued", "running"):
            raise HTTPException(409, "A build for this person is already running.")
        builder.submit(p.folder, req.passages)
        return info_for(slug)

    def session_for(p: Person_, sid: str | None) -> str:
        """The live session for a chat: in memory, else rebuilt from its saved turns (after an app
        restart), else a new one."""
        if sid in p.sessions:
            return sid
        saved = p.chats.get(sid) if sid and not guest else None
        sid = sid if saved else uuid.uuid4().hex
        while len(p.sessions) >= MAX_SESSIONS:
            p.sessions.pop(next(iter(p.sessions)))
        t = p.thinker(llm)
        if saved:
            chats.restore(t, saved["turns"])
        p.sessions[sid] = t
        return sid

    def keep(p: Person_, sid: str, question: str, reply: dict) -> None:
        if not guest:
            chats.add_turn(p.chats, sid, question.strip()[:4000], reply)

    @app.get("/api/t/{slug}/chats")
    def list_chats(slug: str):
        return person(slug).chats.list()

    @app.get("/api/t/{slug}/chats/{cid}")
    def get_chat(slug: str, cid: str):
        c = person(slug).chats.get(cid)
        if not c:
            raise HTTPException(404, "That conversation isn't saved.")
        return c

    @app.delete("/api/t/{slug}/chats/{cid}")
    def delete_chat(slug: str, cid: str):
        p = person(slug)
        p.chats.delete(cid)
        p.sessions.pop(cid, None)
        return {"ok": True}

    @app.post("/api/t/{slug}/follow")
    def set_follow(slug: str, req: Follow):
        p = person(slug)
        with discover.editing(p.folder) as cfg:
            cfg.setdefault("follow", {}).update(on=req.on, auto_build=req.auto_build)
        changed(p.folder)
        return info_for(slug)

    @app.post("/api/t/{slug}/follow/check")
    def follow_now(slug: str):
        p = person(slug)
        if discover.status(p.folder) and discover.status(p.folder)["state"] == "running":
            raise HTTPException(409, "Already looking for sources.")
        threading.Thread(target=lambda: (follow.check(p.folder, llm, builder), changed(p.folder)), daemon=True).start()
        return info_for(slug)

    @app.get("/api/t/{slug}/worldview")
    def get_worldview(slug: str):
        from . import signature
        p = person(slug)
        if "signature" not in p.cfg:  # maps built before signature ideas existed: ask once
            ideas = signature.ideas(llm, p.cfg)
            with discover.editing(p.folder) as cfg:
                cfg["signature"] = ideas
            p.sessions = {}
        try:
            out = worldview.build(p.map, p.cfg, llm, p.embedder(), p.folder / "worldview.json")
        except LLMError as e:
            raise HTTPException(503, str(e))
        return {**out, "evolved": bool(p.cfg.get("evolved"))}

    @app.post("/api/t/{slug}/evolve")
    def evolve_views(slug: str):
        """Compare views across years on a map built before that was part of every build."""
        from .extract import evolve_map
        p = person(slug)
        try:
            n = evolve_map(llm, p.map)
        except LLMError as e:
            raise HTTPException(503, str(e))
        p.save()
        with discover.editing(p.folder) as cfg:
            cfg["evolved"] = True
        changed(p.folder)
        return {"changes": n}

    @app.post("/api/t/{slug}/critique")
    def critique(slug: str, req: Critique):
        if len(req.draft.strip()) < 40:
            raise HTTPException(400, "Paste a longer draft: a few sentences at least.")
        try:
            return person(slug).thinker(llm).critique(req.draft, req.about)
        except LLMError as e:
            raise HTTPException(503, str(e))

    @app.post("/api/t/{slug}/ask/stream")
    def ask_stream(slug: str, req: Ask):
        """The answer as it is written (server-sent events): {"phase"}, {"text"} with the draft so
        far, then {"done": reply} once it is verified, or {"error"}."""
        import queue

        p = person(slug)
        sid = session_for(p, req.session)
        q: queue.Queue = queue.Queue()

        def run():
            try:
                r = p.sessions[sid].ask(req.message.strip()[:4000], on_text=lambda t: q.put({"text": t}),
                                        on_phase=lambda ph: q.put({"phase": ph}))
                keep(p, sid, req.message, r)
                q.put({"done": {"session": sid, **r}})
            except Exception as e:
                q.put({"error": str(e)})
        threading.Thread(target=run, daemon=True).start()

        def events():
            last = ""
            while True:
                ev = q.get()
                if "text" in ev:  # coalesce: only the newest draft matters
                    while not q.empty() and "text" in q.queue[0]:
                        ev = q.get()
                    if ev["text"] == last:
                        continue
                    last = ev["text"]
                yield f"data: {json.dumps(ev, ensure_ascii=False)}\n\n"
                if "done" in ev or "error" in ev:
                    return
        return StreamingResponse(events(), media_type="text/event-stream",
                                 headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"})

    # ---------- just for fun: playful, not grounded (play.py) ----------

    plays: dict[tuple[str, str], Play] = {}

    @app.post("/api/t/{slug}/play/stream")
    def play_stream(slug: str, req: Ask):
        """Like /ask/stream: {"text"} as it is written, then {"done": {"session", "answer"}}."""
        import queue

        p = person(slug)
        sid = req.session if (slug, req.session) in plays else uuid.uuid4().hex[:16]
        if (slug, sid) not in plays:
            if len(plays) > MAX_SESSIONS:
                plays.pop(next(iter(plays)))
            plays[(slug, sid)] = Play(llm, p.cfg, p.cfg.get("signature"))
        q: queue.Queue = queue.Queue()

        def run():
            try:
                r = plays[(slug, sid)].ask(req.message.strip()[:2000], on_text=lambda t: q.put({"text": t}))
                q.put({"done": {"session": sid, **r}})
            except Exception as e:
                q.put({"error": str(e)})
        threading.Thread(target=run, daemon=True).start()

        def events():
            while True:
                ev = q.get()
                if "text" in ev:
                    while not q.empty() and "text" in q.queue[0]:
                        ev = q.get()
                yield f"data: {json.dumps(ev, ensure_ascii=False)}\n\n"
                if "done" in ev or "error" in ev:
                    return
        return StreamingResponse(events(), media_type="text/event-stream",
                                 headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"})

    @app.get("/api/t/{slug}/pack")
    def download_pack(slug: str):
        p = person(slug)
        try:
            data = packs.export(p.folder)
        except ValueError as e:
            raise HTTPException(400, str(e))
        return Response(data, media_type="application/zip",
                        headers={"Content-Disposition": f'attachment; filename="{slug}.aristotle.zip"'})

    # ---------- map packs ----------

    @app.get("/api/packs")
    def list_packs():
        have = {p.name for p in people(root)}
        return [{**x, "installed": x["slug"] in have} for x in packs.catalog()]

    @app.post("/api/packs/{slug}")
    def install_pack(slug: str):
        try:
            got = packs.install(root, packs.fetch(slug))
        except ValueError as e:
            raise HTTPException(400, str(e))
        except Exception as e:
            raise HTTPException(502, f"Couldn't download that map: {e}")
        changed(root / got)
        return {"slug": got}

    @app.post("/api/packs")
    async def upload_pack(file: UploadFile = File(...)):
        try:
            got = packs.install(root, await file.read())
        except (ValueError, Exception) as e:
            raise HTTPException(400, str(e) if isinstance(e, ValueError) else "That isn't an Aristotle map pack.")
        changed(root / got)
        return {"slug": got}

    # ---------- decision journal ----------

    @app.get("/api/journal")
    def journal_list():
        return {"entries": journal.all()}

    @app.post("/api/journal")
    def journal_add(req: JournalIn):
        p = person(req.slug)
        return journal.add(req.slug, p.cfg["name"], req.question, req.answer, req.cited, req.plan, req.follow_up)

    @app.post("/api/journal/{eid}")
    def journal_edit(eid: str, req: JournalEdit):
        try:
            return journal.update(eid, req.plan, req.follow_up, req.outcome)
        except KeyError:
            raise HTTPException(404, "no such entry")
        except ValueError as e:
            raise HTTPException(400, str(e))

    @app.delete("/api/journal/{eid}")
    def journal_delete(eid: str):
        journal.delete(eid)
        return {"ok": True}

    @app.get("/api/t/{slug}/job")
    def job(slug: str):
        return read_job(person(slug).folder) or {"state": "none"}

    @app.delete("/api/t/{slug}")
    def remove(slug: str):
        """Delete a person: their folder goes to the Trash (Mac) or Recycle Bin (Windows), so a
        slip can be undone, and they leave every council; a council left with fewer than two goes too."""
        import shutil
        p = person(slug)
        if guest and (p.folder / "map.json").exists():  # guests may only clear away drafts
            raise HTTPException(403, "Only the owner can delete a built map.")
        job = read_job(p.folder) or {}
        if job.get("state") in ("queued", "running"):
            raise HTTPException(409, "Their map is building. Wait for it to finish, then delete.")
        dropped, kept = [], []
        for c in councils.all():
            if slug in c["members"]:
                rest = [m for m in c["members"] if m != slug]
                if len(rest) < 2:
                    councils.delete(c["id"])
                    dropped.append(c["name"])
                else:
                    councils.update(c["id"], members=rest)
                    kept.append(c["name"])
                for sid in [s for s, (cid, _) in council_sessions.items() if cid == c["id"]]:
                    council_sessions.pop(sid)
        from .system import to_trash
        if guest or not to_trash(p.folder):  # the Trash on a Mac, the Recycle Bin on Windows
            shutil.rmtree(p.folder)
        loaded.pop(slug, None)
        changed(p.folder)
        return {"ok": True, "councils_deleted": dropped, "councils_changed": kept}

    # ---------- asking, the map, blind rating (also served unprefixed for the default person) ----------

    def routes(prefix: str, get_slug):
        @app.post(prefix + "/ask")
        def ask(req: Ask, slug: str = None):
            p = person(get_slug(slug))
            sid = session_for(p, req.session)
            try:
                reply = p.sessions[sid].ask(req.message.strip()[:4000])
            except LLMError as e:
                raise HTTPException(503, str(e))
            keep(p, sid, req.message, reply)
            return {"session": sid, **reply}

        @app.get(prefix + "/map")
        def get_map(slug: str = None):
            m = person(get_slug(slug)).map
            return {"thinker": m.thinker,
                    "nodes": [{"id": n.id, "kind": n.kind, "statement": n.statement, "review": n.review,
                               "note": n.note, "first_seen": n.first_seen, "last_seen": n.last_seen,
                               "tier": n.best_tier, "sources": [s.__dict__ for s in n.sources]}
                              for n in m.nodes],
                    "edges": [e.__dict__ for e in m.edges]}

        @app.post(prefix + "/node/{node_id}")
        def review(node_id: str, req: Review, slug: str = None):
            p = person(get_slug(slug))
            n = p.map.node(node_id)
            if not n:
                raise HTTPException(404, "no such node")
            if req.review is not None:
                if req.review not in REVIEW_STATES:
                    raise HTTPException(400, f"review must be one of {REVIEW_STATES}")
                n.review = req.review
            if req.statement:
                n.statement = req.statement.strip()  # quotes stay verbatim; only the gloss is editable
            if req.note is not None:
                n.note = req.note
            p.save()
            return {"ok": True}

        @app.post(prefix + "/merge")
        def merge(req: Merge, slug: str = None):
            p = person(get_slug(slug))
            m = p.map
            keep, drop = m.node(req.keep), m.node(req.drop)
            if not keep or not drop or keep is drop:
                raise HTTPException(400, "need two different existing nodes")
            keep.sources.extend(drop.sources)
            for e in m.edges:
                e.src = keep.id if e.src == drop.id else e.src
                e.dst = keep.id if e.dst == drop.id else e.dst
            m.edges = [e for e in m.edges if e.src != e.dst]
            m.nodes = [n for n in m.nodes if n.id != drop.id]
            p.save()
            return {"ok": True}

        @app.get(prefix + "/blind")
        def blind(slug: str = None):
            folder = person(get_slug(slug)).folder
            path = folder / "eval" / "blind.json"
            if not path.exists():
                raise HTTPException(404, "run `python cli.py eval <thinker> run blind` first")
            rpath = folder / "eval" / "ratings.json"
            return {"pairs": json.loads(path.read_text(encoding="utf-8")),
                    "ratings": json.loads(rpath.read_text(encoding="utf-8")) if rpath.exists() else {}}

        @app.post(prefix + "/rate")
        def rate(req: Rate, slug: str = None):
            if req.choice not in ("A", "B", "tie"):
                raise HTTPException(400, "choice must be A, B or tie")
            rpath = person(get_slug(slug)).folder / "eval" / "ratings.json"
            ratings = json.loads(rpath.read_text(encoding="utf-8")) if rpath.exists() else {}
            ratings[req.id] = req.choice
            rpath.write_text(json.dumps(ratings, indent=2), encoding="utf-8")
            return {"ok": True, "rated": len(ratings)}

    routes("/api/t/{slug}", lambda slug: slug)
    routes("/api", lambda slug: None)

    @app.get("/api/info")
    def legacy_info():
        return info_for(None)

    return app


LOGIN = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Aristotle</title>
<meta name="color-scheme" content="light dark">
<link rel="stylesheet" href="/static/css/tokens.css"><link rel="stylesheet" href="/static/css/app.css">
</head><body class="login"><form method="post" action="/login" class="login-card">
<span class="mark" aria-hidden="true">A</span><h1>Aristotle</h1>
<p>Reason through a decision with a thinker's own words. Enter the password you were given.</p>
{{wrong}}<input class="input" type="password" name="password" placeholder="Password" aria-label="Password" autofocus required>
<button class="btn primary">Continue</button></form></body></html>"""
