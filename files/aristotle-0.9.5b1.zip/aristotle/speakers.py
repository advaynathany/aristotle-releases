"""Who is speaking: transcripts without speaker labels (YouTube captions, interview pages that
don't mark turns) get the other voices set aside before extraction, so an interviewer's question
or a co-panelist's view never becomes the person's belief.

One fast call per ~10k characters: the model gets numbered paragraphs and names the ones spoken
by someone else. Those become INTERVIEWER: lines (context only, never quotable). Files are
rewritten once and marked "speakers: labeled" in their front matter.
"""
from __future__ import annotations

from pathlib import Path

from .ingest import INTERVIEWER
from .llm import parse_json

SYSTEM = """You get numbered paragraphs from a transcript of a talk, interview, podcast or panel \
featuring {name}. Captions have no speaker labels, so work it out from content and flow: \
questions and introductions from a host or interviewer, other guests' answers, audience \
questions, a moderator's remarks. Paragraphs where {name} is speaking are theirs. When a \
paragraph mixes voices, count it as someone else's only if most of it is. When you can't tell, \
it is {name}'s. Return JSON only: {{"others": [paragraph numbers spoken by someone else]}}"""

BATCH = 10_000


def label(llm, paras: list[str], name: str) -> list[str]:
    """Paragraphs with other speakers' lines prefixed INTERVIEWER:."""
    out = list(paras)
    start = 0
    while start < len(paras):
        size, end = 0, start
        while end < len(paras) and (size < BATCH or end == start):
            size += len(paras[end])
            end += 1
        listing = "\n\n".join(f"[{i + 1}] {paras[i][:1500]}" for i in range(start, end))
        try:
            got = parse_json(llm.complete(SYSTEM.format(name=name), listing, tier="fast"))
            others = {int(x) - 1 for x in (got.get("others") or [])} if isinstance(got, dict) else set()
        except (ValueError, TypeError):
            others = set()  # an unreadable reply leaves this batch as theirs; LLMError propagates
        for i in others:
            if start <= i < end and not out[i].startswith(INTERVIEWER):
                out[i] = INTERVIEWER + out[i]
        start = end
    return out


def label_file(llm, path: Path, name: str) -> int:
    """Rewrite a .md source with other speakers set aside. Returns how many paragraphs moved."""
    path = Path(path)
    raw = path.read_text(encoding="utf-8", errors="replace")
    head, body = raw.split("\n---\n", 1) if "\n---\n" in raw[:2000] else ("", raw)
    if "speakers: labeled" in head:
        return 0
    paras = [p for p in body.split("\n\n") if p.strip()]
    new = label(llm, paras, name)
    moved = sum(a != b for a, b in zip(paras, new))
    head = (head + "\n" if head else "") + "speakers: labeled"
    path.write_text(head + "\n---\n" + "\n\n".join(new), encoding="utf-8")
    return moved
