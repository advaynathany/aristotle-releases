"""Bug reports and suggestions from inside the app, forwarded to the maker.

Reports go to a Google Form (responses land in a Google Sheet, and Forms can email each one), set
in feedback_target.json next to this file: {"form": "<form URL>", "fields": {"type": "entry.1",
"message": "entry.2", "email": "entry.3", "details": "entry.4"}}. Nothing secret ships in the app:
a form only accepts responses. If sending fails (offline, no form set), the report waits in
<home>/feedback-outbox.jsonl and goes out with the next one.
"""
from __future__ import annotations

import json
import platform
import re
import threading
import time
from pathlib import Path

import httpx

from . import __version__
from .paths import HOME

TARGET = Path(__file__).resolve().parent / "feedback_target.json"
OUTBOX = HOME / "feedback-outbox.jsonl"
_lock = threading.Lock()


def _target() -> dict | None:
    try:
        t = json.loads(TARGET.read_text(encoding="utf-8"))
        return t if t.get("form") and t.get("fields") else None
    except (OSError, json.JSONDecodeError):
        return None


def details(page: str = "") -> str:
    mac = platform.mac_ver()[0]
    lines = [f"Aristotle {__version__}", f"{'macOS ' + mac if mac else platform.platform()} ({platform.machine()})"]
    if page:
        lines.append(f"Page: {page}")
    log = HOME / "aristotle.log"
    if log.exists():
        tail = log.read_text(errors="replace", encoding="utf-8").splitlines()[-25:]
        if tail:
            lines += ["", "Recent log:", *tail]
    return "\n".join(lines)[:6000]


def _post(target: dict, report: dict) -> bool:
    url = re.sub(r"/(viewform|edit)(\?.*)?$", "/formResponse", target["form"].rstrip("/"))
    if not url.endswith("/formResponse"):
        url += "/formResponse"
    data = {entry: report.get(key, "") for key, entry in target["fields"].items()}
    try:
        r = httpx.post(url, data=data, timeout=15, follow_redirects=True)
        return r.status_code < 400
    except httpx.HTTPError:
        return False


def send(kind: str, message: str, email: str = "", page: str = "", include_details: bool = True) -> bool:
    """True if it went out now; False if it was queued for later."""
    report = {"type": "Bug" if kind == "bug" else "Idea", "message": message.strip()[:5000],
              "email": email.strip()[:200], "details": details(page) if include_details else f"Aristotle {__version__}",
              "time": time.strftime("%Y-%m-%d %H:%M:%S")}
    with _lock:
        queued = []
        if OUTBOX.exists():
            queued = [json.loads(line) for line in OUTBOX.read_text(encoding="utf-8").splitlines() if line.strip()]
        target = _target()
        left, sent_now = [], False
        for r in queued + [report]:
            ok = bool(target) and _post(target, r)
            if r is report:
                sent_now = ok
            if not ok:
                left.append(r)
        OUTBOX.parent.mkdir(parents=True, exist_ok=True)
        OUTBOX.write_text("".join(json.dumps(r) + "\n" for r in left), encoding="utf-8")
    return sent_now
