"""LLM wrapper. The rest of the pipeline only calls `complete`.

Three backends:
  - "cli" (default): shells out to `claude -p`, which runs on your claude.ai plan. No API key, no
    per-token bill; calls count against the plan's usage limits instead. For your own use only.
  - "api": the Anthropic SDK, used when ARISTOTLE_BACKEND=api (needs ANTHROPIC_API_KEY).
  - "openai": any OpenAI-compatible chat endpoint (ARISTOTLE_LLM_URL, ARISTOTLE_LLM_KEY). The
    hosted guest copy uses it with Gemini's free tier, so other people's questions cost nothing
    and never touch your Claude plan. In the app it is "Gemini (free)", with the user's own key.
  - "codex": shells out to `codex exec`, which runs on the user's ChatGPT plan.

The app's Model settings switch backend and model at runtime (`configure`, PROVIDERS).

Two tiers: "strong" for extraction and final answers, "fast" for routing (themes, linking, judging
cheap things). Every reply is cached on disk keyed by (model, system, prompt), so rebuilding the
map or re-running an eval only pays for what changed.
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import os
import re
import subprocess
import tempfile
import threading
from pathlib import Path

from .paths import CACHE
from .system import WINDOWS, quiet

DEFAULTS = {
    "cli": ("claude-opus-5-5", "claude-haiku-5-5"),
    "api": ("claude-opus-5-5", "claude-haiku-5-5"),
    # On the free tier (Oct 2026) Pro models have no quota and the full Flash models mostly time
    # out under load; 3.5 Flash-Lite answers in ~5s with every quote verified.
    "openai": ("gemini-3.5-flash-lite", "gemini-3.5-flash-lite"),
    "codex": ("", ""),  # "": whatever model the user's Codex is set to
}
# What the Model settings offer, per backend: (model id, label, note). The first is the default.
PROVIDERS = {
    "cli": {"name": "Claude", "models": [
        ("claude-opus-5-5", "Opus 5.5", "Best answers. The default."),
        ("claude-fable-5-1", "Fable 5.1", "The most capable. Uses the most plan."),
        ("claude-sonnet-5-5", "Sonnet 5.5", "Faster, uses less plan."),
        ("claude-haiku-5-5", "Haiku 5.5", "Fastest, lightest."),
    ]},
    "openai": {"name": "Gemini (free)", "models": [
        ("gemini-3.5-flash-lite", "3.5 Flash-Lite", "Answers in seconds on the free tier."),
        ("gemini-3.5-flash", "3.5 Flash", "Better answers, but often slow or busy on the free tier."),
    ]},
    "codex": {"name": "Codex", "experimental": True, "models": [
        ("", "Codex default", "Whatever model your Codex is set to."),
        ("gpt-5.5", "GPT-5.5", ""),
        ("gpt-5.5-mini", "GPT-5.5 mini", "Faster, uses less of your plan."),
    ]},
}
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/openai"
CACHE_DIR = Path(os.environ.get("ARISTOTLE_CACHE", CACHE / "llm"))


class LLMError(RuntimeError):
    pass


@contextlib.contextmanager
def _system_arg(system: str):
    """--system-prompt, or on Windows --system-prompt-file: a Windows command line stops at 32K
    characters, and answer prompts carry whole sets of beliefs."""
    if not WINDOWS:
        yield ["--system-prompt", system]
        return
    fd, path = tempfile.mkstemp(suffix=".txt", prefix="aristotle-system-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(system)
        yield ["--system-prompt-file", path]
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def claude_bin() -> str:
    """The Claude Code CLI. Apps started from a dock or launcher get a bare PATH, so look in the
    places its installers use too."""
    import shutil

    found = shutil.which("claude")
    if found:
        return found
    if WINDOWS:  # the native installer, then npm (claude.exe beats claude.cmd: cmd.exe mangles long args)
        places = ["~/.local/bin/claude.exe", os.path.expandvars("%APPDATA%/npm/claude.cmd"),
                  os.path.expandvars("%LOCALAPPDATA%/Programs/claude/claude.exe")]
    else:
        places = ["~/.local/bin/claude", "~/.claude/local/claude", "~/.npm-global/bin/claude",
                  "/opt/homebrew/bin/claude", "/usr/local/bin/claude"]
    for p in places:
        try:  # a folder we can't read raises PermissionError instead of answering False
            if Path(p).expanduser().is_file() and os.access(Path(p).expanduser(), os.X_OK):
                return str(Path(p).expanduser())
        except OSError:
            continue
    if WINDOWS:
        return "claude"
    try:  # npm, nvm and others set PATH in the login shell, which a launched app doesn't read
        shell = os.environ.get("SHELL") or "/bin/zsh"
        out = subprocess.run([shell, "-lic", "command -v claude"], capture_output=True, text=True, timeout=10)
        found = out.stdout.strip().splitlines()[-1] if out.stdout.strip() else ""
        if found and Path(found).exists():
            return found
    except (OSError, subprocess.TimeoutExpired):
        pass
    return "claude"


def claude_status() -> dict:
    """Is the Claude CLI installed and signed in? Uses no plan usage."""
    exe = claude_bin()
    try:
        p = subprocess.run([exe, "auth", "status", "--json"], capture_output=True, text=True, timeout=20, **quiet())
        info = json.loads(p.stdout or "{}")
    except FileNotFoundError:
        return {"installed": False, "logged_in": False}
    except (subprocess.TimeoutExpired, json.JSONDecodeError):
        return {"installed": True, "logged_in": False}
    except OSError:  # unreadable, or mid-update (npm swaps the binary in place): ask again later
        return {"installed": True, "logged_in": False}
    return {"installed": True, "logged_in": bool(info.get("loggedIn")),
            "plan": info.get("subscriptionType") or info.get("authMethod") or "", "email": info.get("email", "")}


def codex_bin() -> str:
    import shutil

    found = shutil.which("codex")
    if found:
        return found
    if WINDOWS:
        places = [os.path.expandvars("%APPDATA%/npm/codex.cmd"), "~/.local/bin/codex.exe"]
    else:
        places = ["/opt/homebrew/bin/codex", "/usr/local/bin/codex", "~/.local/bin/codex", "~/.npm-global/bin/codex"]
    for p in places:
        if Path(p).expanduser().exists():
            return str(Path(p).expanduser())
    if not WINDOWS:
        try:
            shell = os.environ.get("SHELL") or "/bin/zsh"
            out = subprocess.run([shell, "-lic", "command -v codex"], capture_output=True, text=True, timeout=10)
            found = out.stdout.strip().splitlines()[-1] if out.stdout.strip() else ""
            if found and Path(found).exists():
                return found
        except (OSError, subprocess.TimeoutExpired):
            pass
    return "codex"


def codex_status() -> dict:
    """Is the Codex CLI installed and signed in? `codex login status` exits 0 when it is."""
    try:
        p = subprocess.run([codex_bin(), "login", "status"], capture_output=True, text=True, timeout=20, **quiet())
    except FileNotFoundError:
        return {"installed": False, "logged_in": False}
    except subprocess.TimeoutExpired:
        return {"installed": True, "logged_in": False}
    said = (p.stdout + p.stderr).strip()
    return {"installed": True, "logged_in": p.returncode == 0 and "not logged in" not in said.lower(),
            "plan": "ChatGPT" if "chatgpt" in said.lower() else "API key" if "api key" in said.lower() else ""}


def gemini_check(key: str) -> str | None:
    """None if the key works; otherwise what went wrong. Listing models is free."""
    import httpx

    try:
        r = httpx.get(GEMINI_URL + "/models", headers={"Authorization": f"Bearer {key}"}, timeout=15)
    except httpx.HTTPError:
        return "Couldn't reach Google. Check your internet connection."
    if r.status_code == 200:
        return None
    return "Google didn't accept that key." if r.status_code in (400, 401, 403) else f"Google said {r.status_code}."


class LLM:
    def __init__(self, backend: str | None = None, cache: bool = True):
        self.cache = cache
        self.calls = 0  # uncached calls made, for reporting
        self._lock = threading.Lock()
        self._cwd = tempfile.mkdtemp(prefix="aristotle-llm-")  # no CLAUDE.md gets picked up
        self.configure(backend or os.environ.get("ARISTOTLE_BACKEND", "cli"),
                       os.environ.get("ARISTOTLE_MODEL"), fast=os.environ.get("ARISTOTLE_FAST_MODEL"))

    def configure(self, backend: str, model: str | None = None, key: str | None = None,
                  fast: str | None = None) -> None:
        """Switch backend and model in place: the server, builder and follower all hold this one
        object, so a change in Model settings reaches every later call. The cache is keyed by
        model, so switching back finds earlier replies."""
        if backend not in DEFAULTS:
            raise ValueError(f"unknown backend {backend!r}")
        strong, fast_default = DEFAULTS[backend]
        strong = strong if model is None else model
        fast = fast or fast_default or strong  # routing calls stay on the cheap model; Codex reuses its own
        self.backend = backend
        self.models = {"strong": strong, "fast": fast}
        if backend == "api":
            import anthropic  # imported lazily so tests and the cli backend run without it

            self.client = anthropic.Anthropic()
        elif backend == "openai":
            import httpx

            self.url = os.environ.get("ARISTOTLE_LLM_URL", GEMINI_URL).rstrip("/") + "/chat/completions"
            self.key = key or os.environ.get("ARISTOTLE_LLM_KEY") or os.environ.get("GEMINI_API_KEY") or ""
            self.http = httpx.Client(timeout=90)
            # Gemini Flash at its default reasoning took over 5 minutes on one answer; "low" took
            # 10s with the same citations. Set ARISTOTLE_REASONING="" for providers that reject it.
            self.reasoning = os.environ.get("ARISTOTLE_REASONING", "low")

    def complete(self, system: str, user: str, history: list[dict] | None = None,
                 max_tokens: int = 8000, tier: str = "strong", tools: list[str] | None = None) -> str:
        """`tools` (claude CLI only) lets the model use Claude Code tools, e.g. WebSearch and
        WebFetch for source discovery. Other backends refuse, so callers can skip that step."""
        model = self.models[tier]
        prompt = _flatten(history, user)
        if tools and self.backend != "cli":
            raise LLMError("tools need the claude CLI backend")
        key = hashlib.sha256(json.dumps([model, system, prompt] + ([tools] if tools else [])).encode()).hexdigest()
        path = CACHE_DIR / key[:2] / f"{key}.json"
        if self.cache and path.exists():
            return json.loads(path.read_text(encoding="utf-8"))["text"]
        if self.backend == "cli":
            text = self._cli(model, system, prompt, tier, tools)
        elif self.backend == "openai":
            text = self._openai(model, system, history, user)
        elif self.backend == "codex":
            text = self._codex(model, system, prompt, tier)
        else:
            text = self._api(model, system, history, user, max_tokens, tier)
        with self._lock:
            self.calls += 1
        if self.cache:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps({"model": model, "text": text}), encoding="utf-8")
        return text

    def stream(self, system: str, user: str, on_text, history: list[dict] | None = None,
               tier: str = "strong") -> str:
        """Like `complete`, but calls on_text(text_so_far) as the reply is written. Cached replies
        and backends without streaming deliver it in one piece. Returns the full text."""
        model = self.models[tier]
        prompt = _flatten(history, user)
        key = hashlib.sha256(json.dumps([model, system, prompt]).encode()).hexdigest()
        path = CACHE_DIR / key[:2] / f"{key}.json"
        if (self.cache and path.exists()) or self.backend not in ("cli", "api"):
            text = self.complete(system, user, history=history, tier=tier)
            on_text(text)
            return text
        text = self._cli_stream(model, system, prompt, tier, on_text) if self.backend == "cli" \
            else self._api_stream(model, system, history, user, tier, on_text)
        with self._lock:
            self.calls += 1
        if self.cache:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps({"model": model, "text": text}), encoding="utf-8")
        return text

    def _cli_stream(self, model: str, system: str, prompt: str, tier: str, on_text) -> str:
        with _system_arg(system) as sys_arg:
            return self._cli_stream_run(model, sys_arg, prompt, tier, on_text)

    def _cli_stream_run(self, model: str, sys_arg: list, prompt: str, tier: str, on_text) -> str:
        cmd = [claude_bin(), "-p", "--model", model, *sys_arg,
               "--tools", "", "--strict-mcp-config", "--setting-sources", "",
               "--no-session-persistence", "--disable-slash-commands",
               "--output-format", "stream-json", "--verbose", "--include-partial-messages",
               "--effort", "low" if tier == "fast" else "medium"]
        p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             text=True, cwd=self._cwd, **quiet())
        p.stdin.write(prompt)
        p.stdin.close()
        so_far, result, err = "", None, ""
        for line in p.stdout:
            try:
                e = json.loads(line)
            except json.JSONDecodeError:
                continue
            if e.get("type") == "stream_event":
                d = (e.get("event") or {}).get("delta") or {}
                if d.get("type") == "text_delta":
                    so_far += d.get("text", "")
                    on_text(so_far)
            elif e.get("type") == "result":
                if e.get("is_error"):
                    err = str(e.get("result") or e.get("api_error_status"))
                else:
                    result = e.get("result", "")
        p.wait(timeout=60)
        if result is None:
            raise LLMError(f"claude -p failed: {err or (p.stderr.read() or '')[-500:]}")
        return result

    def _api_stream(self, model, system, history, user, tier, on_text) -> str:
        messages = list(history or []) + [{"role": "user", "content": user}]
        so_far = ""
        with self.client.messages.stream(
                model=model, max_tokens=8000,
                system=[{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
                output_config={"effort": "low" if tier == "fast" else "medium"}, messages=messages) as st:
            for chunk in st.text_stream:
                so_far += chunk
                on_text(so_far)
        return so_far

    def _cli(self, model: str, system: str, prompt: str, tier: str, tools: list[str] | None = None) -> str:
        with _system_arg(system) as sys_arg:
            return self._cli_run(model, sys_arg, prompt, tier, tools)

    def _cli_run(self, model: str, sys_arg: list, prompt: str, tier: str, tools: list[str] | None) -> str:
        allow = ",".join(tools or [])
        cmd = [claude_bin(), "-p", "--model", model, *sys_arg,
               "--tools", allow, *(["--allowedTools", allow] if allow else []), "--strict-mcp-config", "--setting-sources", "",
               "--no-session-persistence", "--disable-slash-commands",
               "--output-format", "json", "--effort", "low" if tier == "fast" else "medium"]
        last = ""
        for _ in range(3):
            p = subprocess.run(cmd, input=prompt, capture_output=True, text=True,
                               cwd=self._cwd, timeout=600, **quiet())
            try:
                out = json.loads(p.stdout)
            except json.JSONDecodeError:
                last = (p.stderr or p.stdout)[-500:]
                continue
            if not out.get("is_error"):
                return out.get("result", "")
            last = str(out.get("result") or out.get("api_error_status"))
            if "limit" in last.lower():  # plan usage limit: retrying won't help
                break
        raise LLMError(f"claude -p failed: {last}")

    def _api(self, model, system, history, user, max_tokens, tier) -> str:
        messages = list(history or []) + [{"role": "user", "content": user}]
        r = self.client.messages.create(
            model=model, max_tokens=max_tokens,
            system=[{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            output_config={"effort": "low" if tier == "fast" else "medium"},
            messages=messages,
        )
        return "".join(b.text for b in r.content if b.type == "text")


    def _codex(self, model: str, system: str, prompt: str, tier: str) -> str:
        """`codex exec` has no system-prompt flag, so the instructions lead the prompt. It runs in a
        read-only sandbox in an empty folder, and only its final message is kept."""
        fd, out = tempfile.mkstemp(suffix=".txt", prefix="aristotle-codex-")
        os.close(fd)
        cmd = [codex_bin(), "exec", "--skip-git-repo-check", "--sandbox", "read-only", "--color", "never",
               "-c", f"model_reasoning_effort={'low' if tier == 'fast' else 'medium'}",
               *(["--model", model] if model else []), "--output-last-message", out, "-"]
        text = f"INSTRUCTIONS (follow these exactly; do not run commands or edit files):\n{system}\n\n---\n\n{prompt}"
        last = ""
        try:
            for _ in range(2):
                try:
                    p = subprocess.run(cmd, input=text, capture_output=True, text=True,
                                       cwd=self._cwd, timeout=600, **quiet())
                except FileNotFoundError:
                    raise LLMError("Codex isn't installed. Install it, or pick another model in Settings.")
                except subprocess.TimeoutExpired:
                    last = "timed out"
                    continue
                reply = Path(out).read_text(encoding="utf-8").strip() if Path(out).exists() else ""
                if p.returncode == 0 and reply:
                    return reply
                last = (p.stderr or p.stdout or "no reply")[-500:]
                if "limit" in last.lower() or "login" in last.lower():
                    break
        finally:
            try:
                os.unlink(out)
            except OSError:
                pass
        raise LLMError(f"codex failed: {last}")

    def _openai(self, model, system, history, user) -> str:
        """No max_tokens: on reasoning models it also caps the thinking, and a short cap (themes
        ask for 300) can leave nothing for the reply. Rate limits, overload and timeouts back off
        briefly, then fail."""
        import time

        import httpx

        messages = [{"role": "system", "content": system}] + [
            {"role": "assistant" if m["role"] == "assistant" else "user", "content": m["content"]}
            for m in history or []] + [{"role": "user", "content": user}]
        body = {"model": model, "messages": messages}
        if self.reasoning:
            body["reasoning_effort"] = self.reasoning
        last = ""
        for wait in (0, 2, 6, 15, 30, 60):
            time.sleep(wait)
            try:
                r = self.http.post(self.url, headers={"Authorization": f"Bearer {self.key}"}, json=body)
            except httpx.TimeoutException:
                last = "timed out"
                continue
            if r.status_code == 200:
                text = r.json()["choices"][0]["message"].get("content") or ""
                if text:
                    return text
                last = "empty reply"
                continue
            last = f"{r.status_code} {r.text[:300]}"
            if r.status_code not in (429, 500, 502, 503, 504):
                break
        if "429" in last[:3]:
            raise LLMError("The free model is at its rate limit. Try again in a minute.")
        raise LLMError(f"model call failed: {last}")


def _flatten(history: list[dict] | None, user: str) -> str:
    """`claude -p` takes one prompt, so earlier turns are rendered as a transcript."""
    if not history:
        return user
    turns = "\n\n".join(f"[{m['role'].upper()}]\n{m['content']}" for m in history)
    return f"EARLIER IN THIS CONVERSATION:\n{turns}\n\n[USER, NOW]\n{user}"


def partial_field(text: str, field: str = "answer") -> str:
    """The value of a JSON string field from a reply that is still being written, unescaped as
    far as it goes: '{"answer": "Patience is th' -> 'Patience is th'."""
    m = re.search(r'"%s"\s*:\s*"' % re.escape(field), text)
    if not m:
        return ""
    out, i, esc_map = [], m.end(), {"n": "\n", "t": "\t", '"': '"', "\\": "\\", "/": "/", "r": "", "b": "", "f": ""}
    while i < len(text):
        c = text[i]
        if c == '"':
            break
        if c == "\\":
            if i + 1 >= len(text):
                break
            nxt = text[i + 1]
            if nxt == "u":
                if i + 6 > len(text):
                    break
                try:
                    out.append(chr(int(text[i + 2:i + 6], 16)))
                except ValueError:
                    pass
                i += 6
                continue
            out.append(esc_map.get(nxt, nxt))
            i += 2
            continue
        out.append(c)
        i += 1
    return "".join(out)


def parse_json(text: str):
    """Pull the first JSON value out of a model reply (handles ``` fences and chatter)."""
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if fenced:
        text = fenced.group(1)
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    starts = [i for i in (text.find("["), text.find("{")) if i != -1]
    if not starts:
        raise ValueError("no JSON found in model reply")
    start = min(starts)
    end = max(text.rfind("]"), text.rfind("}"))
    try:
        return json.loads(text[start : end + 1])
    except json.JSONDecodeError as e:
        raise ValueError(f"bad JSON in model reply: {e}") from e
