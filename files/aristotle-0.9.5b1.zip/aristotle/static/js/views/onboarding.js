// First run: what Aristotle is, connecting Claude, choosing the first people, and how to read an
// answer. Shown once to a new owner (the flag lives in settings.json, since localStorage is lost
// when the app gets a new port); guests see the short version once per browser.
import {$, $$, OS, api, avatar, debounce, esc, icon, toast} from "../ui.js";

const GUEST_KEY = "aristotle-intro-seen";

export async function maybeShow(store, refreshLibrary) {
  if (store.guest) {
    let seen = false;
    try { seen = localStorage.getItem(GUEST_KEY) === "1"; } catch {}
    if (!seen) show(store, refreshLibrary);
    return !seen;
  }
  try { if ((await api("/api/onboarding")).show) { show(store, refreshLibrary); return true; } } catch {}
  return false;
}

export async function show(store, refreshLibrary) {
  if ($(".scrim.intro")) return;
  const scrim = document.createElement("div");
  scrim.className = "scrim intro";
  document.body.append(scrim);
  let claude = store.guest ? {backend: "guest", ready: true} : await api("/api/claude").catch(() => ({ready: true}));
  const steps = ["welcome", ...(claude.backend === "cli" && !claude.ready ? ["connect"] : []), ...(store.guest ? [] : ["pick"]), "tour"];
  let at = 0, timer = null, packs = null, sugg = null, found = [];
  const picked = new Map();  // key -> {kind: "pack"|"person", id, name, image, description}
  const added = [];          // [{name, slug, ready}]

  const close = async (go) => {
    clearInterval(timer);
    scrim.remove();
    if (store.guest) { try { localStorage.setItem(GUEST_KEY, "1"); } catch {} }
    else api("/api/onboarding", {done: true}).catch(() => {});
    await refreshLibrary();
    if (go) location.hash = go;
  };

  const dots = () => `<div class="intro-dots" aria-hidden="true">${steps.map((_, i) => `<span class="${i === at ? "on" : i < at ? "past" : ""}"></span>`).join("")}</div>`;
  const nav = (next, label = "Continue", disabled = false) => `<div class="intro-nav">
      ${at > 0 ? `<button class="btn ghost" data-back>${icon("arrow-left", "sm")} Back</button>` : `<button class="btn ghost" data-skip>Skip the intro</button>`}
      ${dots()}<button class="btn primary" data-next="${next}" ${disabled ? "disabled" : ""}>${label}</button></div>`;

  const card = person => {
    const key = `${person.kind}:${person.id}`;
    const on = picked.has(key);
    return `<button type="button" class="pick ${on ? "on" : ""}" data-key="${esc(key)}" aria-pressed="${on}">
      ${avatar({name: person.name, image: person.image}, "lg")}
      <span class="txt"><b>${esc(person.name.replace(/\s*\(.*\)/, ""))}</b><span>${esc(person.description || "")}</span>
        <small>${person.kind === "pack" ? `${icon("check", "sm")} Ready now · no plan use` : "Built for you · about 5 minutes"}</small></span>
      <span class="tick">${on ? icon("check", "sm") : ""}</span></button>`;
  };

  function draw() {
    const step = steps[at];
    clearInterval(timer);
    if (step === "welcome") {
      scrim.innerHTML = `<div class="intro-card" role="dialog" aria-modal="true" aria-labelledby="intro-h">
        <span class="mark" aria-hidden="true">A</span>
        <h2 id="intro-h">Think it through with the people you trust.</h2>
        <p class="lead">Pick thinkers, writers or traditions you admire. Aristotle reads their own words and maps what they believe. Then you bring a real decision.</p>
        <ul class="intro-points">
          <li>${icon("quote")}<div><b>Built only from their words</b><span>Every claim points to the passage it came from. Nothing is made up or put in their mouth.</span></div></li>
          <li>${icon("circle-alert")}<div><b>Honest about the gaps</b><span>If their writing doesn't cover your question, it says so instead of guessing.</span></div></li>
          <li>${icon("users")}<div><b>One question, several minds</b><span>Ask a council of people at once and see where they agree and differ.</span></div></li>
        </ul>
        ${nav("next", "Get started")}</div>`;
    } else if (step === "connect") {
      const install = OS.install;
      scrim.innerHTML = `<div class="intro-card" role="dialog" aria-modal="true" aria-labelledby="intro-h">
        <h2 id="intro-h">Connect your Claude account</h2>
        <p class="lead">Aristotle thinks with Claude, on your own subscription (Pro or Max). Your library and conversations stay on ${OS.computer}.</p>
        <p class="lead">No Claude subscription? <button class="linkish" id="use-other">Use Gemini for free, or Codex</button></p>
        <ol class="intro-steps">
          <li class="${claude.installed ? "done" : ""}"><span class="n">${claude.installed ? icon("check", "sm") : 1}</span><div>
            <b>Install Claude Code</b>${claude.installed ? `<span>Installed.</span>` : `<span>${OS.terminal}</span>
            <div class="cmd"><code>${esc(install)}</code><button class="btn sm" id="copy">Copy</button></div>`}</div></li>
          <li class="${claude.ready ? "done" : claude.installed ? "" : "dim"}"><span class="n">${claude.ready ? icon("check", "sm") : 2}</span><div>
            <b>Sign in with your Claude account</b>${claude.ready ? `<span>Connected${claude.email ? ` as ${esc(claude.email)}` : ""}.</span>` : `<span>Your browser opens claude.ai. Approve it there, then come back.</span>
            <div class="row-btns"><button class="btn" id="signin" ${claude.installed ? "" : "disabled"}>Sign in with Claude</button></div>`}</div></li>
        </ol>
        <p class="fine">Building a person's map and asking questions count toward your plan's usage, like using Claude yourself.</p>
        ${nav("next", claude.ready ? "Continue" : "Waiting for Claude", !claude.ready)}
        ${claude.ready ? "" : `<button class="linkish later" data-next="next">I'll connect later</button>`}</div>`;
      $("#copy", scrim)?.addEventListener("click", async () => {
        try { await navigator.clipboard.writeText(install); $("#copy", scrim).textContent = "Copied"; } catch { toast("Select the command and copy it", "bad"); }
      });
      $("#use-other", scrim).onclick = () => window.dispatchEvent(new Event("aristotle:model"));  // the poll below moves on once it's ready
      $("#signin", scrim)?.addEventListener("click", async e => {
        e.currentTarget.disabled = true; e.currentTarget.innerHTML = `${icon("loader-circle", "sm spin")} Waiting for you in the browser`;
        try { await api("/api/claude/login", {}); } catch (err) { toast(err.message, "bad"); }
      });
      if (!claude.ready) timer = setInterval(async () => {
        const st = await api("/api/claude").catch(() => null);
        if (st && st.backend !== "cli" && st.ready) { $(".modelbox")?.remove(); at++; draw(); return; }
        if (st && (st.ready !== claude.ready || st.installed !== claude.installed)) { claude = st; draw(); }
      }, 2500);
    } else if (step === "pick") {
      const ready = (packs || []).filter(p => !p.installed).map(p => ({kind: "pack", id: p.slug, name: p.name, image: p.image, description: p.description}));
      const build = (sugg || []).map(s => ({kind: "person", id: s.title, name: s.title, image: s.image, description: s.description}));
      scrim.innerHTML = `<div class="intro-card wide" role="dialog" aria-modal="true" aria-labelledby="intro-h">
        <h2 id="intro-h">Who do you want to think with?</h2>
        <p class="lead">Pick as many as you like. You can add anyone later.</p>
        ${ready.length ? `<h3 class="pick-h">Ready now</h3><div class="picks">${ready.map(card).join("")}</div>` : ""}
        <h3 class="pick-h">Or someone else</h3>
        <div class="field-ico">${icon("search")}<input class="input" id="isearch" placeholder="Search anyone: a philosopher, a founder, a scientist" autocomplete="off" aria-label="Search for a person"></div>
        <div class="picks" id="ifound">${(found.length ? found : build).map(card).join("") || (sugg ? "" : `<p class="faint">${icon("loader-circle", "sm spin")} Loading suggestions</p>`)}</div>
        <p class="fine">People you search for get their writing found and their map built in the background: about 5 minutes and 70 plan calls each.</p>
        ${nav("add", picked.size ? `Add ${picked.size === 1 ? [...picked.values()][0].name.replace(/\s*\(.*\)/, "") : `${picked.size} people`}` : "Choose someone", !picked.size)}
        <button class="linkish later" data-next="next">Skip for now</button></div>`;
      const s = $("#isearch", scrim);
      const search = debounce(async q => {
        if (q.length < 2) { found = []; $("#ifound", scrim).innerHTML = build.map(card).join(""); wirePicks(); return; }
        const res = await api(`/api/people?q=${encodeURIComponent(q)}`).catch(() => []);
        if (s.value.trim() !== q) return;
        found = res.filter(r => !r.slug).map(r => ({kind: "person", id: r.title, name: r.title, image: r.image, description: r.description}));
        $("#ifound", scrim).innerHTML = found.map(card).join("") || `<p class="faint">No match on Wikipedia. Try their full name.</p>`;
        wirePicks();
      }, 250);
      s.oninput = () => search(s.value.trim());
      wirePicks();
      function wirePicks() {
        $$(".pick", scrim).forEach(b => b.onclick = () => {
          const key = b.dataset.key;
          const all = [...ready, ...build, ...found];
          if (picked.has(key)) picked.delete(key);
          else picked.set(key, all.find(p => `${p.kind}:${p.id}` === key));
          const q = s.value; draw(); const s2 = $("#isearch", scrim); s2.value = q; if (q) { s2.focus(); }
        });
      }
    } else {
      const names = added.map(a => a.ready
        ? `<li>${icon("circle-check-big", "sm")}<span><b>${esc(a.name)}</b> is ready to ask.</span></li>`
        : `<li>${icon("loader-circle", "sm spin")}<span><b>${esc(a.name)}</b>: finding their writing, then building the map. About 5 minutes; you'll get a note when it's ready.</span></li>`).join("");
      const first = added.find(a => a.ready);
      scrim.innerHTML = `<div class="intro-card wide" role="dialog" aria-modal="true" aria-labelledby="intro-h">
        <h2 id="intro-h">How to read an answer</h2>
        ${names ? `<ul class="intro-added">${names}</ul>` : ""}
        <div class="sample" aria-label="An example answer">
          <p class="q">I keep putting off my side project until I have more free time. Should I wait?</p>
          <p>Franklin's framework points against waiting. He treats time as the one resource that can't be recovered<sup class="fn">1</sup>, so a better moment rarely arrives on its own.</p>
          <div class="note"><span class="n">1</span><blockquote>Lost Time is never found again.</blockquote><span class="src">The Way to Wealth, 1758</span></div>
        </div>
        <ul class="intro-points tight">
          <li><em class="ink">Blue serif</em><div><span>is word for word from their sources. Everything else is reasoning from it.</span></div></li>
          <li><sup class="fn">1</sup><div><span>Each number opens the passage behind that claim. Push back in a follow-up when something misses.</span></div></li>
        </ul>
        <div class="intro-more">
          <div>${icon("compass")}<b>Worldview</b><span>Their core beliefs and how their views changed</span></div>
          <div>${icon("pen-line")}<b>Critique</b><span>Paste a draft; get it marked up in their terms</span></div>
          <div>${icon("users")}<b>Councils</b><span>One question, several people</span></div>
          <div>${icon("notebook-pen")}<b>Journal</b><span>Save decisions and see how they turned out</span></div>
        </div>
        <div class="intro-nav">${at > 0 && !added.length ? `<button class="btn ghost" data-back>${icon("arrow-left", "sm")} Back</button>` : "<span></span>"}${dots()}
          <button class="btn primary" data-finish>${first ? `Ask ${esc(first.name.replace(/\s*\(.*\)/, "").split(" ")[0])}` : "Go to your library"}</button></div></div>`;
    }
    $$("[data-back]", scrim).forEach(b => b.onclick = () => { at = Math.max(0, at - 1); draw(); });
    $$("[data-skip]", scrim).forEach(b => b.onclick = () => close());
    $$("[data-next]", scrim).forEach(b => b.onclick = () => b.dataset.next === "add" ? addPicked(b) : (at++, draw()));
    $$("[data-finish]", scrim).forEach(b => b.onclick = () => {
      const first = added.find(a => a.ready);
      close(first ? `#/p/${first.slug}/ask` : "#/");
    });
    scrim.querySelector(".btn.primary:not([disabled])")?.focus({preventScroll: true});
  }

  async function addPicked(btn) {
    btn.disabled = true; btn.innerHTML = `${icon("loader-circle", "sm spin")} Adding`;
    for (const p of picked.values()) {
      try {
        if (p.kind === "pack") added.push({name: p.name, slug: (await api(`/api/packs/${p.id}`, {})).slug, ready: true});
        else added.push({name: p.name, slug: (await api("/api/people", {title: p.id, auto_build: true})).slug, ready: false});
      } catch (e) { toast(`Couldn't add ${p.name}: ${e.message}`, "bad"); }
    }
    picked.clear();
    refreshLibrary();
    at++; draw();
  }

  scrim.addEventListener("keydown", e => { if (e.key === "Escape") close(); });
  draw();
  if (!store.guest) {
    api("/api/packs").then(p => { packs = p; if (steps[at] === "pick") draw(); }).catch(() => { packs = []; });
    api("/api/suggestions").then(s => { sugg = s.slice(0, 6); if (steps[at] === "pick") draw(); }).catch(() => { sugg = []; });
  }
}
