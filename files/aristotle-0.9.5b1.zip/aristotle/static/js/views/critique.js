// Critique: paste a draft (a plan, essay, pitch, memo) and get it marked up from a person's
// published worldview. Every comment is pinned to an exact span of the draft, and every claim
// cites the belief and verbatim quote it rests on.
import {$, $$, api, cap, esc, icon, shortName, toast} from "../ui.js";

const drafts = new Map();  // slug -> {draft, about, result}

export async function mount(view, ctx) {
  const {slug, info} = ctx;
  const name = shortName(info);
  const st = drafts.get(slug) || {draft: "", about: "", result: null};
  drafts.set(slug, st);
  const STANCE = {object: ["Pushes back", "bad"], agree: ["Backs this", "ok"], suggest: ["Would add", "live"]};

  function draw() {
    view.innerHTML = `<div class="page critique">
      <div class="section-head"><h2>Critique a draft</h2><p>Paste a plan, essay, pitch or memo. ${esc(name)}'s published beliefs mark it up, each comment pinned to your words.</p></div>
      ${st.result ? result() : form()}</div>`;
    wire();
  }

  const form = () => `<form id="cf" class="cform">
      <input class="input" id="about" placeholder="What is it? (optional: “seed pitch”, “plan to quit my job”)" value="${esc(st.about)}" aria-label="What the draft is">
      <textarea class="input draft" id="draft" rows="14" placeholder="Paste your draft here" aria-label="Your draft">${esc(st.draft)}</textarea>
      <div class="row"><span class="faint" id="count"></span><button class="btn primary" id="go">${icon("pen-line", "sm")} Get ${esc(name)}'s critique</button></div>
    </form>`;

  function marked() {
    // the draft with each commented span highlighted and numbered, in draft order
    const text = st.draft;
    const spans = [];
    st.result.comments.forEach((c, i) => {
      const at = text.indexOf(c.excerpt);
      if (at >= 0 && !spans.some(s => at < s.end && at + c.excerpt.length > s.start)) spans.push({start: at, end: at + c.excerpt.length, i});
    });
    spans.sort((a, b) => a.start - b.start);
    let out = "", pos = 0;
    for (const s of spans) {
      out += esc(text.slice(pos, s.start)) + `<mark class="${STANCE[st.result.comments[s.i].stance][1]}" data-c="${s.i}">${esc(text.slice(s.start, s.end))}<sup>${s.i + 1}</sup></mark>`;
      pos = s.end;
    }
    return (out + esc(text.slice(pos))).replace(/\n/g, "<br>");
  }

  function withCites(text, r, folded = false) {
    const used = [];
    const html = esc(text).replace(/\s*\[(n\d{4})\]/g, (_, id) => { if (!used.includes(id)) used.push(id); return ""; });
    const cards = used.map(id => r.sources[id]).filter(Boolean).map(s =>
      `<div class="cite"><blockquote>${esc(s.quote)}</blockquote><span>${esc(s.origin || s.section || "")}${s.date ? `, ${esc(s.date.slice(0, 4))}` : ""}</span></div>`).join("");
    if (!cards) return `<p>${html}</p>`;
    return folded ? `<p>${html}</p><details><summary>The ${used.length === 1 ? "passage" : `${used.length} passages`} this rests on</summary>${cards}</details>`
      : `<p>${html}</p>${cards}`;
  }

  function result() {
    const r = st.result;
    if (r.not_covered) return `<div class="callout">${icon("circle-alert", "sm")}<span>${esc(r.answer || `${name}'s sources don't speak to what this draft is about.`)}</span></div>
      <button class="btn" id="again">Edit the draft</button>`;
    return `<div class="crit">
      <div class="draft-view">${marked()}</div>
      <div class="comments">
        ${r.summary ? `<div class="verdict"><h3>The draft as a whole</h3>${withCites(r.summary, r, true)}</div>` : ""}
        ${r.comments.map((c, i) => `<div class="comment" data-c="${i}"><div class="head"><span class="n">${i + 1}</span>
            <span class="badge ${STANCE[c.stance][1]}">${STANCE[c.stance][0]}</span></div>${withCites(c.comment, r)}</div>`).join("")}
        <div class="coda">${r.verified ? `<span class="badge ok">${icon("check", "sm")} Every quote checked against its source</span>`
          : `<span class="badge bad">${icon("circle-alert", "sm")} Some claims couldn't be verified</span>`}
          <button class="btn sm" id="copy">${icon("copy", "sm")} Copy critique</button>
          <button class="btn sm" id="again">${icon("pencil", "sm")} Edit and run again</button></div>
      </div></div>`;
  }

  // The critique as a document: formatted for pasting into Google Docs or Word, plain text otherwise.
  async function copy() {
    const r = st.result, clean = t => t.replace(/\s*\[n\d{4}\]/g, "");
    const quotes = t => [...new Set(t.match(/n\d{4}/g) || [])].map(id => r.sources[id]).filter(Boolean)
      .map(q => ({quote: q.quote, from: [q.origin || q.section, q.date && q.date.slice(0, 4)].filter(Boolean).join(", ")}));
    const parts = [{h: `${name}'s critique${st.about ? `: ${st.about}` : ""}`}];
    if (r.summary) parts.push({h2: "The draft as a whole", p: clean(r.summary), q: quotes(r.summary)});
    r.comments.forEach((c, i) => parts.push({h2: `${i + 1}. ${STANCE[c.stance][0]}`, ex: c.excerpt, p: clean(c.comment), q: quotes(c.comment)}));
    const html = parts.map(x => x.h ? `<h1>${esc(x.h)}</h1>` : `<h2>${esc(x.h2)}</h2>${x.ex ? `<p><i>On: “${esc(x.ex)}”</i></p>` : ""}<p>${esc(x.p)}</p>`
      + x.q.map(q => `<blockquote>“${esc(q.quote)}”${q.from ? ` (${esc(q.from)})` : ""}</blockquote>`).join("")).join("");
    const text = parts.map(x => x.h ? x.h : `${x.h2}\n${x.ex ? `On: “${x.ex}”\n` : ""}${x.p}`
      + x.q.map(q => `\n  “${q.quote}”${q.from ? ` (${q.from})` : ""}`).join("")).join("\n\n");
    try {
      await navigator.clipboard.write([new ClipboardItem({"text/html": new Blob([html], {type: "text/html"}), "text/plain": new Blob([text], {type: "text/plain"})})]);
    } catch {
      try { await navigator.clipboard.writeText(text); } catch { return toast("Couldn't copy. Select the text and copy it instead.", "bad"); }
    }
    toast("Copied. Paste it into a doc to keep it.");
  }

  function wire() {
    const draft = $("#draft", view), count = $("#count", view);
    if (draft) {
      const n = () => { count.textContent = draft.value.trim() ? `${draft.value.trim().split(/\s+/).length} words` : ""; };
      draft.oninput = () => { st.draft = draft.value; n(); };
      $("#about", view).oninput = e => { st.about = e.target.value; };
      n();
      $("#cf", view).onsubmit = async e => {
        e.preventDefault();
        if (st.draft.trim().length < 40) return draft.focus();
        const go = $("#go", view);
        go.disabled = true; go.innerHTML = `${icon("loader-circle", "sm spin")} Reading your draft against ${esc(name)}'s beliefs`;
        try { st.result = await api(`/api/t/${slug}/critique`, {draft: st.draft, about: st.about}); draw(); }
        catch (err) { go.disabled = false; go.innerHTML = `${icon("pen-line", "sm")} Get ${esc(name)}'s critique`;
          view.querySelector(".cform").insertAdjacentHTML("beforeend", `<div class="callout bad">${icon("circle-alert", "sm")}<span>${esc(err.message)}</span></div>`); }
      };
    }
    const again = $("#again", view);
    if (again) again.onclick = () => { st.result = null; draw(); };
    const cp = $("#copy", view);
    if (cp) cp.onclick = copy;
    $$("[data-c]", view).forEach(el => {
      el.onmouseenter = () => $$(`[data-c="${el.dataset.c}"]`, view).forEach(x => x.classList.add("lit"));
      el.onmouseleave = () => $$(".lit", view).forEach(x => x.classList.remove("lit"));
      el.onclick = () => $(`.comment[data-c="${el.dataset.c}"]`, view)?.scrollIntoView({behavior: "smooth", block: "center"});
    });
  }
  draw();
}
