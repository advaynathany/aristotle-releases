// Just for fun: playful questions and hypotheticals, answered loosely in the person's spirit.
// Nothing here is cited or checked, so the page says so and nothing is set in the quote serif.
// Fictional characters only have this tab. Conversations live until the page reloads.
import {$, avatar, esc, icon, shortName} from "../ui.js";

const threads = new Map();  // slug -> {session, turns: [{question, answer, live, error}]}

export async function mount(view, ctx) {
  const {slug, info} = ctx;
  const first = shortName(info);
  const fiction = info.fictional;
  const t = threads.get(slug) || {session: null, turns: []};
  threads.set(slug, t);
  let alive = true;
  const starters = fiction
    ? [`What would ${first} do on a perfect day off?`, `What's ${first}'s advice for a first date?`, `If ${first} swapped places with me for a week, what would go wrong?`]
    : [`What would ${first} order at a diner at 2am?`, `What's ${first}'s advice for a first date?`, `How would ${first} spend a rainy Sunday?`];

  const intro = () => `<div class="ask-intro" id="intro">${avatar(info, "xl")}
      <h1>${fiction ? `Ask about ${esc(first)}` : "Just for fun"}</h1>
      <p>${fiction ? `${esc(info.name)}${fiction.from ? `, from ${esc(fiction.from)}` : ""}.` : `Light questions and what-ifs, answered in ${esc(first)}'s spirit.`}
        Hypotheticals, dating advice, silly questions: anything goes.</p>
      <div class="starters">${starters.map(s => `<button class="starter" type="button">${esc(s)}${icon("arrow-up", "sm")}</button>`).join("")}</div>
      <p class="fine">Made up for fun. Unlike ${fiction ? "the rest of Aristotle" : "Ask"}, nothing here is taken from ${fiction ? "the original story" : `${esc(first)}'s own words`} or checked against a source.</p></div>`;

  view.innerHTML = `<div class="thread play" id="thread"></div>
    <div class="composer"><form id="playf"><div class="field">
      <textarea id="q" rows="1" placeholder="Ask anything about ${esc(first)}" aria-label="Your question"></textarea>
      <button class="send" id="send" disabled aria-label="Send">${icon("arrow-up")}</button></div>
      <div class="under"><span>Just for fun: not grounded in sources.</span><span>Shift + Enter for a new line</span></div>
    </form></div>`;
  $("#topbar-actions").innerHTML = `<button class="btn sm ghost" id="newchat">${icon("plus", "sm")} New conversation</button>`;

  const q = $("#q"), thread = $("#thread");
  const grow = () => { q.style.height = "auto"; q.style.height = q.scrollHeight + "px"; $("#send").disabled = !q.value.trim(); };
  q.addEventListener("input", grow);
  q.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); $("#playf").requestSubmit(); } });

  const paras = text => text.split(/\n\s*\n/).filter(p => p.trim()).map(p => `<p>${esc(p.trim())}</p>`).join("");
  function turnEl(x) {
    const el = document.createElement("div");
    el.className = "turn";
    el.innerHTML = `<div class="question">${esc(x.question)}</div><div class="answer">${x.answer !== undefined
      ? `<div class="playful">${paras(x.answer)}</div><div class="coda"><span class="badge">${icon("sparkle", "sm")} Just for fun</span></div>`
      : x.error ? `<div class="callout bad">${icon("circle-alert", "sm")}<span>No answer came back: ${esc(x.error)}. Your question is back in the box, so you can send it again.</span></div>`
      : x.live ? `<div class="live" aria-hidden="true">${paras(x.live)}</div>`
      : `<div class="thinking" role="status">${icon("loader-circle", "spin")}<span class="shimmer">Thinking it up</span></div>`}</div>`;
    return el;
  }
  function draw() {
    if (!alive) return;
    thread.innerHTML = "";
    if (!t.turns.length) {
      thread.innerHTML = intro();
      thread.querySelectorAll(".starter").forEach(b => b.onclick = () => { q.value = b.textContent.trim(); grow(); $("#playf").requestSubmit(); });
    }
    t.turns.forEach(x => thread.append(turnEl(x)));
    $("#newchat").classList.toggle("hidden", !t.turns.length);
  }
  t.draw = draw;
  $("#newchat").onclick = () => { t.session = null; t.turns = []; draw(); q.focus(); };

  $("#playf").onsubmit = async e => {
    e.preventDefault();
    const text = q.value.trim();
    if (!text) return;
    const x = {question: text};
    t.turns.push(x);
    draw();
    thread.lastElementChild?.scrollIntoView({block: "start", behavior: "smooth"});
    q.value = ""; grow();
    try {
      const r = await stream(text, live => {
        x.live = live;
        const ans = alive && $(".turn:last-child .answer", view);
        if (ans) ans.innerHTML = `<div class="live" aria-hidden="true">${paras(live)}</div>`;
      });
      t.session = r.session;
      x.answer = r.answer;
    } catch (err) {
      x.error = err.message;
      if (alive) { q.value = text; grow(); }
    } finally {
      t.draw?.();
      if (alive) q.focus();
    }
  };

  async function stream(message, onText) {
    const res = await fetch(`/api/t/${slug}/play/stream`, {method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({session: t.session, message})});
    if (!res.ok || !res.body) throw new Error(`the server said ${res.status}`);
    const reader = res.body.getReader(), dec = new TextDecoder();
    let buf = "";
    for (;;) {
      const {value, done} = await reader.read();
      if (done) break;
      buf += dec.decode(value, {stream: true});
      let cut;
      while ((cut = buf.indexOf("\n\n")) >= 0) {
        let ev;
        try { ev = JSON.parse(buf.slice(0, cut).replace(/^data: /, "")); } catch { ev = null; }
        buf = buf.slice(cut + 2);
        if (!ev) continue;
        if (ev.done) return ev.done;
        if (ev.error) throw new Error(ev.error);
        if (ev.text !== undefined) onText(ev.text);
      }
    }
    throw new Error("the answer stopped before it finished");
  }

  draw();
  q.focus();
  return () => { alive = false; t.draw = null; };
}
