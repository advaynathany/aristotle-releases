"""Map packs: a built map of a public-domain thinker, shared so other people can add it without
spending their plan on a build.

  shareable(folder)        (ok, why): only maps built entirely from public-domain sources
  export(folder) -> bytes  a zip of config.json, map.json, build.json, chunks.json, worldview.json
                           and the source files (public domain, so they may travel)
  install(root, data)      unpack a pack into <library>/<slug>/ (refuses to overwrite)
  catalog() / fetch(slug)  the published index, from the public releases repo

Packs are published with `desktop/release.py pack <folder>`. The index lists each pack's sha256,
and a download that doesn't match is refused.
"""
from __future__ import annotations

import hashlib
import io
import json
import re
import urllib.request
import zipfile
from pathlib import Path

INDEX = "https://raw.githubusercontent.com/advaynathany/aristotle-releases/main/packs/index.json"
FILES = ("config.json", "map.json", "build.json", "chunks.json", "worldview.json")
PD_KINDS = {"book", "scripture", "wikisource", "archive"}
PD_DIED = 1955  # Wikiquote excerpts and other quotations: only for people dead this long


def shareable(folder: Path) -> tuple[bool, str]:
    folder = Path(folder)
    if not (folder / "map.json").exists():
        return False, "no map built yet"
    cfg = json.loads((folder / "config.json").read_text(encoding="utf-8"))
    if cfg.get("tradition"):
        return True, ""
    died = (cfg.get("profile") or {}).get("died")
    kinds = {c["file"]: c["kind"] for c in cfg.get("candidates", []) if c.get("file")}
    for src in cfg.get("sources", []):
        kind = kinds.get(src["file"], "source")
        if kind in PD_KINDS:
            continue
        if kind == "quotes" and died and died < PD_DIED:
            continue
        return False, f"{src.get('title') or src['file']} isn't public domain"
    return True, ""


def export(folder: Path) -> bytes:
    folder = Path(folder)
    ok, why = shareable(folder)
    if not ok:
        raise ValueError(f"Can't share {folder.name}: {why}.")
    cfg = json.loads((folder / "config.json").read_text(encoding="utf-8"))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name in FILES:
            if (folder / name).exists():
                z.write(folder / name, f"{folder.name}/{name}")
        for src in cfg.get("sources", []):
            p = folder / "sources" / src["file"]
            if p.exists():
                z.write(p, f"{folder.name}/sources/{src['file']}")
    return buf.getvalue()


SAFE = re.compile(r"^[a-z0-9-]+/(?:(?:config|map|build|chunks|worldview)\.json|sources/[\w.\-]+)$")


def install(root: Path, data: bytes) -> str:
    """Unpack a pack into the library. Returns the person's slug."""
    root = Path(root)
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = z.namelist()
        slugs = {n.split("/", 1)[0] for n in names}
        if len(slugs) != 1 or not all(SAFE.match(n) for n in names if not n.endswith("/")):
            raise ValueError("That isn't an Aristotle map pack.")
        slug = slugs.pop()
        if f"{slug}/config.json" not in names or f"{slug}/map.json" not in names:
            raise ValueError("That pack has no map in it.")
        folder = root / slug
        if (folder / "config.json").exists():
            raise ValueError(f"{slug} is already in your library.")
        for n in names:
            if n.endswith("/"):
                continue
            out = root / n
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(z.read(n))
    (folder / "sources").mkdir(exist_ok=True)
    return slug


def _get(url: str, timeout: int = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "Aristotle"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def catalog() -> list[dict]:
    try:
        return json.loads(_get(INDEX, timeout=15))
    except Exception:
        return []


def fetch(slug: str) -> bytes:
    entry = next((p for p in catalog() if p["slug"] == slug), None)
    if not entry:
        raise ValueError("No such map pack.")
    data = _get(entry["url"], timeout=300)
    if hashlib.sha256(data).hexdigest() != entry["sha256"]:
        raise ValueError("The download didn't match the published pack. Try again later.")
    return data


def index_entry(folder: Path, url: str, data: bytes) -> dict:
    folder = Path(folder)
    cfg = json.loads((folder / "config.json").read_text(encoding="utf-8"))
    build = json.loads((folder / "build.json").read_text(encoding="utf-8")) if (folder / "build.json").exists() else {}
    prof = cfg.get("profile") or {}
    trad = cfg.get("tradition") or {}
    return {"slug": folder.name, "name": cfg["name"], "description": prof.get("description") or trad.get("text", ""),
            "image": "" if trad.get("no_portrait") else prof.get("image", ""), "nodes": build.get("nodes"),
            "passages": build.get("passages"), "size": len(data), "sha256": hashlib.sha256(data).hexdigest(), "url": url}
