"""Decision journal: save a decision with the advice you got, say what you plan to do, and come
back on a follow-up date to record what happened. Kept in <library>/journal.json.

An entry: {id, created, slug, person, question, answer, cited: [{id, statement, quote}], plan,
follow_up (YYYY-MM-DD), outcome: {text, followed: yes|partly|no, result: better|expected|worse,
recorded} | None}. Entries are the user's own notes: never sent anywhere.
"""
from __future__ import annotations

import json
import threading
import uuid
from datetime import date, timedelta
from pathlib import Path

FOLLOWED = ("yes", "partly", "no")
RESULTS = ("better", "expected", "worse")


class Journal:
    def __init__(self, root: Path):
        self.path = Path(root) / "journal.json"
        self.lock = threading.Lock()

    def _load(self) -> list[dict]:
        return json.loads(self.path.read_text(encoding="utf-8")) if self.path.exists() else []

    def _save(self, entries: list[dict]) -> None:
        self.path.write_text(json.dumps(entries, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    def all(self) -> list[dict]:
        today = date.today().isoformat()
        out = sorted(self._load(), key=lambda e: e["created"], reverse=True)
        for e in out:
            e["due"] = not e.get("outcome") and e.get("follow_up", "9999") <= today
        return out

    def due(self) -> int:
        return sum(e["due"] for e in self.all())

    def get(self, eid: str) -> dict | None:
        return next((e for e in self.all() if e["id"] == eid), None)

    def add(self, slug: str, person: str, question: str, answer: str, cited: list[dict],
            plan: str = "", follow_up: str = "") -> dict:
        e = {"id": uuid.uuid4().hex[:10], "created": date.today().isoformat(), "slug": slug,
             "person": person, "question": question.strip()[:4000], "answer": answer.strip()[:8000],
             "cited": cited[:20], "plan": plan.strip()[:2000],
             "follow_up": follow_up or (date.today() + timedelta(days=30)).isoformat(), "outcome": None}
        with self.lock:
            entries = self._load()
            entries.append(e)
            self._save(entries)
        return e

    def update(self, eid: str, plan: str | None = None, follow_up: str | None = None,
               outcome: dict | None = None) -> dict:
        with self.lock:
            entries = self._load()
            e = next((x for x in entries if x["id"] == eid), None)
            if not e:
                raise KeyError(eid)
            if plan is not None:
                e["plan"] = plan.strip()[:2000]
            if follow_up:
                date.fromisoformat(follow_up)  # raises on a bad date
                e["follow_up"] = follow_up
            if outcome is not None:
                if outcome.get("followed") not in FOLLOWED or outcome.get("result") not in RESULTS:
                    raise ValueError(f"followed must be one of {FOLLOWED}, result one of {RESULTS}")
                e["outcome"] = {"text": str(outcome.get("text", "")).strip()[:4000], "followed": outcome["followed"],
                                "result": outcome["result"], "recorded": date.today().isoformat()}
            self._save(entries)
        return self.get(eid)

    def delete(self, eid: str) -> None:
        with self.lock:
            self._save([e for e in self._load() if e["id"] != eid])
