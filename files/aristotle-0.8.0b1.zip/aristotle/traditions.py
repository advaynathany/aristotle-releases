"""Sacred texts: religious teachers added from their scripture, with every belief cited to a verse.

Wikipedia search can't add these. Krishna isn't a "human" on Wikidata, and Gutenberg's author
search doesn't find the Gospels or the Quran. So each entry here names its texts (public-domain
translations on Project Gutenberg) and a parser that turns them into the source format ingest
reads:

  § Section title          starts a new section (a Gospel, a chapter, a surah)
  verse text [N]           one paragraph per verse or stanza; [N] cites "Matthew 5:3 (KJV)"
  INTERVIEWER: (Arjuna) …  someone else speaking: context only, never a belief or a quote

The figure's "lens" is what prompts call the thinker. The Quran is, in Muslim belief, God's word
revealed to Muhammad and not his own speech, so that entry reasons from "the Quran" and shows no
portrait.
"""
from __future__ import annotations

import re
from pathlib import Path

from .ingest import INTERVIEWER, SECTION, clean

GUTENBERG = "https://www.gutenberg.org/cache/epub/{n}/pg{n}.txt"


def _body(raw: str) -> str:
    start = re.search(r"\*\*\*\s*START OF (THE|THIS) PROJECT GUTENBERG.*?\*\*\*", raw, re.I | re.S)
    end = re.search(r"\*\*\*\s*END OF (THE|THIS) PROJECT GUTENBERG", raw, re.I)
    return raw[start.end() if start else 0: end.start() if end else len(raw)].replace("\r", "")


class _Out:
    """Collects paragraphs and their citations in the source file format."""

    def __init__(self):
        self.paras: list[str] = []
        self.cites: list[str] = []

    def section(self, title: str) -> None:
        self.paras.append(SECTION + title)

    def verse(self, text: str, ref: str) -> None:
        text = clean(text)
        if text:
            self.cites.append(f"{ref} | | 1")
            self.paras.append(f"{text} [{len(self.cites)}]")

    def context(self, who: str, text: str) -> None:
        text = clean(text)
        if text:
            self.paras.append(f"{INTERVIEWER}({who}) {text}")

    def text(self) -> str:
        return "\n\n".join(self.paras) + "\n\n=== citations ===\n" + \
            "\n".join(f"[{i + 1}] {c}" for i, c in enumerate(self.cites))


def kjv_book(raw: str, book: str) -> _Out:
    """A King James book from Gutenberg's per-book files: '40:005:003 Blessed are the poor...'."""
    out, chapter = _Out(), None
    for m in re.finditer(r"^\d+:(\d{3}):(\d{3}) (.*?)(?=^\d+:\d{3}:\d{3} |\Z)", _body(raw), re.M | re.S):
        ch, v = int(m.group(1)), int(m.group(2))
        if ch != chapter:
            chapter = ch
            out.section(f"{book} {ch}")
        out.verse(m.group(3), f"{book} {ch}:{v} (KJV)")
    return out


def quran_pickthall(raw: str) -> _Out:
    """Pickthall's translation, taken from Gutenberg's three-translations-side-by-side file."""
    body = _body(raw)
    names = {int(n): clean(t).title() for n, t in
             re.findall(r"Chapter (\d+):\s*\n\s*\n?\s*([^\n]+?)\s*\n\s*Total Verses", body)}
    out, sura = _Out(), None
    for m in re.finditer(r"^(\d{3})\.(\d{3})\s*\n(.*?)(?=^\d{3}\.\d{3}\s*$|^-{10,}|\Z)", body, re.M | re.S):
        s, v = int(m.group(1)), int(m.group(2))
        p = re.search(r"^P:(.*?)(?=^[YS]:|\Z)", m.group(3), re.M | re.S)
        if not p:
            continue
        if s != sura:
            sura = s
            out.section(f"Surah {s}: {names.get(s, '')}".rstrip(": "))
        out.verse(p.group(1), f"Quran {s}:{v} (Pickthall)")
    return out


ROMAN = re.compile(r"^\s*CHAPTER ([IVXL]+)\s*$", re.M)


def _roman(s: str) -> int:
    vals, n = {"I": 1, "V": 5, "X": 10, "L": 50}, 0
    for a, b in zip(s, s[1:] + " "):
        n += -vals[a] if vals.get(b, 0) > vals[a] else vals[a]
    return n


def gita_arnold(raw: str) -> _Out:
    """Edwin Arnold's verse Gita. Krishna's speeches are the teaching; Arjuna and Sanjaya are
    context."""
    body = _body(raw)
    out = _Out()
    heads = list(ROMAN.finditer(body))
    for i, h in enumerate(heads):
        ch = _roman(h.group(1))
        text = body[h.end(): heads[i + 1].start() if i + 1 < len(heads) else len(body)]
        text = re.split(r"^\s*HERE END", text, flags=re.M)[0]
        out.section(f"Chapter {ch}")
        speaker = "Sanjaya"
        for stanza in re.split(r"\n\s*\n", text):
            lines = [x.strip() for x in stanza.strip().splitlines() if x.strip()]
            if lines and re.fullmatch(r"(Krishna|Arjuna|Sanjaya|Dhritirashtra|Dhritarashtra)\.?", lines[0]):
                speaker, lines = lines[0].rstrip("."), lines[1:]
            if not lines:
                continue
            if speaker == "Krishna":
                out.verse(" ".join(lines), f"Bhagavad Gita, chapter {ch} (Arnold)")
            else:
                out.context(speaker, " ".join(lines))
    return out


def dhammapada(raw: str) -> _Out:
    """Max Müller's Dhammapada: 'Chapter I. The Twin-Verses' then numbered verses."""
    body = _body(raw)
    out = _Out()
    start = re.search(r"^Chapter I\. ", body, re.M)
    body = body[start.start():] if start else body
    body = re.split(r"^\s*(Notes?|NOTES?)\s*$", body, flags=re.M)[0]
    for block in re.split(r"\n\s*\n", body):
        block = block.strip()
        c = re.match(r"Chapter ([IVXL]+)\. (.+)", block)
        if c:
            out.section(f"Chapter {_roman(c.group(1))}: {clean(c.group(2))}")
            continue
        v = re.match(r"(\d+(?:,\s*\d+)*)\. (.+)", block, re.S)
        if v:
            out.verse(v.group(2), f"Dhammapada {v.group(1).replace(' ', '')} (Müller)")
    return out


def tao_legge(raw: str) -> _Out:
    """James Legge's Tao Te Ching: 'Ch. 1. 1. ...' or '16. 1. ...' then '2. ...' paragraphs. Some
    chapters are a bare '6.' line followed by indented verse. Chapters are short, so they are not
    sections (a passage per chapter would triple the build); each verse still cites its chapter."""
    body = _body(raw)
    out, ch, para = _Out(), 0, 1
    start = re.search(r"^Ch\. 1\. ", body, re.M)
    body = body[start.start():] if start else body

    def chapter(n: int) -> None:
        nonlocal ch, para
        ch, para = n, 1

    for block in re.split(r"\n\s*\n", body):
        block = block.strip()
        if not block or re.fullmatch(r"PART [IV1-9]+\.?", block):
            continue
        m = re.match(r"(?:Ch\. )?(\d+)\. (\d+)\. (.+)", block, re.S)
        if m and int(m.group(1)) == ch + 1:
            chapter(ch + 1)
            out.verse(m.group(3), f"Tao Te Ching {ch} (Legge)")
            continue
        m = re.match(r"(\d+)\.(?: (.+))?$", block, re.S)
        if m:
            n = int(m.group(1))
            # "11." is the next chapter unless it is just as plausibly this chapter's next paragraph
            if n == ch + 1 and n != para + 1:
                chapter(n)
            elif n == para + 1:
                para = n
            if not m.group(2):
                continue
            block = m.group(2)
        if ch:
            out.verse(block, f"Tao Te Ching {ch} (Legge)")
    return out


PARSERS = {"kjv": kjv_book, "quran": quran_pickthall, "gita": gita_arnold, "dhammapada": dhammapada,
           "tao": tao_legge}

# What every entry adds to the extraction prompt: the text is not the figure's own writing, other
# characters speak in it, and a reading must not pass interpretation off as the text.
NOTE = ("This passage is scripture: {text}. Extract the teachings it puts forward ({who}). Lines "
        "starting INTERVIEWER: are other people speaking (a questioner, a narrator, opponents): use "
        "them only as context. Narrative verses can be cases (what the figure did and why). Keep "
        "statements faithful to the passage; do not add doctrine or interpretation from any later "
        "tradition.")

TRADITIONS = [
    {"id": "jesus", "name": "Jesus", "wikipedia": "Jesus", "tradition": "Christianity",
     "description": "Central figure of Christianity",
     "text": "The four Gospels", "translation": "King James Version",
     "lens": "Jesus in the Gospels", "who": "Jesus's words and actions as the Gospels record them",
     "sources": [{"id": f"kjv-{b.lower()}", "title": f"The Gospel According to {b} (KJV)",
                  "gutenberg": n, "parser": "kjv", "arg": b}
                 for b, n in (("Matthew", 8040), ("Mark", 8041), ("Luke", 8042), ("John", 8043))]},
    {"id": "muhammad", "name": "Prophet Muhammad", "wikipedia": "Muhammad", "tradition": "Islam",
     "description": "Prophet of Islam", "portrait": False,
     "text": "The Quran", "translation": "Marmaduke Pickthall",
     "lens": "the Quran", "who": "what the Quran teaches; in Muslim belief it is the word of God "
                                "revealed to the Prophet Muhammad, so never attribute it to him as his own speech",
     "sources": [{"id": "quran-pickthall", "title": "The Quran (Pickthall translation)", "gutenberg": 16955,
                  "parser": "quran"}]},
    {"id": "krishna", "name": "Krishna", "wikipedia": "Krishna", "tradition": "Hinduism",
     "description": "Hindu deity; teacher of the Bhagavad Gita",
     "text": "The Bhagavad Gita", "translation": "Edwin Arnold, The Song Celestial",
     "lens": "Krishna in the Bhagavad Gita", "who": "Krishna's teaching to Arjuna",
     "sources": [{"id": "gita-arnold", "title": "The Bhagavad Gita (Arnold, The Song Celestial)",
                  "gutenberg": 2388, "parser": "gita"}]},
    {"id": "buddha", "name": "The Buddha", "wikipedia": "The Buddha", "tradition": "Buddhism",
     "description": "Founder of Buddhism",
     "text": "The Dhammapada", "translation": "F. Max Müller",
     "lens": "the Buddha in the Dhammapada", "who": "the Buddha's sayings collected in the Dhammapada",
     "sources": [{"id": "dhammapada-muller", "title": "The Dhammapada (Müller translation)",
                  "gutenberg": 2017, "parser": "dhammapada"}]},
    {"id": "laozi", "name": "Laozi", "wikipedia": "Laozi", "tradition": "Taoism",
     "description": "Founder of Taoism",
     "text": "The Tao Te Ching", "translation": "James Legge",
     "lens": "Laozi in the Tao Te Ching", "who": "the Tao Te Ching's teaching",
     "sources": [{"id": "tao-legge", "title": "The Tao Te Ching (Legge translation)", "gutenberg": 216,
                  "parser": "tao"}]},
]
BY_ID = {t["id"]: t for t in TRADITIONS}
# other names people search by; Wikipedia search can't find Krishna at all (not a human on Wikidata)
# and buries the others among namesakes
ALIASES = {"jesus": "christ jesus christ gospel gospels bible christianity christian",
           "muhammad": "mohammed mohammad muhammed prophet quran koran islam muslim",
           "krishna": "krsna gita bhagavad bhagavad gita hinduism hindu",
           "buddha": "buddha gautama siddhartha shakyamuni dhammapada buddhism buddhist",
           "laozi": "lao tzu lao tse lao-tzu tao te ching taoism daoism"}


def matches(q: str) -> list[dict]:
    """Scripture entries for a search query: 'kri', 'gita', 'quran', 'lao tzu'."""
    q = " ".join(q.lower().split())
    if len(q) < 2:
        return []
    out = []
    for t in TRADITIONS:
        terms = " ".join([t["name"], t["wikipedia"], t["text"], t["tradition"], ALIASES.get(t["id"], "")]).lower()
        words = terms.replace("-", " ").split()
        if any(w.startswith(q) for w in words) or f" {q}" in f" {terms}":
            out.append(t)
    return out
# rough sizes, so the sources page can show a passage estimate before anything is downloaded
EST_PASSAGES = {8040: 55, 8041: 35, 8042: 60, 8043: 50, 16955: 365, 2388: 50, 2017: 32, 216: 20}


def lens(cfg: dict) -> str:
    """What prompts call the thinker: 'Krishna in the Bhagavad Gita' for scripture, else the name."""
    return (cfg.get("tradition") or {}).get("lens") or cfg["name"]


def extract_note(cfg: dict) -> str:
    t = cfg.get("tradition")
    return NOTE.format(text=f"{t['text']} ({t['translation']} translation)", who=t["who"]) if t else ""


def card(t: dict, image: str = "") -> dict:
    """What the shelf shows. No portrait for the Prophet Muhammad."""
    return {"id": t["id"], "title": t["name"], "description": t["description"], "tradition": t["tradition"],
            "text": t["text"], "scripture": t["text"], "translation": t["translation"],
            "image": image if t.get("portrait", True) else ""}


def create(root: Path, tid: str) -> str:
    """Make thinkers/<slug>/ for a scripture entry. The texts download when the build starts."""
    from .discover import load_cfg, profile, save_cfg, slugify

    t = BY_ID[tid]
    slug = slugify(t["name"])
    folder = Path(root) / slug
    if (folder / "config.json").exists():
        return slug
    try:
        prof = profile(t["wikipedia"])
    except Exception:
        prof = {"title": t["wikipedia"], "extract": "", "wikipedia": "", "wikidata": ""}
    prof.update(description=t["description"], image=prof.get("image", "") if t.get("portrait", True) else "")
    (folder / "sources").mkdir(parents=True, exist_ok=True)
    cfg = {"name": t["name"], "voice": "scripture", "profile": prof, "sources": [],
           "tradition": {k: t[k] for k in ("id", "tradition", "text", "translation", "lens", "who")},
           "candidates": [{"id": s["id"], "kind": "scripture", "title": s["title"],
                           "url": GUTENBERG.format(n=s["gutenberg"]), "gutenberg": s["gutenberg"],
                           "parser": s["parser"], "arg": s.get("arg"),
                           "detail": f"{t['translation']}, public domain, from Project Gutenberg",
                           "selected": True, "status": "remote", "est_passages": EST_PASSAGES.get(s["gutenberg"])}
                          for s in t["sources"]]}
    save_cfg(folder, cfg)
    return slug


def materialize(folder: Path, c: dict) -> str:
    """Download and parse one scripture candidate into sources/. Returns the file name."""
    from .discover import _get

    raw = _get(GUTENBERG.format(n=c["gutenberg"]), timeout=120, raw=True).decode("utf-8", errors="ignore")
    parse = PARSERS[c["parser"]]
    out = parse(raw, c["arg"]) if c.get("arg") else parse(raw)
    if len(out.cites) < 10:
        raise ValueError(f"Couldn't read the verses in {c['title']}; the Gutenberg file may have changed.")
    file = f"{c['id']}.md"
    (Path(folder) / "sources" / file).write_text(f"title: {c['title']}\nurl: {c['url']}\ntier: 1\n---\n" + out.text())
    return file
