"""Find a person and their source material, so anyone can be added to the library.

  search_people("seneca")          Wikipedia title search: name, one-line description, portrait
  profile("Seneca the Younger")    Wikipedia summary for the library entry
  discover(folder, llm)            candidate sources from every finder at once: Wikiquote, Project
                                   Gutenberg, their website, Wikisource, the Internet Archive,
                                   open-access papers, YouTube talks, and a Claude web search
                                   (finders.py). `start` runs it in the background; progress is
                                   in discovery.json.
  add_url(folder, url)             a blog (every WordPress post, or the latest from its feed), a
                                   direct pdf/epub/txt, or an article page (main text extracted)
  add_file(folder, name, data)     an uploaded document, or an X archive .zip
  materialize(folder, cand)        download a selected candidate into sources/ and config.json

Candidates live in config.json under "candidates" until they are built; built ones are also listed
under "sources", which is what ingest reads. Downloaded text is the author's copyright unless it is
public domain: personal use only, never committed.
"""
from __future__ import annotations

import json
import re
import threading
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path

from bs4 import BeautifulSoup

from . import finders
from .ingest import clean

UA = {"User-Agent": "Aristotle/0.2 (personal research tool; https://github.com/)"}
CHARS_PER_PASSAGE = 2600  # ingest packs ~3000-char chunks on paragraph boundaries
SKIP_QUOTE_SECTIONS = re.compile(
    r"disputed|misattributed|attributed|about |quotes about|quotes from others|see also|external|"
    r"sources|references|notes|further reading|dialogue|cast|criticism|commentary", re.I)


def _get(url: str, timeout: int = 30, raw: bool = False):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read()
    return data if raw else json.loads(data.decode())


def slugify(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:48] or "person"


def _thumb(page: dict) -> str:
    t = page.get("thumbnail") or {}
    url = t.get("source") or t.get("url") or ""
    return ("https:" + url) if url.startswith("//") else url


# ---------- who ----------

def search_people(q: str, limit: int = 8) -> list[dict]:
    """People only: Wikipedia prefix and full-text matches, kept when Wikidata says the article is
    about a human (P31 = Q5), so "sene" finds Seneca and not Senegal."""
    if not q.strip():
        return []
    pages: dict[str, dict] = {}
    for gen in ({"generator": "prefixsearch", "gpssearch": q, "gpslimit": 12},
                {"generator": "search", "gsrsearch": q, "gsrlimit": 12}):
        try:
            r = _get("https://en.wikipedia.org/w/api.php?" + urllib.parse.urlencode({
                "action": "query", "format": "json", "prop": "pageprops|pageimages|description",
                "ppprop": "wikibase_item", "piprop": "thumbnail", "pithumbsize": 120, "redirects": 1, **gen}))
        except Exception:
            continue
        for p in sorted((r.get("query") or {}).get("pages", {}).values(), key=lambda p: p.get("index", 99)):
            pages.setdefault(p["title"], p)
    items = {p["pageprops"]["wikibase_item"]: t for t, p in pages.items() if p.get("pageprops", {}).get("wikibase_item")}
    humans = set(items)
    if items:
        try:
            sparql = ("SELECT ?i ?n WHERE { VALUES ?i { " + " ".join(f"wd:{i}" for i in items) +
                      " } ?i wdt:P31 wd:Q5 ; wikibase:sitelinks ?n }")
            r = _get("https://query.wikidata.org/sparql?" + urllib.parse.urlencode({"query": sparql, "format": "json"}), timeout=20)
            fame = {b["i"]["value"].rsplit("/", 1)[-1]: int(b["n"]["value"]) for b in r["results"]["bindings"]}
            humans = set(fame)
            ql = q.lower().strip()
            starts = lambda t: plain_name(t).lower().startswith(ql) or any(w.startswith(ql) for w in t.lower().split())
            # names that start with what was typed first, then the best known
            items = dict(sorted(items.items(), key=lambda kv: (not starts(kv[1]), -fame.get(kv[0], 0))))
        except Exception:
            pass  # Wikidata unreachable: show everything rather than nothing
    out = []
    for qid, title in items.items():
        if qid in humans:
            p = pages[title]
            out.append({"title": title, "description": p.get("description", ""), "image": _thumb(p)})
    return out[:limit]


def profile(title: str) -> dict:
    s = _get("https://en.wikipedia.org/api/rest_v1/page/summary/" +
             urllib.parse.quote(title.replace(" ", "_")))
    website = ""
    if s.get("wikibase_item"):  # official website (P856), for people whose writing lives online
        try:
            c = _get("https://www.wikidata.org/w/api.php?" + urllib.parse.urlencode(
                {"action": "wbgetclaims", "entity": s["wikibase_item"], "property": "P856", "format": "json"}), timeout=15)
            website = c["claims"]["P856"][0]["mainsnak"]["datavalue"]["value"]
        except Exception:
            pass
    return {"title": s.get("title", title), "description": s.get("description", ""), "website": website,
            "extract": s.get("extract", ""), "image": (s.get("thumbnail") or {}).get("source", ""),
            "wikipedia": (s.get("content_urls") or {}).get("desktop", {}).get("page", ""),
            "wikidata": s.get("wikibase_item", "")}


# ---------- what they said ----------

def _year(text: str) -> str:
    m = re.findall(r"\b(1[0-9]{3}|20[0-3][0-9])\b", text)
    return m[0] if m else ""


def wikiquote(name: str) -> dict | None:
    """Sourced quotes from Wikiquote, as text with [N] markers pointing at their citations."""
    page = {}
    for title in dict.fromkeys([name, plain_name(name)]):
        try:
            page = _get("https://en.wikiquote.org/w/api.php?" + urllib.parse.urlencode(
                {"action": "parse", "page": title, "prop": "text", "format": "json", "redirects": 1}))
        except Exception:
            continue
        if "parse" in page:
            name = title
            break
    if "parse" not in page:
        return None
    soup = BeautifulSoup(page["parse"]["text"]["*"], "html.parser")
    root = soup.select_one(".mw-parser-output") or soup
    quotes, cites, heading, work, skipping = [], [], "", "", False
    for el in root.find_all(["h2", "h3", "li"]):  # document order
        if el.name in ("h2", "h3"):
            text = clean(el.get_text())
            if el.name == "h2":
                skipping = bool(SKIP_QUOTE_SECTIONS.search(text))
                work = "" if text.lower() in ("quotes", "sourced") else text
            elif not re.match(r"(book|chapter|part|letter)\b", text, re.I) or not work:
                work = text
            heading = text
            continue
        if skipping or el.find_parent("li") or el.parent is None:
            continue
        if el.find_parent(class_=re.compile("toc|navbox|reflist|mw-references")):
            continue
        nested = el.find("ul")
        # the nested list is usually the citation, but some pages put alternate translations there:
        # keep the shortest line that reads like a reference, else fall back to the section's work
        lines = [clean(li.get_text(" ")) for li in nested.find_all("li")] if nested else []
        refs = [x for x in lines if len(x) <= 140]
        cite = min(refs, key=len) if refs else (work if lines else "")
        own = [c for c in el.children if c is not nested]
        text = clean(" ".join(c.get_text(" ") if hasattr(c, "get_text") else str(c) for c in own))
        text = re.sub(r"\[\s*\d+\s*\]", "", text).strip()
        if len(text) < 40 or not cite:  # unsourced lines are where misattributions live
            continue
        ref = f"{work}, {cite}" if work and len(cite) < 60 and work.lower() not in cite.lower() else cite
        ref = re.sub(r"\s*\|\s*", " / ", ref)
        cites.append(f"{ref[:200]} | {_year(cite) or _year(work)} | 2")
        quotes.append(f"{text} [{len(cites)}]")
    if len(quotes) < 3:
        return None
    return {"title": f"{name} on Wikiquote", "url": f"https://en.wikiquote.org/wiki/{urllib.parse.quote(name.replace(' ', '_'))}",
            "text": "\n\n".join(quotes), "citations": cites}


def plain_name(name: str) -> str:
    """'Paul Graham (programmer)' -> 'Paul Graham'; 'Seneca the Younger' -> 'Seneca'."""
    name = re.sub(r"\s*\(.*?\)", "", name)
    return re.sub(r"\b(the (younger|elder|great))\b", "", name, flags=re.I).strip()


def gutenberg(name: str, limit: int = 4) -> list[dict]:
    """Public-domain books whose author matches the person, most-downloaded first, one per title.
    Uses Project Gutenberg's own OPDS search (fast and current)."""
    import xml.etree.ElementTree as ET

    name = plain_name(name)
    try:
        raw = _get("https://www.gutenberg.org/ebooks/search.opds/?" +
                   urllib.parse.urlencode({"query": name, "sort_order": "downloads"}), timeout=20, raw=True)
        feed = ET.fromstring(raw)
    except Exception:
        return []
    ns = {"a": "http://www.w3.org/2005/Atom"}
    want = {w for w in re.findall(r"[a-z]+", name.lower()) if len(w) > 2}
    out, keys, main_author = [], [], None
    stop = want | {"the", "of", "and", "a", "an", "emperor", "on", "by", "complete", "works", "volume", "vol"}
    for e in feed.findall("a:entry", ns):
        m = re.search(r"/ebooks/(\d+)\.opds", e.findtext("a:id", "", ns))
        title = clean(e.findtext("a:title", "", ns))
        author = (e.findtext("a:content", "", ns) or "").lower()
        if not m or not want or not want <= set(re.findall(r"[a-z]+", author)):
            continue
        main_author = main_author or author  # the most-downloaded match decides who "they" are
        if author != main_author or title.lower().startswith("index of") or \
                re.search(r"\((german|french|spanish|italian|latin|greek|dutch|finnish|portuguese|swedish|esperanto|hungarian|polish|czech|russian|danish|norwegian|catalan|japanese|chinese|welsh|tagalog)\)\s*$", title, re.I):
            continue
        key = {w for w in re.findall(r"[a-z]+", title.lower()) if w not in stop}
        if any(key <= k or k <= key for k in keys):  # another edition or translation of a book we have
            continue
        keys.append(key)
        n = m.group(1)
        out.append({"id": f"gutenberg-{n}", "kind": "book", "title": title[:140],
                    "url": f"https://www.gutenberg.org/cache/epub/{n}/pg{n}.txt",
                    "detail": "Public-domain book from Project Gutenberg", "est_passages": None})
        if len(out) >= limit:
            break
    return out


def _size(url: str) -> int | None:
    try:
        req = urllib.request.Request(url, headers=UA, method="HEAD")
        with urllib.request.urlopen(req, timeout=15) as r:
            n = r.headers.get("Content-Length")
            return int(n) if n else None
    except Exception:
        return None


# ---------- config plumbing ----------

# One lock for every config.json edit: discovery runs in a background thread while the user ticks
# sources or adds links, and each edit is a read-modify-write of the whole file.
CFG_LOCK = threading.RLock()


def load_cfg(folder: Path) -> dict:
    return json.loads((Path(folder) / "config.json").read_text())


def save_cfg(folder: Path, cfg: dict) -> None:
    (Path(folder) / "config.json").write_text(json.dumps(cfg, indent=2, ensure_ascii=False) + "\n")


@contextmanager
def editing(folder: Path):
    with CFG_LOCK:
        cfg = load_cfg(folder)
        yield cfg
        save_cfg(folder, cfg)


def _register(folder: Path, cfg: dict, entry: dict, cand: dict | None = None) -> None:
    if not any(s["file"] == entry["file"] for s in cfg["sources"]):
        cfg["sources"].append(entry)
    if cand:
        cand.update(status="ready", file=entry["file"])
        if not any(c["id"] == cand["id"] for c in cfg.setdefault("candidates", [])):
            cfg["candidates"].append(cand)


def passages_in(folder: Path, file: str) -> int:
    p = Path(folder) / "sources" / file
    if not p.exists():
        return 0
    size = p.stat().st_size
    if p.suffix == ".pdf":  # a PDF is mostly not text: use the sampled text size when there is one
        known = p.parent / f".{file}.chars"
        size = int(known.read_text() or 0) if known.exists() else size // 3
    return max(1, round(size / CHARS_PER_PASSAGE))


def create_person(root: Path, title: str, llm=None, on_done=None) -> tuple[str, dict]:
    """Make thinkers/<slug>/ from a Wikipedia title and start looking for their sources in the
    background (see `start`); the page shows progress from discovery.json."""
    prof = profile(title)
    slug = slugify(prof["title"])
    folder = Path(root) / slug
    if (folder / "config.json").exists():
        return slug, load_cfg(folder)
    (folder / "sources").mkdir(parents=True, exist_ok=True)
    cfg = {"name": prof["title"], "voice": "third", "profile": prof, "sources": [], "candidates": []}
    save_cfg(folder, cfg)
    start(folder, llm, on_done)
    return slug, load_cfg(folder)


# ---------- discovery: every finder, with progress ----------

EXTRAS = True  # the finders beyond Wikiquote and Gutenberg (tests turn them off: they need the network)
SOCIAL = re.compile(r"(^|\.)(twitter|x|facebook|instagram|youtube|linkedin|tiktok|threads)\.(com|net)$")
SKIP_HOSTS = re.compile(r"(wikipedia|wikiquote|gutenberg|goodreads|brainyquote|amazon|azquotes)\.")
_running: set[str] = set()
try:  # optional: installs made before 0.8 lack it, and update without a new download
    import yt_dlp  # noqa: F401
    HAVE_YTDLP = True
except ImportError:
    HAVE_YTDLP = False


def status(folder: Path) -> dict | None:
    """Discovery progress for the page. A 'running' file left by a crashed app reads as done."""
    p = Path(folder) / "discovery.json"
    if not p.exists():
        return None
    s = json.loads(p.read_text())
    if s.get("state") == "running" and str(Path(folder).resolve()) not in _running:
        s["state"] = "done"
    return s


def start(folder: Path, llm=None, on_done=None) -> bool:
    """Run `discover` in a background thread. False if one is already running for this person."""
    key = str(Path(folder).resolve())
    with CFG_LOCK:
        if key in _running:
            return False
        _running.add(key)
        (Path(folder) / "discovery.json").write_text(json.dumps({"state": "running", "steps": []}))

    def run():
        try:
            discover(folder, llm)
        finally:
            _running.discard(key)
            if on_done:
                on_done(Path(folder))
    threading.Thread(target=run, daemon=True).start()
    return True


def _web_ok(llm) -> bool:
    return llm is not None and getattr(llm, "backend", None) == "cli"


def discover(folder: Path, llm=None) -> list[dict]:
    """Look everywhere at once. Each finder adds its candidates as soon as it is done, so the page
    fills in while the slow ones (the web search) are still going."""
    folder = Path(folder)
    cfg = load_cfg(folder)
    name, prof = cfg["name"], cfg.get("profile", {})
    if EXTRAS and prof.get("wikidata") and "born" not in prof and "died" not in prof:
        years = finders.life_years(prof["wikidata"])
        with editing(folder) as c:
            c.setdefault("profile", {}).update(years)
        prof.update(years)
    books_done = threading.Event()  # the Internet Archive skips books Gutenberg already has

    def books():
        try:
            return _find_books(folder, name)
        finally:
            books_done.set()

    def archive():
        books_done.wait(120)
        return _find_archive(folder, name, prof.get("born"))
    steps = [("quotes", "Wikiquote", lambda: _find_quotes(folder, name)),
             ("books", "Project Gutenberg", books)]
    if EXTRAS:
        site = prof.get("website", "")
        if site and not SOCIAL.search(urllib.parse.urlparse(site).netloc.replace("www.", "")):
            steps.append(("site", "Their website", lambda: _find_site(folder, site, name)))
        steps += [("wikisource", "Wikisource", lambda: _add(folder, finders.wikisource(prof.get("wikidata", "")), pick=3)),
                  ("archive", "Internet Archive", archive),
                  ("papers", "Open-access papers", lambda: _add(folder, finders.openalex(name, prof), pick=2)),
                  ("talks", "Talks on YouTube", lambda: _add(folder, finders.youtube_talks(name, prof.get("died")), pick=2, solo_only=True))]
        if _web_ok(llm):
            steps.append(("web", "Web search", lambda: _find_web(folder, llm)))
    state = {"state": "running", "steps": [{"id": i, "label": label, "state": "running", "found": 0} for i, label, _ in steps]}
    lock = threading.Lock()

    def write():
        (folder / "discovery.json").write_text(json.dumps(state))
    write()

    def one(step):
        sid, _, fn = step
        try:
            n = fn() or 0
            res = {"state": "done", "found": n}
        except Exception as e:  # a finder that breaks finds nothing; the others carry on
            res = {"state": "failed", "found": 0, "error": str(e)[:200]}
        with lock:
            next(s for s in state["steps"] if s["id"] == sid).update(res)
            write()
    with ThreadPoolExecutor(len(steps)) as pool:
        list(pool.map(one, steps))
    with editing(folder) as cfg:
        for c in cfg.get("candidates", []):
            if c.get("file"):
                c["est_passages"] = passages_in(folder, c["file"])
    state["state"] = "done"
    write()
    return load_cfg(folder)["candidates"]


def _add(folder: Path, cands: list[dict], pick: int = 0, solo_only: bool = False) -> int:
    """Remote candidates (downloaded when a build starts). The first `pick` new ones are ticked."""
    n = 0
    with editing(folder) as cfg:
        have = {c["id"] for c in cfg.setdefault("candidates", [])} | {c.get("url") for c in cfg["candidates"]}
        for c in cands:
            if c["id"] in have or c.get("url") in have:
                continue
            on = n < pick and (c.get("solo", True) or not solo_only)
            c.update(selected=on, status="remote", est_passages=c.get("est_passages"))
            cfg["candidates"].append(c)
            n += 1
    return n


def _find_quotes(folder: Path, name: str) -> int:
    wq = wikiquote(name)
    if not wq:
        return 0
    file = "wikiquote.md"
    body = (f"title: {wq['title']}\nurl: {wq['url']}\ntier: 2\n---\n{wq['text']}\n\n"
            "=== citations ===\n" + "\n".join(f"[{i + 1}] {c}" for i, c in enumerate(wq["citations"])))
    with editing(folder) as cfg:
        if any(c["id"] == "wikiquote" for c in cfg.get("candidates", [])):
            return 0
        (folder / "sources" / file).write_text(body)
        _register(folder, cfg, {"id": "wikiquote", "file": file, "tier": 2, "date": "", "title": wq["title"]},
                  {"id": "wikiquote", "kind": "quotes", "title": "Sourced quotations",
                   "detail": f"{len(wq['citations'])} quotes with citations, from Wikiquote",
                   "url": wq["url"], "selected": True})
    return 1


def _find_books(folder: Path, name: str) -> int:
    books = gutenberg(name)
    for b in books:
        n = _size(b["url"])
        b["est_passages"] = round(n / CHARS_PER_PASSAGE) if n else None
    # the best-known book is on by default; the rest are one tick away, so a starter build isn't
    # spread across several translations of the same work
    return _add(folder, books, pick=1)


def _find_archive(folder: Path, name: str, born: int | None = None) -> int:
    cfg = load_cfg(folder)
    have = [finders.words(c["title"]) - finders.words(name) for c in cfg.get("candidates", []) if c["kind"] == "book"]
    books = finders.internet_archive(name, [h for h in have if h], born)
    for b in books:
        b["est_passages"] = round(b.pop("size") / CHARS_PER_PASSAGE)
    gutenberg_found = any(c["kind"] == "book" for c in cfg.get("candidates", []))
    return _add(folder, books, pick=0 if gutenberg_found else 1)


def _write_page(folder: Path, cid: str, page: dict, url: str, title: str, tier: int, date: str) -> str:
    """Save a page read by finders.read_page as sources/<cid>.md (or .pdf). Returns the file name."""
    if "pdf" in page:
        file = f"{cid}.pdf"
        (folder / "sources" / file).write_bytes(page["pdf"])
        (folder / "sources" / f".{file}.chars").write_text(str(page.get("chars", 0)))
    else:
        file = f"{cid}.md"
        (folder / "sources" / file).write_text(
            f"title: {title}\ndate: {date}\nurl: {url}\ntier: {tier}\n---\n" + "\n\n".join(page["paras"]))
    return file


def _find_site(folder: Path, site: str, name: str) -> int:
    """Their own site: every WordPress post, or the latest posts from its RSS/Atom feed."""
    host = urllib.parse.urlparse(site).netloc.replace("www.", "")
    if _is_wordpress(site):
        from .fetch import fetch_wordpress
        entries = fetch_wordpress(folder, site, plain_name(name).split()[0], register=False)
        items = [(e, {"id": e["id"], "kind": "post", "title": e["title"], "url": site, "date": e["date"],
                      "detail": f"{'Transcript' if e['tier'] == 2 else 'Post'} from {host}"}) for e in entries]
    else:
        items = []
        for p in finders.feed_posts(site, name):
            cid = finders.cid(host, urllib.parse.urlparse(p["url"]).path.strip("/").split("/")[-1] or p["title"])
            file = _write_page(folder, cid, p, p["url"], p["title"], 1, p["date"])
            items.append(({"id": cid, "file": file, "tier": 1, "date": p["date"], "title": p["title"]},
                          {"id": cid, "kind": "post", "title": p["title"], "url": p["url"], "date": p["date"],
                           "detail": f"Post from {host}"}))
    n = 0
    with editing(folder) as cfg:
        for entry, cand in items:
            if not any(c["id"] == cand["id"] for c in cfg.setdefault("candidates", [])):
                _register(folder, cfg, entry, {**cand, "selected": True})
                n += 1
    return n


WEB_TIER = {"speech": 2, "transcript": 2, "interview": 2, "video": 2}


def _find_web(folder: Path, llm) -> int:
    """Claude's web search, then every suggestion is fetched: pages too thin to be a source, dead
    links and pages that are about the person rather than by them are dropped."""
    cfg = load_cfg(folder)
    prof = cfg.setdefault("profile", {})
    if "works" not in prof:
        prof["works"] = finders.notable_works(prof.get("wikidata", ""))
        with editing(folder) as c:
            c.setdefault("profile", {})["works"] = prof["works"]
    have = [c["title"] for c in cfg.get("candidates", [])][:30]
    known = {c.get("url") for c in cfg.get("candidates", [])}
    titles = [finders.words(c["title"]) for c in cfg.get("candidates", [])]
    same = lambda t: (w := finders.words(t)) and len(w) > 1 and any(w == k for k in titles)
    found = [f for f in finders.web_search(llm, cfg, have)
             if f["url"] not in known and not SKIP_HOSTS.search(urllib.parse.urlparse(f["url"]).netloc)
             and not same(re.sub(r"\(.*?\)", "", f["title"]))]
    name = cfg["name"]

    def one(f):
        host = urllib.parse.urlparse(f["url"]).netloc.replace("www.", "")
        yt = re.search(r"(?:youtube\.com/watch\?v=|youtu\.be/)([\w-]{11})", f["url"])
        if yt and not HAVE_YTDLP:
            return None
        if yt:
            return None, finders.video_candidate(yt.group(1), f["title"] or "Talk", "", name)
        page = finders.read_page(f["url"], name)
        if not page:
            return None
        cid = finders.cid(host, urllib.parse.urlparse(f["url"]).path.strip("/").split("/")[-1] or f["title"])
        title = f["title"] or page.get("title") or host
        tier = WEB_TIER.get(f["kind"], 1)
        date = page.get("date") or f["year"]
        file = _write_page(folder, cid, page, f["url"], title, tier, date)
        return ({"id": cid, "file": file, "tier": tier, "date": date, "title": title},
                {"id": cid, "kind": f["kind"] if f["kind"] in KINDS else "article", "title": title[:140],
                 "url": f["url"], "date": date, "detail": f"{f['kind'].capitalize()} from {host}"})
    with ThreadPoolExecutor(8) as pool:
        results = [r for r in pool.map(one, found) if r]
    n = 0
    with editing(folder) as cfg:
        for entry, cand in results:
            if any(c["id"] == cand["id"] or c.get("url") == cand["url"] for c in cfg.setdefault("candidates", [])):
                continue
            if entry is None:  # a video: captions download when the build starts
                cand.update(selected=n < 12 and cand.pop("solo", False), status="remote", est_passages=None)
                cfg["candidates"].append(cand)
            else:
                big = passages_in(folder, entry["file"]) > 400  # a whole volume: one tick away, not on by default
                _register(folder, cfg, entry, {**cand, "selected": n < 12 and not big})
            n += 1
    return n


KINDS = {"essay", "speech", "letter", "transcript", "interview", "paper", "book", "video", "article"}


def _strip_gutenberg(text: str) -> str:
    start = re.search(r"\*\*\*\s*START OF (THE|THIS) PROJECT GUTENBERG.*?\*\*\*", text, re.I | re.S)
    end = re.search(r"\*\*\*\s*END OF (THE|THIS) PROJECT GUTENBERG", text, re.I)
    text = text[start.end() if start else 0: end.start() if end else len(text)]
    return _rejoin(text)


def _rejoin(text: str) -> str:
    # hard-wrapped lines (Gutenberg, scanned text) rejoined so paragraphs are paragraphs
    paras = [re.sub(r"\s*\n\s*", " ", p).strip() for p in re.split(r"\n\s*\n", text.replace("\r", ""))]
    return "\n\n".join(p for p in paras if p)


def materialize(folder: Path, cand: dict) -> bool:
    """Download a remote candidate into sources/. Returns True when it is ready to ingest.
    Raises when the download fails; the build marks that candidate failed and carries on."""
    folder = Path(folder)
    if cand.get("status") == "ready":
        return True
    c = next(x for x in load_cfg(folder)["candidates"] if x["id"] == cand["id"])
    head = lambda title, tier, date="": f"title: {title}\ndate: {date}\nurl: {c['url']}\ntier: {tier}\n---\n"
    entry = {"id": c["id"], "tier": 1, "date": c.get("date", ""), "title": c["title"]}
    if c["kind"] == "book":
        raw = _get(c["url"], timeout=120, raw=True).decode("utf-8", errors="ignore")
        file = f"{c['id']}.md"
        (folder / "sources" / file).write_text(head(c["title"], 1) + _strip_gutenberg(raw))
        entry["skip_front"] = 0.06
    elif c["kind"] == "archive":
        raw = _get(c["url"], timeout=180, raw=True).decode("utf-8", errors="ignore")
        file = f"{c['id']}.md"
        (folder / "sources" / file).write_text(head(c["title"], 1, c.get("date", "")) + _rejoin(raw))
        entry["skip_front"] = 0.04
    elif c["kind"] == "scripture":
        from .traditions import materialize as fetch_scripture
        file = fetch_scripture(folder, c)
    elif c["kind"] == "wikisource":
        file = f"{c['id']}.md"
        (folder / "sources" / file).write_text(head(c["title"], 1, c.get("date", "")) + finders.wikisource_text(c["page"]))
    elif c["kind"] == "video":
        title, date, text = finders.youtube_text(c["url"])
        if len(text) < finders.MIN_TEXT:
            raise ValueError("captions too short")
        file = f"{c['id']}.md"
        (folder / "sources" / file).write_text(head(title, 2, date) + text)
        entry.update(tier=2, date=date)
    else:  # paper, document or page by URL
        page = finders.read_page(c["url"], cfg_name(folder))
        if not page:
            raise ValueError("couldn't read enough text at that link")
        if c["kind"] == "paper" and "paras" in page and sum(map(len, page["paras"])) < 5000:
            raise ValueError("the link leads to an abstract page, not the paper")
        file = _write_page(folder, c["id"], page, c["url"], c["title"], 1, c.get("date", ""))
    with editing(folder) as cfg:
        _register(folder, cfg, {**entry, "file": file}, None)
        cc = next(x for x in cfg["candidates"] if x["id"] == c["id"])
        cc.update(status="ready", file=file, est_passages=passages_in(folder, file))
    return True


def mark_failed(folder: Path, cand_id: str, why: str) -> None:
    with editing(folder) as cfg:
        for c in cfg.get("candidates", []):
            if c["id"] == cand_id:
                c.update(status="failed", selected=False, error=why[:200])


def cfg_name(folder: Path) -> str:
    return load_cfg(folder)["name"]


# ---------- your own links and files ----------

def add_url(folder: Path, url: str) -> list[dict]:
    """Add a WordPress blog (all posts), a blog with an RSS/Atom feed (its latest posts), a direct
    document, or one article. Returns new candidates."""
    folder = Path(folder)
    url = url.strip()
    if not re.match(r"https?://", url):
        url = "https://" + url
    parsed = urllib.parse.urlparse(url)
    host = parsed.netloc.replace("www.", "")
    name = cfg_name(folder)
    added: list[dict] = []
    if parsed.path.lower().endswith((".pdf", ".epub", ".txt", ".md")):
        ext = Path(parsed.path).suffix.lower()
        file = slugify(host + "-" + Path(parsed.path).stem) + ext
        (folder / "sources" / file).write_bytes(_get(url, timeout=120, raw=True))
        cid = Path(file).stem
        with editing(folder) as cfg:
            _register(folder, cfg, {"id": cid, "file": file, "tier": 1, "date": "", "title": Path(parsed.path).stem},
                      {"id": cid, "kind": "document", "title": Path(parsed.path).name, "url": url,
                       "detail": f"Document from {host}", "selected": True})
            added.append(cfg["candidates"][-1])
    elif parsed.path in ("", "/"):
        before = {c["id"] for c in load_cfg(folder).get("candidates", [])}
        _find_site(folder, url, name)
        added = [c for c in load_cfg(folder)["candidates"] if c["id"] not in before]
        if not added:
            raise ValueError("Couldn't find posts on that site. Try links to individual essays, or a PDF.")
    else:
        page = finders.read_page(url, name)
        if not page:
            raise ValueError("Couldn't find enough article text on that page. Try a direct link to the post or a PDF.")
        title = page.get("title") or host
        date = page.get("date", "")
        cid = slugify(host + "-" + (parsed.path.strip("/").split("/")[-1] or title))[:60]
        file = _write_page(folder, cid, page, url, title, 1, date)
        with editing(folder) as cfg:
            _register(folder, cfg, {"id": cid, "file": file, "tier": 1, "date": date, "title": title},
                      {"id": cid, "kind": "article", "title": title, "url": url, "date": date,
                       "detail": f"Article from {host}", "selected": True})
            added.append(cfg["candidates"][-1])
    with editing(folder) as cfg:
        ids = {c["id"] for c in added}
        for c in cfg["candidates"]:
            if c["id"] in ids:
                c["est_passages"] = passages_in(folder, c["file"])
        added = [c for c in cfg["candidates"] if c["id"] in ids]
    return added


def _is_wordpress(url: str) -> bool:
    try:
        _get(url.rstrip("/") + "/wp-json/wp/v2/posts?per_page=1&_fields=id", timeout=15)
        return True
    except Exception:
        return False


def add_file(folder: Path, filename: str, data: bytes) -> dict:
    """An uploaded document, or an X archive (.zip, or its data/tweets.js) as one tweets source."""
    folder = Path(folder)
    ext = Path(filename).suffix.lower()
    if ext in (".zip", ".js"):
        body, n = finders.x_archive(data)
        cid, file = "x-archive", "x-archive.md"
        (folder / "sources" / file).write_text(body)
        cand = {"id": cid, "kind": "tweets", "title": "Tweets", "detail": f"{n:,} tweets from an X archive",
                "selected": True}
        title = "Tweets (X archive)"
    elif ext in (".pdf", ".epub", ".txt", ".md"):
        cid = slugify(Path(filename).stem)
        file = cid + ext
        (folder / "sources" / file).write_bytes(data)
        cand = {"id": cid, "kind": "document", "title": Path(filename).name, "detail": "Uploaded file",
                "selected": True}
        title = Path(filename).stem
    else:
        raise ValueError("Upload a PDF, EPUB, TXT or Markdown file, or an X archive (.zip).")
    with editing(folder) as cfg:
        cfg["candidates"] = [c for c in cfg.get("candidates", []) if c["id"] != cid]  # a re-upload replaces it
        cfg["sources"] = [s for s in cfg["sources"] if s["file"] != file]
        _register(folder, cfg, {"id": cid, "file": file, "tier": 1, "date": "", "title": title}, cand)
        cand["est_passages"] = passages_in(folder, file)
    return cand
