"""Fetch a thinker's posts from a WordPress site into dated, speaker-tagged source files.

  python cli.py fetch thinkers/naval https://nav.al --speaker Naval --since 2025-07-01 \
      --exclude hiring industrial --max-speakers 2

Each post becomes sources/<host>-<slug>.md with front matter (title, date, url, tier) and is added
to config.json. In transcripts, paragraphs spoken by anyone other than --speaker are prefixed
"INTERVIEWER: " so extraction can use them as context but never as the thinker's belief.
Posts with no speaker labels are treated as the thinker's own writing (tier 1); transcripts are
tier 2. Downloaded text is the author's copyright: personal use only, never committed.
"""
from __future__ import annotations

import html
import json
import re
import urllib.request
from pathlib import Path
from urllib.parse import urlparse

from .ingest import INTERVIEWER, clean

LABEL = re.compile(r"^\s*<(strong|b)>\s*([A-Z][A-Za-z .'-]{1,30}?)\s*:\s*(&nbsp;)?\s*</\1>\s*", re.S)


def _get(url: str):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (aristotle personal research)"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read().decode())


def posts(site: str) -> list[dict]:
    out, page = [], 1
    while True:
        batch = _get(f"{site.rstrip('/')}/wp-json/wp/v2/posts?per_page=100&page={page}"
                     "&_fields=date,link,title,content")
        out += batch
        if len(batch) < 100:
            return out
        page += 1


def to_paragraphs(content: str, speaker: str) -> tuple[list[str], set[str]]:
    """Split post HTML into paragraphs, tagging other speakers' lines."""
    from bs4 import BeautifulSoup

    soup = BeautifulSoup(content, "html.parser")
    paras, current, seen = [], None, set()
    for el in soup.find_all(["p", "li", "blockquote", "h2", "h3"]):
        if el.find_parent(["li", "blockquote"]) and el.name == "p":
            continue  # counted via the parent
        raw = el.decode_contents()
        m = LABEL.match(raw)
        if m:
            current = m.group(2).strip()
            seen.add(current)
            raw = raw[m.end():]
        text = clean(html.unescape(BeautifulSoup(raw, "html.parser").get_text()))
        if not text:
            continue
        # headings and bold or italic one-liners are editorial (section titles, intros): drop
        only = el.find(["strong", "b", "em", "i"])
        if el.name in ("h2", "h3") or (not m and only and clean(only.get_text()) == text):
            continue
        if current and not current.lower().startswith(speaker.lower()) and \
                not speaker.lower().startswith(current.lower()):
            text = INTERVIEWER + text
        paras.append(text)
    return paras, seen


def fetch_wordpress(folder: Path, site: str, speaker: str, since: str = "", until: str = "9999",
                    include: list[str] | None = None, exclude: list[str] | None = None,
                    max_speakers: int = 99, register: bool = True) -> list[dict]:
    """register=False only writes the files; the caller adds them to config.json."""
    folder = Path(folder)
    cfg_path = folder / "config.json"
    cfg = json.loads(cfg_path.read_text())
    host = urlparse(site).netloc.replace(".", "")
    have = {s["file"] for s in cfg["sources"]}
    added = []
    for p in posts(site):
        slug = p["link"].rstrip("/").rsplit("/", 1)[-1]
        date = p["date"][:10]
        if include and slug not in include:
            continue
        if not include and (not (since <= date <= until) or slug in (exclude or [])):
            continue
        paras, speakers = to_paragraphs(p["content"]["rendered"], speaker)
        own = [x for x in paras if not x.startswith(INTERVIEWER)]
        if len(speakers) > max_speakers or sum(len(x) for x in own) < 800:
            continue
        tier = 2 if speakers else 1
        title = clean(html.unescape(re.sub(r"<[^>]+>", "", p["title"]["rendered"])))
        fname = f"{host}-{slug}.md"
        (folder / "sources" / fname).write_text(
            f"title: {title}\ndate: {date}\nurl: {p['link']}\ntier: {tier}\n---\n" + "\n\n".join(paras))
        entry = {"id": f"{host}-{slug}", "file": fname, "tier": tier, "date": date, "title": title}
        if fname not in have:
            cfg["sources"].append(entry)
        added.append(entry)
    if register:
        cfg_path.write_text(json.dumps(cfg, indent=2, ensure_ascii=False) + "\n")
    return added
