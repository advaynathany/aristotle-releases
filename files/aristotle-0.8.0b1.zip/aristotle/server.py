"""Local web UI: the library of people, adding a person, chat with citations, map review and
blind A/B rating.

`make_app(path)` takes either thinkers/ (the whole library) or one person's folder (the library is
then its parent, opened on that person). Conversations live in memory and are never written to disk.

Guest mode (ARISTOTLE_GUEST=1) is the hosted copy for other people: they can add people, build
and ask, but not review, edit or merge beliefs, or see the blind test. ARISTOTLE_PASSWORD puts one
shared password in front of everything. `on_change(folder)` is called whenever a person's files
change, so the host can save them somewhere that outlives its disk.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import threading
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import council, discover, traditions
from .chat import Thinker
from .embed import Embedder
from .jobs import Builder, estimate
from .library import built_ids, people, read_job, summary
from .llm import LLM, LLMError, claude_bin, claude_status
from .paths import CACHE
from .schema import REVIEW_STATES, EpistemeMap

STATIC = Path(__file__).resolve().parent / "static"
STARTER = 40
MAX_SESSIONS = 200  # per person; the oldest conversation goes first
GUEST_DENIED = re.compile(r"/(node/[^/]+|merge|rate|blind)$")  # curating maps stays with the owner


class Ask(BaseModel):
    session: str | None = None
    message: str


class Review(BaseModel):
    review: str | None = None
    statement: str | None = None
    note: str | None = None


class Merge(BaseModel):
    keep: str
    drop: str


class Rate(BaseModel):
    id: str
    choice: str  # A | B | tie


class Person(BaseModel):
    title: str


class Tradition(BaseModel):
    id: str


class CouncilIn(BaseModel):
    name: str = ""
    members: list[str] | None = None


class CouncilTurn(BaseModel):
    session: str | None = None
    message: str = ""


class Link(BaseModel):
    url: str


class Pick(BaseModel):
    id: str
    selected: bool


class Channel(BaseModel):
    channel: str  # stable | beta


class Appearance(BaseModel):
    mode: str = "system"     # system | light | dark
    surface: str = "neutral"
    accent: str = "graphite"
    size: str = "default"    # small | default | large


APPEARANCE = {"mode": ("system", "light", "dark"), "surface": ("neutral", "paper", "slate", "sage"),
              "accent": ("graphite", "forest", "clay", "plum", "teal"), "size": ("small", "default", "large")}


class Feedback(BaseModel):
    kind: str = "bug"  # bug | idea
    message: str
    email: str = ""
    page: str = ""
    details: bool = True


class Build(BaseModel):
    passages: int | None = STARTER  # None reads every remaining passage


class Revalidated(StaticFiles):
    """Static files the browser must check before reuse (a cheap 304 when unchanged). Without it
    Chrome keeps the old JS after an update, so new features don't show until a hard reload."""

    def file_response(self, *args, **kwargs):
        r = super().file_response(*args, **kwargs)
        r.headers["Cache-Control"] = "no-cache"
        return r


class Person_:
    """One person's loaded state: map, retrieval index and chat sessions, all lazy."""

    def __init__(self, folder: Path):
        self.folder = folder
        self.lock = threading.Lock()
        self.reset()

    def reset(self) -> None:
        self._map, self._emb, self.sessions = None, None, {}

    @property
    def cfg(self) -> dict:
        return json.loads((self.folder / "config.json").read_text())

    @property
    def map(self) -> EpistemeMap:
        if self._map is None:
            path = self.folder / "map.json"
            if not path.exists():
                raise HTTPException(409, f"{self.cfg['name']} has no map yet. Build one from Sources.")
            self._map = EpistemeMap.load(path)
        return self._map

    def embedder(self) -> Embedder:
        with self.lock:
            if self._emb is None:
                self._emb = Embedder([Thinker._doc(n) for n in self.map.live_nodes()])
            return self._emb

    def save(self) -> None:
        self.map.save(self.folder / "map.json")
        self._emb, self.sessions = None, {}  # live node set changed: rebuild retrieval lazily


def make_app(path: Path, llm=None, guest: bool | None = None, password: str | None = None,
             on_change=None) -> FastAPI:
    path = Path(path)
    root = path.parent if (path / "config.json").exists() else path
    default = path.name if (path / "config.json").exists() else None
    llm = llm or LLM()
    guest = os.environ.get("ARISTOTLE_GUEST") == "1" if guest is None else guest
    password = os.environ.get("ARISTOTLE_PASSWORD") if password is None else password
    loaded: dict[str, Person_] = {}
    app = FastAPI(title="Aristotle", docs_url=None if guest else "/docs", redoc_url=None,
                  openapi_url=None if guest else "/openapi.json")

    changed = on_change or (lambda folder: None)

    def person(slug: str | None) -> Person_:
        slug = slug or default or next((p.name for p in people(root)), None)
        folder = root / (slug or "")
        if not slug or not (folder / "config.json").exists():
            raise HTTPException(404, "no such person")
        if slug not in loaded:
            loaded[slug] = Person_(folder)
        return loaded[slug]

    Builder.recover(root)

    def built(folder: Path) -> None:
        if folder.name in loaded:
            loaded[folder.name].reset()
        changed(folder)
    builder = Builder(llm, on_done=built)

    token = hashlib.sha256(f"aristotle:{password}".encode()).hexdigest() if password else None

    @app.middleware("http")
    async def gate(request: Request, call_next):
        route = request.url.path
        if token and route != "/login" and not hmac.compare_digest(request.cookies.get("aristotle", ""), token):
            if route.startswith("/api/"):
                return JSONResponse({"detail": "Enter the password first."}, status_code=401)
            if not route.startswith("/static/"):
                return RedirectResponse("/login", status_code=303)
        if guest and route.startswith("/api/") and GUEST_DENIED.search(route):
            return JSONResponse({"detail": "Only the owner can review or edit beliefs."}, status_code=403)
        return await call_next(request)

    @app.get("/login")
    def login_page(wrong: int = 0):
        return HTMLResponse(LOGIN.replace("{{wrong}}", '<p class="wrong">That password isn\'t right.</p>' if wrong else ""))

    @app.post("/login")
    def login(password_: str = Form(..., alias="password")):
        if not token or not hmac.compare_digest(hashlib.sha256(f"aristotle:{password_}".encode()).hexdigest(), token):
            return RedirectResponse("/login?wrong=1", status_code=303)
        r = RedirectResponse("/", status_code=303)
        r.set_cookie("aristotle", token, max_age=60 * 60 * 24 * 90, httponly=True, samesite="lax",
                     secure=os.environ.get("ARISTOTLE_HTTPS") == "1")
        return r

    app.mount("/static", Revalidated(directory=STATIC), name="static")

    @app.get("/")
    def index():
        return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-store"})

    # ---------- bug reports and ideas, forwarded to the maker ----------

    @app.post("/api/feedback")
    def feedback(req: Feedback):
        from . import feedback as fb
        if not req.message.strip():
            raise HTTPException(400, "Write a sentence or two first.")
        return {"sent": fb.send(req.kind, req.message, req.email, req.page, req.details)}

    # ---------- updates (Mac app only) ----------

    @app.get("/api/update")
    def update_status():
        from . import updater
        return updater.status() if not guest else {"enabled": False}

    @app.post("/api/update/check")
    def update_check():
        from . import updater
        if guest:
            raise HTTPException(403, "Not available here.")
        return updater.check()

    @app.post("/api/update/channel")
    def update_channel(req: Channel):
        from . import updater
        if guest:
            raise HTTPException(403, "Not available here.")
        try:
            updater.set_channel(req.channel)
        except ValueError as e:
            raise HTTPException(400, str(e))
        return updater.check()

    @app.post("/api/update/restart")
    def update_restart():
        from . import desktop
        if guest:
            raise HTTPException(403, "Not available here.")
        try:
            desktop.restart()
        except RuntimeError as e:
            raise HTTPException(400, str(e))
        return {"ok": True}

    # ---------- appearance: saved with the library, so it survives the app picking a new port ----------

    @app.get("/api/appearance")
    def appearance():
        from . import updater
        saved = {} if guest else updater.settings().get("appearance") or {}
        if not saved:
            return {}  # nothing chosen yet: the page keeps whatever it has
        default = Appearance().model_dump()
        return {k: saved[k] if saved.get(k) in ok else default[k] for k, ok in APPEARANCE.items()}

    @app.post("/api/appearance")
    def set_appearance(req: Appearance):
        from . import updater
        a = req.model_dump()
        bad = [k for k, ok in APPEARANCE.items() if a[k] not in ok]
        if bad:
            raise HTTPException(400, f"Unknown {', '.join(bad)}.")
        if not guest:  # guests share one server, so their choice stays in their own browser
            updater.save_setting("appearance", a)
        return a

    # ---------- connecting the user's own Claude account ----------

    @app.get("/api/claude")
    def claude():
        if guest or getattr(llm, "backend", "cli") != "cli":
            return {"backend": getattr(llm, "backend", "other"), "ready": True}
        st = claude_status()
        return {"backend": "cli", "ready": st["logged_in"], **st}

    @app.post("/api/claude/login")
    def claude_login():
        """Starts the CLI's own sign-in, which opens claude.ai in the browser; the page polls
        /api/claude until it reports signed in."""
        if guest:
            raise HTTPException(403, "Not available here.")
        import subprocess
        try:
            subprocess.Popen([claude_bin(), "auth", "login", "--claudeai"], stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        except FileNotFoundError:
            raise HTTPException(400, "Claude Code isn't installed yet.")
        return {"ok": True}

    # ---------- library ----------

    @app.get("/api/library")
    def library():
        return {"default": default, "guest": guest, "people": [summary(p) for p in people(root)]}

    trad_path = CACHE / "traditions.json"

    @app.get("/api/people")
    def search(q: str):
        sacred = traditions.matches(q)
        try:
            found = discover.search_people(q)
        except Exception as e:
            if not sacred:
                raise HTTPException(502, f"Wikipedia search failed: {e}")
            found = []
        # scripture entries first: Krishna isn't a "human" to Wikipedia search, and Jesus or the
        # Buddha sit among people who share the name
        images = json.loads(trad_path.read_text()) if trad_path.exists() else {}
        titles = {t["wikipedia"] for t in sacred}
        found = [{"title": t["wikipedia"], "image": images.get(t["id"], "")} for t in sacred] + \
                [f for f in found if f["title"] not in titles]
        have = {json.loads((p / "config.json").read_text()).get("profile", {}).get("title")
                or json.loads((p / "config.json").read_text())["name"]: p.name for p in people(root)}
        scripture = {t["wikipedia"]: t for t in traditions.TRADITIONS}
        for f in found:
            f["slug"] = have.get(f["title"])
            if f["title"] in scripture:  # same card as the shelf: name, no portrait of the Prophet
                f.update(traditions.card(scripture[f["title"]], f.get("image", "")), title=f["title"])
                f["slug"] = f["slug"] or have.get(scripture[f["title"]]["name"])
        return found

    @app.post("/api/people")
    def add_person(req: Person):
        try:
            # Jesus or Muhammad found by search: add them from their scripture, not Wikiquote
            t = next((t for t in traditions.TRADITIONS if t["wikipedia"] == req.title), None)
            slug = traditions.create(root, t["id"]) if t else discover.create_person(root, req.title, llm=llm, on_done=changed)[0]
        except Exception as e:
            raise HTTPException(502, f"Couldn't set up {req.title}: {e}")
        changed(root / slug)
        return {"slug": slug}

    SUGGESTED = ["Marcus Aurelius", "Seneca the Younger", "Paul Graham (programmer)", "Charlie Munger",
                 "Richard Feynman", "Benjamin Franklin", "Epictetus", "Ralph Waldo Emerson"]
    sugg_path = CACHE / "suggestions.json"

    @app.get("/api/suggestions")
    def suggestions():
        """A starter shelf of people worth adding, with portraits; fetched once, then cached."""
        if sugg_path.exists():
            return json.loads(sugg_path.read_text())
        from concurrent.futures import ThreadPoolExecutor

        def one(t):
            try:
                p = discover.profile(t)
                return {"title": p["title"], "description": p["description"], "image": p["image"]}
            except Exception:
                return None
        with ThreadPoolExecutor(8) as pool:
            out = [x for x in pool.map(one, SUGGESTED) if x]
        if out:
            sugg_path.parent.mkdir(parents=True, exist_ok=True)
            sugg_path.write_text(json.dumps(out))
        return out

    @app.get("/api/traditions")
    def list_traditions():
        """The sacred-texts shelf. Portraits come from Wikipedia once, then from the cache."""
        images = json.loads(trad_path.read_text()) if trad_path.exists() else {}
        if not images:
            from concurrent.futures import ThreadPoolExecutor

            def img(t):
                try:
                    return t["id"], discover.profile(t["wikipedia"]).get("image", "")
                except Exception:
                    return t["id"], None
            with ThreadPoolExecutor(5) as pool:
                images = {k: v for k, v in pool.map(img, traditions.TRADITIONS) if v is not None}
            if images:
                trad_path.parent.mkdir(parents=True, exist_ok=True)
                trad_path.write_text(json.dumps(images))
        have = {}
        for p in people(root):
            tid = (json.loads((p / "config.json").read_text()).get("tradition") or {}).get("id")
            if tid:
                have[tid] = p.name
        return [{**traditions.card(t, images.get(t["id"], "")), "slug": have.get(t["id"])}
                for t in traditions.TRADITIONS]

    @app.post("/api/traditions")
    def add_tradition(req: Tradition):
        if req.id not in traditions.BY_ID:
            raise HTTPException(404, "Unknown text")
        slug = traditions.create(root, req.id)
        changed(root / slug)
        return {"slug": slug}

    # ---------- councils: several people, one question ----------

    councils = council.Store(root)
    council_sessions: dict[str, tuple[str, council.Session]] = {}

    def voice_name(slug: str) -> str:
        """How a member is named in a council: "Krishna", but "The Quran" (see traditions.py)."""
        cfg = person(slug).cfg
        lens = (cfg.get("tradition") or {}).get("lens", "")
        return lens[0].upper() + lens[1:] if lens.startswith("the ") else cfg["name"]

    def council_out(c: dict) -> dict:
        members = [m for m in c["members"] if (root / m / "config.json").exists()]
        return {**c, "members": [{**summary(root / m), "voice": voice_name(m)} for m in members]}

    def council_or_404(cid: str) -> dict:
        c = councils.get(cid)
        if not c:
            raise HTTPException(404, "No such council")
        return c

    def checked(members: list[str]) -> list[str]:
        try:
            members = council.check_members(members)
        except ValueError as e:
            raise HTTPException(400, str(e))
        for m in members:
            if not (root / m / "map.json").exists():
                raise HTTPException(400, f"{person(m).cfg['name']} has no map yet. Build one first.")
        return members

    @app.get("/api/councils")
    def list_councils():
        return [council_out(c) for c in councils.all()]

    @app.post("/api/councils")
    def create_council(req: CouncilIn):
        members = checked(req.members or [])
        voices = [voice_name(m) for m in members]
        name = req.name.strip() or " & ".join([voices[0]] + [re.sub(r"^The ", "the ", v) for v in voices[1:]])
        return council_out(councils.create(name, members))

    @app.get("/api/councils/{cid}")
    def get_council(cid: str):
        return council_out(council_or_404(cid))

    @app.patch("/api/councils/{cid}")
    def edit_council(cid: str, req: CouncilIn):
        council_or_404(cid)
        members = checked(req.members) if req.members is not None else None
        for sid in [s for s, (c, _) in council_sessions.items() if c == cid and members is not None]:
            council_sessions.pop(sid)  # a new line-up starts a new conversation
        return council_out(councils.update(cid, name=req.name.strip() or None, members=members))

    @app.delete("/api/councils/{cid}")
    def delete_council(cid: str):
        councils.delete(cid)
        return {"ok": True}

    def council_session(cid: str, sid: str | None, new: bool = False) -> tuple[str, council.Session]:
        if sid in council_sessions and council_sessions[sid][0] == cid:
            return sid, council_sessions[sid][1]
        if not new:
            raise HTTPException(409, "That conversation has ended. Ask the council again.")
        c = council_or_404(cid)
        members = []
        for m in checked(c["members"]):
            p = person(m)
            members.append((m, voice_name(m), Thinker(llm, p.map, voice=p.cfg.get("voice", "third"), embedder=p.embedder())))
        while len(council_sessions) >= MAX_SESSIONS:
            council_sessions.pop(next(iter(council_sessions)))
        sid = uuid.uuid4().hex
        council_sessions[sid] = (cid, council.Session(llm, members))
        return sid, council_sessions[sid][1]

    def council_call(fn):
        try:
            return fn()
        except LLMError as e:
            raise HTTPException(503, str(e))
        except ValueError as e:
            raise HTTPException(400, str(e))

    @app.post("/api/councils/{cid}/ask")
    def council_ask(cid: str, req: CouncilTurn):
        if not req.message.strip():
            raise HTTPException(400, "Ask a question.")
        sid, s = council_session(cid, req.session, new=True)
        return {"session": sid, "answers": council_call(lambda: s.ask(req.message.strip()[:4000]))}

    @app.post("/api/councils/{cid}/respond")
    def council_respond(cid: str, req: CouncilTurn):
        sid, s = council_session(cid, req.session)
        replies = council_call(s.respond)
        return {"session": sid, "replies": replies, "round": len(s.turns[-1]["rounds"]),
                "max_rounds": council.MAX_ROUNDS}

    @app.post("/api/councils/{cid}/summary")
    def council_summary(cid: str, req: CouncilTurn):
        sid, s = council_session(cid, req.session)
        return {"session": sid, **council_call(s.summarize)}

    # ---------- one person ----------

    def info_for(slug: str | None) -> dict:
        p = person(slug)
        cfg = p.cfg
        s = summary(p.folder)
        built = built_ids(p.folder)
        chunks = p.folder / "chunks.json"
        available = len(json.loads(chunks.read_text())) if chunks.exists() else None
        selected = sum((c.get("est_passages") or 0) for c in cfg.get("candidates", []) if c.get("selected", True))
        files = [{"id": x["id"], "title": x.get("title") or x["id"], "date": x.get("date", ""),
                  "tier": x.get("tier", 1), "file": x["file"]} for x in cfg.get("sources", [])]
        return {**s, "thinker": cfg["name"], "source_files": files, "voice": cfg.get("voice", "third"), "profile": cfg.get("profile", {}),
                "tradition": cfg.get("tradition"),
                "candidates": cfg.get("candidates", []), "built_passages": len(built),
                "available_passages": available, "selected_passages": selected,
                "starter": STARTER, "estimate": estimate(STARTER), "job": read_job(p.folder),
                "discovery": discover.status(p.folder),
                "web_search": not guest and getattr(llm, "backend", None) == "cli"}

    @app.get("/api/t/{slug}")
    def info(slug: str):
        return info_for(slug)

    @app.post("/api/t/{slug}/candidates")
    def pick(slug: str, req: Pick):
        p = person(slug)
        with discover.editing(p.folder) as cfg:
            for c in cfg.get("candidates", []):
                if c["id"] == req.id:
                    c["selected"] = req.selected
        changed(p.folder)
        return info_for(slug)

    @app.post("/api/t/{slug}/links")
    def add_link(slug: str, req: Link):
        p = person(slug)
        try:
            added = discover.add_url(p.folder, req.url)
        except ValueError as e:
            raise HTTPException(400, str(e))
        except Exception as e:
            raise HTTPException(502, f"Couldn't read that link: {e}")
        changed(p.folder)
        return {"added": added, **info_for(slug)}

    @app.post("/api/t/{slug}/files")
    async def add_file(slug: str, file: UploadFile = File(...)):
        p = person(slug)
        try:
            cand = discover.add_file(p.folder, file.filename or "upload.txt", await file.read())
        except ValueError as e:
            raise HTTPException(400, str(e))
        changed(p.folder)
        return {"added": [cand], **info_for(slug)}

    @app.post("/api/t/{slug}/rediscover")
    def rediscover(slug: str):
        p = person(slug)
        cfg = p.cfg
        if cfg.get("tradition"):  # scripture entries have their texts; Wikiquote would add hearsay
            return info_for(slug)
        try:  # refresh the profile too (portrait, website), keeping everything else
            fresh = discover.profile(cfg.get("profile", {}).get("title") or cfg["name"])
            with discover.editing(p.folder) as cfg:
                cfg["profile"] = {**cfg.get("profile", {}), **fresh}
        except Exception:
            pass
        discover.start(p.folder, llm, on_done=changed)  # in the background; the page polls discovery progress
        return info_for(slug)

    @app.post("/api/t/{slug}/build")
    def build(slug: str, req: Build):
        p = person(slug)
        j = read_job(p.folder)
        if j and j.get("state") in ("queued", "running"):
            raise HTTPException(409, "A build for this person is already running.")
        builder.submit(p.folder, req.passages)
        return info_for(slug)

    @app.get("/api/t/{slug}/job")
    def job(slug: str):
        return read_job(person(slug).folder) or {"state": "none"}

    @app.delete("/api/t/{slug}")
    def remove(slug: str):
        p = person(slug)
        if (p.folder / "map.json").exists():
            raise HTTPException(400, "This person has a built map. Remove their folder by hand if you really mean it.")
        import shutil
        shutil.rmtree(p.folder)
        loaded.pop(slug, None)
        changed(p.folder)
        return {"ok": True}

    # ---------- asking, the map, blind rating (also served unprefixed for the default person) ----------

    def routes(prefix: str, get_slug):
        @app.post(prefix + "/ask")
        def ask(req: Ask, slug: str = None):
            p = person(get_slug(slug))
            sid = req.session if req.session in p.sessions else uuid.uuid4().hex
            if sid not in p.sessions:
                while len(p.sessions) >= MAX_SESSIONS:
                    p.sessions.pop(next(iter(p.sessions)))
                p.sessions[sid] = Thinker(llm, p.map, voice=p.cfg.get("voice", "third"), embedder=p.embedder())
            try:
                reply = p.sessions[sid].ask(req.message.strip()[:4000])
            except LLMError as e:
                raise HTTPException(503, str(e))
            return {"session": sid, **reply}

        @app.get(prefix + "/map")
        def get_map(slug: str = None):
            m = person(get_slug(slug)).map
            return {"thinker": m.thinker,
                    "nodes": [{"id": n.id, "kind": n.kind, "statement": n.statement, "review": n.review,
                               "note": n.note, "first_seen": n.first_seen, "last_seen": n.last_seen,
                               "tier": n.best_tier, "sources": [s.__dict__ for s in n.sources]}
                              for n in m.nodes],
                    "edges": [e.__dict__ for e in m.edges]}

        @app.post(prefix + "/node/{node_id}")
        def review(node_id: str, req: Review, slug: str = None):
            p = person(get_slug(slug))
            n = p.map.node(node_id)
            if not n:
                raise HTTPException(404, "no such node")
            if req.review is not None:
                if req.review not in REVIEW_STATES:
                    raise HTTPException(400, f"review must be one of {REVIEW_STATES}")
                n.review = req.review
            if req.statement:
                n.statement = req.statement.strip()  # quotes stay verbatim; only the gloss is editable
            if req.note is not None:
                n.note = req.note
            p.save()
            return {"ok": True}

        @app.post(prefix + "/merge")
        def merge(req: Merge, slug: str = None):
            p = person(get_slug(slug))
            m = p.map
            keep, drop = m.node(req.keep), m.node(req.drop)
            if not keep or not drop or keep is drop:
                raise HTTPException(400, "need two different existing nodes")
            keep.sources.extend(drop.sources)
            for e in m.edges:
                e.src = keep.id if e.src == drop.id else e.src
                e.dst = keep.id if e.dst == drop.id else e.dst
            m.edges = [e for e in m.edges if e.src != e.dst]
            m.nodes = [n for n in m.nodes if n.id != drop.id]
            p.save()
            return {"ok": True}

        @app.get(prefix + "/blind")
        def blind(slug: str = None):
            folder = person(get_slug(slug)).folder
            path = folder / "eval" / "blind.json"
            if not path.exists():
                raise HTTPException(404, "run `python cli.py eval <thinker> run blind` first")
            rpath = folder / "eval" / "ratings.json"
            return {"pairs": json.loads(path.read_text()),
                    "ratings": json.loads(rpath.read_text()) if rpath.exists() else {}}

        @app.post(prefix + "/rate")
        def rate(req: Rate, slug: str = None):
            if req.choice not in ("A", "B", "tie"):
                raise HTTPException(400, "choice must be A, B or tie")
            rpath = person(get_slug(slug)).folder / "eval" / "ratings.json"
            ratings = json.loads(rpath.read_text()) if rpath.exists() else {}
            ratings[req.id] = req.choice
            rpath.write_text(json.dumps(ratings, indent=2))
            return {"ok": True, "rated": len(ratings)}

    routes("/api/t/{slug}", lambda slug: slug)
    routes("/api", lambda slug: None)

    @app.get("/api/info")
    def legacy_info():
        return info_for(None)

    return app


LOGIN = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Aristotle</title>
<meta name="color-scheme" content="light dark">
<link rel="stylesheet" href="/static/css/tokens.css"><link rel="stylesheet" href="/static/css/app.css">
</head><body class="login"><form method="post" action="/login" class="login-card">
<span class="mark" aria-hidden="true">A</span><h1>Aristotle</h1>
<p>Reason through a decision with a thinker's own words. Enter the password you were given.</p>
{{wrong}}<input class="input" type="password" name="password" placeholder="Password" aria-label="Password" autofocus required>
<button class="btn primary">Continue</button></form></body></html>"""
