// A person's sources and their map build: pick what to read, add links or files, and watch
// beliefs arrive as each quote is verified against its source.
import {$, $$, api, avatar, esc, fmt, icon, kdot, plural, shortName, toast} from "../ui.js";

const KIND_ICON = {scripture: "book-open", quotes: "quote", book: "book-open", archive: "book-open", wikisource: "scroll-text",
  article: "globe", post: "globe", essay: "globe", letter: "mail", document: "file", source: "file-text", paper: "graduation-cap",
  speech: "mic", transcript: "mic", interview: "mic", video: "video", tweets: "at-sign"};
const GROUPS = [["Books", ["scripture", "book", "archive"]], ["Writing", ["quotes", "wikisource", "essay", "letter", "article", "post", "tweets", "document", "source"]],
  ["Speeches and interviews", ["speech", "transcript", "interview", "video"]], ["Papers", ["paper"]]];
const perCall = 1.8;  // keep in step with jobs.py
const estimate = n => ({calls: Math.round(n * perCall), minutes: Math.max(1, Math.round(n * perCall * 15 / 4 / 60))});

export async function mount(view, ctx) {
  let info = ctx.info, choice = null, timer = null, dtimer = null, seen = new Set(), alive = true;
  const searching = () => info.discovery?.state === "running";

  const remaining = () => {
    const total = info.available_passages ?? info.selected_passages;
    return Math.max(0, (total || 0) - (info.built ? info.built_passages : 0));
  };

  function draw() {
    const p = info.profile || {};
    const job = info.job;
    const running = job && ["queued", "running"].includes(job.state);
    view.innerHTML = `<div class="page">
      <div class="profile">${avatar(info, "xl")}<div>
        <h1>${esc(info.name)}</h1><p>${esc(p.description || "")}</p>
        ${p.wikipedia ? `<a href="${esc(p.wikipedia)}" target="_blank" rel="noopener">Wikipedia ${icon("external-link", "sm")}</a>` : ""}
      </div></div>
      <div id="buildbox">${job && job.state !== "none" ? buildBox(job) : ""}</div>
      <div class="split">
        <div>
          <div class="section-head"><h2>Sources</h2><p id="srcsum">${sourceSummary()}</p>
            ${info.tradition ? "" : `<button class="btn sm" id="again" ${searching() ? "disabled" : ""}>${icon("refresh-cw", "sm")} ${info.web_search ? "Search the web again" : "Look again"}</button>`}</div>
          <div id="disc">${discoveryBox()}</div>
          <div class="list" id="srcs">${sourceRows()}</div>
          <div class="section-head" style="margin-top:32px"><h2>Add your own</h2><p>Blog home pages bring in every post</p></div>
          ${p.website ? `<p class="muted" style="margin:0 0 4px;font-size:13px">${esc(info.name.replace(/\s*\(.*\)/, ""))}'s site is
            <a href="${esc(p.website)}" target="_blank" rel="noopener" style="text-decoration:underline">${esc(p.website.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, ""))}</a>.
            Paste its address if it's a blog, or links to individual essays.</p>` : ""}
          <form class="adder" id="linkf"><div class="field-ico" style="flex:1">${icon("link")}
            <input class="input" id="url" placeholder="Paste a link to an essay, a blog, a transcript or a PDF" aria-label="Link to add"></div>
            <button class="btn" id="addlink">Add link</button></form>
          <label class="drop" id="drop">${icon("upload", "lg")}<span><b>Drop a PDF, EPUB, TXT or Markdown file</b>, or an X archive (.zip) for their tweets, or click to choose one</span>
            <input type="file" id="file" accept=".pdf,.epub,.txt,.md,.zip" class="sr"></label>
        </div>
        <aside class="sticky" id="side">${buildPanel(running)}</aside>
      </div></div>`;
    wire();
  }

  function sourceSummary() {
    const on = (info.candidates || []).filter(c => c.selected !== false);
    const legacy = legacyFiles();
    const n = on.length + legacy.length;
    const passages = info.available_passages ?? info.selected_passages;
    return n ? `${plural(n, "source")} selected${passages ? `, about ${fmt(passages)} passages` : ""}` : "None selected";
  }

  function legacyFiles() {  // sources added by the CLI, before candidates existed
    const known = new Set((info.candidates || []).map(c => c.file).filter(Boolean));
    return (info.source_files || []).filter(f => !known.has(f.file));
  }

  function row(c) {
    const failed = c.status === "failed";
    const est = failed ? "" : c.est_passages ? `about ${fmt(c.est_passages)} passages<br>` : "size unknown until downloaded<br>";
    const state = failed ? "Couldn't download" : c.status === "remote" ? "Downloads when you build" : "Downloaded";
    const link = c.url && !c.url.startsWith("https://www.gutenberg.org/cache") ? ` <a href="${esc(c.url)}" target="_blank" rel="noopener" class="ext" aria-label="Open ${esc(c.title)}">${icon("external-link", "sm")}</a>` : "";
    return `<label class="src-row ${c.selected === false ? "off" : ""}" ${failed ? `title="${esc(c.error || "")}"` : ""}>
      <input type="checkbox" class="check" data-pick="${esc(c.id)}" ${c.selected === false ? "" : "checked"} ${failed ? "disabled" : ""} aria-label="Include ${esc(c.title)}">
      ${icon(KIND_ICON[c.kind] || "file-text")}
      <div class="txt"><b>${esc(c.title)}</b><span>${esc(c.detail || "")}${c.date ? `, ${esc(c.date.slice(0, 4))}` : ""}${link}</span></div>
      <span class="faint num" style="font-size:12px;text-align:right">${est}${state}</span></label>`;
  }

  function sourceRows() {
    const cands = info.candidates || [];
    const grouped = GROUPS.map(([label, kinds]) => [label, cands.filter(c => kinds.includes(c.kind))]);
    const known = new Set(GROUPS.flatMap(([, k]) => k));
    grouped[1][1].push(...cands.filter(c => !known.has(c.kind)));
    const used = grouped.filter(([, cs]) => cs.length);
    const rows = used.flatMap(([label, cs]) => [
      ...(used.length > 1 ? [`<div class="src-group">${esc(label)} <span class="faint num">${cs.filter(c => c.selected !== false).length} of ${cs.length} on</span></div>`] : []),
      ...cs.map(row)]);
    const legacy = legacyFiles();
    if (legacy.length > 8) {
      rows.push(`<div class="src-row"><input type="checkbox" class="check" checked disabled aria-label="Included">${icon("file-text")}
        <div class="txt"><b>${plural(legacy.length, "source file")}</b><span>${esc(legacy.slice(0, 3).map(f => f.title).join(", "))}, and more</span></div>
        <span class="faint" style="font-size:12px">Included</span></div>`);
    } else {
      legacy.forEach(f => rows.push(`<div class="src-row"><input type="checkbox" class="check" checked disabled aria-label="Included">${icon("file-text")}
        <div class="txt"><b>${esc(f.title)}</b><span>${f.tier === 1 ? "Own writing" : "Transcribed speech"}${f.date ? `, ${esc(f.date.slice(0, 4))}` : ""}</span></div>
        <span class="faint" style="font-size:12px">Included</span></div>`));
    }
    if (!rows.length && searching()) return `<div class="src-row"><span></span>${icon("loader-circle", "spin")}<div class="txt"><b>Looking for their writing</b>
      <span>Books, essays, speeches, letters, papers and talks show up here as they're found.</span></div><span></span></div>`;
    return rows.join("") || `<div class="src-row"><span></span>${icon("circle-alert")}<div class="txt"><b>Nothing found yet</b>
      <span>${info.web_search ? "Try searching the web again, or add" : "Add"} a link to their essays, a blog, a PDF, or their X archive below.</span></div><span></span></div>`;
  }

  function discoveryBox() {
    const d = info.discovery;
    if (!d || d.state !== "running") return "";
    const steps = (d.steps || []).map(s => `<span class="${s.state === "running" ? "now" : "done"}">${s.state === "running" ? icon("loader-circle", "sm spin") :
      s.state === "failed" ? icon("circle-alert", "sm") : icon("check", "sm")}${esc(s.label)}${s.state !== "running" && s.found ? ` <b class="num">${s.found}</b>` : ""}</span>`).join("");
    const slow = (d.steps || []).some(s => s.id === "web" && s.state === "running");
    return `<div class="discover" role="status" aria-live="polite"><div class="steps">${steps || `<span class="now">${icon("loader-circle", "sm spin")}Starting</span>`}</div>
      ${slow ? `<p class="faint">The web search reads pages to check each one is in their own words. It takes a few minutes and runs in the background.</p>` : ""}</div>`;
  }

  function buildPanel(running) {
    const rem = remaining();
    const opts = info.built
      ? [[Math.min(40, rem), "40 more"], [Math.min(120, rem), "120 more"], [rem, "All the rest"]]
      : [[Math.min(info.starter, rem || info.starter), "Starter"], [Math.min(120, rem || 120), "120"], [rem, "Everything"]];
    const usable = opts.filter(([n]) => n > 0);
    if (choice === null || !usable.some(([n]) => n === choice)) choice = usable[0]?.[0] ?? 0;
    const e = estimate(choice);
    const title = info.built ? "Grow the map" : "Build the map";
    const lead = info.built
      ? `${fmt(info.nodes)} beliefs from ${plural(info.built_passages, "passage")}. Reading more adds beliefs; nothing already read is redone.`
      : "Start small to try them out right away, then grow the map later.";
    if (!rem && info.built) return `<div class="panel"><h3>Map complete</h3><p>${fmt(info.nodes)} beliefs from every selected passage. Add a source to grow it.</p>
      <a class="btn primary" href="#/p/${ctx.slug}/ask">${icon("message-square-text", "sm")} Ask ${esc(shortName(info))}</a></div>`;
    return `<div class="panel"><h3>${title}</h3><p>${lead}</p>
      <div class="seg" role="group" aria-label="How much to read">${usable.map(([n, label]) =>
        `<button data-n="${n}" aria-pressed="${n === choice}">${label}</button>`).join("")}</div>
      <dl class="cost"><dt>Passages to read</dt><dd>${fmt(choice)}</dd><dt>${document.documentElement.classList.contains("guest") ? "Model calls" : "Claude plan calls"}</dt><dd>about ${fmt(e.calls)}</dd>
        <dt>Time</dt><dd>about ${e.minutes} min</dd></dl>
      <button class="btn primary lg" id="build" ${running || !choice ? "disabled" : ""}>${running ? `${icon("loader-circle", "sm spin")} Building` : info.built ? "Read more passages" : "Build map"}</button>
      ${info.built ? `<a class="btn lg" style="width:100%;margin-top:8px" href="#/p/${ctx.slug}/ask">Ask ${esc(shortName(info))}</a>` : ""}
      <p class="fine">${document.documentElement.classList.contains("guest")
        ? "Builds run one at a time for everyone using this copy, and keep going if you close the tab. Every belief is checked word for word against its source."
        : "Builds use your Claude plan, one at a time. Every reply is cached, so an interrupted build picks up where it stopped."}</p></div>`;
  }

  function buildBox(j) {
    const phases = [["fetch", "Download"], ["read", "Split into passages"], ["extract", "Read and verify"], ["link", "Link beliefs"]];
    const at = Math.max(0, phases.findIndex(([k]) => k === j.phase));
    const done = j.state === "done";
    const failed = ["error", "interrupted"].includes(j.state);
    const pct = done ? 100 : j.phase === "link" ? 96 : j.total ? Math.round(88 * j.done / j.total) + 6 : 3;
    const title = done ? `Map built: ${j.message}` : failed ? "The build stopped" : j.state === "queued" ? "Waiting to start" : j.message;
    const feed = (j.recent || []).map(b => {
      const fresh = !seen.has(b.statement); seen.add(b.statement);
      return `<div class="belief ${fresh ? "new" : ""}">${kdot(b.kind)}<div><b>${esc(b.statement)}</b><q>${esc(b.quote)}</q>
        <small>${icon("check", "sm")} Found word for word${b.where ? ` in ${esc(b.where)}` : ""}</small></div></div>`;
    }).join("");
    return `<div class="build" role="status" aria-live="polite"><div class="build-head">
        <div class="row1">${done ? icon("circle-check-big") : failed ? icon("circle-alert") : icon("loader-circle", "spin")}<b>${esc(title)}</b>
          ${done ? `<a class="btn sm primary" href="#/p/${ctx.slug}/ask">Start asking</a>` : failed ? `<span class="err-text">${esc(j.state === "error" ? j.message : "")}</span>` : `<span class="faint num">${j.found ? `${fmt(j.found)} beliefs so far` : ""}</span>`}</div>
        ${failed && j.state === "interrupted" ? `<p class="faint" style="margin:0">${esc(j.message)}</p>` : ""}
        ${done || failed ? "" : `<div class="bar"><i style="width:${pct}%"></i></div>
        <div class="steps">${phases.map(([k, label], i) => `<span class="${i < at ? "done" : i === at ? "now" : ""}">${i < at ? icon("check", "sm") : i === at ? icon("loader-circle", "sm spin") : ""}${label}${k === "extract" && j.total ? ` ${j.done}/${j.total}` : ""}</span>`).join("")}</div>`}
      </div>${feed ? `<div class="feed">${feed}</div>` : ""}</div>`;
  }

  function wire() {
    $$("[data-pick]", view).forEach(c => c.onchange = async () => {
      try { info = await api(`/api/t/${ctx.slug}/candidates`, {id: c.dataset.pick, selected: c.checked}); draw(); }
      catch (e) { toast(e.message, "bad"); }
    });
    $$(".seg button", view).forEach(b => b.onclick = () => { choice = +b.dataset.n; draw(); });
    const again = $("#again", view);
    if (again) again.onclick = async () => {
      try { info = await api(`/api/t/${ctx.slug}/rediscover`, {}); draw(); watchDiscovery(); }
      catch (e) { toast(e.message, "bad"); }
    };
    const buildBtn = $("#build", view);
    if (buildBtn) buildBtn.onclick = async () => {
      const all = choice >= remaining();
      try {
        info = await api(`/api/t/${ctx.slug}/build`, {passages: all ? null : choice});
        seen = new Set();
        draw(); poll(); ctx.refreshLibrary();
      } catch (e) { toast(e.message, "bad"); }
    };
    $("#linkf", view).onsubmit = async e => {
      e.preventDefault();
      const url = $("#url", view).value.trim();
      if (!url) return;
      const btn = $("#addlink", view);
      btn.disabled = true; btn.innerHTML = `${icon("loader-circle", "sm spin")} Reading`;
      try {
        const r = await api(`/api/t/${ctx.slug}/links`, {url});
        info = r; draw();
        toast(r.added.length > 1 ? `Added ${r.added.length} posts` : `Added ${r.added[0]?.title || "the page"}`);
      } catch (err) { toast(err.message, "bad"); btn.disabled = false; btn.textContent = "Add link"; }
    };
    const drop = $("#drop", view), file = $("#file", view);
    const upload = async f => {
      if (!f) return;
      const fd = new FormData(); fd.append("file", f);
      drop.classList.add("over"); drop.querySelector("span").innerHTML = `${icon("loader-circle", "sm spin")} Adding ${esc(f.name)}`;
      try {
        const r = await api(`/api/t/${ctx.slug}/files`, fd); info = r; draw();
        toast(r.added?.[0]?.kind === "tweets" ? r.added[0].detail : `Added ${f.name}`);
      }
      catch (e) { toast(e.message, "bad"); draw(); }
    };
    file.onchange = () => upload(file.files[0]);
    drop.ondragover = e => { e.preventDefault(); drop.classList.add("over"); };
    drop.ondragleave = () => drop.classList.remove("over");
    drop.ondrop = e => { e.preventDefault(); upload(e.dataTransfer.files[0]); };
  }

  async function poll() {
    clearTimeout(timer);
    if (!alive) return;
    let j;
    try { j = await api(`/api/t/${ctx.slug}/job`); } catch { return; }
    info.job = j;
    const box = $("#buildbox", view);
    if (box) box.innerHTML = buildBox(j);
    if (["queued", "running"].includes(j.state)) timer = setTimeout(poll, 1500);
    else { info = await api(`/api/t/${ctx.slug}`); draw(); ctx.refreshLibrary(); }
  }

  // discovery runs in the background: refresh the list in place (not the whole page, so a link
  // being typed survives) until every finder is done
  async function watchDiscovery() {
    clearTimeout(dtimer);
    if (!alive || !searching()) return;
    dtimer = setTimeout(async () => {
      try { info = await api(`/api/t/${ctx.slug}`); } catch { return watchDiscovery(); }
      if (!searching()) { draw(); ctx.refreshLibrary(); return; }
      $("#disc", view).innerHTML = discoveryBox();
      $("#srcsum", view).textContent = sourceSummary();
      $("#srcs", view).innerHTML = sourceRows();
      if (!info.job || !["queued", "running"].includes(info.job.state)) $("#side", view).innerHTML = buildPanel(false);
      wire();
      watchDiscovery();
    }, 2000);
  }

  draw();
  if (info.job && ["queued", "running"].includes(info.job.state)) poll();
  watchDiscovery();
  return () => { alive = false; clearTimeout(timer); clearTimeout(dtimer); };
}
