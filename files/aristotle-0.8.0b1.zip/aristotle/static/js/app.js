// App shell: sidebar, router, command palette, and polling while a build runs.
import {$, $$, api, avatar, debounce, esc, fmt, icon, toast, typing} from "./ui.js";
import * as home from "./views/home.js";
import * as sources from "./views/sources.js";
import * as ask from "./views/ask.js";
import * as map from "./views/map.js";
import * as rate from "./views/rate.js";
import * as council from "./views/council.js";

export const store = {people: [], councils: [], current: null, info: null};
let cleanup = null, pollTimer = null;

/* ---------- appearance: mode, surface, accent and text size ---------- */
// Swatches show each choice in light and dark; the values mirror tokens.css.
const MODES = {system: "System", light: "Light", dark: "Dark"};
const SURFACES = {neutral: ["Neutral", "#ffffff", "#111113"], paper: ["Paper", "#fbf9f4", "#161412"],
  slate: ["Slate", "#fafbfc", "#0f1217"], sage: ["Sage", "#f9faf7", "#111411"]};
const ACCENTS = {graphite: ["Graphite", "#19191c", "#ececef"], forest: ["Forest", "#1f6b47", "#6fcf9a"],
  clay: ["Clay", "#b04a26", "#f0956c"], plum: ["Plum", "#7b3f98", "#c79ae0"], teal: ["Teal", "#0f6e6e", "#5ccbc6"]};
const SIZES = {small: "Small", default: "Default", large: "Large"};
const DEFAULT_LOOK = {mode: "system", surface: "neutral", accent: "graphite", size: "default"};
let saving = Promise.resolve();  // saves go one at a time, so quick clicks can't land out of order
let look = (() => {
  try { return {...DEFAULT_LOOK, ...(JSON.parse(localStorage.getItem("appearance") || "null") || {mode: localStorage.getItem("theme") || "system"})}; }
  catch { return {...DEFAULT_LOOK}; }
})();

function setLook(patch, save = true) {
  look = {...look, ...patch};
  window.applyAppearance(look);
  try { localStorage.setItem("appearance", JSON.stringify(look)); } catch {}
  const chosen = look;
  if (save) saving = saving.then(() => api("/api/appearance", chosen)).catch(() => {});
  if ($(".appearance")) drawAppearance();
}
async function loadLook() {
  const saved = await api("/api/appearance").catch(() => null);
  if (!saved) return;
  if (Object.keys(saved).length) setLook(saved, false);
  else if (!store.guest) api("/api/appearance", look).catch(() => {});  // first run of this version: keep the old choice
}
function toggleTheme() {
  setLook({mode: document.documentElement.dataset.theme === "dark" ? "light" : "dark"});
}

function drawAppearance() {
  const box = $(".appearance");
  const dark = document.documentElement.dataset.theme === "dark";
  const seg = (key, opts, label) => `<div class="lbl">${label}</div>
    <div class="seg" role="group" aria-label="${label}">${Object.entries(opts).map(([v, l]) =>
      `<button type="button" data-${key}="${v}" aria-pressed="${look[key] === v}">${l}</button>`).join("")}</div>`;
  const swatches = (key, opts, label) => `<div class="lbl">${label}</div>
    <div class="swatches" role="group" aria-label="${label}">${Object.entries(opts).map(([v, [l, light, darkC]]) =>
      `<button type="button" data-${key}="${v}" aria-pressed="${look[key] === v}" title="${l}">
        <span class="sw ${key}" style="--c:${dark ? darkC : light}">${look[key] === v ? icon("check", "sm") : ""}</span><span>${l}</span></button>`).join("")}</div>`;
  box.innerHTML = `<h3>Appearance</h3>
    ${seg("mode", MODES, "Mode")}
    ${swatches("surface", SURFACES, "Background")}
    ${swatches("accent", ACCENTS, "Accent")}
    ${seg("size", SIZES, "Text size")}
    <p class="meta">Quotes from sources stay in blue serif in every theme, so you can always tell them apart.</p>
    <button class="btn sm ghost" id="look-reset" ${Object.keys(DEFAULT_LOOK).every(k => look[k] === DEFAULT_LOOK[k]) ? "disabled" : ""}>Reset to default</button>`;
  for (const key of Object.keys(DEFAULT_LOOK))
    $$(`[data-${key}]`, box).forEach(b => b.onclick = () => setLook({[key]: b.dataset[key]}));
  $("#look-reset", box).onclick = () => setLook(DEFAULT_LOOK);
}
function toggleAppearance() {
  if ($(".appearance")) return $(".appearance").remove();
  $(".about")?.remove();
  const box = document.createElement("div");
  box.className = "appearance"; box.setAttribute("role", "dialog"); box.setAttribute("aria-label", "Appearance");
  document.body.append(box);
  drawAppearance();
}
document.addEventListener("mousedown", e => { if ($(".appearance") && !e.target.closest(".appearance, #theme")) $(".appearance").remove(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") $(".appearance")?.remove(); });
matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => { if ($(".appearance")) drawAppearance(); });

/* ---------- library + sidebar ---------- */
export async function refreshLibrary() {
  const [lib, councils] = await Promise.all([api("/api/library"), api("/api/councils").catch(() => store.councils)]);
  store.people = lib.people;
  store.councils = councils;
  store.defaultSlug = lib.default;
  store.guest = !!lib.guest;
  document.documentElement.classList.toggle("guest", store.guest);
  drawSidebar();
  schedulePoll();
  return lib.people;
}

const building = p => p.job && ["queued", "running"].includes(p.job.state);

function drawSidebar() {
  const slug = store.current;
  $("#people").innerHTML = store.people.length ? store.people.map(p => {
    const meta = building(p) ? `${icon("loader-circle", "sm spin")}`
      : p.built ? `<span class="meta">${fmt(p.nodes)}</span>` : `<span class="meta">Draft</span>`;
    return `<a class="nav-item" href="#/p/${p.slug}" ${p.slug === slug ? 'aria-current="page"' : ""}>
      ${avatar(p, "xs")}<span class="name">${esc(p.name)}</span>${meta}</a>`;
  }).join("") : `<p class="faint" style="padding:0 8px;font-size:13px">Nobody yet. Add someone to start.</p>`;
  const built = store.people.filter(p => p.built).length;
  $("#councils").innerHTML = store.councils.map(c => `<a class="nav-item" href="#/c/${c.id}" ${location.hash.startsWith(`#/c/${c.id}`) ? 'aria-current="page"' : ""}>
      <span class="stack xs">${c.members.slice(0, 3).map(m => avatar(m, "xs")).join("")}</span><span class="name">${esc(c.name)}</span></a>`).join("")
    + (built >= 2 ? `<a class="nav-item" href="#/c/new" ${location.hash === "#/c/new" ? 'aria-current="page"' : ""}>${icon("plus")}<span class="name">New council</span></a>`
      : store.councils.length ? "" : `<p class="faint" style="padding:0 8px;font-size:13px">Build two people's maps to start a council.</p>`);
  $$(".nav-main .nav-item").forEach(a => a.setAttribute("aria-current", (location.hash || "#/") === a.getAttribute("href") ? "page" : "false"));
}

function schedulePoll() {
  clearTimeout(pollTimer);
  if (store.people.some(building)) pollTimer = setTimeout(async () => {
    const before = new Map(store.people.map(p => [p.slug, p.job?.state]));
    await refreshLibrary().catch(() => {});
    for (const p of store.people) {
      if (before.get(p.slug) === "running" && p.job?.state === "done") toast(`${p.name}'s map is ready: ${p.job.message}`);
      if (before.get(p.slug) === "running" && p.job?.state === "error") toast(`${p.name}'s build stopped: ${p.job.message}`, "bad");
    }
    window.dispatchEvent(new CustomEvent("library"));
  }, 2000);
}

/* ---------- router ---------- */
// #/            library        #/p/<slug>             a person (ask if built, else sources)
// #/add         library+search #/p/<slug>/<tab>[/<id>] ask | map | sources | blind
// #/c/new       new council    #/c/<id>[/edit]        a council
async function route() {
  if (cleanup) { try { cleanup(); } catch {} cleanup = null; }
  $(".app").classList.remove("nav-open");
  const [, a, slug, tab, id] = (location.hash || "#/").split("/");
  const main = $("#main");
  main.scrollTop = 0;
  if (a === "c" && slug) {
    store.current = null; store.info = null;
    drawSidebar();
    let edit = null;
    if (tab === "edit") edit = await api(`/api/councils/${slug}`).catch(() => null);
    cleanup = await (slug === "new" || edit ? council.mountNew(main, {store, refreshLibrary, edit})
      : council.mount(main, {id: slug, store, refreshLibrary}));
    return;
  }
  if (a !== "p" || !slug) {
    store.current = null; store.info = null;
    drawSidebar();
    cleanup = await home.mount(main, {focus: a === "add", refreshLibrary});
    return;
  }
  store.current = slug;
  drawSidebar();
  let info;
  try { info = store.info = await api(`/api/t/${slug}`); }
  catch (e) { main.innerHTML = `<div class="page"><p class="empty">That person isn't in your library. <a href="#/" style="text-decoration:underline">Back to the library</a></p></div>`; return; }
  const tabs = [["ask", "message-square-text", "Ask", info.built], ["map", "waypoints", "Map", info.built],
    ["sources", "file-text", "Sources", true], ["blind", "scale", "Blind test", info.has_blind && !store.guest]];
  const view = tabs.find(t => t[0] === tab && t[3]) ? tab : info.built ? "ask" : "sources";
  main.innerHTML = `<header class="topbar">
      <button class="btn ghost icon menu-btn" id="menu" aria-label="Open navigation">${icon("panel-left")}</button>
      <div class="who">${avatar(info, "sm")}<span>${esc(info.name)}</span></div>
      <nav class="tabs" aria-label="${esc(info.name)}">${tabs.filter(t => t[3]).map(([v, ic, label]) =>
        `<a class="tab" href="#/p/${slug}/${v}" ${v === view ? 'aria-current="page"' : ""}>${icon(ic, "sm")}<span class="label">${label}</span></a>`).join("")}</nav>
      <div class="spacer"></div><div id="topbar-actions"></div>
    </header><div id="view" style="display:contents"></div>`;
  $("#menu").onclick = () => $(".app").classList.add("nav-open");
  const views = {ask, map, sources, blind: rate};
  cleanup = await (views[view] || sources).mount($("#view"), {slug, info, id, refreshLibrary, store});
}
window.addEventListener("hashchange", route);
document.addEventListener("click", e => { if (e.target === $(".app") && $(".app").classList.contains("nav-open")) $(".app").classList.remove("nav-open"); });

/* ---------- command palette ---------- */
let palette = null;
export function openPalette(prefill = "") {
  if (palette) return;
  const scrim = document.createElement("div");
  scrim.className = "scrim";
  scrim.innerHTML = `<div class="palette" role="dialog" aria-modal="true" aria-label="Search">
    <div class="q">${icon("search", "lg")}<input id="pq" placeholder="Search the library or anyone on Wikipedia" autocomplete="off" aria-label="Search"></div>
    <div class="opts" id="popts" role="listbox"></div>
    <div class="foot"><span><kbd>↑</kbd><kbd>↓</kbd> move</span><span><kbd>↵</kbd> open</span><span><kbd>esc</kbd> close</span></div></div>`;
  document.body.append(scrim);
  palette = scrim;
  const input = $("#pq", scrim);
  input.value = prefill;
  let items = [], sel = 0, wiki = [], wikiQ = "", loading = false;

  const close = () => { scrim.remove(); palette = null; };
  scrim.addEventListener("mousedown", e => { if (e.target === scrim) close(); });

  function options() {
    const q = input.value.trim().toLowerCase();
    const cur = store.people.find(p => p.slug === store.current);
    const go = [{label: "Library", icon: "library", run: () => location.hash = "#/"},
      ...(cur?.built ? [{label: `Ask ${cur.name}`, icon: "message-square-text", run: () => location.hash = `#/p/${cur.slug}/ask`},
        {label: `${cur.name}'s map`, icon: "waypoints", run: () => location.hash = `#/p/${cur.slug}/map`}] : []),
      ...(cur ? [{label: `${cur.name}'s sources`, icon: "file-text", run: () => location.hash = `#/p/${cur.slug}/sources`}] : []),
      {label: "Appearance: colours and text size", icon: "sparkle", run: toggleAppearance},
      {label: "Switch between light and dark", icon: "sparkle", run: toggleTheme}];
    const people = store.people.map(p => ({label: p.name, sub: p.built ? `${fmt(p.nodes)} beliefs` : "Draft", img: p,
      run: () => location.hash = `#/p/${p.slug}`}));
    const councils = store.councils.map(c => ({label: c.name, sub: c.members.map(m => m.voice).join(", "), icon: "users",
      run: () => location.hash = `#/c/${c.id}`}));
    if (store.people.filter(p => p.built).length >= 2) go.push({label: "New council: ask several people at once", icon: "users", run: () => location.hash = "#/c/new"});
    const match = o => !q || o.label.toLowerCase().includes(q) || (o.sub || "").toLowerCase().includes(q);
    const groups = [["People", people.filter(match)], ["Councils", councils.filter(match)], ["Go to", go.filter(match)]];
    if (q.length > 1) {
      const add = wiki.filter(w => !w.slug).map(w => ({label: w.title, sub: w.description, img: w, add: true,
        run: () => addPerson(w.title)}));
      groups.push(["Add from Wikipedia", add.length ? add : [{label: loading ? "Searching Wikipedia" : wikiQ === q ? "No people found" : "Searching Wikipedia",
        icon: loading || wikiQ !== q ? "loader-circle" : "circle-alert", disabled: true}]]);
    }
    return groups.filter(g => g[1].length);
  }
  function draw() {
    const groups = options();
    items = groups.flatMap(g => g[1].filter(o => !o.disabled));
    sel = Math.min(sel, Math.max(0, items.length - 1));
    let i = 0;
    $("#popts", scrim).innerHTML = groups.map(([name, opts]) => `<div class="grp">${name}</div>` + opts.map(o => {
      const idx = o.disabled ? -1 : i++;
      const lead = o.img ? avatar(o.img, "sm") : icon(o.icon, o.icon === "loader-circle" ? "spin" : "");
      return `<div class="opt" role="option" data-i="${idx}" aria-selected="${idx === sel}" ${o.disabled ? 'aria-disabled="true"' : ""}>
        ${lead}<span class="txt">${esc(o.label)}${o.sub ? `<small>${esc(o.sub)}</small>` : ""}</span>${o.add ? `<span class="hint">Add</span>` : ""}</div>`;
    }).join("")).join("") || `<div class="grp">Nothing found</div>`;
    $$(".opt", scrim).forEach(el => {
      el.onmousemove = () => { if (+el.dataset.i >= 0 && sel !== +el.dataset.i) { sel = +el.dataset.i; mark(); } };
      el.onclick = () => { if (+el.dataset.i >= 0) { const o = items[+el.dataset.i]; close(); o.run(); } };
    });
  }
  const mark = () => $$(".opt", scrim).forEach(el => el.setAttribute("aria-selected", +el.dataset.i === sel));
  const search = debounce(async q => {
    if (q.length < 2) return;
    loading = true; draw();
    try { wiki = await api(`/api/people?q=${encodeURIComponent(q)}`); } catch { wiki = []; }
    wikiQ = q; loading = false;
    if (palette === scrim && input.value.trim().toLowerCase() === q) draw();
  }, 250);
  input.addEventListener("input", () => { sel = 0; draw(); search(input.value.trim().toLowerCase()); });
  input.addEventListener("keydown", e => {
    if (e.key === "Escape") { e.preventDefault(); close(); }
    else if (e.key === "ArrowDown") { e.preventDefault(); sel = Math.min(items.length - 1, sel + 1); mark(); $(`.opt[data-i="${sel}"]`, scrim)?.scrollIntoView({block: "nearest"}); }
    else if (e.key === "ArrowUp") { e.preventDefault(); sel = Math.max(0, sel - 1); mark(); $(`.opt[data-i="${sel}"]`, scrim)?.scrollIntoView({block: "nearest"}); }
    else if (e.key === "Enter" && items[sel]) { e.preventDefault(); const o = items[sel]; close(); o.run(); }
  });
  draw();
  if (prefill) search(prefill.toLowerCase());
  input.focus();
}

export async function addTradition(id, btn) {
  if (btn) { btn.disabled = true; btn.innerHTML = `${icon("loader-circle", "sm spin")} Setting up`; }
  try {
    const {slug} = await api("/api/traditions", {id});
    await refreshLibrary();
    location.hash = `#/p/${slug}/sources`;
  } catch (e) {
    toast(e.message, "bad");
    if (btn) { btn.disabled = false; btn.innerHTML = `${icon("plus", "sm")} Add`; }
  }
}

export async function addPerson(title, btn) {
  if (btn) { btn.disabled = true; btn.innerHTML = `${icon("loader-circle", "sm spin")} Finding sources`; }
  else toast(`Setting up ${title} and looking for sources`);
  try {
    const {slug} = await api("/api/people", {title});
    await refreshLibrary();
  loadLook();
    location.hash = `#/p/${slug}/sources`;
  } catch (e) {
    toast(e.message, "bad");
    if (btn) { btn.disabled = false; btn.innerHTML = `${icon("plus", "sm")} Add`; }
  }
}

document.addEventListener("keydown", e => {
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); palette ? null : openPalette(); }
});

/* ---------- connecting the user's own Claude account ---------- */
// The app answers with Claude Code on this Mac, signed in to the user's own subscription. Until
// that's true, a setup card explains the two steps and checks again on its own.
const PLANS = {pro: "Pro", max: "Max", team: "Team", enterprise: "Enterprise", free: "Free"};
let connectTimer = null;
async function checkClaude(quiet = false) {
  let st;
  try { st = await api("/api/claude"); } catch { return; }
  const pill = $("#claude-state");
  if (st.backend !== "cli") { pill.classList.add("hidden"); return; }
  pill.classList.remove("hidden");
  pill.classList.toggle("off", !st.ready);
  pill.innerHTML = st.ready ? `<span class="dot"></span>Claude ${esc(PLANS[st.plan] || "")} connected`
    : `<span class="dot"></span>Claude not connected`;
  pill.title = st.email || "";
  pill.onclick = st.ready ? null : () => showConnect(st);
  if (st.ready) {
    if ($(".scrim.connecting")) { $(".scrim.connecting").remove(); clearInterval(connectTimer); toast(`Connected to Claude${st.plan ? ` ${PLANS[st.plan] || st.plan}` : ""}`); }
  } else if (!quiet || ($(".scrim.connecting") && $(".scrim.connecting").dataset.installed !== String(st.installed))) showConnect(st);
}

function showConnect(st) {
  let scrim = $(".scrim.connecting");
  if (!scrim) {
    scrim = document.createElement("div");
    scrim.className = "scrim connecting";
    document.body.append(scrim);
    clearInterval(connectTimer);
    connectTimer = setInterval(() => checkClaude(true), 2500);
  }
  scrim.dataset.installed = String(st.installed);  // polling redraws only when this changes
  const install = "curl -fsSL https://claude.ai/install.sh | bash";
  scrim.innerHTML = `<div class="connect" role="dialog" aria-modal="true" aria-labelledby="connect-h">
    <h2 id="connect-h">Connect your Claude account</h2>
    <p>Aristotle thinks with Claude, on your own Claude subscription (Pro or Max). Your library and conversations stay on this Mac.</p>
    <ol>
      <li class="${st.installed ? "done" : ""}"><span class="n">${st.installed ? icon("check", "sm") : 1}</span><div>
        <b>Install Claude Code</b>
        ${st.installed ? `<span>Installed.</span>` : `<span>Open Terminal, paste this, and press Return.</span>
          <div class="cmd"><code>${esc(install)}</code><button class="btn sm" id="copy">Copy</button></div>`}</div></li>
      <li class="${st.installed ? "" : "dim"}"><span class="n">2</span><div>
        <b>Sign in with your Claude account</b>
        <span>Your browser opens claude.ai. Approve it there, then come back.</span>
        <div class="row-btns"><button class="btn primary" id="signin" ${st.installed ? "" : "disabled"}>Sign in with Claude</button></div></div></li>
    </ol>
    <p class="fine">Builds and answers count toward your plan's usage limits, the same as using Claude yourself. This window closes on its own once you're connected.</p>
  </div>`;
  $("#copy", scrim)?.addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(install); $("#copy", scrim).textContent = "Copied"; } catch { toast("Select the command and copy it", "bad"); }
  });
  $("#signin", scrim)?.addEventListener("click", async e => {
    const b = e.currentTarget;
    b.disabled = true; b.innerHTML = `${icon("loader-circle", "sm spin")} Waiting for you in the browser`;
    try { await api("/api/claude/login", {}); } catch (err) { toast(err.message, "bad"); b.disabled = false; b.textContent = "Sign in with Claude"; }
  });
}

/* ---------- feedback: a bug or an idea, sent straight to the maker ---------- */
function openFeedback() {
  if ($(".fb-panel")) return closeFeedback();
  let kind = "bug", email = "";
  try { email = localStorage.getItem("fb-email") || ""; } catch {}
  const panel = document.createElement("form");
  panel.className = "fb-panel";
  panel.setAttribute("role", "dialog"); panel.setAttribute("aria-label", "Send feedback");
  const draw = () => {
    panel.innerHTML = `<h3>Help make Aristotle better</h3>
      <div class="seg" role="group" aria-label="Kind"><button type="button" data-k="bug" aria-pressed="${kind === "bug"}">Something broke</button><button type="button" data-k="idea" aria-pressed="${kind === "idea"}">An idea</button></div>
      <textarea id="fb-msg" required placeholder="${kind === "bug" ? "What happened, and what did you expect?" : "What would make this more useful?"}" aria-label="Your message"></textarea>
      <input class="input" id="fb-email" type="email" placeholder="Your email, if you'd like a reply" value="${esc(email)}" aria-label="Your email (optional)">
      <label class="fb-opt"><input type="checkbox" class="check" id="fb-details" checked> Include the app version and recent errors</label>
      <div class="foot"><button type="button" class="btn ghost" id="fb-cancel">Cancel</button><button class="btn primary" id="fb-send">Send</button></div>`;
    $$("[data-k]", panel).forEach(b => b.onclick = () => { const msg = $("#fb-msg", panel).value; email = $("#fb-email", panel).value; kind = b.dataset.k; draw(); $("#fb-msg", panel).value = msg; $("#fb-msg", panel).focus(); });
    $("#fb-cancel", panel).onclick = closeFeedback;
  };
  draw();
  panel.onsubmit = async e => {
    e.preventDefault();
    const message = $("#fb-msg", panel).value.trim();
    if (!message) return;
    email = $("#fb-email", panel).value.trim();
    try { localStorage.setItem("fb-email", email); } catch {}
    const b = $("#fb-send", panel); b.disabled = true; b.innerHTML = `${icon("loader-circle", "sm spin")} Sending`;
    try {
      const r = await api("/api/feedback", {kind, message, email, page: location.hash || "#/", details: $("#fb-details", panel).checked});
      closeFeedback();
      toast(r.sent ? "Sent. Thank you." : "Saved. It'll send next time you're online.");
    } catch (err) { toast(err.message, "bad"); b.disabled = false; b.textContent = "Send"; }
  };
  panel.addEventListener("keydown", e => { if (e.key === "Escape") closeFeedback(); });
  document.body.append(panel);
  $("#fb-msg", panel).focus();
}
function closeFeedback() { $(".fb-panel")?.remove(); $("#fb")?.focus(); }
document.addEventListener("mousedown", e => { if ($(".fb-panel") && !e.target.closest(".fb-panel, #fb")) closeFeedback(); });

/* ---------- updates: stable or beta, applied with one restart ---------- */
let upd = null;
const CH = {stable: "Stable", beta: "Beta"};
async function refreshUpdate(fn = () => api("/api/update")) {
  try { upd = await fn(); } catch { return; }
  if (!upd.enabled) return;
  const ver = $("#ver");
  ver.classList.remove("hidden");
  ver.textContent = `v${upd.version}${upd.channel === "beta" ? " beta" : ""}`;
  const box = $("#update-ready");
  if (upd.ready) box.innerHTML = `<div class="update-ready"><b>Update ready: ${esc(upd.ready)}</b>
      ${upd.available?.notes ? `<span>${esc(upd.available.notes)}</span>` : ""}
      <button class="btn sm primary" id="restart">Restart to update</button></div>`;
  else if (upd.needs_download) box.innerHTML = `<div class="update-ready"><b>Aristotle ${esc(upd.available.version)} is out</b>
      <span>This one needs a fresh download.</span><a class="btn sm" href="${esc(upd.needs_download)}" target="_blank" rel="noopener">Download</a></div>`;
  else box.innerHTML = "";
  $("#restart")?.addEventListener("click", restartForUpdate);
  if ($(".about")) drawAbout();
}

async function restartForUpdate() {
  const cover = document.createElement("div");
  cover.className = "restarting";
  cover.innerHTML = `<div>${icon("loader-circle", "spin")} Restarting with the update</div>`;
  document.body.append(cover);
  const before = upd.version;
  try { await api("/api/update/restart", {}); } catch (e) { cover.remove(); return toast(e.message, "bad"); }
  const start = Date.now();
  const poll = setInterval(async () => {
    try {
      const u = await api("/api/update");
      if (u.version !== before) { clearInterval(poll); location.reload(); }
    } catch {}
    if (Date.now() - start > 30000) { clearInterval(poll); cover.innerHTML = `<div>Aristotle restarted in a new window. You can close this one.</div>`; }
  }, 1000);
}

function drawAbout() {
  const box = $(".about");
  if (!box || !upd) return;
  const line = upd.checking ? `${icon("loader-circle", "sm spin")} Checking`
    : upd.ready ? `Version ${esc(upd.ready)} is ready. Restart to use it.`
    : upd.needs_download ? `Version ${esc(upd.available.version)} needs a fresh download.`
    : upd.error ? `Couldn't check for updates: ${esc(upd.error)}`
    : upd.checked_at ? "You're up to date." : "";
  box.innerHTML = `<h3>Aristotle ${esc(upd.version)}</h3>
    <p class="meta">Runs on your own Claude subscription. Your library is in the Aristotle folder in your home folder.</p>
    <div class="lbl">Updates</div>
    <div class="seg" role="group" aria-label="Update channel">${Object.entries(CH).map(([v, l]) =>
      `<button type="button" data-ch="${v}" aria-pressed="${upd.channel === v}">${l}</button>`).join("")}</div>
    <p class="meta">${upd.channel === "beta" ? "You get new versions early, before everyone else. They may have rough edges." : "You get versions once they've been tested."}</p>
    <p class="status">${line}</p>
    <button class="btn" id="check" ${upd.checking ? "disabled" : ""}>Check for updates</button>`;
  $$("[data-ch]", box).forEach(b => b.onclick = () => {
    if (b.dataset.ch === upd.channel) return;
    upd.checking = true; drawAbout();
    refreshUpdate(() => api("/api/update/channel", {channel: b.dataset.ch}));
  });
  $("#check", box).onclick = () => { upd.checking = true; drawAbout(); refreshUpdate(() => api("/api/update/check", {})); };
}

function toggleAbout() {
  if ($(".about")) return $(".about").remove();
  $(".appearance")?.remove();
  const box = document.createElement("div");
  box.className = "about"; box.setAttribute("role", "dialog"); box.setAttribute("aria-label", "About Aristotle");
  document.body.append(box);
  drawAbout();
}
document.addEventListener("mousedown", e => { if ($(".about") && !e.target.closest(".about, #ver")) $(".about").remove(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") $(".about")?.remove(); });

/* ---------- start ---------- */
$("#search-trigger").onclick = () => openPalette();
$("#theme").onclick = toggleAppearance;
$("#fb").onclick = openFeedback;
$("#ver").onclick = toggleAbout;
(async () => {
  await refreshLibrary();
  loadLook();
  if (!store.guest) checkClaude();
  if (!store.guest) { refreshUpdate(); setInterval(() => refreshUpdate(), 5 * 60 * 1000); }
  if (!location.hash && store.defaultSlug) location.hash = `#/p/${store.defaultSlug}`;
  else route();
})();
