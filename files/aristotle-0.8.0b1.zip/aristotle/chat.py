"""Answer a scenario from the map, then verify the answer before showing it.

Reasoning loop (PRD): (1) find the beliefs in play, (2) walk the graph for supporting and
conflicting beliefs, (3) apply the thinker's tradeoff weights, (4) draft in the thinker's framing,
(5) verify every claim against the map. If the map is silent, say so instead of guessing.
"""
from __future__ import annotations

import re

import numpy as np

from .embed import Embedder
from .ingest import norm
from .llm import parse_json
from .schema import EpistemeMap, Node

ANSWER_SYSTEM = """You reason about a user's real decision using ONLY the beliefs of {thinker} \
listed below, which were extracted from their published words. You are not {thinker}; you apply \
their published worldview, and you show your work.

Voice: {voice}.

Method:
1. Pick the beliefs that actually bear on the user's specifics. Ignore the rest. Build the \
answer on the most fundamental ones (marked "core": they are central to {thinker}'s worldview) \
and use narrower beliefs and cases as support, not as the backbone.
2. Find where they pull against each other (see RELATIONS and conflicts_with/outweighs) and how \
{thinker} ranks them. Value nodes are tradeoff weights; use them to settle conflicts.
3. Apply them to the user's constraints (money, time, people, stage of life) as they stated them. \
If a belief has a boundary or caveat node, respect it. When two statements conflict, prefer the \
more recent dated one and say so.
4. Give a clear view: what {thinker}'s framework points toward and why, in plain language.
5. Do not flatter. If the beliefs point against what the user seems to want, say so directly. \
Name the strongest counterpoint from the beliefs.

Citations: put the belief id in square brackets right after each claim that rests on it, \
like [n0012]. Every substantive claim needs one. Only use ids from the list.
Quotes: only put text in quotation marks if it is copied word for word from a "quote" field \
below. Never invent a quote or attribute a sentence to {thinker} that isn't there.
Coverage: if the beliefs below don't really address the situation, set "not_covered" to true \
and say plainly what the sources don't cover instead of improvising.
Keep the answer under about 250 words unless the user asks for more.

Return JSON only:
{{"answer": str, "cited": [ids used], "tension": str (the main conflict between beliefs, or ""), \
"uncertainty": str (where {thinker}'s view is uncertain, limited, or changed, or where the \
user's case falls outside it), "not_covered": bool, \
"advice_domain": "none" | "medical" | "legal" | "financial"}}"""

# A council turn: the other members answered the same question; this one replies to them.
RESPOND_SYSTEM = """You are one voice on a council: several thinkers' or traditions' published \
worldviews answering the same question side by side. You speak ONLY from the beliefs of \
{thinker} listed below, extracted from their own words. You are not {thinker}; you apply their \
worldview and show your work. The other voices ({names}) have answered; their words are below.

Voice: {voice}.

Reply to them, as in a respectful conversation:
1. Where {thinker}'s beliefs agree with what they said, say so specifically, and note when they \
reach the same place for different reasons.
2. Where {thinker}'s beliefs diverge or would push back, say how and why, citing the beliefs.
3. What {thinker}'s beliefs add that the others missed, if anything.
Refer to the others by name. Describe their positions only as their text states them: never \
quote them, never attribute words or ideas to them that aren't in their text, never cite their \
ids. Don't try to win or to merge the views into one; real differences are worth seeing. \
If {thinker}'s beliefs don't bear on a point, don't comment on it.

Citations: put the belief id in square brackets right after each claim that rests on it, \
like [n0012]. Every substantive claim about {thinker} needs one. Only use ids from the list.
Quotes: only put text in quotation marks if it is copied word for word from a "quote" field below.
Keep it under about 180 words.

Return JSON only:
{{"answer": str, "cited": [ids used], "tension": "", "uncertainty": str (where the comparison \
is uncertain, or ""), "not_covered": bool, "advice_domain": "none"}}"""

THEMES_SYSTEM = """List 6 to 10 short themes, concepts or principles (single words or short \
phrases) that a thoughtful person would need to reason about the situation below, including ones \
the user did not name. Return a JSON list of strings only."""

# Same voice and length as Aristotle, so a blind rater can't tell them apart by style alone; the
# only difference is the map.
GATE_SYSTEM = """You check which of {thinker}'s beliefs bear on a user's question. A belief bears \
on it if someone applying {thinker}'s worldview would actually use it to answer: it addresses \
the question's subject, or a principle that clearly governs the decision. Shared words are not \
enough. If the question is a how-to, technical, factual or trivia question with an objective \
answer (repairs, code, science facts, recipes, tax filing, geography), return an empty list \
even if some belief is loosely related: {thinker}'s worldview isn't what answers it. Only \
decisions, values, judgment, life and work choices get beliefs. Return JSON only: \
{{"relevant": [ids]}}"""

BASELINE_SYSTEM = """Answer as {thinker} would, applying their known views to the user's \
situation. Write in third person ("{thinker}'s framework suggests..."). Keep it under about 250 \
words."""

VOICES = {
    "third": "third person (\"{t}'s framework suggests...\"); never speak as {t}",
    "first": "first person, as if {t} were speaking, while staying strictly inside the beliefs below",
    "scripture": "third person, attributing each teaching to the text (\"In the Gospels, Jesus teaches...\", "
                 "\"The Quran says...\"). Never speak as the figure or as God. Be respectful and present "
                 "what the text says, not whether it is true; don't rank this tradition against others. "
                 "Readers within the tradition interpret these passages in different ways: say so where it "
                 "matters, and never present one reading as a religious ruling",
}

ID_RE = re.compile(r"\[(n\d{4})\]")


class Thinker:
    centrality_weight = 0.06  # cosine gaps between good candidates are ~0.02-0.08 on bge-small

    def __init__(self, llm, emap: EpistemeMap, voice: str = "third", top_k: int = 10,
                 hops: int = 6, min_sim: float | None = None, embedder: Embedder | None = None):
        self.llm, self.map, self.voice, self.top_k, self.hops = llm, emap, voice, top_k, hops
        self.nodes = emap.live_nodes()
        self.emb = embedder or Embedder([self._doc(n) for n in self.nodes])
        # cosine cutoffs differ by embedding space; tuned on the Naval map (see eval/README.md)
        # embedding floor: below this, skip even the gate. Relevance itself is decided by `gate`
        # because raw cosine can't separate in-scope from out-of-scope (eval/coverage).
        self.min_sim = min_sim if min_sim is not None else (0.08 if self.emb.backend == "tfidf" else 0.5)
        # centrality: how load-bearing a belief is in the worldview (links + independent sources).
        # Without it a niche aside outranks a core principle whenever its wording matches better.
        deg = {}
        for e in emap.edges:
            deg[e.src] = deg.get(e.src, 0) + 1
            deg[e.dst] = deg.get(e.dst, 0) + 1
        c = np.array([np.log1p(deg.get(n.id, 0)) + np.log(len(n.sources)) for n in self.nodes])
        self.centrality = c / c.max() if len(c) and c.max() > 0 else c
        self.core = set(np.argsort(-self.centrality)[:60]) if len(c) else set()
        self.core_ids = {self.nodes[i].id for i in self.core}
        self.history: list[dict] = []
        self.user_turns: list[str] = []
        self.carried: list[str] = []  # ids cited last turn, kept in context for pushback

    @staticmethod
    def _doc(n: Node) -> str:
        return n.statement + " " + " ".join(s.quote for s in n.sources[:2])

    def themes(self, scenario: str) -> list[str]:
        try:
            out = parse_json(self.llm.complete(THEMES_SYSTEM, scenario, max_tokens=300, tier="fast"))
            return [str(t) for t in out][:10] if isinstance(out, list) else []
        except ValueError:
            return []

    def retrieve(self, scenario: str) -> tuple[list[Node], float]:
        """Hybrid retrieval: embed the situation (plus earlier turns) and LLM-expanded themes,
        take the top matches, then add graph neighbours, preferring conflict and priority edges."""
        if not self.nodes:
            return [], 0.0
        situation = " ".join(self.user_turns[-3:] + [scenario])
        themes = self.themes(situation)
        sims = self.emb.sims([situation] + themes)
        direct = sims[0]
        score = 0.6 * direct + 0.4 * sims[1:].max(axis=0) if themes else direct
        best = float(direct.max())
        ranked = score + self.centrality_weight * self.centrality
        order = [i for i in np.argsort(-ranked)[: self.top_k + 6] if score[i] >= self.min_sim]
        # offer the gate the worldview's core beliefs that are at least loosely on topic
        core = sorted((i for i in self.core if i not in order and score[i] >= self.min_sim + 0.05),
                      key=lambda i: -ranked[i])[:8]
        picked = self.gate(situation, [self.nodes[i] for i in order + core])
        if not picked:
            return [], best
        ids = {n.id for n in picked}
        for cid in self.carried:  # pushback must reason over what was said before
            if cid not in ids and (n := self.map.node(cid)) and n.review != "rejected":
                picked.append(n)
                ids.add(cid)
        rank = {"conflicts_with": 0, "outweighs": 1, "derives_from": 2, "supports": 3}
        cands = sorted(((rank[e.kind], nid) for n in picked[: self.top_k]
                        for nid, e in self.map.neighbors(n.id) if nid not in ids))
        added = 0
        for _, nid in cands:
            nb = self.map.node(nid)
            if nid not in ids and nb and nb.review != "rejected" and added < self.hops:
                picked.append(nb)
                ids.add(nid)
                added += 1
        return picked, best

    def gate(self, situation: str, cands: list[Node]) -> list[Node]:
        """Keep only candidates the fast model judges relevant, at most top_k, in rank order."""
        if not cands:
            return []
        listing = "\n".join(f"[{n.id}] {n.statement}" for n in cands)
        try:
            out = parse_json(self.llm.complete(
                GATE_SYSTEM.format(thinker=self.map.thinker),
                f"QUESTION:\n{situation}\n\nBELIEFS:\n{listing}", max_tokens=400, tier="fast"))
            keep = set(out.get("relevant") or []) if isinstance(out, dict) else set()
        except ValueError:
            keep = {n.id for n in cands}  # gate failed: fall back to embedding order
        return [n for n in cands if n.id in keep][: self.top_k]

    def _context(self, nodes: list[Node]) -> str:
        ids = {n.id for n in nodes}
        lines = []
        for n in nodes:
            s = sorted(n.sources, key=lambda s: (s.tier, s.date or "9999"))[0]
            when = f", {n.first_seen}" + (f" to {n.last_seen}" if n.last_seen != n.first_seen else "") \
                if n.first_seen else ""
            core = ", core" if n.id in self.core_ids else ""
            lines.append(f"[{n.id}] ({n.kind}{core}{when}) {n.statement}\n    quote: \"{s.quote}\"")
        rels = [f"{e.src} {e.kind} {e.dst}" + (f" ({e.note})" if e.note else "")
                for e in self.map.edges if e.src in ids and e.dst in ids]
        return "\n".join(lines) + ("\n\nRELATIONS:\n" + "\n".join(rels) if rels else "")

    def verify(self, reply: dict, nodes: list[Node]) -> list[str]:
        """Return a list of problems; empty means the answer is grounded."""
        problems = []
        valid = {n.id for n in nodes}
        text = f"{reply.get('answer', '')} {reply.get('tension', '')} {reply.get('uncertainty', '')}"
        cited = set(reply.get("cited") or []) | set(ID_RE.findall(text))
        for cid in sorted(cited - valid):
            problems.append(f"cited id {cid} is not one of the provided beliefs")
        if not cited and not reply.get("not_covered"):
            problems.append("no beliefs cited")
        allowed = norm(" ".join(s.quote for n in nodes for s in n.sources))
        for q in re.findall(r"[\"“]([^\"”]{25,})[\"”]", text):
            # a span that starts with a space or holds a citation id is the gap *between* two
            # quotes (closing mark paired with the next opening mark), not a quotation
            if q[:1].isspace() or ID_RE.search(q):
                continue
            if norm(q.rstrip(".,")) not in allowed:
                problems.append(f"quoted text not found in sources: \"{q[:60]}...\"")
        return problems

    def _not_covered(self, best: float, text: str = "") -> dict:
        return {"answer": text or f"The sources I have don't clearly cover this, so I won't guess "
                                  f"what {self.map.thinker} would say.", "cited": [], "tension": "",
                "uncertainty": "", "not_covered": True, "advice_domain": "none",
                "verified": True, "problems": [], "retrieval_score": best, "sources": {},
                "considered": []}

    def ask(self, scenario: str) -> dict:
        nodes, best = self.retrieve(scenario)
        if not nodes:  # nothing relevant: say so instead of letting the model improvise
            return self._not_covered(best)
        system = ANSWER_SYSTEM.format(
            thinker=self.map.thinker, voice=VOICES[self.voice].format(t=self.map.thinker))
        user = f"BELIEFS:\n{self._context(nodes)}\n\nUSER'S SITUATION:\n{scenario}"
        return self._reply(system, user, nodes, best, scenario, scenario)

    def respond(self, question: str, others: list[tuple[str, str]]) -> dict:
        """A council turn: answer the other members' replies to the same question, from this
        thinker's own beliefs only. `others` is [(name, what they said)], citations stripped."""
        said = "\n\n".join(f"{name}:\n{text}" for name, text in others)
        nodes, best = self.retrieve(f"{question}\n\n{said[:3000]}")
        if not nodes:
            return self._not_covered(best, f"The sources behind {self.map.thinker} don't speak to "
                                           "what the others raised, so there's nothing grounded to add.")
        names = ", ".join(name for name, _ in others)
        system = RESPOND_SYSTEM.format(
            thinker=self.map.thinker, names=names, voice=VOICES[self.voice].format(t=self.map.thinker))
        user = (f"BELIEFS:\n{self._context(nodes)}\n\nTHE USER'S QUESTION:\n{question}\n\n"
                f"WHAT THE OTHER VOICES SAID:\n{said}")
        return self._reply(system, user, nodes, best, f"(Respond to {names})",
                           f"Respond to what {names} said about: {question}")

    def _reply(self, system: str, user: str, nodes: list[Node], best: float, turn: str,
               history_user: str) -> dict:
        """Draft, verify, retry once; then record the turn so follow-ups keep the context."""
        reply, problems = {}, []
        for _ in range(2):
            prompt = user if not problems else (
                user + "\n\nYour last reply had problems, fix them: " + "; ".join(problems))
            try:
                reply = parse_json(self.llm.complete(system, prompt, history=self.history))
            except ValueError:
                reply, problems = {"answer": "", "cited": []}, ["reply was not valid JSON"]
                continue
            if not isinstance(reply, dict):
                reply, problems = {"answer": "", "cited": []}, ["reply was not a JSON object"]
                continue
            problems = self.verify(reply, nodes)
            if not problems:
                break
        text = f"{reply.get('answer', '')} {reply.get('tension', '')} {reply.get('uncertainty', '')}"
        cited = list(dict.fromkeys(list(reply.get("cited") or []) + ID_RE.findall(text)))
        reply["cited"] = [c for c in cited if self.map.node(c)]
        reply["verified"] = not problems
        reply["problems"] = problems
        reply["retrieval_score"] = best
        reply["considered"] = [n.id for n in nodes]
        reply["sources"] = {cid: self.source_card(self.map.node(cid)) for cid in reply["cited"]}
        self.user_turns.append(turn)
        self.carried = reply["cited"]
        self.history += [
            {"role": "user", "content": history_user},
            {"role": "assistant", "content": reply.get("answer", "")},
        ]
        return reply

    @staticmethod
    def source_card(n: Node) -> dict:
        s = sorted(n.sources, key=lambda s: (s.tier, s.date or "9999"))[0]
        return {"statement": n.statement, "kind": n.kind, "quote": s.quote, "section": s.section,
                "origin": s.origin, "date": s.date, "tier": s.tier, "n_sources": len(n.sources)}


def baseline_answer(llm, thinker: str, scenario: str) -> str:
    """The thing Aristotle must beat: a plain model prompted to answer as the thinker."""
    return llm.complete(BASELINE_SYSTEM.format(thinker=thinker), scenario)
