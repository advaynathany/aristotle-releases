"""Where a person's own words live, beyond Wikiquote and Gutenberg. Each finder returns candidate
dicts (see discover.py) and never raises: a source that is down just finds nothing.

  site_posts(site, ...)        their own website: WordPress, or any RSS/Atom feed (Substack, Medium...)
  wikisource(qid)              public-domain speeches, letters and essays on English Wikisource
  internet_archive(name, ...)  public-domain books with full text on the Internet Archive
  openalex(name, profile)      open-access papers, for academics
  youtube_talks(name)          talks and interviews with captions (spoken words, tier 2)
  web_search(llm, cfg, have)   Claude searches the web for essays, speeches, letters, transcripts
  x_archive(data)              an X/Twitter archive .zip, one tweet per paragraph with its date

Fetching a remote candidate's text happens in `fetch_text`, called by discover.materialize when a
build starts. Downloaded text is the author's copyright unless it is public domain: personal use only.
"""
from __future__ import annotations

import html
import io
import json
import re
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime

from bs4 import BeautifulSoup

from .ingest import INTERVIEWER, clean

BROWSER = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 "
                         "(KHTML, like Gecko) Version/17.0 Safari/605.1.15"}
API_UA = {"User-Agent": "Aristotle/0.8 (personal research tool)"}
MIN_TEXT = 600  # characters of real text a page needs to count as a source
ACADEMIC = re.compile(r"histor|scien|economist|professor|philosoph|physic|research|scholar|mathematic|"
                      r"psycholog|sociolog|biolog|chemist|linguist|anthropolog|academic|theorist|"
                      r"political scientist|neuroscien|astronom|geolog|engineer|computer scientist", re.I)
TALK = re.compile(r"\b(lecture|talk|speech|keynote|address|commencement|sermon|testimony|ted\b|tedx|"
                  r"remarks|lesson|class|seminar|masterclass)", re.I)
ABOUT = re.compile(r"\b(documentary|quotes|biography|life of|story of|history of|explained|summary|"
                   r"reads?|reading|audiobook|animated|reaction|tribute|who was|death of)\b", re.I)
MIXED = re.compile(r"\b(interview|conversation|podcast|panel|debate|q&a|discussion|in dialogue|"
                   r"fireside|with|and|vs\.?|feat)\b", re.I)


def _get(url: str, timeout: int = 30, headers: dict | None = None, limit: int | None = None) -> tuple[bytes, str]:
    req = urllib.request.Request(url, headers=headers or API_UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return (r.read(limit) if limit else r.read()), r.headers.get("Content-Type", "")


def _json(url: str, timeout: int = 30):
    return json.loads(_get(url, timeout)[0].decode())


def words(s: str) -> set[str]:
    return {w for w in re.findall(r"[a-z]+", s.lower()) if len(w) > 2}


def plain_name(name: str) -> str:
    name = re.sub(r"\s*\(.*?\)", "", name)
    return re.sub(r"\b(the (younger|elder|great))\b", "", name, flags=re.I).strip()


def text_of(el) -> str:
    """An element's text with inline tags spaced, but no space before punctuation."""
    return re.sub(r"\s+([,.;:!?)\]’”])", r"\1", clean(el.get_text(" ")))


def cid(*parts: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", "-".join(parts).lower()).strip("-")[:64]


# ---------- pages, the common case ----------

def english(text: str) -> bool:
    """Roughly: mostly Latin letters and common English words (the map is built in English)."""
    letters = re.findall(r"[^\W\d_]", text[:5000])
    latin = sum(c.isascii() for c in letters)
    common = len(re.findall(r"\b(the|and|of|to|that|is|in|it)\b", text[:5000].lower()))
    return bool(letters) and latin / len(letters) > 0.9 and common > len(letters) / 200

def tag_speakers(paras: list[str], person: str) -> list[str]:
    """Interview pages label turns ("Q:", "Tyler Cowen:"). Lines from anyone but the person become
    INTERVIEWER context, so a question is never mistaken for their belief. Unlabelled pages pass through."""
    mine = words(plain_name(person))
    out, current = [], None
    for p in paras:
        m = re.match(r"^\s*(Q|A|Question|Answer|Interviewer|[A-Z][A-Za-z.'-]+(?: [A-Z][A-Za-z.'-]+){0,2})\s*[:：]\s+", p)
        if m and len(p) > m.end():
            label = m.group(1)
            current = "them" if label in ("A", "Answer") or words(label) & mine else "other"
            p = p[m.end():]
        out.append(INTERVIEWER + p if current == "other" else p)
    return out


def read_page(url: str, person: str = "") -> dict | None:
    """Main text of an article/transcript page, or the bytes of a PDF. None when there isn't enough."""
    try:
        data, ctype = _get(url, timeout=45, headers=BROWSER, limit=40_000_000)
    except Exception:
        return None
    if data[:5] == b"%PDF-" or "pdf" in ctype:
        if data[:5] != b"%PDF-" or len(data) < 5000:
            return None
        chars = pdf_chars(data)
        if chars < MIN_TEXT:  # a scan with no text layer: nothing to quote
            return None
        return {"pdf": data, "title": "", "date": "", "chars": chars}
    import trafilatura

    page = data.decode("utf-8", errors="ignore")
    doc = trafilatura.bare_extraction(page, url=url, with_metadata=True, include_comments=False)
    doc = doc.as_dict() if hasattr(doc, "as_dict") else (doc or {})
    text = (doc.get("text") or "").strip()
    if len(text) < MIN_TEXT or not english(text):
        return None
    paras = [clean(p) for p in re.split(r"\n+", text) if clean(p)]
    return {"paras": tag_speakers(paras, person) if person else paras,
            "title": clean(doc.get("title") or ""), "date": (doc.get("date") or "")[:10]}


def pdf_chars(data: bytes) -> int:
    """Estimated characters of text in a PDF, from a sample of its pages."""
    import pdfplumber

    try:
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            n = len(pdf.pages)
            sample = [pdf.pages[i] for i in sorted({0, n // 3, n // 2, (2 * n) // 3, n - 1})]
            per = sum(len(pg.extract_text() or "") for pg in sample) / len(sample)
            return int(per * n)
    except Exception:
        return 0


# ---------- their own website ----------

def find_feed(site: str) -> str | None:
    """An RSS/Atom feed for a site: the page's <link rel=alternate>, then the usual paths."""
    try:
        page, _ = _get(site, timeout=20, headers=BROWSER, limit=2_000_000)
        soup = BeautifulSoup(page, "html.parser")
        for link in soup.find_all("link", rel="alternate"):
            if re.search(r"rss|atom", link.get("type", ""), re.I) and link.get("href"):
                return urllib.parse.urljoin(site, link["href"])
    except Exception:
        pass
    base = site.rstrip("/")
    for path in ("/feed", "/rss", "/feed.xml", "/atom.xml", "/index.xml", "/rss.xml"):
        try:
            data, ctype = _get(base + path, timeout=15, headers=BROWSER, limit=200_000)
            if re.search(rb"<(rss|feed)\b", data[:2000]):
                return base + path
        except Exception:
            continue
    return None


def feed_items(feed: str, limit: int = 40) -> list[dict]:
    """[{title, url, date, html}] from RSS or Atom, newest first as the feed lists them."""
    try:
        root = ET.fromstring(_get(feed, timeout=30, headers=BROWSER)[0])
    except Exception:
        return []
    out = []
    strip = lambda t: t.split("}", 1)[-1]
    for el in root.iter():
        if strip(el.tag) not in ("item", "entry"):
            continue
        f = {strip(c.tag): c for c in el}
        link = f.get("link")
        url = (link.get("href") or link.text or "").strip() if link is not None else ""
        body = next((f[k].text for k in ("encoded", "content", "description", "summary")
                     if k in f and f[k].text and len(f[k].text) > 400), "")
        when = next((f[k].text for k in ("pubDate", "published", "updated", "date") if k in f and f[k].text), "")
        out.append({"title": clean(html.unescape(f["title"].text or "")) if "title" in f else url,
                    "url": url, "date": _iso(when), "html": body})
        if len(out) >= limit:
            break
    return out


def _iso(when: str) -> str:
    when = (when or "").strip()
    for fmt in ("%a, %d %b %Y %H:%M:%S %z", "%a, %d %b %Y %H:%M:%S %Z", "%Y-%m-%dT%H:%M:%S%z"):
        try:
            return datetime.strptime(when, fmt).date().isoformat()
        except ValueError:
            pass
    m = re.match(r"\d{4}-\d{2}-\d{2}", when)
    return m.group(0) if m else ""


def feed_posts(site: str, person: str, limit: int = 40) -> list[dict]:
    """Posts from a site's feed, each read into paragraphs (from the feed's full text when it has
    it, else from the page). Returns ready-to-write items: {title, url, date, paras}."""
    feed = find_feed(site)
    if not feed:
        return []
    items = feed_items(feed, limit)

    def one(it):
        if it["html"] and len(BeautifulSoup(it["html"], "html.parser").get_text()) > 1500:
            soup = BeautifulSoup(it["html"], "html.parser")
            paras = [text_of(p) for p in soup.find_all(["p", "li", "blockquote"])
                     if not p.find_parent(["li", "blockquote"])]
            paras = tag_speakers([p for p in paras if p], person)
            if sum(map(len, paras)) >= MIN_TEXT:
                return {**it, "paras": paras}
        page = read_page(it["url"], person) if it["url"] else None
        return {**it, "paras": page["paras"]} if page and "paras" in page else None
    with ThreadPoolExecutor(6) as pool:
        return [x for x in pool.map(one, items) if x]


# ---------- Wikisource ----------

SKIP_WS = re.compile(r"about|biograph|portrait|external|see also|translations of|works by others", re.I)


def wikisource(qid: str, limit: int = 12) -> list[dict]:
    """Works listed on the person's Wikisource author page (speeches, letters, essays, books)."""
    if not qid:
        return []
    try:
        e = _json("https://www.wikidata.org/w/api.php?" + urllib.parse.urlencode(
            {"action": "wbgetentities", "ids": qid, "props": "sitelinks", "sitefilter": "enwikisource", "format": "json"}))
        author = e["entities"][qid]["sitelinks"]["enwikisource"]["title"]
        page = _json("https://en.wikisource.org/w/api.php?" + urllib.parse.urlencode(
            {"action": "parse", "page": author, "prop": "text", "format": "json", "redirects": 1}))
    except Exception:
        return []
    root = BeautifulSoup(page["parse"]["text"]["*"], "html.parser")
    out, seen, skipping = [], set(), False
    for el in root.find_all(["h2", "h3", "li"]):
        if el.name in ("h2", "h3"):
            skipping = bool(SKIP_WS.search(el.get_text()))
            continue
        a = el.find("a", href=re.compile(r"^/wiki/[^:]+$"))
        if skipping or not a or "new" in (a.get("class") or []):
            continue
        title = urllib.parse.unquote(a["href"][6:]).replace("_", " ")
        other = re.search(r"\(([^)]*)\)$", title)  # "The Rainbow (Byron)": someone else's work
        if title in seen or title.startswith("Author") or "/" in title or \
                (other and not words(other.group(1)) & words(author) and not re.search(r"\d", other.group(1))):
            continue
        seen.add(title)
        year = re.search(r"\b(1[0-9]{3}|20[0-2][0-9])\b", el.get_text())
        out.append({"id": cid("wikisource", title), "kind": "wikisource", "title": clean(a.get_text()) or title,
                    "url": f"https://en.wikisource.org/wiki/{urllib.parse.quote(title.replace(' ', '_'))}",
                    "page": title, "date": year.group(0) if year else "",
                    "detail": "Public-domain text on Wikisource"})
        if len(out) >= limit:
            break
    return out


def _ws_paras(title: str) -> tuple[list[str], list[str]]:
    page = _json("https://en.wikisource.org/w/api.php?" + urllib.parse.urlencode(
        {"action": "parse", "page": title, "prop": "text", "format": "json", "redirects": 1}), timeout=60)
    root = BeautifulSoup(page["parse"]["text"]["*"], "html.parser")
    for junk in root.select(".ws-header, .wst-header, #headertemplate, .ws-noexport, .reference, .mw-editsection, table"):
        junk.decompose()
    paras = [text_of(p) for p in root.find_all(["p", "dd", "blockquote"])]
    subs = [urllib.parse.unquote(a["href"][6:]).replace("_", " ") for a in root.find_all("a", href=True)
            if a["href"].startswith("/wiki/" + urllib.parse.quote(title.replace(" ", "_"), safe="(),'") + "/")]
    return [p for p in paras if len(p) > 1], list(dict.fromkeys(subs))


def wikisource_text(title: str) -> str:
    """A Wikisource work as paragraphs; multi-part works are read part by part (up to 60)."""
    paras, subs = _ws_paras(title)
    if sum(map(len, paras)) < 3000 and subs:
        for sub in subs[:60]:
            try:
                more, _ = _ws_paras(sub)
            except Exception:
                continue
            paras += [f"§ {sub.split('/', 1)[-1]}"] + more
    return "\n\n".join(paras)


# ---------- Internet Archive ----------

def creator_is(creator: str, name: str) -> bool:
    """'Franklin, Benjamin, 1706-1790' or 'Benjamin Franklin' is him; 'Benjamin Franklin Finkel' isn't."""
    parts = re.findall(r"[a-z]+", name.lower())
    first, last = parts[0], parts[-1]
    c = creator.lower()
    return bool(re.match(rf"\s*{last},\s*{first}\b(?!\s+[a-z]{{3,}},)", c) or
                re.match(rf"\s*{re.escape(' '.join(parts))}\s*($|[,;(\d])", c))


def internet_archive(name: str, skip_titles: list[set[str]], born: int | None = None, limit: int = 3) -> list[dict]:
    """Public-domain (not lending-only) English texts whose first creator is the person."""
    name = plain_name(name)
    want = words(name)
    q = (f'creator:("{name}") AND mediatype:texts AND NOT access-restricted-item:true '
         'AND (language:eng OR language:English)')
    try:
        docs = _json("https://archive.org/advancedsearch.php?" + urllib.parse.urlencode(
            [("q", q), ("fl[]", "identifier"), ("fl[]", "title"), ("fl[]", "creator"), ("fl[]", "year"),
             ("sort[]", "downloads desc"), ("rows", "30"), ("output", "json")]), timeout=25)["response"]["docs"]
    except Exception:
        return []
    picked, keys = [], list(skip_titles)
    for d in docs:
        creator = d["creator"][0] if isinstance(d.get("creator"), list) else d.get("creator", "")
        title = clean(str(d.get("title", "")))
        key = words(title) - want - {"the", "and", "with", "works", "complete", "volume", "vol"}
        year = int(str(d.get("year"))[:4]) if str(d.get("year", ""))[:4].isdigit() else None
        if not creator_is(creator, name) or not key or any(key <= k or k <= key for k in keys):
            continue
        if born and year and year < born + 12:  # a namesake from before they could write
            continue
        keys.append(key)
        picked.append({**d, "title": title})
        if len(picked) >= limit * 2:
            break

    def with_text(d):
        try:
            files = _json(f"https://archive.org/metadata/{d['identifier']}/files", timeout=20)["result"]
        except Exception:
            return None
        txt = next((f for f in files if f["name"].endswith("_djvu.txt")), None)
        if not txt or int(txt.get("size") or 0) < 20_000:
            return None
        return {"id": cid("archive", d["identifier"]), "kind": "archive", "title": d["title"][:140],
                "url": f"https://archive.org/download/{d['identifier']}/{urllib.parse.quote(txt['name'])}",
                "date": str(d.get("year") or ""), "size": int(txt["size"]),
                "detail": "Public-domain book from the Internet Archive (scanned text)"}
    with ThreadPoolExecutor(6) as pool:
        return [x for x in pool.map(with_text, picked) if x][:limit]


# ---------- OpenAlex (academics) ----------

def openalex(name: str, profile: dict, limit: int = 6) -> list[dict]:
    """Their most-cited open-access papers with a PDF. Only for people Wikipedia calls a scholar of
    some kind, since common names match strangers' papers otherwise."""
    if not ACADEMIC.search(f"{profile.get('description', '')} {profile.get('extract', '')[:300]}"):
        return []
    name = plain_name(name)
    try:
        found = _json("https://api.openalex.org/authors?" + urllib.parse.urlencode({"search": name, "per_page": 10}))["results"]
    except Exception:
        return []
    exact = [a for a in found if clean(a["display_name"]).lower() == name.lower()]
    if not exact:
        return []
    author = max(exact, key=lambda a: a.get("works_count", 0))["id"].rsplit("/", 1)[-1]
    try:
        works = _json("https://api.openalex.org/works?" + urllib.parse.urlencode(
            {"filter": f"author.id:{author},is_oa:true", "sort": "cited_by_count:desc", "per_page": 40}))["results"]
    except Exception:
        return []
    out = []
    for w in works:
        pdf = ((w.get("best_oa_location") or {}).get("pdf_url") or "")
        n = len(w.get("authorships") or [])
        if not pdf or n > 3 or not w.get("title") or w.get("language") not in (None, "en"):
            continue
        out.append({"id": cid("paper", w["id"].rsplit("/", 1)[-1]), "kind": "paper", "title": clean(w["title"])[:140],
                    "url": pdf, "date": str(w.get("publication_year") or ""),
                    "detail": "Open-access paper" + (f" with {n - 1} co-author{'s' if n > 2 else ''}" if n > 1 else "")})
        if len(out) >= limit:
            break
    return out


# ---------- YouTube ----------

def youtube_talks(name: str, died: int | None = None, limit: int = 6) -> list[dict]:
    """Talks whose title names the person. Captions carry no speaker labels, so only solo talks
    (lecture, speech, keynote...) are ticked; interviews and panels are listed with a warning.
    Nothing for people who died before their voice could be recorded and posted."""
    if died and died < 1935:
        return []
    try:
        import yt_dlp
    except ImportError:
        return []
    name = plain_name(name)
    full = re.compile(r"\b" + r"\W+".join(map(re.escape, name.lower().split())) + r"\b")
    seen, out = set(), []
    opts = {"quiet": True, "no_warnings": True, "extract_flat": True, "skip_download": True}
    for q in (f'"{name}" speech OR lecture OR keynote OR talk', f'"{name}" interview'):
        try:
            with yt_dlp.YoutubeDL(opts) as y:
                found = y.extract_info(f"ytsearch12:{q}", download=False).get("entries") or []
        except Exception:
            continue
        for e in found:
            title = e.get("title") or ""
            if not e.get("id") or e["id"] in seen or not full.search(title.lower()) or \
                    ABOUT.search(title) or not 300 < (e.get("duration") or 0) < 4 * 3600:
                continue
            seen.add(e["id"])
            out.append(video_candidate(e["id"], title, e.get("channel") or "", name))
    solo = [v for v in out if v["solo"]]
    return (solo + [v for v in out if not v["solo"]])[:limit]


def video_candidate(vid: str, title: str, channel: str, name: str) -> dict:
    rest = re.sub(re.escape(plain_name(name)), "", title, flags=re.I)
    solo = bool(TALK.search(title)) and not MIXED.search(rest)
    return {"id": cid("youtube", vid), "kind": "video", "title": clean(title)[:140],
            "url": f"https://www.youtube.com/watch?v={vid}", "solo": solo,
            "detail": ("Talk captions" if solo else "Captions with other voices mixed in, no speaker labels") +
                      (f", {channel}" if channel else "")}


def youtube_text(url: str) -> tuple[str, str, str]:
    """(title, date, paragraphs) from a video's captions, human-made when there are any."""
    import yt_dlp

    with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "skip_download": True}) as y:
        info = y.extract_info(url, download=False)
    tracks = None
    for pool in (info.get("subtitles") or {}, info.get("automatic_captions") or {}):
        lang = next((k for k in pool if k == "en" or k.startswith("en-")), None)
        if lang:
            tracks = pool[lang]
            break
    track = next((t for t in tracks or [] if t.get("ext") == "json3"), None)
    if not track:
        raise ValueError("This video has no English captions.")
    events = json.loads(_get(track["url"], timeout=60)[0])["events"]
    paras, cur, last = [], [], 0
    for ev in events:
        text = clean("".join(s.get("utf8", "") for s in ev.get("segs") or []))
        text = re.sub(r"\[(music|applause|laughter|inaudible)\]", "", text, flags=re.I).strip()
        if not text:
            continue
        start = ev.get("tStartMs", 0)
        if cur and (start - last > 2500 or sum(map(len, cur)) > 700):
            paras.append(" ".join(cur))
            cur = []
        cur.append(text)
        last = start + ev.get("dDurationMs", 0)
    if cur:
        paras.append(" ".join(cur))
    d = info.get("upload_date") or ""
    return info.get("title") or url, f"{d[:4]}-{d[4:6]}-{d[6:]}" if len(d) == 8 else "", "\n\n".join(paras)


# ---------- the web, searched by Claude ----------

SEARCH_SYSTEM = """You find primary sources: the person's OWN words, in full, free to read online.
Search the web; never guess a URL you have not seen in search results or fetched. English-language
texts only (an English translation is fine). Return ONLY a JSON array."""

SEARCH_PROMPT = """Find up to 25 web pages or PDFs where {name} ({description}) speaks or writes in their own words, in full.

Good: essays, op-eds, blog posts, open letters and shareholder letters, speeches and their official
transcripts, lecture or talk transcripts, interview or podcast transcripts (Q&A), testimony,
commencement addresses, papers, free full-text books or PDFs, and YouTube recordings of their talks.
Bad: articles about them, summaries, quote collections (BrainyQuote, Goodreads), paywalled or
login-only pages, social media profiles, shop pages, Wikipedia, Wikiquote, and Project Gutenberg
(already covered).

Prefer the original host (their site, the publisher, a government or university archive), and spread
across their life and topics rather than ten pieces on one theme.
{context}
Reply with only a JSON array, best first:
[{{"url": "...", "title": "...", "kind": "essay|speech|letter|transcript|interview|paper|book|video", "year": "YYYY or empty"}}]
(today is {today})"""


def web_search(llm, cfg: dict, have: list[str]) -> list[dict]:
    """Ask Claude (with WebSearch/WebFetch) for primary sources. Raw suggestions; discover validates them."""
    from .llm import parse_json

    prof = cfg.get("profile", {})
    ctx = []
    if prof.get("extract"):
        ctx.append("Who they are: " + prof["extract"][:600])
    if prof.get("website"):
        ctx.append(f"Their website: {prof['website']}")
    if prof.get("works"):
        ctx.append("Notable works: " + "; ".join(prof["works"][:12]))
    if have:
        ctx.append("Already found (don't repeat): " + "; ".join(have[:30]))
    prompt = SEARCH_PROMPT.format(name=plain_name(cfg["name"]), description=prof.get("description") or "person",
                                  context="\n" + "\n".join(ctx) + "\n" if ctx else "", today=date.today().isoformat())
    try:
        found = parse_json(llm.complete(SEARCH_SYSTEM, prompt, tier="strong", tools=["WebSearch", "WebFetch"]))
    except Exception:
        return []
    out = []
    for f in found if isinstance(found, list) else []:
        if isinstance(f, dict) and re.match(r"https?://", str(f.get("url", ""))):
            out.append({"url": f["url"].strip(), "title": clean(str(f.get("title") or "")),
                        "kind": str(f.get("kind") or "essay").lower(), "year": str(f.get("year") or "")[:4]})
    return out


def life_years(qid: str) -> dict:
    """{'born': 1706, 'died': 1790} from Wikidata P569/P570 (either may be missing)."""
    out = {}
    for key, prop in (("born", "P569"), ("died", "P570")):
        try:
            c = _json("https://www.wikidata.org/w/api.php?" + urllib.parse.urlencode(
                {"action": "wbgetclaims", "entity": qid, "property": prop, "format": "json"}), timeout=15)
            t = c["claims"][prop][0]["mainsnak"]["datavalue"]["value"]["time"]
            out[key] = int(re.match(r"[+-]?(\d+)", t).group(1)) * (-1 if t.startswith("-") else 1)
        except Exception:
            pass
    return out


def notable_works(qid: str) -> list[str]:
    """Titles of the person's notable works (Wikidata P800), to steer the web search."""
    if not qid:
        return []
    try:
        c = _json("https://www.wikidata.org/w/api.php?" + urllib.parse.urlencode(
            {"action": "wbgetclaims", "entity": qid, "property": "P800", "format": "json"}), timeout=15)
        ids = [x["mainsnak"]["datavalue"]["value"]["id"] for x in c.get("claims", {}).get("P800", [])][:20]
        if not ids:
            return []
        e = _json("https://www.wikidata.org/w/api.php?" + urllib.parse.urlencode(
            {"action": "wbgetentities", "ids": "|".join(ids), "props": "labels", "languages": "en", "format": "json"}), timeout=15)
        return [v["labels"]["en"]["value"] for v in e["entities"].values() if "en" in v.get("labels", {})]
    except Exception:
        return []


# ---------- X / Twitter archive ----------

def x_archive(data: bytes) -> tuple[str, int]:
    """An X archive .zip (or its data/tweets.js) as a source file body: one tweet per paragraph,
    each with a [N] citation carrying its date. Retweets and very short tweets are left out."""
    import zipfile

    raws = []
    if data[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = [n for n in z.namelist() if re.search(r"(^|/)data/tweets?(-part\d+)?\.js$", n)]
            if not names:
                raise ValueError("That zip isn't an X archive: it has no data/tweets.js.")
            raws = [z.read(n).decode("utf-8", errors="ignore") for n in names]
    else:
        raws = [data.decode("utf-8", errors="ignore")]
    tweets = []
    for raw in raws:
        items = json.loads(raw[raw.index("["):])
        for it in items:
            t = it.get("tweet", it)
            text = html.unescape(t.get("full_text") or t.get("text") or "")
            if text.startswith("RT @"):
                continue
            text = clean(re.sub(r"https?://\S+", "", text))
            text = re.sub(r"^(@\w+\s+)+", "", text)  # reply prefixes
            if len(text) < 40:
                continue
            try:
                when = datetime.strptime(t["created_at"], "%a %b %d %H:%M:%S %z %Y").date().isoformat()
            except (KeyError, ValueError):
                when = ""
            tweets.append((when, text))
    if not tweets:
        raise ValueError("No tweets found in that archive.")
    tweets.sort()
    body = "\n\n".join(f"{text} [{i + 1}]" for i, (_, text) in enumerate(tweets))
    cites = "\n".join(f"[{i + 1}] Tweet, {when or 'undated'} | {when[:4]} | 1" for i, (when, _) in enumerate(tweets))
    return f"title: Tweets (X archive)\ntier: 1\n---\n{body}\n\n=== citations ===\n{cites}", len(tweets)
