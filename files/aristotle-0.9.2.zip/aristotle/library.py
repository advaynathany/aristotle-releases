"""The library: every folder in thinkers/ with a config.json is a person.

Also the build plumbing shared by the CLI and the web app: which chunks to read, how a capped
build picks passages spread across all sources, and saving a map without losing review decisions.
"""
from __future__ import annotations

import json
from pathlib import Path

from .schema import Chunk, EpistemeMap

GOLDEN = 0.6180339887


def people(root: Path) -> list[Path]:
    root = Path(root)
    return sorted((p for p in root.iterdir() if (p / "config.json").exists()), key=lambda p: p.name) \
        if root.is_dir() else []


def summary(folder: Path) -> dict:
    """What the library list needs, without loading the whole map."""
    folder = Path(folder)
    cfg = json.loads((folder / "config.json").read_text())
    prof = cfg.get("profile", {})
    out = {"slug": folder.name, "name": cfg["name"], "description": prof.get("description", ""),
           "image": prof.get("image", ""), "sources": len(cfg.get("sources", [])),
           "scripture": (cfg.get("tradition") or {}).get("text"),
           "nodes": 0, "edges": 0, "years": None, "built": False,
           "has_blind": (folder / "eval" / "blind.json").exists(), "job": read_job(folder)}
    meta = folder / "build.json"
    if meta.exists():
        out.update({k: v for k, v in json.loads(meta.read_text()).items() if k in ("nodes", "edges", "years", "passages")})
        out["built"] = (folder / "map.json").exists()
    elif (folder / "map.json").exists():  # built before build.json existed: count once and record
        m = EpistemeMap.load(folder / "map.json")
        years = sorted(n.first_seen[:4] for n in m.nodes if n.first_seen)
        info = {"nodes": len(m.nodes), "edges": len(m.edges),
                "years": [years[0], years[-1]] if years else None}
        meta.write_text(json.dumps(info))
        out.update(info, built=True)
    return out


def read_job(folder: Path) -> dict | None:
    p = Path(folder) / "job.json"
    return json.loads(p.read_text()) if p.exists() else None


def selected_sources(cfg: dict) -> list[dict]:
    """Sources to read. A candidate the user unticked keeps its file but is left out."""
    off = {c.get("file") for c in cfg.get("candidates", []) if not c.get("selected", True)}
    return [s for s in cfg["sources"] if s["file"] not in off]


def load_chunks(folder: Path, exclude_origins: list[str] | None = None, log=print) -> list[Chunk]:
    from .ingest import ingest

    folder = Path(folder)
    cfg = json.loads((folder / "config.json").read_text())
    chunks: list[Chunk] = []
    for src in selected_sources(cfg):
        path = folder / "sources" / src["file"]
        if not path.exists():
            log(f"missing source: {path} (see README)")
            continue
        chunks += ingest(path, src["id"], src.get("tier", 1), src.get("date", ""),
                         skip_sections=cfg.get("skip_sections"), exclude_origins=exclude_origins,
                         skip_front=src.get("skip_front", 0.0))
    return chunks


def pick_chunks(chunks: list[Chunk], already: set[str], n: int | None,
                first: list[str] | None = None) -> list[Chunk]:
    """The chunks a capped build reads: everything already built plus up to n new ones, taken in
    turn from each source at well-spread positions so a starter map covers the whole corpus.
    `first` (chunk ids stating the person's signature ideas, see signature.py) fills up to a
    third of the new passages before the spread."""
    if n is None:
        return chunks
    lead = [cid for cid in (first or []) if cid not in already][: n // 3]
    already = already | set(lead)
    n -= len(lead)
    by_source: dict[str, list[Chunk]] = {}
    for c in chunks:
        if c.id not in already:
            by_source.setdefault(c.source_id, []).append(c)
    queues = [sorted(cs, key=lambda c, cs=cs: (cs.index(c) * GOLDEN) % 1) for cs in by_source.values()]
    new: list[Chunk] = []
    while len(new) < n and any(queues):
        for q in queues:
            if q and len(new) < n:
                new.append(q.pop(0))
    keep = already | {c.id for c in new}
    return [c for c in chunks if c.id in keep]  # `lead` is in `already` now, so it is kept too


def save_map(folder: Path, emap: EpistemeMap, out: str = "map.json", built_ids: list[str] | None = None) -> dict:
    """Write the map, carrying review decisions over from the previous build, and record what it
    covers in build.json so the library never has to load a map just to list it."""
    folder = Path(folder)
    old = folder / out
    if old.exists():
        reviewed = {n.statement: n for n in EpistemeMap.load(old).nodes if n.review != "auto"}
        for n in emap.nodes:
            if n.statement in reviewed:
                n.review, n.note = reviewed[n.statement].review, reviewed[n.statement].note
    emap.save(folder / out)
    if out != "map.json":
        return {}
    years = sorted(n.first_seen[:4] for n in emap.nodes if n.first_seen)
    info = {"nodes": len(emap.nodes), "edges": len(emap.edges),
            "years": [years[0], years[-1]] if years else None}
    if built_ids is not None:
        info.update(passages=len(built_ids), chunk_ids=built_ids)
    (folder / "build.json").write_text(json.dumps(info))
    return info


def built_ids(folder: Path) -> set[str]:
    p = Path(folder) / "build.json"
    if not p.exists():
        return set()
    ids = json.loads(p.read_text()).get("chunk_ids")
    if ids is None and (Path(folder) / "chunks.json").exists():  # a full CLI build covered everything
        return {c["id"] for c in json.loads((Path(folder) / "chunks.json").read_text())}
    return set(ids or [])
