// Small shared helpers: escaping, icons, avatars, formatting, toasts, the API client.

export const $ = (s, el = document) => el.querySelector(s);
export const $$ = (s, el = document) => [...el.querySelectorAll(s)];
export const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
export const fmt = n => (n ?? 0).toLocaleString("en-US");
export const cap = s => s ? s[0].toUpperCase() + s.slice(1) : "";
export const plural = (n, one, many = one + "s") => `${fmt(n)} ${n === 1 ? one : many}`;

export const icon = (name, cls = "") => `<svg class="i ${cls}" aria-hidden="true"><use href="/static/icons.svg#i-${name}"/></svg>`;

export const KINDS = ["principle", "heuristic", "value", "case", "boundary"];
export const PLURAL = {principle: "Principles", heuristic: "Heuristics", value: "Values", case: "Cases", boundary: "Boundaries"};
export const kdot = k => `<span class="dot" style="--k:var(--k-${esc(k)})"></span>`;

// What "Ask ___" names: a first name, "the Buddha", or "the Quran" (its words are not the
// Prophet's own speech, so his entry is asked as the text)
export function shortName(info) {
  const t = info?.tradition;
  if (t) return t.lens.startsWith("the ") ? t.lens : info.name.replace(/^The /, "the ");
  return (info?.name || "").replace(/\s*\(.*\)/, "").split(" ")[0];
}

export function avatar(p, size = "") {
  const initials = (p?.name || p?.title || "?").replace(/\(.*?\)/g, "").trim().split(/\s+/).map(w => w[0]).slice(0, 2).join("");
  if (!p?.image && p?.scripture) return `<span class="avatar ${size} glyph" aria-hidden="true">${icon("book-open")}</span>`;
  return p?.image
    ? `<img class="avatar ${size}" src="${esc(p.image)}" alt="" loading="lazy" referrerpolicy="no-referrer">`
    : `<span class="avatar ${size}" aria-hidden="true">${esc(initials)}</span>`;
}

export function yearsText(y) {
  if (!y) return "";
  return y[0] === y[1] ? y[0] : `${y[0]} to ${y[1]}`;
}

export async function api(path, body, method) {
  const opts = body instanceof FormData ? {method: "POST", body}
    : body !== undefined ? {method: method || "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)}
    : {method: method || "GET"};
  const r = await fetch(path, opts);
  if (r.status === 401) location.href = "/login";  // the password cookie expired
  if (!r.ok) {
    const detail = (await r.json().catch(() => ({}))).detail;
    const err = new Error(typeof detail === "string" ? detail : r.statusText);
    err.status = r.status;
    throw err;
  }
  return r.json();
}

export function toast(msg, kind = "") {
  let box = $(".toasts");
  if (!box) { box = document.createElement("div"); box.className = "toasts"; box.setAttribute("role", "status"); document.body.append(box); }
  const t = document.createElement("div");
  t.className = `toast ${kind}`;
  t.innerHTML = `${icon(kind === "bad" ? "circle-alert" : "circle-check-big")}<span>${esc(msg)}</span>`;
  box.append(t);
  setTimeout(() => t.remove(), kind === "bad" ? 6000 : 3200);
}

export function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

// Whether a keystroke should be left alone because the person is typing somewhere.
export const typing = () => /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName) || document.activeElement?.isContentEditable;

// A confirmation dialog for anything destructive. Resolves true only on the confirm button;
// Escape, the scrim and Cancel all resolve false. Focus starts on Cancel, so Enter never deletes
// by accident.
export function confirmDialog({title, body = "", confirm = "Delete", danger = true}) {
  return new Promise(resolve => {
    const before = document.activeElement;
    const scrim = document.createElement("div");
    scrim.className = "scrim dialog-scrim";
    scrim.innerHTML = `<div class="dialog" role="alertdialog" aria-modal="true" aria-labelledby="dlg-h" aria-describedby="dlg-b">
      <div class="dialog-icon ${danger ? "danger" : ""}">${icon(danger ? "trash-2" : "circle-alert")}</div>
      <h2 id="dlg-h">${esc(title)}</h2><div id="dlg-b">${body}</div>
      <div class="dialog-btns"><button class="btn" data-no>Cancel</button><button class="btn ${danger ? "danger" : "primary"}" data-yes>${esc(confirm)}</button></div></div>`;
    document.body.append(scrim);
    const done = ok => { scrim.remove(); document.removeEventListener("keydown", key, true); before?.focus?.(); resolve(ok); };
    const key = e => {
      if (e.key === "Escape") { e.preventDefault(); done(false); }
      if (e.key === "Tab") {  // keep focus inside the dialog
        const b = [...scrim.querySelectorAll("button")];
        const i = b.indexOf(document.activeElement);
        e.preventDefault(); b[(i + (e.shiftKey ? -1 : 1) + b.length) % b.length].focus();
      }
    };
    document.addEventListener("keydown", key, true);
    scrim.querySelector("[data-no]").onclick = () => done(false);
    scrim.querySelector("[data-yes]").onclick = () => done(true);
    scrim.onmousedown = e => { if (e.target === scrim) done(false); };
    scrim.querySelector("[data-no]").focus();
  });
}
