// Decision journal: decisions saved from answers, what you planned to do, and what happened.
// Entries come due on their follow-up date; recording the outcome closes them.
import {$, $$, api, avatar, esc, icon, toast} from "../ui.js";

const FOLLOWED = [["yes", "Followed it"], ["partly", "Partly"], ["no", "Went another way"]];
const RESULTS = [["better", "Better than expected"], ["expected", "About as expected"], ["worse", "Worse than expected"]];
const day = d => d ? new Date(d + "T12:00").toLocaleDateString("en-US", {month: "short", day: "numeric", year: "numeric"}) : "";

export async function mount(main, ctx) {
  main.innerHTML = `<header class="topbar"><button class="btn ghost icon menu-btn" id="menu" aria-label="Open navigation">${icon("panel-left")}</button>
      <div class="who"><span>Decision journal</span></div><div class="spacer"></div></header><div class="page journal" id="jv"></div>`;
  $("#menu").onclick = () => $(".app").classList.add("nav-open");
  const people = new Map(ctx.store.people.map(p => [p.slug, p]));
  let entries = (await api("/api/journal")).entries;

  const outcomeText = o => `${FOLLOWED.find(f => f[0] === o.followed)?.[1]}. ${RESULTS.find(r => r[0] === o.result)?.[1]}.`;

  function list() {
    const due = entries.filter(e => e.due), open = entries.filter(e => !e.due && !e.outcome), done = entries.filter(e => e.outcome);
    const row = e => `<a class="j-row" href="#/j/${e.id}">${avatar(people.get(e.slug) || {name: e.person}, "sm")}
        <div class="txt"><b>${esc(e.question)}</b><span>${esc(e.person)} · ${day(e.created)}${e.plan ? ` · You planned: ${esc(e.plan.slice(0, 90))}` : ""}</span></div>
        ${e.outcome ? `<span class="badge ${e.outcome.result === "worse" ? "bad" : "ok"}">${esc(RESULTS.find(r => r[0] === e.outcome.result)?.[1])}</span>`
          : e.due ? `<span class="badge warn">${icon("bell", "sm")} Follow up</span>` : `<span class="faint">${icon("calendar", "sm")} ${day(e.follow_up)}</span>`}</a>`;
    const sec = (title, sub, xs) => xs.length ? `<section class="section"><div class="section-head"><h2>${title}</h2><p>${sub}</p></div><div class="list">${xs.map(row).join("")}</div></section>` : "";
    $("#jv").innerHTML = `<div class="page-head"><h1>Decisions, and how they turned out.</h1>
        <p>Save an answer from Ask when you're deciding something real. On the follow-up date, come back and note what happened, so you learn which advice holds up.</p></div>
      ${entries.length ? sec("Ready for a follow-up", "Their dates have come", due) + sec("Waiting", "You'll see these again on their follow-up date", open) + sec("Closed", "Outcomes recorded", done)
        : `<p class="empty">Nothing saved yet. After an answer in Ask, choose “Save to journal”.</p>`}`;
  }

  function one(id) {
    const e = entries.find(x => x.id === id);
    if (!e) { $("#jv").innerHTML = `<p class="empty">That entry is gone. <a href="#/j" style="text-decoration:underline">Back to the journal</a></p>`; return; }
    $("#jv").innerHTML = `<a class="back" href="#/j">${icon("arrow-left", "sm")} Journal</a>
      <div class="j-entry">
        <div class="who">${avatar(people.get(e.slug) || {name: e.person}, "sm")}<span>Asked ${esc(e.person)} on ${day(e.created)}</span></div>
        <h1>${esc(e.question)}</h1>
        <div class="said"><h3>What the answer said</h3><p>${esc(e.answer).replace(/\s*\[n\d{4}\]/g, "").replace(/\n+/g, "</p><p>")}</p>
          ${e.cited?.length ? `<details><summary>${e.cited.length} cited ${e.cited.length === 1 ? "belief" : "beliefs"}</summary>${e.cited.map(c => `<div class="cite"><blockquote>${esc(c.quote)}</blockquote><span>${esc(c.statement)}</span></div>`).join("")}</details>` : ""}</div>
        <form id="plan" class="j-form"><label for="plantext"><h3>What you plan to do</h3></label>
          <textarea class="input" id="plantext" rows="3" placeholder="Your decision, in a sentence or two">${esc(e.plan)}</textarea>
          <div class="row"><label class="faint" for="fu">Follow up on</label><input class="input date" type="date" id="fu" value="${esc(e.follow_up)}">
            <button class="btn sm">Save</button></div></form>
        <form id="outcome" class="j-form"><h3>${e.outcome ? "What happened" : e.due ? "What happened?" : "When it's time: what happened?"}</h3>
          ${e.outcome ? `<p class="j-out"><b>${esc(outcomeText(e.outcome))}</b> Recorded ${day(e.outcome.recorded)}.</p>` : ""}
          <div class="seg" role="radiogroup" aria-label="Did you follow it">${FOLLOWED.map(([v, l]) => `<button type="button" data-f="${v}" aria-pressed="${e.outcome?.followed === v}">${l}</button>`).join("")}</div>
          <div class="seg" role="radiogroup" aria-label="How it went">${RESULTS.map(([v, l]) => `<button type="button" data-r="${v}" aria-pressed="${e.outcome?.result === v}">${l}</button>`).join("")}</div>
          <textarea class="input" id="outtext" rows="3" placeholder="What actually happened, and what you'd tell yourself next time">${esc(e.outcome?.text || "")}</textarea>
          <div class="row"><button type="button" class="btn sm ghost" id="del">${icon("trash-2", "sm")} Delete entry</button><span class="spacer"></span>
            <button class="btn sm primary">${e.outcome ? "Update outcome" : "Record outcome"}</button></div></form>
      </div>`;
    let followed = e.outcome?.followed, result = e.outcome?.result;
    $$("[data-f]").forEach(b => b.onclick = () => { followed = b.dataset.f; $$("[data-f]").forEach(x => x.setAttribute("aria-pressed", x === b)); });
    $$("[data-r]").forEach(b => b.onclick = () => { result = b.dataset.r; $$("[data-r]").forEach(x => x.setAttribute("aria-pressed", x === b)); });
    const save = async body => {
      const got = await api(`/api/journal/${e.id}`, body);
      entries = entries.map(x => x.id === e.id ? got : x);
      await ctx.refreshLibrary();
      return got;
    };
    $("#plan").onsubmit = async ev => {
      ev.preventDefault();
      try { await save({plan: $("#plantext").value, follow_up: $("#fu").value}); toast("Saved"); one(e.id); } catch (err) { toast(err.message, "bad"); }
    };
    $("#outcome").onsubmit = async ev => {
      ev.preventDefault();
      if (!followed || !result) return toast("Pick whether you followed it and how it went", "bad");
      try { await save({outcome: {followed, result, text: $("#outtext").value}}); toast("Outcome recorded"); one(e.id); } catch (err) { toast(err.message, "bad"); }
    };
    $("#del").onclick = async () => {
      if ($("#del").dataset.sure !== "1") { $("#del").dataset.sure = "1"; $("#del").innerHTML = `${icon("trash-2", "sm")} Click again to delete`; return; }
      await api(`/api/journal/${e.id}`, undefined, "DELETE");
      entries = entries.filter(x => x.id !== e.id);
      await ctx.refreshLibrary();
      location.hash = "#/j";
    };
  }
  ctx.id ? one(ctx.id) : list();
}
