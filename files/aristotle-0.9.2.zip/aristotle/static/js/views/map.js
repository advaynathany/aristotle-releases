// Map review: filter 1,000s of beliefs, check each against its verbatim source, follow its links,
// and approve or reject from the keyboard.
import {$, $$, KINDS, PLURAL, api, cap, esc, fmt, icon, kdot, toast, typing} from "../ui.js";

const REL = {supports: ["Supports", "Supported by"], derives_from: ["Follows from", "Leads to"],
  conflicts_with: ["Conflicts with", "Conflicts with"], outweighs: ["Outweighs", "Outweighed by"], changed_to: ["Later became", "Earlier view"]};

export async function mount(view, ctx) {
  const {slug} = ctx;
  view.innerHTML = `<div class="mapview" id="mv">
    <div class="listcol"><div class="filters">
      <div class="field-ico">${icon("search")}<input class="input" id="search" type="search" placeholder="Search beliefs and quotes" aria-label="Search beliefs and quotes"></div>
      <div class="chips" id="kinds"></div><div class="chips owner" id="reviews"></div>
      <div class="years" id="years"></div><div class="yearlabels" id="yearlabels"></div>
      <div class="count"><span id="mapcount" class="num">Loading the map</span><button class="hidden" id="clear">Clear filters</button></div>
    </div><div class="rows" id="rows" role="listbox" aria-label="Beliefs"></div></div>
    <div class="detail" id="detail"><div class="blank">
      <p>Every belief here was extracted from a passage and kept only because its quote appears word for word in the source.</p>
      <p>Check them against the source and reject anything that misreads it. Rejected beliefs are never used in answers.</p>
      <div class="keys"><span><kbd>J</kbd><kbd>K</kbd> move</span><span class="owner"><kbd>A</kbd> approve</span><span class="owner"><kbd>R</kbd> reject</span><span class="owner"><kbd>E</kbd> edit</span><span><kbd>/</kbd> search</span></div>
    </div></div></div>`;

  let MAP;
  try { MAP = await api(`/api/t/${slug}/map`); }
  catch (e) { $("#mapcount").textContent = e.message; return; }
  const byId = new Map(MAP.nodes.map(n => [n.id, n]));
  const F = {q: "", kind: "", review: "", year: ""};
  let ROWS = [], SEL = null;

  // filters
  const count = k => MAP.nodes.filter(n => n.kind === k).length;
  $("#kinds").innerHTML = KINDS.map(k => `<button class="chip" data-kind="${k}" aria-pressed="false">${kdot(k)}${PLURAL[k]} <span class="count">${fmt(count(k))}</span></button>`).join("");
  $("#reviews").innerHTML = [["auto", "Not reviewed"], ["approved", "Approved"], ["rejected", "Rejected"]].map(([v, l]) =>
    `<button class="chip" data-review="${v}" aria-pressed="false">${l} <span class="count" data-rc="${v}"></span></button>`).join("");
  const byYear = {};
  MAP.nodes.forEach(n => { const y = (n.first_seen || "").slice(0, 4); if (y) byYear[y] = (byYear[y] || 0) + 1; });
  const ys = Object.keys(byYear).map(Number);
  if (ys.length > 1) {
    const years = [];
    for (let y = Math.min(...ys); y <= Math.max(...ys); y++) years.push(String(y));
    const max = Math.max(...Object.values(byYear));
    $("#years").innerHTML = years.map(y => `<button data-year="${y}" aria-pressed="false" title="${y}: ${fmt(byYear[y] || 0)} beliefs first said" aria-label="${y}, ${byYear[y] || 0} beliefs"><i style="height:${byYear[y] ? Math.max(8, Math.sqrt(byYear[y] / max) * 100) : 0}%"></i></button>`).join("");
    $("#yearlabels").innerHTML = `<span>${years[0]}</span><span id="yearpick">First said, by year</span><span>${years.at(-1)}</span>`;
  } else { $("#years").remove(); $("#yearlabels").remove(); }
  const toggle = (attr, key) => $$(`[data-${attr}]`, view).forEach(b => b.onclick = () => { F[key] = F[key] === b.dataset[attr] ? "" : b.dataset[attr]; draw(); });
  toggle("kind", "kind"); toggle("review", "review"); toggle("year", "year");
  $("#search").oninput = e => { F.q = e.target.value.toLowerCase(); draw(); };
  $("#clear").onclick = () => { Object.assign(F, {q: "", kind: "", review: "", year: ""}); $("#search").value = ""; draw(); };

  const rowHTML = n => `<div class="row ${n.review} ${n.id === SEL ? "sel" : ""}" data-id="${n.id}" role="option" aria-selected="${n.id === SEL}">
    ${kdot(n.kind)}<span>${esc(n.statement)}</span><span class="id">${n.review === "approved" ? icon("check", "sm") : ""}${n.id}</span></div>`;
  const reviewCounts = () => $$("[data-rc]", view).forEach(s => s.textContent = fmt(MAP.nodes.filter(n => n.review === s.dataset.rc).length));

  function draw() {
    ROWS = MAP.nodes.filter(n => (!F.kind || n.kind === F.kind) && (!F.review || n.review === F.review) &&
      (!F.year || (n.first_seen || "").startsWith(F.year)) &&
      (!F.q || (n.id + " " + n.statement + " " + n.sources.map(s => s.quote + " " + (s.origin || "")).join(" ")).toLowerCase().includes(F.q)));
    $$("[data-kind]", view).forEach(b => b.setAttribute("aria-pressed", b.dataset.kind === F.kind));
    $$("[data-review]", view).forEach(b => b.setAttribute("aria-pressed", b.dataset.review === F.review));
    $$("[data-year]", view).forEach(b => b.setAttribute("aria-pressed", b.dataset.year === F.year));
    reviewCounts();
    if ($("#yearpick")) $("#yearpick").textContent = F.year ? `First said in ${F.year}` : "First said, by year";
    const filtered = F.q || F.kind || F.review || F.year;
    $("#mapcount").textContent = filtered ? `${fmt(ROWS.length)} of ${fmt(MAP.nodes.length)} beliefs` : `${fmt(MAP.nodes.length)} beliefs, ${fmt(MAP.edges.length)} links`;
    $("#clear").classList.toggle("hidden", !filtered);
    $("#rows").innerHTML = ROWS.length ? ROWS.map(rowHTML).join("") : `<p class="empty" style="padding:20px">Nothing matches. Try fewer filters or a shorter search.</p>`;
  }
  $("#rows").onclick = e => { const r = e.target.closest(".row"); if (r) select(r.dataset.id); };

  function select(id) {
    const n = byId.get(id);
    if (!n) return;
    const prev = SEL; SEL = id;
    if (prev) { const p = $(`.row[data-id="${prev}"]`); p?.classList.remove("sel"); p?.setAttribute("aria-selected", "false"); }
    const row = $(`.row[data-id="${id}"]`);
    if (row) { row.classList.add("sel"); row.setAttribute("aria-selected", "true"); row.scrollIntoView({block: "nearest"}); }
    $("#mv").classList.add("reading");
    history.replaceState(null, "", `#/p/${slug}/map/${id}`);
    detail(n);
  }

  function detail(n, extra = "") {
    const f = n.first_seen?.slice(0, 4), l = n.last_seen?.slice(0, 4);
    const span = f ? (l && l !== f ? `Said from ${f} to ${l}` : `Said in ${f}`) : "Undated";
    const groups = {};
    MAP.edges.forEach(e => {
      if (e.src !== n.id && e.dst !== n.id) return;
      const out = e.src === n.id, other = byId.get(out ? e.dst : e.src);
      if (!other) return;
      const label = (REL[e.kind] || [e.kind, e.kind])[out ? 0 : 1];
      (groups[e.kind + label] ||= {kind: e.kind, label, items: []}).items.push({other, note: e.note});
    });
    const rels = Object.values(groups).map(g => `<div class="rel ${g.kind}"><h5>${esc(g.label)}</h5>${g.items.map(({other, note}) =>
      `<button class="link" data-goto="${other.id}">${kdot(other.kind)}<span>${esc(other.statement)}${note ? `<small>${esc(note)}</small>` : ""}</span></button>`).join("")}</div>`).join("");
    const reviewed = n.review !== "auto";
    $("#detail").innerHTML = `<button class="btn sm ghost back" id="back">${icon("arrow-left", "sm")} All beliefs</button>
      <div class="dhead">${kdot(n.kind)}<span class="kind" style="--k:var(--k-${n.kind})">${cap(n.kind)}</span><span class="num">${n.id}</span><span>${span}</span>
        ${reviewed ? `<span class="badge ${n.review === "approved" ? "ok" : "bad"}">${n.review === "approved" ? "Approved" : "Rejected, never used in answers"}</span>` : ""}</div>
      <div class="statement" id="stmt">${esc(n.statement)}</div>
      <div class="acts owner" id="acts">
        <button class="btn ${n.review === "approved" ? "ok-on" : ""}" data-act="approved">${icon("check", "sm")} Approve <kbd>A</kbd></button>
        <button class="btn ${n.review === "rejected" ? "bad-on" : ""}" data-act="rejected">${icon("x", "sm")} Reject <kbd>R</kbd></button>
        ${reviewed ? `<button class="btn ghost" data-act="auto">${icon("undo-2", "sm")} Undo</button>` : ""}
        <button class="btn ghost" data-act="edit">${icon("pencil", "sm")} Edit wording</button>
        <button class="btn ghost" data-act="merge">${icon("git-merge", "sm")} Merge</button>
      </div>${extra}
      <section><h4>Verbatim source${n.sources.length > 1 ? `s, ${n.sources.length}` : ""}</h4>${n.sources.map(s => `<div class="verb"><blockquote>${esc(s.quote)}</blockquote>
        <div>${esc([s.origin, s.section && s.section !== s.origin ? s.section : "", s.date].filter(Boolean).join(", "))}</div></div>`).join("")}</section>
      <section><h4>${rels ? "Connected beliefs" : "Not connected to other beliefs yet"}</h4>${rels}</section>
      ${n.note ? `<section><h4>Reviewer note</h4><p>${esc(n.note)}</p></section>` : ""}
      <div class="keys"><span><kbd>J</kbd><kbd>K</kbd> next and previous</span><span class="owner"><kbd>A</kbd> approve and move on</span><span class="owner"><kbd>R</kbd> reject and move on</span></div>`;
    $("#detail").scrollTop = 0;
    $("#back").onclick = () => $("#mv").classList.remove("reading");
    $$("[data-goto]", $("#detail")).forEach(b => b.onclick = () => select(b.dataset.goto));
    $$("[data-act]", $("#detail")).forEach(b => b.onclick = () => act(n, b.dataset.act));
  }

  function step(d) {
    if (!ROWS.length) return;
    const i = ROWS.findIndex(r => r.id === SEL);
    const next = ROWS[Math.min(ROWS.length - 1, Math.max(0, i === -1 ? 0 : i + d))];
    if (next) select(next.id);
  }

  async function act(n, a, advance = false) {
    try {
      if (a === "edit") {
        $("#stmt").innerHTML = `<textarea id="edit" aria-label="Belief wording">${esc(n.statement)}</textarea>`;
        $("#acts").innerHTML = `<button class="btn primary" id="save">Save wording</button><button class="btn ghost" id="cancel">Cancel</button>
          <span class="faint" style="font-size:13px">Only the wording changes. Quotes stay word for word.</span>`;
        const ed = $("#edit"); ed.focus(); ed.setSelectionRange(ed.value.length, ed.value.length);
        $("#cancel").onclick = () => detail(n);
        $("#save").onclick = async () => {
          const v = ed.value.trim(); if (!v) return;
          await api(`/api/t/${slug}/node/${n.id}`, {statement: v}); n.statement = v;
          const r = $(`.row[data-id="${n.id}"]`); if (r) r.outerHTML = rowHTML(n);
          detail(n); toast("Wording saved");
        };
        return;
      }
      if (a === "merge") {
        detail(n, `<form class="mergebar" id="mergef"><input class="input" id="keep" placeholder="Belief to keep, like n0012" aria-label="Belief to keep">
          <button class="btn primary">Merge into it</button><button class="btn ghost" type="button" id="cancel">Cancel</button></form>`);
        $("#keep").focus();
        $("#cancel").onclick = () => detail(n);
        $("#mergef").onsubmit = async e => {
          e.preventDefault();
          const keep = $("#keep").value.trim();
          try { await api(`/api/t/${slug}/merge`, {keep, drop: n.id}); }
          catch (err) { return toast(err.message, "bad"); }
          MAP = await api(`/api/t/${slug}/map`);
          byId.clear(); MAP.nodes.forEach(x => byId.set(x.id, x));
          draw(); select(keep); toast(`Merged ${n.id} into ${keep}`);
        };
        return;
      }
      await api(`/api/t/${slug}/node/${n.id}`, {review: a});
      n.review = a;
      const r = $(`.row[data-id="${n.id}"]`); if (r) r.outerHTML = rowHTML(n);
      reviewCounts();
      if (advance) step(1); else detail(n);
    } catch (err) { toast(`That didn't save: ${err.message}`, "bad"); }
  }

  const onKey = e => {
    if (e.metaKey || e.ctrlKey || e.altKey || typing() || document.querySelector(".scrim")) return;
    const n = document.documentElement.classList.contains("guest") ? null : byId.get(SEL);
    const k = {j: () => step(1), ArrowDown: () => step(1), k: () => step(-1), ArrowUp: () => step(-1),
      "/": () => $("#search").focus(), a: () => n && act(n, "approved", true), r: () => n && act(n, "rejected", true),
      e: () => n && act(n, "edit")}[e.key];
    if (k) { e.preventDefault(); k(); }
  };
  document.addEventListener("keydown", onKey);
  draw();
  if (ctx.id) select(ctx.id);
  return () => document.removeEventListener("keydown", onKey);
}
