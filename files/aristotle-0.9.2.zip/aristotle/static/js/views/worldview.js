// Worldview: a person's map at a glance. The beliefs everything else leans on, the themes they
// fall into, where they pull against each other, how views changed, and which of their best-known
// ideas the map covers so far. Every quote is verbatim (ink serif) and opens in the map.
import {$, api, avatar, cap, esc, icon, kdot, plural, shortName, toast} from "../ui.js";

export async function mount(view, ctx) {
  const {slug, info} = ctx;
  view.innerHTML = `<div class="page"><div class="profile">${avatar(info, "xl")}<div>
      <h1>${esc(info.name)}</h1><p>${esc(info.profile?.description || "")}</p></div></div>
    <div id="wv"><p class="empty">${icon("loader-circle", "sm spin")} Laying out ${esc(shortName(info))}'s worldview</p></div></div>`;
  let w;
  try { w = await api(`/api/t/${slug}/worldview`); }
  catch (e) { $("#wv", view).innerHTML = `<div class="callout bad">${icon("circle-alert", "sm")}<span>${esc(e.message)}</span></div>`; return; }
  const name = shortName(info);
  const where = b => [b.origin || b.section, (b.date || "").slice(0, 4)].filter(Boolean).map(esc).join(", ");
  const belief = b => `<a class="belief link" href="#/p/${slug}/map/${b.id}">${kdot(b.kind)}<div><b>${esc(b.statement)}</b>
      <q>${esc(b.quote)}</q><small class="where">${cap(b.kind)}${where(b) ? ` · ${where(b)}` : ""}${b.n_sources > 1 ? ` · said in ${plural(b.n_sources, "source")}` : ""}</small></div></a>`;

  const sig = w.signature || [];
  const covered = sig.filter(s => s.node).length;
  const sections = [];
  if (sig.length) sections.push(`<section class="section"><div class="section-head"><h2>Best known for</h2>
      <p>${covered} of ${sig.length} in the map so far${covered < sig.length ? ". Growing the map from Sources reads more" : ""}</p></div>
    <div class="list sig">${sig.map(s => `<div class="sig-row ${s.node ? "" : "off"}">${s.node ? icon("check", "sm") : `<span class="ring" aria-hidden="true"></span>`}
      <div class="txt"><b>${esc(s.idea)}</b>${s.node ? `<a href="#/p/${slug}/map/${s.node}">${esc(s.statement)}</a>` : `<span>Not in the map yet</span>`}</div></div>`).join("")}</div></section>`);
  sections.push(`<section class="section"><div class="section-head"><h2>The core of it</h2>
      <p>The beliefs the rest of ${esc(name)}'s map leans on most: the most links and the most sources</p></div>
    <div class="list">${w.core.map(belief).join("")}</div></section>`);
  if (w.themes?.length) sections.push(`<section class="section"><div class="section-head"><h2>Themes</h2><p>How the core beliefs group</p></div>
    <div class="themes">${w.themes.map(t => `<details class="theme"><summary><b>${esc(t.name)}</b><span>${esc(t.line)}</span>
        <span class="faint num">${plural(t.beliefs.length, "belief")}</span></summary>
      <div class="list">${t.beliefs.map(belief).join("")}</div></details>`).join("")}</div></section>`);
  if (w.tensions?.length) sections.push(`<section class="section"><div class="section-head"><h2>Where the beliefs pull apart</h2>
      <p>Pairs that point different ways in some situations</p></div>
    <div class="pairs">${w.tensions.map(t => `<div class="pair"><div class="list">${belief(t.a)}${belief(t.b)}</div>
      ${t.note ? `<p class="faint">${icon("git-merge", "sm")} ${esc(t.note)}</p>` : ""}</div>`).join("")}</div></section>`);
  sections.push(`<section class="section"><div class="section-head"><h2>How their views changed</h2>
      <p>${w.changes?.length ? "The same subject at different times, where the view really moved" : ""}</p></div>
    ${w.changes?.length ? `<div class="timeline">${w.changes.map(c => `<div class="change">
        <div class="when"><b class="num">${esc((c.old.first_seen || "").slice(0, 4))}</b>${icon("arrow-right", "sm")}<b class="num">${esc((c.new.first_seen || "").slice(0, 4))}</b></div>
        <div>${c.note ? `<p class="how">${esc(cap(c.note))}</p>` : ""}<div class="list">${belief(c.old)}${belief(c.new)}</div></div></div>`).join("")}</div>`
      : !w.evolved && info.years && info.years[0] !== info.years[1]
        ? `<div class="callout">${icon("history", "sm")}<span>This map was built before views were compared across years.
            <button class="linkish" id="evolve">Compare them now</button> (about 10 plan calls).</span></div>`
        : `<p class="empty">No changes found${info.years && info.years[0] !== info.years[1] ? " yet. They show up once the map holds the same subject from different years" : ": the sources don't span enough years"}.</p>`}</section>`);
  $("#wv", view).innerHTML = sections.join("");
  const ev = $("#evolve", view);
  if (ev) ev.onclick = async () => {
    ev.disabled = true; ev.textContent = "Comparing views across years…";
    try { const r = await api(`/api/t/${slug}/evolve`, {}); toast(r.changes ? `Found ${plural(r.changes, "changed view")}` : "No views changed over time"); mount(view, ctx); }
    catch (e) { toast(e.message, "bad"); ev.disabled = false; ev.textContent = "Compare them now"; }
  };
}
