// Library: your people, search anyone on Wikipedia, and a shelf of suggestions.
import {$, $$, api, avatar, debounce, esc, fmt, icon, plural, toast, yearsText} from "../ui.js";
import {addPerson, addTradition, refreshLibrary, store} from "../app.js";

let suggestions = null;
let sacred = null;
let packs = null;

export async function mount(main, {focus}) {
  main.innerHTML = `<header class="topbar"><button class="btn ghost icon menu-btn" id="menu" aria-label="Open navigation">${icon("panel-left")}</button>
      <div class="who"><span>Library</span></div><div class="spacer"></div></header>
    <div class="page">
      <div class="page-head">
        <h1>Think it through with the people you trust.</h1>
        <p>Each person is a map of beliefs taken from their own words. Bring a real decision, and every claim in the answer links to the passage it came from.</p>
      </div>
      <div class="big-search field-ico">${icon("search")}
        <input class="input" id="find" type="search" placeholder="Search for anyone: a philosopher, a founder, a scientist" autocomplete="off" aria-label="Search for a person to add">
        <div id="found"></div>
      </div>
      <section class="section"><div class="section-head"><h2>${store.guest ? "Library" : "Your library"}</h2><p id="libcount"></p></div><div id="lib"></div></section>
      <section class="section hidden" id="packsec"><div class="section-head"><h2>Ready-made maps</h2><p>Built once from public-domain books and shared. Adding one uses none of your plan.</p></div>
        <div class="shelf" id="packs"></div></section>
      <section class="section"><div class="section-head"><h2>Sacred texts</h2><p>Ask what a tradition's scripture teaches. Every claim cites the verse, from public-domain translations.</p></div>
        <div class="shelf" id="sacred"><p class="empty">Loading</p></div></section>
      <section class="section"><div class="section-head"><h2>Worth adding</h2><p>Sources are found automatically. Public-domain books come from Project Gutenberg.</p></div>
        <div class="shelf" id="shelf"><p class="empty">Loading suggestions</p></div></section>
    </div>`;
  $("#menu").onclick = () => $(".app").classList.add("nav-open");
  drawLibrary();
  drawShelf();
  drawSacred();
  api("/api/traditions").then(s => { sacred = s; drawSacred(); }).catch(() => { sacred = sacred || []; drawSacred(); });
  if (!store.guest) api("/api/packs").then(p => { packs = p; drawPacks(); }).catch(() => {});
  drawPacks();
  if (!suggestions) api("/api/suggestions").then(s => { suggestions = s; drawShelf(); }).catch(() => { suggestions = []; drawShelf(); });

  const find = $("#find");
  const search = debounce(async q => {
    if (q.length < 2) { $("#found").innerHTML = ""; return; }
    $("#found").innerHTML = `<div class="results"><div class="note">${icon("loader-circle", "sm spin")} Searching Wikipedia</div></div>`;
    let res = [];
    try { res = await api(`/api/people?q=${encodeURIComponent(q)}`); }
    catch (e) { $("#found").innerHTML = `<div class="results"><div class="note err-text">${esc(e.message)}</div></div>`; return; }
    if (find.value.trim() !== q) return;
    $("#found").innerHTML = `<div class="results">${res.length ? res.map(r => `<div class="result">${avatar(r)}
        <div class="txt"><b>${esc(r.title)}</b><span>${esc(r.description || "No description on Wikipedia")}</span></div>
        ${r.slug ? `<a class="btn sm" href="#/p/${r.slug}">Open</a>` : `<button class="btn sm" data-add="${esc(r.title)}">${icon("plus", "sm")} Add</button>`}
      </div>`).join("") : `<div class="note">No Wikipedia article matches “${esc(q)}”. Try their full name.</div>`}</div>`;
    $$("[data-add]", $("#found")).forEach(b => b.onclick = () => addPerson(b.dataset.add, b));
  }, 250);
  find.addEventListener("input", () => search(find.value.trim()));
  if (focus) find.focus();

  const onLib = () => { drawLibrary(); drawSacred(); drawPacks(); };
  window.addEventListener("library", onLib);
  return () => window.removeEventListener("library", onLib);
}

function status(p) {
  if (p.job && ["queued", "running"].includes(p.job.state))
    return `<span class="badge live">${icon("loader-circle", "sm spin")} ${p.job.total ? `${p.job.done} of ${p.job.total}` : "Starting"}</span>`;
  if (p.job?.state === "error" || p.job?.state === "interrupted") return `<span class="badge bad">Build stopped</span>`;
  return p.built ? `<span class="badge ok">Ready</span>` : `<span class="badge warn">Needs a build</span>`;
}

function drawLibrary() {
  const people = store.people;
  $("#libcount").textContent = people.length ? plural(people.length, "person", "people") : "";
  $("#lib").innerHTML = people.length ? `<div class="people">${people.map(p => `
    <a class="person-row" href="#/p/${p.slug}">${avatar(p, "lg")}
      <div class="txt"><b>${esc(p.name)}</b><span>${esc(p.description || "")}</span></div>
      <div class="stat"><b>${p.built ? fmt(p.nodes) : "None yet"}</b>beliefs</div>
      <div class="stat"><b>${fmt(p.sources)}</b>${p.years ? yearsText(p.years) : "sources"}</div>
      ${status(p)}
    </a>`).join("")}</div>`
    : `<p class="empty">Your library is empty. Search above, or pick someone from the shelf below.</p>`;
}

function drawSacred() {
  const el = $("#sacred");
  if (!sacred || !el) return;
  const have = new Map(store.people.map(p => [p.name, p.slug]));
  el.innerHTML = sacred.length ? sacred.map(s => {
    const slug = s.slug || have.get(s.title);
    return `<div class="tile">${avatar(s, "lg")}
      <div class="txt"><b>${esc(s.title)}</b><span>${esc(s.text)}</span><small>${esc(s.tradition)} · ${esc(s.translation)}</small></div>
      ${slug ? `<a class="btn sm" href="#/p/${slug}">Open</a>` : `<button class="btn sm" data-trad="${esc(s.id)}">${icon("plus", "sm")} Add</button>`}</div>`;
  }).join("") : `<p class="empty">Couldn't load the sacred texts.</p>`;
  $$("[data-trad]", el).forEach(b => b.onclick = () => addTradition(b.dataset.trad, b));
}

function drawShelf() {
  if (!suggestions) return;
  const have = new Set(store.people.map(p => p.name));
  const list = suggestions.filter(s => !have.has(s.title));
  $("#shelf").innerHTML = list.length ? list.map(s => `<div class="tile">${avatar(s, "lg")}
      <div class="txt"><b>${esc(s.title.replace(/\s*\(.*\)/, ""))}</b><span>${esc(s.description)}</span></div>
      <button class="btn sm" data-add="${esc(s.title)}">${icon("plus", "sm")} Add</button></div>`).join("")
    : `<p class="empty">Couldn't reach Wikipedia for suggestions. Search for a name above instead.</p>`;
  $$("[data-add]", $("#shelf")).forEach(b => b.onclick = () => addPerson(b.dataset.add, b));
}

function drawPacks() {
  const el = $("#packs");
  if (!el || !packs?.length) return;
  const have = new Set(store.people.map(p => p.slug));
  $("#packsec").classList.remove("hidden");
  el.innerHTML = packs.map(k => `<div class="tile">${avatar({name: k.name, image: k.image}, "lg")}
      <div class="txt"><b>${esc(k.name)}</b><span>${esc(k.description || "")}</span><small>${fmt(k.nodes)} beliefs · ${(k.size / 1e6).toFixed(1)} MB</small></div>
      ${have.has(k.slug) ? `<a class="btn sm" href="#/p/${k.slug}">Open</a>` : `<button class="btn sm" data-pack="${esc(k.slug)}">${icon("plus", "sm")} Add</button>`}</div>`).join("");
  $$("[data-pack]", el).forEach(b => b.onclick = async () => {
    b.disabled = true; b.innerHTML = `${icon("loader-circle", "sm spin")} Adding`;
    try {
      const r = await api(`/api/packs/${b.dataset.pack}`, {});
      await refreshLibrary();
      location.hash = `#/p/${r.slug}`;
    } catch (e) { toast(e.message, "bad"); b.disabled = false; b.innerHTML = `${icon("plus", "sm")} Add`; }
  });
}
