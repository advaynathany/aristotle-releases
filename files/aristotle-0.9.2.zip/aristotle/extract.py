"""Build an episteme map: extract -> ground -> dedupe -> link.

Grounding is the key rule: a node survives only if its quote is a verbatim substring of the
thinker's own lines in the chunk it came from (interviewer questions don't count). Hallucinated
beliefs are dropped here.
"""
from __future__ import annotations

import re
from concurrent.futures import ThreadPoolExecutor

import numpy as np

from .embed import Embedder
from .ingest import INTERVIEWER, norm, quotable, resolve_origin
from .llm import parse_json
from .schema import EDGE_KINDS, NODE_KINDS, Chunk, Edge, EpistemeMap, Node, Source

EXTRACT_SYSTEM = """You extract a thinker's beliefs from their own words so they can be mapped as \
a graph and later used to reason about other people's real decisions. The thinker is {thinker}.

The passage may contain lines starting "INTERVIEWER:" (someone else's question; use it only as \
context, never as a belief or a quote) and "TWEET:" (the thinker's own tweet). Bracketed numbers \
like [12] are citation markers; leave them out of quotes.

Return a JSON list. Each item has:
  "kind": one of principle | heuristic | value | case | boundary
     principle = a foundational claim the thinker treats as true ("wealth is assets that earn \
while you sleep")
     heuristic = a rule of thumb for acting ("if you can't decide, the answer is no")
     value = a priority or tradeoff weight: what the thinker ranks above what, and when \
("freedom over income")
     case = a concrete example or application the thinker gives, usable as a precedent
     boundary = a limit the thinker puts on a view, something they say they don't know, a \
caveat, or a view they say changed
  "statement": the belief as one clear, specific, self-contained sentence a reader could act on \
without seeing the passage. Name the concept ("specific knowledge", "leverage") when the \
thinker does. Not a summary of the passage, not vague ("life is complex").
  "quote": an EXACT verbatim excerpt (one or two sentences, under 300 characters) copied \
character for character from the thinker's own lines that best supports the statement

Rules: only beliefs the passage actually states; never add outside knowledge or your own \
interpretation. Prefer fewer, sharper beliefs over many paraphrases of one idea (usually 3 to 10 \
per passage). If nothing qualifies, return []. Return JSON only."""

LINK_SYSTEM = """You link beliefs in {thinker}'s worldview into a graph. You get beliefs, each \
with an id, and for each a list of nearby candidate beliefs. Return a JSON list of relations:
  {{"src": id, "dst": id, "kind": one of {kinds}, "note": short reason}}
supports = src is evidence or a reason for dst
derives_from = src follows from dst (dst is the more fundamental belief)
conflicts_with = they pull in opposite directions in some situations
outweighs = when both apply, {thinker} ranks src above dst
Only use ids you were given. Only link when the relation is clear from the statements \
themselves; most candidates should get no link. Return JSON only."""


def ground(quote: str, haystack: str) -> str | None:
    """Return the cleaned quote if it is verbatim in the haystack, else None."""
    q = re.sub(r"\s*\[\d+\]", "", quote).strip().strip('"“”').strip()
    for prefix in (INTERVIEWER.strip(), "TWEET:"):
        q = q.removeprefix(prefix).strip()
    if len(q) < 12 or norm(q) not in haystack:
        return None
    return q


def extract_chunk(llm, chunk: Chunk, thinker: str, note: str = "") -> tuple[list[Node], int]:
    """Return (grounded nodes, number of rejected items). `note` adds source-specific guidance
    (scripture: who is speaking, see traditions.py)."""
    try:
        items = parse_json(llm.complete(
            EXTRACT_SYSTEM.format(thinker=thinker) + (f"\n\n{note}" if note else ""),
            f"SECTION: {chunk.section}\n\nPASSAGE:\n{chunk.text}",
        ))
    except ValueError:
        return [], 0
    nodes, rejected = [], 0
    haystack = quotable(chunk.text)
    for it in items if isinstance(items, list) else []:
        if not isinstance(it, dict):
            rejected += 1
            continue
        quote = ground(str(it.get("quote", "")), haystack)
        if not (it.get("kind") in NODE_KINDS and it.get("statement") and quote):
            rejected += 1
            continue
        origin, date, tier = resolve_origin(chunk, quote)
        nodes.append(Node(
            id="",  # assigned after dedupe
            kind=it["kind"],
            statement=str(it["statement"]).strip(),
            sources=[Source(chunk.id, chunk.section, quote, tier, date, origin)],
        ))
    return nodes, rejected


def dedupe(nodes: list[Node], threshold: float | None = None) -> list[Node]:
    """Merge near-duplicate statements of the same kind, pooling their sources."""
    if not nodes:
        return []
    emb = Embedder([n.statement for n in nodes])
    if threshold is None:
        threshold = 0.55 if emb.backend == "tfidf" else 0.86
    sims = emb.matrix @ emb.matrix.T
    kept: list[int] = []
    for i, n in enumerate(nodes):
        target = next((j for j in sorted(kept, key=lambda j: -sims[i, j])
                       if sims[i, j] >= threshold and nodes[j].kind == n.kind), None)
        if target is None:
            kept.append(i)
            continue
        have = {(s.chunk_id, norm(s.quote)) for s in nodes[target].sources}
        nodes[target].sources.extend(s for s in n.sources if (s.chunk_id, norm(s.quote)) not in have)
    out = [nodes[i] for i in kept]
    for i, n in enumerate(out):
        n.id = f"n{i:04d}"
    return out


def link(llm, nodes: list[Node], thinker: str, k: int = 6, batch: int = 10,
         workers: int = 4) -> list[Edge]:
    if len(nodes) < 2:
        return []
    emb = Embedder([n.statement for n in nodes])
    sims = emb.matrix @ emb.matrix.T
    np.fill_diagonal(sims, -1)
    system = LINK_SYSTEM.format(thinker=thinker, kinds=" | ".join(EDGE_KINDS))

    def run(start: int) -> list[Edge]:
        block, allowed = [], {}
        for i in range(start, min(start + batch, len(nodes))):
            cands = list(np.argsort(-sims[i])[:k])
            allowed[nodes[i].id] = {nodes[j].id for j in cands}
            block.append(
                f"[{nodes[i].id}] ({nodes[i].kind}) {nodes[i].statement}\n  candidates:\n"
                + "\n".join(f"  [{nodes[j].id}] ({nodes[j].kind}) {nodes[j].statement}" for j in cands)
            )
        try:
            rels = parse_json(llm.complete(system, "\n\n".join(block)))
        except ValueError:
            return []
        out = []
        for r in rels if isinstance(rels, list) else []:
            if not isinstance(r, dict):
                continue
            src, dst, kind = r.get("src"), r.get("dst"), r.get("kind")
            if kind in EDGE_KINDS and dst in allowed.get(src, set()):
                out.append(Edge(src, dst, kind, str(r.get("note", ""))))
        return out

    edges, seen = [], set()
    with ThreadPoolExecutor(workers) as pool:
        for got in pool.map(run, range(0, len(nodes), batch)):
            for e in got:
                key = (e.src, e.dst, e.kind) if e.kind != "conflicts_with" else \
                    (*sorted((e.src, e.dst)), e.kind)
                if key not in seen:
                    seen.add(key)
                    edges.append(e)
    return edges


EVOLVE_SYSTEM = """You compare pairs of beliefs extracted from {thinker}'s words at different \
times. In each pair A is the earlier statement and B the later one, each with its date and a \
verbatim quote. Decide for each pair:
  "same": B restates A's view (same idea, maybe different wording or emphasis)
  "shifted": the view moved: B narrows, extends, qualifies or changes A in a real way
  "reversed": B contradicts or abandons A
  "different": they are about different things; no relation over time
Be strict: "shifted" and "reversed" need a real change in the view, not just a different example. \
"note" says in under 20 words how the view changed (empty for "same" and "different").
Return JSON only: [{{"pair": number, "verdict": "same|shifted|reversed|different", "note": str}}]"""


def evolve(llm, nodes: list[Node], thinker: str, max_pairs: int = 120, batch: int = 12,
           workers: int = 4) -> tuple[list[Node], list[Edge], dict[str, str]]:
    """The same idea across years. Dedupe only merges near-identical wording; here similar beliefs
    from different years are compared by the model: restatements merge (so a belief shows every
    year it was said), and real changes become changed_to edges from the older to the newer view.
    Returns (kept nodes, changed_to edges, {merged-away id: id it was merged into})."""
    dated = [n for n in nodes if n.first_seen[:4]]
    if len(dated) < 2:
        return nodes, [], {}
    emb = Embedder([n.statement for n in dated])
    sims = emb.matrix @ emb.matrix.T
    lo = 0.30 if emb.backend == "tfidf" else 0.72  # dedupe already merged same-kind pairs above ~0.86
    pairs = []
    for i in range(len(dated)):
        for j in range(i + 1, len(dated)):
            a, b = dated[i], dated[j]
            if sims[i, j] >= lo and a.first_seen[:4] != b.first_seen[:4] and \
                    {s.chunk_id for s in a.sources}.isdisjoint(s.chunk_id for s in b.sources):
                old, new = (a, b) if a.first_seen <= b.first_seen else (b, a)
                pairs.append((float(sims[i, j]), old, new))
    pairs = [p[1:] for p in sorted(pairs, key=lambda p: -p[0])[:max_pairs]]
    if not pairs:
        return nodes, [], {}
    system = EVOLVE_SYSTEM.format(thinker=thinker)

    def quote(n: Node) -> str:
        s = min(n.sources, key=lambda s: s.date or "9999")
        return s.quote[:240]

    def run(start: int):
        block = pairs[start:start + batch]
        text = "\n\n".join(
            f"PAIR {k + 1}\nA ({old.first_seen[:4]}, {old.kind}): {old.statement}\n   quote: \"{quote(old)}\"\n"
            f"B ({new.first_seen[:4]}, {new.kind}): {new.statement}\n   quote: \"{quote(new)}\""
            for k, (old, new) in enumerate(block))
        try:
            out = parse_json(llm.complete(system, text, tier="fast"))
        except (ValueError, TypeError, IndexError, KeyError):
            return []  # a bad reply only skips these pairs; plan-limit errors still stop the build
        got = []
        for r in out if isinstance(out, list) else []:
            if isinstance(r, dict) and isinstance(r.get("pair"), int) and 1 <= r["pair"] <= len(block):
                got.append((*block[r["pair"] - 1], r.get("verdict"), str(r.get("note", ""))[:200]))
        return got

    with ThreadPoolExecutor(workers) as pool:
        verdicts = [v for got in pool.map(run, range(0, len(pairs), batch)) for v in got]
    merged: dict[str, Node] = {}  # dropped node id -> the node it was merged into
    edges = []

    def home(n: Node) -> Node:
        while n.id in merged:
            n = merged[n.id]
        return n
    for old, new, verdict, note in verdicts:
        old, new = home(old), home(new)
        if old is new:
            continue
        if verdict == "same" and old.kind == new.kind:
            have = {(s.chunk_id, norm(s.quote)) for s in old.sources}
            old.sources.extend(s for s in new.sources if (s.chunk_id, norm(s.quote)) not in have)
            merged[new.id] = old
        elif verdict in ("shifted", "reversed"):
            edges.append(Edge(old.id, new.id, "changed_to", (f"{verdict}: " + note).strip(": ")))
    kept = [n for n in nodes if n.id not in merged]
    live = {n.id for n in kept}
    return kept, [e for e in edges if e.src in live and e.dst in live], {k: home(v).id for k, v in merged.items()}


def build_map(llm, chunks: list[Chunk], thinker: str, progress=print,
              workers: int = 4, on_nodes=None, note: str = "") -> tuple[EpistemeMap, dict]:
    """`on_nodes`, when given, receives each chunk's grounded nodes as they are extracted."""
    raw_nodes: list[Node] = []
    rejected = done = 0
    with ThreadPoolExecutor(workers) as pool:
        for got, rej in pool.map(lambda ch: extract_chunk(llm, ch, thinker, note), chunks):
            raw_nodes.extend(got)
            rejected += rej
            if on_nodes and got:
                on_nodes(got)
            done += 1
            progress(f"extracted {done}/{len(chunks)} chunks: {len(raw_nodes)} nodes, {rejected} rejected")
    nodes = dedupe(raw_nodes)
    progress(f"deduped to {len(nodes)} nodes; comparing views across years...")
    nodes, changes, _ = evolve(llm, nodes, thinker, workers=workers)
    progress(f"{len(changes)} views changed over time; linking...")
    edges = changes + link(llm, nodes, thinker, workers=workers)
    stats = {
        "chunks": len(chunks),
        "raw_nodes": len(raw_nodes),
        "rejected_ungrounded": rejected,
        "nodes": len(nodes),
        "edges": len(edges),
        "changed_views": len(changes),
    }
    return EpistemeMap(thinker, nodes, edges), stats


def evolve_map(llm, emap: EpistemeMap) -> int:
    """Run `evolve` on an already-built map in place (maps built before it existed). Existing
    edges follow merged nodes. Returns how many changed views it found."""
    kept, changes, merged = evolve(llm, emap.nodes, emap.thinker)
    for e in emap.edges:
        e.src, e.dst = merged.get(e.src, e.src), merged.get(e.dst, e.dst)
    seen, edges = set(), []
    for e in [x for x in emap.edges if x.kind != "changed_to"] + changes:
        if e.src != e.dst and (e.src, e.dst, e.kind) not in seen:
            seen.add((e.src, e.dst, e.kind))
            edges.append(e)
    emap.nodes, emap.edges = kept, edges
    return len(changes)
