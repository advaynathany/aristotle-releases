"""Following a living person: once a week, look for anything new (their feed, the web search,
talks) and, if their map is built, read the new passages in a small capped build.

cfg["follow"] = {"on": bool, "last_check": ISO date, "found": n new last time, "auto_build": bool}.
The app checks every few hours while it is open; nothing runs when it is closed, and an overdue
check simply happens at the next launch. Builds go through the normal build queue, so they never
overlap and every reply stays cached.
"""
from __future__ import annotations

import threading
import time
from datetime import date, timedelta
from pathlib import Path

from . import discover
from .library import people, read_job

EVERY = timedelta(days=7)
GROW = 40  # passages per weekly build: about 70 plan calls at most


def due(cfg: dict) -> bool:
    f = cfg.get("follow") or {}
    return bool(f.get("on")) and (not f.get("last_check") or
                                  date.fromisoformat(f["last_check"]) + EVERY <= date.today())


def check(folder: Path, llm, builder=None) -> int:
    """Look for new sources now. Returns how many were added; queues a build when there are some."""
    folder = Path(folder)
    before = {c["id"] for c in discover.load_cfg(folder).get("candidates", [])}
    discover.discover(folder, llm)
    cfg = discover.load_cfg(folder)
    new = [c for c in cfg.get("candidates", []) if c["id"] not in before and c.get("selected")]
    with discover.editing(folder) as c:
        c.setdefault("follow", {}).update(last_check=date.today().isoformat(), found=len(new))
    f = cfg.get("follow") or {}
    job = read_job(folder) or {}
    if new and builder and f.get("auto_build", True) and (folder / "map.json").exists() \
            and job.get("state") not in ("queued", "running"):
        builder.submit(folder, GROW)
    return len(new)


class Follower:
    """Background loop: every few hours, check whoever is due."""

    def __init__(self, root: Path, llm, builder, on_change=None, every: float = 6 * 3600):
        self.root, self.llm, self.builder, self.every = Path(root), llm, builder, every
        self.on_change = on_change or (lambda folder: None)
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self) -> None:
        time.sleep(90)  # let the app finish starting
        while True:
            for folder in people(self.root):
                try:
                    if due(discover.load_cfg(folder)):
                        if check(folder, self.llm, self.builder):
                            self.on_change(folder)
                except Exception:
                    continue
            time.sleep(self.every)
