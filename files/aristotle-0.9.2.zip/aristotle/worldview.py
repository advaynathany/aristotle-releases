"""A person's worldview at a glance, from their map: the beliefs everything else leans on, the
themes they fall into, where they pull against each other, how views changed over the years, and
which of their best-known ideas the map covers so far.

Everything but the theme names is computed from the map. Themes take one fast call, cached in
worldview.json until the map changes.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np

from .chat import Thinker, centrality, signature_scores
from .llm import parse_json
from .schema import EpistemeMap
from .signature import coverage

THEMES_SYSTEM = """Group beliefs from {thinker}'s worldview into the 5 to 8 themes that best show \
how it is organised (say "Wealth and leverage", "Judgment", "Happiness as a skill"). Use the \
beliefs' own concepts. Each theme: "name" (2 to 4 words), "line" (one plain sentence on what \
{thinker} holds about it, no quotation marks), "ids" (3 to 10 belief ids from the list, most \
central first). A belief goes in at most one theme; leave out ones that fit nowhere. \
Return JSON only: [{{"name": str, "line": str, "ids": [str]}}]"""


def card(n) -> dict:
    return {"id": n.id, **Thinker.source_card(n), "first_seen": n.first_seen, "last_seen": n.last_seen}


def build(emap: EpistemeMap, cfg: dict, llm, emb, cache: Path) -> dict:
    nodes = emap.live_nodes()
    if not nodes:
        return {"core": [], "themes": [], "tensions": [], "changes": [], "signature": []}
    by_id = {n.id: n for n in nodes}
    cent = centrality(emap, nodes)
    sig = signature_scores(emb, nodes, cfg.get("signature") or [])
    rank = cent + 0.5 * sig
    order = [nodes[i] for i in np.argsort(-rank)]
    score = {n.id: float(rank[i]) for i, n in enumerate(nodes)}

    tensions = sorted((e for e in emap.edges if e.kind == "conflicts_with" and e.src in by_id and e.dst in by_id),
                      key=lambda e: -(score[e.src] + score[e.dst]))[:6]
    changes = sorted((e for e in emap.edges if e.kind == "changed_to" and e.src in by_id and e.dst in by_id),
                     key=lambda e: by_id[e.dst].first_seen)
    th = themes(emap.thinker, order[:60], llm, cache)
    return {"core": [card(n) for n in order[:10]],
            "themes": [{**t, "beliefs": [card(by_id[i]) for i in t["ids"] if i in by_id]} for t in th],
            "tensions": [{"a": card(by_id[e.src]), "b": card(by_id[e.dst]), "note": e.note} for e in tensions],
            "changes": [{"old": card(by_id[e.src]), "new": card(by_id[e.dst]), "note": e.note} for e in changes],
            "signature": [{**c, "statement": by_id[c["node"]].statement if c["node"] else ""}
                          for c in coverage(emb, nodes, cfg.get("signature") or [])]}


def themes(thinker: str, top: list, llm, cache: Path) -> list[dict]:
    key = hashlib.sha256(json.dumps([n.id + n.statement for n in top]).encode()).hexdigest()[:16]
    if cache.exists():
        saved = json.loads(cache.read_text())
        if saved.get("key") == key:
            return saved["themes"]
    listing = "\n".join(f"[{n.id}] ({n.kind}) {n.statement}" for n in top)
    try:
        out = parse_json(llm.complete(THEMES_SYSTEM.format(thinker=thinker), listing, tier="fast"))
    except Exception:
        return []
    valid, used, got = {n.id for n in top}, set(), []
    for t in out if isinstance(out, list) else []:
        if not isinstance(t, dict) or not t.get("name"):
            continue
        ids = [i for i in t.get("ids") or [] if i in valid and i not in used]
        used.update(ids)
        if len(ids) >= 2:
            got.append({"name": str(t["name"])[:60], "line": str(t.get("line", ""))[:240], "ids": ids})
    if got:
        cache.write_text(json.dumps({"key": key, "themes": got}))
    return got
