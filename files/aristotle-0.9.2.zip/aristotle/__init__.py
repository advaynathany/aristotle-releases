"""Aristotle. Pure-Python libraries that must stay current (yt-dlp: YouTube changes often) ship
inside this package in _vendor/ (see desktop/vendor.txt), so an ordinary update refreshes them and
nobody needs a new download. A checkout has no _vendor/ and uses the virtualenv's copies."""
import sys as _sys
from pathlib import Path as _Path

_VENDOR = _Path(__file__).resolve().parent / "_vendor"
if _VENDOR.is_dir() and str(_VENDOR) not in _sys.path:
    _sys.path.insert(0, str(_VENDOR))

__version__ = "0.9.2"
