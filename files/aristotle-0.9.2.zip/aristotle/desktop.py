"""Aristotle as a Mac app: a real app (Dock icon, menu, Cmd-Q) that runs the local server and shows
the interface in its own window.

The window is native: a WKWebView in the app's own window, with Edit/View/Window menus. It needs the
bundle's NSAllowsLocalNetworking (App Transport Security blocks http://127.0.0.1 otherwise, which
is why an early try showed a blank page) and pyobjc's WebKit; app bundles built before those
(shell 1) fall back to a Chromium app-mode window, and the page offers them the new download.

Everything runs on this Mac. The library lives in ~/Aristotle, and every model call goes through
the Claude Code CLI signed in to the user's own subscription (the app walks them through
installing it and signing in). Clicking the Dock icon reopens the window; quitting stops it all.
"""
from __future__ import annotations

import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

CHROMIUM = ["Google Chrome", "Microsoft Edge", "Brave Browser", "Chromium"]


def _free_port(preferred: int = 8765) -> int:
    for port in [preferred, *range(preferred + 1, preferred + 50)]:
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _app_path(name: str) -> Path | None:
    for base in (Path("/Applications"), Path.home() / "Applications"):
        if (base / f"{name}.app").exists():
            return base / f"{name}.app"
    return None


def native() -> bool:
    try:
        import WebKit  # noqa: F401
        return True
    except ImportError:
        return False


def open_window(url: str, home: Path) -> None:
    """A tabless app window when a Chromium browser is installed (its own profile, so it never
    mixes with the user's tabs), otherwise a tab in the default browser."""
    for name in CHROMIUM:
        if _app_path(name):
            subprocess.Popen(["open", "-na", name, "--args", f"--app={url}",
                              f"--user-data-dir={home / '.window'}", "--no-first-run",
                              "--no-default-browser-check", "--window-size=1320,860"])
            return
    subprocess.Popen(["open", url])


def main() -> None:
    os.environ.setdefault("ARISTOTLE_HOME", str(Path.home() / "Aristotle"))
    home = Path(os.environ["ARISTOTLE_HOME"])
    (home / "thinkers").mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("FASTEMBED_CACHE_PATH", str(home / ".cache" / "fastembed"))
    log = open(home / "aristotle.log", "a", buffering=1)
    if getattr(sys, "frozen", False):  # a bundled app has no terminal to print to
        sys.stdout = sys.stderr = log

    import uvicorn

    from .server import make_app

    port_file = home / ".port"
    try:  # the same port as last time, so an open window reconnects after an update restart
        last = int(port_file.read_text())
    except (OSError, ValueError):
        last = 8765
    port = _free_port(last)
    port_file.write_text(str(port))
    restarted = os.environ.pop("ARISTOTLE_RESTARTED", "") == "1"
    url = f"http://127.0.0.1:{port}/"
    server = uvicorn.Server(uvicorn.Config(make_app(home / "thinkers"), host="127.0.0.1", port=port,
                                           log_level="warning", log_config=None))
    threading.Thread(target=server.run, daemon=True).start()
    for _ in range(300):  # first launch can be slow while macOS checks the app
        try:
            urllib.request.urlopen(url + "api/library", timeout=1)
            break
        except Exception:
            time.sleep(0.2)
    print(f"Aristotle {url}", flush=True)
    from . import updater
    updater.start_background()
    if native():
        os.environ["ARISTOTLE_WINDOW"] = "native"
        _run_native(url)
        return
    os.environ["ARISTOTLE_WINDOW"] = "browser"
    # after an update restart on the same port, the old window reloads itself
    _run_app(url, home, open_first=not (restarted and port == last))


def restart() -> None:
    """Quit and reopen the app, which switches to a downloaded update (see desktop/launch.py)."""
    bundle = Path(sys.executable).resolve().parents[2]
    if bundle.suffix != ".app":
        raise RuntimeError("Restart only works in the Mac app.")
    home = os.environ.get("ARISTOTLE_HOME", "")
    subprocess.Popen(["/bin/sh", "-c", f'sleep 1; open -n "{bundle}" --env ARISTOTLE_RESTARTED=1 --env ARISTOTLE_HOME="{home}"'],
                     start_new_session=True)
    threading.Timer(0.3, lambda: os._exit(0)).start()


def _run_app(url: str, home: Path, open_first: bool = True) -> None:
    """The Cocoa side: Dock icon, a small menu, reopen on Dock click, Cmd-Q to quit."""
    from AppKit import (NSApplication, NSApplicationActivationPolicyRegular, NSMenu, NSMenuItem)
    from Foundation import NSObject

    class Delegate(NSObject):
        def applicationDidFinishLaunching_(self, note):
            if open_first:
                open_window(url, home)

        def applicationShouldHandleReopen_hasVisibleWindows_(self, app, visible):
            open_window(url, home)
            return True

        def openWindow_(self, sender):
            open_window(url, home)

    app = NSApplication.sharedApplication()
    app.setActivationPolicy_(NSApplicationActivationPolicyRegular)
    delegate = Delegate.alloc().init()
    app.setDelegate_(delegate)

    bar, app_item = NSMenu.alloc().init(), NSMenuItem.alloc().init()
    bar.addItem_(app_item)
    menu = NSMenu.alloc().init()
    item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_("Open Aristotle Window", "openWindow:", "n")
    item.setTarget_(delegate)
    menu.addItem_(item)
    menu.addItem_(NSMenuItem.separatorItem())
    menu.addItem_(NSMenuItem.alloc().initWithTitle_action_keyEquivalent_("Quit Aristotle", "terminate:", "q"))
    app_item.setSubmenu_(menu)
    app.setMainMenu_(bar)
    app.run()


if __name__ == "__main__":
    main()


# ---------- the native window ----------

def _run_native(url: str) -> None:
    """One window with the app in a WKWebView. Closing it keeps Aristotle running (the Dock icon
    brings it back), like other Mac apps; Cmd-Q quits. Links that leave the app open in the
    default browser, file inputs get a real Open panel, and downloads go through the browser."""
    import objc
    from AppKit import (NSAlert, NSApplication, NSApplicationActivationPolicyRegular, NSBackingStoreBuffered,
                        NSColor, NSMakeRect, NSMakeSize, NSMenu, NSMenuItem, NSModalResponseOK, NSOpenPanel,
                        NSWindow, NSWorkspace)
    from Foundation import NSURL, NSObject, NSURLRequest
    from WebKit import WKWebView, WKWebViewConfiguration

    STYLE = 1 | 2 | 4 | 8  # titled, closable, miniaturizable, resizable
    home_host = "127.0.0.1"

    def external(u) -> bool:
        return u is not None and (u.host() or "") != home_host and (u.scheme() or "") in ("http", "https", "mailto")

    class AristotleWindowDelegate(NSObject):
        def init(self):
            self = objc.super(AristotleWindowDelegate, self).init()
            self.window = None
            return self

        # app
        def applicationDidFinishLaunching_(self, note):
            self.show_(None)

        def applicationShouldHandleReopen_hasVisibleWindows_(self, app, visible):
            self.show_(None)
            return True

        def show_(self, sender):
            if self.window is None:
                self.window = self.makeWindow()
            self.window.makeKeyAndOrderFront_(None)
            NSApplication.sharedApplication().activateIgnoringOtherApps_(True)

        def reload_(self, sender):
            if self.window is not None:
                self.web.reload()

        def makeWindow(self):
            win = NSWindow.alloc().initWithContentRect_styleMask_backing_defer_(
                NSMakeRect(0, 0, 1320, 860), STYLE, NSBackingStoreBuffered, False)
            win.setTitle_("Aristotle")
            win.setReleasedWhenClosed_(False)
            win.setMinSize_(NSMakeSize(720, 520))
            win.setBackgroundColor_(NSColor.windowBackgroundColor())
            win.center()
            win.setFrameAutosaveName_("AristotleMain")  # reopens where it was left
            cfg = WKWebViewConfiguration.alloc().init()
            web = WKWebView.alloc().initWithFrame_configuration_(win.contentView().bounds(), cfg)
            web.setAutoresizingMask_(2 | 16)  # width and height follow the window
            web.setAllowsBackForwardNavigationGestures_(True)
            if hasattr(web, "setInspectable_"):
                web.setInspectable_(True)
            web.setNavigationDelegate_(self)
            web.setUIDelegate_(self)
            win.setContentView_(web)
            web.loadRequest_(NSURLRequest.requestWithURL_(NSURL.URLWithString_(url)))
            self.web = web
            return win

        # navigation: stay inside the app; everything else opens in the browser
        def webView_decidePolicyForNavigationAction_decisionHandler_(self, web, action, handler):
            u = action.request().URL()
            download = (hasattr(action, "shouldPerformDownload") and action.shouldPerformDownload()) or \
                (u is not None and str(u.path() or "").endswith("/pack"))
            if external(u) or download:
                NSWorkspace.sharedWorkspace().openURL_(u)
                handler(0)  # cancel
                return
            handler(1)  # allow

        def webView_createWebViewWithConfiguration_forNavigationAction_windowFeatures_(self, web, cfg, action, features):
            u = action.request().URL()
            if u is not None:
                NSWorkspace.sharedWorkspace().openURL_(u)  # target=_blank links
            return None

        def webViewWebContentProcessDidTerminate_(self, web):
            web.reload()

        # file inputs, alerts and confirms the page might use
        def webView_runOpenPanelWithParameters_initiatedByFrame_completionHandler_(self, web, params, frame, handler):
            panel = NSOpenPanel.openPanel()
            panel.setAllowsMultipleSelection_(params.allowsMultipleSelection())
            panel.setCanChooseDirectories_(False)
            handler(panel.URLs() if panel.runModal() == NSModalResponseOK else None)

        def webView_runJavaScriptAlertPanelWithMessage_initiatedByFrame_completionHandler_(self, web, msg, frame, handler):
            a = NSAlert.alloc().init()
            a.setMessageText_(msg)
            a.runModal()
            handler()

        def webView_runJavaScriptConfirmPanelWithMessage_initiatedByFrame_completionHandler_(self, web, msg, frame, handler):
            a = NSAlert.alloc().init()
            a.setMessageText_(msg)
            a.addButtonWithTitle_("OK")
            a.addButtonWithTitle_("Cancel")
            handler(a.runModal() == 1000)

    app = NSApplication.sharedApplication()
    app.setActivationPolicy_(NSApplicationActivationPolicyRegular)
    delegate = AristotleWindowDelegate.alloc().init()
    app.setDelegate_(delegate)

    def item(title, action, key="", target=None, mods=None):
        it = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(title, action, key)
        if target is not None:
            it.setTarget_(target)
        if mods is not None:
            it.setKeyEquivalentModifierMask_(mods)
        return it

    def menu(title, items):
        m = NSMenu.alloc().initWithTitle_(title)
        for it in items:
            m.addItem_(it if it is not None else NSMenuItem.separatorItem())
        holder = NSMenuItem.alloc().init()
        holder.setSubmenu_(m)
        return holder, m

    bar = NSMenu.alloc().init()
    for holder, m in [
        menu("Aristotle", [item("Hide Aristotle", "hide:", "h"), item("Hide Others", "hideOtherApplications:", "h", mods=(1 << 20) | (1 << 19)),
                           item("Show All", "unhideAllApplications:"), None, item("Quit Aristotle", "terminate:", "q")]),
        menu("Edit", [item("Undo", "undo:", "z"), item("Redo", "redo:", "Z"), None, item("Cut", "cut:", "x"),
                      item("Copy", "copy:", "c"), item("Paste", "paste:", "v"), item("Select All", "selectAll:", "a")]),
        menu("View", [item("Reload", "reload:", "r", delegate), None,
                      item("Enter Full Screen", "toggleFullScreen:", "f", mods=(1 << 20) | (1 << 18))]),
        menu("Window", [item("Aristotle", "show:", "n", delegate), item("Minimize", "performMiniaturize:", "m"),
                        item("Zoom", "performZoom:"), item("Close", "performClose:", "w")]),
    ]:
        bar.addItem_(holder)
        if m.title() == "Window":
            app.setWindowsMenu_(m)
    app.setMainMenu_(bar)
    app.run()
