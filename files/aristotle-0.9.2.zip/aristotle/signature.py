"""Signature ideas: what a person is best known for, so builds read those passages first and
retrieval doesn't bury them under close paraphrases (the blind-eval losses named famous
heuristics the map had missed).

  ideas(llm, cfg)              8-15 short phrases, asked once (one fast call) and kept in config.json
  prioritize(chunks, ideas)    chunk ids that state them best, best first
  coverage(emap, ideas)        which ideas the map states, and with which belief
"""
from __future__ import annotations

import numpy as np

from .llm import parse_json

SYSTEM = """List the ideas a well-read person would name first when asked what {name} is known \
for: their signature principles, heuristics, frameworks and coined terms, in their own vocabulary \
where they have one ("specific knowledge", "margin of safety", "the dichotomy of control"). \
8 to 15 items, each a short phrase plus a few words saying what it means, most famous first. \
Only ideas they actually hold or wrote about, not facts about their life. If you don't know \
this person's ideas well, return fewer items rather than guessing. Return a JSON list of strings."""


def ideas(llm, cfg: dict) -> list[str]:
    prof = cfg.get("profile", {})
    who = f"{cfg['name']}" + (f" ({prof['description']})" if prof.get("description") else "")
    context = prof.get("extract", "")[:800]
    lens = (cfg.get("tradition") or {}).get("lens")
    try:
        out = parse_json(llm.complete(SYSTEM.format(name=lens or who),
                                      f"Who: {lens or who}\n\n{context}".strip(), tier="fast"))
    except Exception:
        return []
    return [str(x).strip() for x in out if str(x).strip()][:15] if isinstance(out, list) else []


def prioritize(chunks: list, phrases: list[str], embedder=None) -> list[str]:
    """Ids of the chunks that best state each signature idea (the top two per idea), interleaved
    so every idea gets a passage before any gets a second."""
    if not phrases or not chunks:
        return []
    from .embed import Embedder

    emb = embedder or Embedder([c.text[:2000] for c in chunks])
    sims = emb.sims(phrases)  # ideas x chunks
    floor = 0.08 if emb.backend == "tfidf" else 0.55
    out: list[str] = []
    for rank in range(2):
        for row in sims:
            order = [i for i in np.argsort(-row) if row[i] >= floor]
            if rank < len(order) and chunks[order[rank]].id not in out:
                out.append(chunks[order[rank]].id)
    return out


def coverage(emb, nodes: list, phrases: list[str]) -> list[dict]:
    """[{idea, node (id or None), score}] using the retrieval embedder over the map's beliefs."""
    if not phrases or not nodes:
        return [{"idea": p, "node": None, "score": 0.0} for p in phrases]
    sims = emb.sims(phrases)
    floor = 0.12 if emb.backend == "tfidf" else 0.75  # below ~0.75 the match is a neighbouring idea
    out = []
    for p, row in zip(phrases, sims):
        i = int(np.argmax(row))
        out.append({"idea": p, "node": nodes[i].id if row[i] >= floor else None, "score": round(float(row[i]), 3)})
    return out
