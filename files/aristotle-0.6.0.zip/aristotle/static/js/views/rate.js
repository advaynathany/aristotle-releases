// Blind test: Aristotle against a plain "answer as X" model, formatting stripped from both so
// neither gives itself away.
import {$, $$, api, esc, icon, typing} from "../ui.js";

const plain = t => String(t || "").replace(/\s*\[n\d{4}\]/g, "").replace(/\*\*(.+?)\*\*/g, "$1").replace(/(^|\s)\*(\S.*?)\*/g, "$1$2")
  .replace(/^#+\s*/gm, "").split(/\n\s*\n/).filter(p => p.trim()).map(p => `<p>${esc(p.trim())}</p>`).join("");

export async function mount(view, ctx) {
  const {slug, info} = ctx;
  view.innerHTML = `<div class="rate" id="rate"></div>`;
  let R, i = 0;
  try { R = await api(`/api/t/${slug}/blind`); }
  catch {
    $("#rate").innerHTML = `<div class="done-card">${icon("scale", "lg")}<h2>No pairs to rate yet</h2>
      <p>Generate them with <code>python cli.py eval thinkers/${esc(slug)} run blind</code>, then come back.</p></div>`;
    return;
  }
  const first = R.pairs.findIndex(p => !R.ratings[p.id]);
  i = first === -1 ? 0 : first;

  const go = n => { i = Math.max(0, Math.min(R.pairs.length - 1, n)); draw(); $(".main").scrollTop = 0; };
  async function pick(c) {
    const p = R.pairs[i];
    try { await api(`/api/t/${slug}/rate`, {id: p.id, choice: c}); } catch (e) { return; }
    R.ratings[p.id] = c;
    if (!R.pairs.some(x => !R.ratings[x.id])) return doneCard();
    const next = R.pairs.findIndex((x, j) => j > i && !R.ratings[x.id]);
    go(next === -1 ? R.pairs.findIndex(x => !R.ratings[x.id]) : next);
  }
  function doneCard() {
    $("#rate").innerHTML = `<div class="done-card">${icon("circle-check-big", "lg")}<h2>All ${R.pairs.length} pairs rated</h2>
      <p>See whether Aristotle passed with <code>python cli.py eval thinkers/${esc(slug)} report</code>.</p>
      <p><button class="btn" id="again">Look back through your ratings</button></p></div>`;
    $("#again").onclick = () => go(0);
  }
  function draw() {
    const p = R.pairs[i], mine = R.ratings[p.id], done = Object.keys(R.ratings).length;
    $("#rate").innerHTML = `<div class="segs">${R.pairs.map((x, j) => `<button class="${R.ratings[x.id] ? "done" : ""} ${j === i ? "cur" : ""}" data-i="${j}" aria-label="Pair ${j + 1}${R.ratings[x.id] ? ", rated" : ""}"></button>`).join("")}</div>
      <p class="ratehead"><b>Pair ${i + 1} of ${R.pairs.length}, ${done} rated.</b> One answer is Aristotle, the other is a plain model told to answer as ${esc(info.name)}. Pick the one that reasons more like them and helps more with the decision.</p>
      <div class="scenario">${esc(p.scenario)}</div>
      <div class="pair"><article class="${mine === "A" ? "chosen" : ""}"><h4>Answer A</h4>${plain(p.A)}</article>
        <article class="${mine === "B" ? "chosen" : ""}"><h4>Answer B</h4>${plain(p.B)}</article></div>`;
    $$("[data-i]", view).forEach(b => b.onclick = () => go(+b.dataset.i));
    bar.querySelectorAll("[data-c]").forEach(b => b.setAttribute("aria-pressed", b.dataset.c === mine));
    bar.querySelector("#prev").disabled = i === 0;
    bar.querySelector("#next").disabled = i === R.pairs.length - 1;
  }
  const bar = document.createElement("div");
  bar.className = "verdict";
  bar.innerHTML = `<div><button class="btn" data-c="A">A is better <kbd>1</kbd></button>
    <button class="btn" data-c="tie">About the same <kbd>2</kbd></button><button class="btn" data-c="B">B is better <kbd>3</kbd></button>
    <span class="spacer"></span><button class="btn ghost" id="prev">${icon("arrow-left", "sm")} Previous</button>
    <button class="btn ghost" id="next">Next ${icon("chevron-right", "sm")}</button></div>`;
  view.append(bar);
  bar.querySelectorAll("[data-c]").forEach(b => b.onclick = () => pick(b.dataset.c));
  bar.querySelector("#prev").onclick = () => go(i - 1);
  bar.querySelector("#next").onclick = () => go(i + 1);
  const onKey = e => {
    if (e.metaKey || e.ctrlKey || typing() || document.querySelector(".scrim")) return;
    const k = {"1": () => pick("A"), "2": () => pick("tie"), "3": () => pick("B"), ArrowLeft: () => go(i - 1), ArrowRight: () => go(i + 1)}[e.key];
    if (k) { e.preventDefault(); k(); }
  };
  document.addEventListener("keydown", onKey);
  draw();
  return () => document.removeEventListener("keydown", onKey);
}
