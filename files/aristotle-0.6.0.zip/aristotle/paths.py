"""Where Aristotle keeps its data.

Run from a checkout (cli.py next to the package), everything stays in the repo as before. Installed
as an app (`uv tool install`), the package lives somewhere read-only-ish, so the library and caches
go to ~/Aristotle instead. ARISTOTLE_HOME overrides both.
"""
import os
from pathlib import Path

_REPO = Path(__file__).resolve().parent.parent

if os.environ.get("ARISTOTLE_HOME"):
    HOME = Path(os.environ["ARISTOTLE_HOME"]).expanduser()
elif (_REPO / "cli.py").exists():
    HOME = _REPO
else:
    HOME = Path.home() / "Aristotle"

CACHE = HOME / ".cache"
LIBRARY = HOME / "thinkers"
