"""Background builds for the web app: one at a time, because every build spends plan usage.

A job's state lives in thinkers/<slug>/job.json so the UI can poll it and a restart can tell the
user a build was cut short. Extraction replies are cached, so re-running an interrupted build only
pays for the passages it had not reached.
"""
from __future__ import annotations

import json
import os
import queue
import re
import threading
import time
from pathlib import Path

from .discover import load_cfg, materialize, save_cfg
from .traditions import extract_note, lens
from .library import built_ids, load_chunks, pick_chunks, save_map
from .schema import save_chunks

CALLS_PER_PASSAGE = 1.8  # one extraction call each, plus linking (~7 beliefs per passage, 10 per call)
# about 12-15s per claude -p call with 4 in flight (measured: 8 passages, 15 calls, 46s)


# claude -p takes ~15s a call; Gemini Flash-Lite on the hosted copy takes ~4s
SECONDS_PER_CALL = 4 if os.environ.get("ARISTOTLE_BACKEND") == "openai" else 15


def estimate(passages: int) -> dict:
    return {"passages": passages, "calls": round(passages * CALLS_PER_PASSAGE),
            "minutes": max(1, round(passages * CALLS_PER_PASSAGE * SECONDS_PER_CALL / 4 / 60))}


class Builder:
    def __init__(self, llm, on_done=None):
        self.llm, self.on_done = llm, on_done
        self.q: queue.Queue = queue.Queue()
        self.lock = threading.Lock()
        threading.Thread(target=self._loop, daemon=True).start()

    @staticmethod
    def recover(root: Path) -> None:
        """A server restart kills the worker; say so instead of showing a build that never ends."""
        for job in Path(root).glob("*/job.json"):
            j = json.loads(job.read_text())
            if j.get("state") in ("queued", "running"):
                j.update(state="interrupted", message="The app restarted during this build. Run it again; "
                         "finished passages are cached and won't be re-read.")
                job.write_text(json.dumps(j))

    def submit(self, folder: Path, passages: int | None) -> dict:
        folder = Path(folder)
        j = {"state": "queued", "phase": "queued", "passages": passages, "done": 0, "total": 0,
             "message": "Waiting for the current build to finish", "recent": [], "started": time.time()}
        self._write(folder, j)
        self.q.put((folder, passages))
        return j

    def _write(self, folder: Path, j: dict) -> None:
        with self.lock:  # write then rename, so a poll never reads half a file
            tmp = folder / "job.json.tmp"
            tmp.write_text(json.dumps(j, ensure_ascii=False))
            os.replace(tmp, folder / "job.json")

    def _loop(self) -> None:
        while True:
            folder, passages = self.q.get()
            try:
                self._run(folder, passages)
            except Exception as e:  # surface every failure in the UI rather than a silent stop
                j = json.loads((folder / "job.json").read_text())
                j.update(state="error", message=str(e) or type(e).__name__)
                self._write(folder, j)
            finally:
                if self.on_done:
                    self.on_done(folder)

    def _run(self, folder: Path, passages: int | None) -> None:
        from .extract import build_map

        j = json.loads((folder / "job.json").read_text())
        upd = lambda **kw: (j.update(kw), self._write(folder, j))
        upd(state="running", phase="fetch", message="Downloading sources")
        cfg = load_cfg(folder)
        for c in cfg.get("candidates", []):
            if c.get("selected", True) and c.get("status") == "remote":
                upd(message=f"Downloading {c['title']}")
                materialize(folder, c)
        upd(phase="read", message="Splitting sources into passages")
        chunks = load_chunks(folder, log=lambda m: None)
        if not chunks:
            raise ValueError("No readable sources are selected. Tick at least one source, or add a link or file.")
        save_chunks(chunks, folder / "chunks.json")
        todo = pick_chunks(chunks, built_ids(folder), passages)
        counts = isinstance(getattr(self.llm, "calls", None), int)
        calls0, t0 = self.llm.calls if counts else 0, time.time()

        def progress(msg: str) -> None:
            m = re.match(r"extracted (\d+)/(\d+) chunks: (\d+) nodes", msg)
            if m:
                upd(phase="extract", done=int(m.group(1)), total=int(m.group(2)),
                    message=f"Reading passage {m.group(1)} of {m.group(2)}", found=int(m.group(3)))
            elif msg.startswith("deduped"):
                upd(phase="link", message="Merging duplicates and linking related beliefs")

        def on_nodes(nodes) -> None:
            fresh = [{"kind": n.kind, "statement": n.statement, "quote": n.sources[0].quote,
                      "where": n.sources[0].origin or n.sources[0].section} for n in nodes[:2]]
            j["recent"] = (fresh + j.get("recent", []))[:8]

        upd(phase="extract", done=0, total=len(todo), message=f"Reading {len(todo)} passages")
        emap, stats = build_map(self.llm, todo, lens(cfg), progress=progress, on_nodes=on_nodes,
                                note=extract_note(cfg))
        info = save_map(folder, emap, built_ids=[c.id for c in todo])
        cfg = load_cfg(folder)
        cfg["built_at"] = time.strftime("%Y-%m-%d")
        save_cfg(folder, cfg)
        calls = (self.llm.calls - calls0) if counts else None
        upd(state="done", phase="done", done=len(todo), total=len(todo), calls=calls,
            seconds=round(time.time() - t0), available=len(chunks),
            message=f"{info['nodes']:,} beliefs from {len(todo)} passages", **stats)
