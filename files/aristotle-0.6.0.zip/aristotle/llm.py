"""LLM wrapper. The rest of the pipeline only calls `complete`.

Three backends:
  - "cli" (default): shells out to `claude -p`, which runs on your claude.ai plan. No API key, no
    per-token bill; calls count against the plan's usage limits instead. For your own use only.
  - "api": the Anthropic SDK, used when ARISTOTLE_BACKEND=api (needs ANTHROPIC_API_KEY).
  - "openai": any OpenAI-compatible chat endpoint (ARISTOTLE_LLM_URL, ARISTOTLE_LLM_KEY). The
    hosted guest copy uses it with Gemini's free tier, so other people's questions cost nothing
    and never touch your Claude plan.

Two tiers: "strong" for extraction and final answers, "fast" for routing (themes, linking, judging
cheap things). Every reply is cached on disk keyed by (model, system, prompt), so rebuilding the
map or re-running an eval only pays for what changed.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import tempfile
import threading
from pathlib import Path

from .paths import CACHE

DEFAULTS = {
    "cli": ("claude-opus-5-5", "claude-haiku-5-5"),
    "api": ("claude-opus-5-5", "claude-haiku-5-5"),
    # On the free tier (Oct 2026) Pro models have no quota and the full Flash models mostly time
    # out under load; 3.5 Flash-Lite answers in ~5s with every quote verified.
    "openai": ("gemini-3.5-flash-lite", "gemini-3.5-flash-lite"),
}
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/openai"
CACHE_DIR = Path(os.environ.get("ARISTOTLE_CACHE", CACHE / "llm"))


class LLMError(RuntimeError):
    pass


def claude_bin() -> str:
    """The Claude Code CLI. Apps started from a dock or launcher get a bare PATH, so look in the
    places its installers use too."""
    import shutil

    found = shutil.which("claude")
    if found:
        return found
    for p in ("~/.local/bin/claude", "~/.claude/local/claude", "~/.npm-global/bin/claude",
              "/opt/homebrew/bin/claude", "/usr/local/bin/claude"):
        if Path(p).expanduser().exists():
            return str(Path(p).expanduser())
    try:  # npm, nvm and others set PATH in the login shell, which a launched app doesn't read
        shell = os.environ.get("SHELL") or "/bin/zsh"
        out = subprocess.run([shell, "-lic", "command -v claude"], capture_output=True, text=True, timeout=10)
        found = out.stdout.strip().splitlines()[-1] if out.stdout.strip() else ""
        if found and Path(found).exists():
            return found
    except (OSError, subprocess.TimeoutExpired):
        pass
    return "claude"


def claude_status() -> dict:
    """Is the Claude CLI installed and signed in? Uses no plan usage."""
    exe = claude_bin()
    try:
        p = subprocess.run([exe, "auth", "status", "--json"], capture_output=True, text=True, timeout=20)
        info = json.loads(p.stdout or "{}")
    except FileNotFoundError:
        return {"installed": False, "logged_in": False}
    except (subprocess.TimeoutExpired, json.JSONDecodeError):
        return {"installed": True, "logged_in": False}
    return {"installed": True, "logged_in": bool(info.get("loggedIn")),
            "plan": info.get("subscriptionType") or info.get("authMethod") or "", "email": info.get("email", "")}


class LLM:
    def __init__(self, backend: str | None = None, cache: bool = True):
        self.backend = backend or os.environ.get("ARISTOTLE_BACKEND", "cli")
        self.cache = cache
        self.calls = 0  # uncached calls made, for reporting
        self._lock = threading.Lock()
        if self.backend not in DEFAULTS:
            raise ValueError(f"unknown backend {self.backend!r}")
        strong, fast = DEFAULTS[self.backend]
        self.models = {"strong": os.environ.get("ARISTOTLE_MODEL", strong),
                       "fast": os.environ.get("ARISTOTLE_FAST_MODEL", fast)}
        if self.backend == "api":
            import anthropic  # imported lazily so tests and the cli backend run without it

            self.client = anthropic.Anthropic()
        elif self.backend == "openai":
            import httpx

            self.url = os.environ.get("ARISTOTLE_LLM_URL", GEMINI_URL).rstrip("/") + "/chat/completions"
            self.key = os.environ.get("ARISTOTLE_LLM_KEY") or os.environ.get("GEMINI_API_KEY") or ""
            self.http = httpx.Client(timeout=90)
            # Gemini Flash at its default reasoning took over 5 minutes on one answer; "low" took
            # 10s with the same citations. Set ARISTOTLE_REASONING="" for providers that reject it.
            self.reasoning = os.environ.get("ARISTOTLE_REASONING", "low")
        self._cwd = tempfile.mkdtemp(prefix="aristotle-llm-")  # no CLAUDE.md gets picked up

    def complete(self, system: str, user: str, history: list[dict] | None = None,
                 max_tokens: int = 8000, tier: str = "strong") -> str:
        model = self.models[tier]
        prompt = _flatten(history, user)
        key = hashlib.sha256(json.dumps([model, system, prompt]).encode()).hexdigest()
        path = CACHE_DIR / key[:2] / f"{key}.json"
        if self.cache and path.exists():
            return json.loads(path.read_text())["text"]
        if self.backend == "cli":
            text = self._cli(model, system, prompt, tier)
        elif self.backend == "openai":
            text = self._openai(model, system, history, user)
        else:
            text = self._api(model, system, history, user, max_tokens, tier)
        with self._lock:
            self.calls += 1
        if self.cache:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps({"model": model, "text": text}))
        return text

    def _cli(self, model: str, system: str, prompt: str, tier: str) -> str:
        cmd = [claude_bin(), "-p", "--model", model, "--system-prompt", system,
               "--tools", "", "--strict-mcp-config", "--setting-sources", "",
               "--no-session-persistence", "--disable-slash-commands",
               "--output-format", "json", "--effort", "low" if tier == "fast" else "medium"]
        last = ""
        for _ in range(3):
            p = subprocess.run(cmd, input=prompt, capture_output=True, text=True,
                               cwd=self._cwd, timeout=600)
            try:
                out = json.loads(p.stdout)
            except json.JSONDecodeError:
                last = (p.stderr or p.stdout)[-500:]
                continue
            if not out.get("is_error"):
                return out.get("result", "")
            last = str(out.get("result") or out.get("api_error_status"))
            if "limit" in last.lower():  # plan usage limit: retrying won't help
                break
        raise LLMError(f"claude -p failed: {last}")

    def _api(self, model, system, history, user, max_tokens, tier) -> str:
        messages = list(history or []) + [{"role": "user", "content": user}]
        r = self.client.messages.create(
            model=model, max_tokens=max_tokens,
            system=[{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            output_config={"effort": "low" if tier == "fast" else "medium"},
            messages=messages,
        )
        return "".join(b.text for b in r.content if b.type == "text")


    def _openai(self, model, system, history, user) -> str:
        """No max_tokens: on reasoning models it also caps the thinking, and a short cap (themes
        ask for 300) can leave nothing for the reply. Rate limits, overload and timeouts back off
        briefly, then fail."""
        import time

        import httpx

        messages = [{"role": "system", "content": system}] + [
            {"role": "assistant" if m["role"] == "assistant" else "user", "content": m["content"]}
            for m in history or []] + [{"role": "user", "content": user}]
        body = {"model": model, "messages": messages}
        if self.reasoning:
            body["reasoning_effort"] = self.reasoning
        last = ""
        for wait in (0, 2, 6, 15, 30, 60):
            time.sleep(wait)
            try:
                r = self.http.post(self.url, headers={"Authorization": f"Bearer {self.key}"}, json=body)
            except httpx.TimeoutException:
                last = "timed out"
                continue
            if r.status_code == 200:
                text = r.json()["choices"][0]["message"].get("content") or ""
                if text:
                    return text
                last = "empty reply"
                continue
            last = f"{r.status_code} {r.text[:300]}"
            if r.status_code not in (429, 500, 502, 503, 504):
                break
        if "429" in last[:3]:
            raise LLMError("The free model is at its rate limit. Try again in a minute.")
        raise LLMError(f"model call failed: {last}")


def _flatten(history: list[dict] | None, user: str) -> str:
    """`claude -p` takes one prompt, so earlier turns are rendered as a transcript."""
    if not history:
        return user
    turns = "\n\n".join(f"[{m['role'].upper()}]\n{m['content']}" for m in history)
    return f"EARLIER IN THIS CONVERSATION:\n{turns}\n\n[USER, NOW]\n{user}"


def parse_json(text: str):
    """Pull the first JSON value out of a model reply (handles ``` fences and chatter)."""
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if fenced:
        text = fenced.group(1)
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    starts = [i for i in (text.find("["), text.find("{")) if i != -1]
    if not starts:
        raise ValueError("no JSON found in model reply")
    start = min(starts)
    end = max(text.rfind("]"), text.rfind("}"))
    try:
        return json.loads(text[start : end + 1])
    except json.JSONDecodeError as e:
        raise ValueError(f"bad JSON in model reply: {e}") from e
