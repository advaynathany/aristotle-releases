"""Core data types for an episteme map."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

NODE_KINDS = ("principle", "heuristic", "value", "case", "boundary")
EDGE_KINDS = ("supports", "derives_from", "conflicts_with", "outweighs")
REVIEW_STATES = ("auto", "approved", "rejected")


@dataclass
class Chunk:
    id: str
    source_id: str
    section: str
    text: str
    tier: int = 1  # 1 = own writing, 2 = transcribed speech, 3 = third-party summary
    date: str = ""
    # citation number -> {"ref", "date", "tier"}; resolved per quote at extraction time
    citations: dict = field(default_factory=dict)


@dataclass
class Source:
    chunk_id: str
    section: str
    quote: str  # verbatim excerpt, verified against the chunk text
    tier: int = 1
    date: str = ""
    origin: str = ""  # original publication the quote came from, when known


@dataclass
class Node:
    id: str
    kind: str
    statement: str
    sources: list[Source] = field(default_factory=list)
    review: str = "auto"  # auto | approved | rejected (set in the review UI)
    note: str = ""  # reviewer note

    @property
    def dates(self) -> list[str]:
        return sorted(s.date for s in self.sources if s.date)

    @property
    def first_seen(self) -> str:
        return self.dates[0] if self.dates else ""

    @property
    def last_seen(self) -> str:
        return self.dates[-1] if self.dates else ""

    @property
    def best_tier(self) -> int:
        return min((s.tier for s in self.sources), default=3)


@dataclass
class Edge:
    src: str
    dst: str
    kind: str
    note: str = ""


@dataclass
class EpistemeMap:
    thinker: str
    nodes: list[Node] = field(default_factory=list)
    edges: list[Edge] = field(default_factory=list)

    def __post_init__(self):
        self._index = {n.id: n for n in self.nodes}

    def node(self, node_id: str) -> Node | None:
        if len(self._index) != len(self.nodes):
            self._index = {n.id: n for n in self.nodes}
        return self._index.get(node_id)

    def live_nodes(self) -> list[Node]:
        """Nodes the reasoner may use: everything a reviewer hasn't rejected."""
        return [n for n in self.nodes if n.review != "rejected"]

    def neighbors(self, node_id: str) -> list[tuple[str, Edge]]:
        out = []
        for e in self.edges:
            if e.src == node_id:
                out.append((e.dst, e))
            elif e.dst == node_id:
                out.append((e.src, e))
        return out

    def save(self, path: str | Path) -> None:
        d = {"thinker": self.thinker, "nodes": [asdict(n) for n in self.nodes],
             "edges": [asdict(e) for e in self.edges]}
        Path(path).write_text(json.dumps(d, indent=2, ensure_ascii=False))

    @classmethod
    def load(cls, path: str | Path) -> "EpistemeMap":
        d = json.loads(Path(path).read_text())
        nodes = []
        for n in d["nodes"]:
            srcs = [Source(**s) for s in n.pop("sources")]
            nodes.append(Node(**n, sources=srcs))
        return cls(thinker=d["thinker"], nodes=nodes, edges=[Edge(**e) for e in d["edges"]])


def save_chunks(chunks: list[Chunk], path: str | Path) -> None:
    Path(path).write_text(json.dumps([asdict(c) for c in chunks], ensure_ascii=False))


def load_chunks(path: str | Path) -> list[Chunk]:
    return [Chunk(**c) for c in json.loads(Path(path).read_text())]
