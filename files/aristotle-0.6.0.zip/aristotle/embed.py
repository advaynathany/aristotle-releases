"""Local text embeddings for dedupe, linking and retrieval. Free: runs on-device.

Default is fastembed (BAAI/bge-small-en-v1.5, ~130 MB, downloaded once). Set
ARISTOTLE_EMBED=tfidf (tests do) to use character n-gram TF-IDF instead, with no model download.
"""
from __future__ import annotations

import hashlib
import os
from functools import lru_cache
from pathlib import Path

import numpy as np

from .paths import CACHE


@lru_cache(maxsize=1)
def _model():
    from fastembed import TextEmbedding

    return TextEmbedding("BAAI/bge-small-en-v1.5")


class Embedder:
    """Fit on a corpus once, then embed queries into the same space. Rows are L2-normalised."""

    def __init__(self, corpus: list[str], backend: str | None = None):
        self.backend = backend or os.environ.get("ARISTOTLE_EMBED", "fastembed")
        if self.backend == "tfidf":
            from sklearn.feature_extraction.text import TfidfVectorizer

            self.vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), sublinear_tf=True)
            self.vec.fit(corpus or ["empty"])
        self.matrix = self._cached(corpus) if corpus else np.zeros((0, 1))

    def _cached(self, corpus: list[str]) -> np.ndarray:
        """Corpus embeddings are cached on disk by content hash: embedding ~2k beliefs on CPU
        takes about a minute, and every chat session and eval run would otherwise redo it."""
        if self.backend == "tfidf":
            return self.embed(corpus)
        key = hashlib.sha256("\x00".join(corpus).encode()).hexdigest()[:24]
        path = CACHE / "emb" / f"{key}.npy"
        if path.exists():
            return np.load(path)
        m = self.embed(corpus)
        path.parent.mkdir(parents=True, exist_ok=True)
        np.save(path, m)
        return m

    def embed(self, texts: list[str]) -> np.ndarray:
        if self.backend == "tfidf":
            m = self.vec.transform(texts).toarray()
        else:
            m = np.array(list(_model().embed(texts)))
        n = np.linalg.norm(m, axis=1, keepdims=True)
        return m / np.where(n == 0, 1, n)

    def sims(self, texts: list[str]) -> np.ndarray:
        """Cosine similarity of each text against the fitted corpus."""
        return self.embed(texts) @ self.matrix.T
