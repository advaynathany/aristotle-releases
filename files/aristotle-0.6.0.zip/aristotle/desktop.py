"""Aristotle as a Mac app: a real app (Dock icon, menu, Cmd-Q) that runs the local server and shows
the interface in its own window.

The window is a Chromium browser in app mode (Chrome, Edge or Brave: no tabs or address bar) when
one is installed, else the default browser. An embedded WKWebView was the first try, but on macOS
27 it never loads a network page, even 127.0.0.1, so the app doesn't depend on it.

Everything runs on this Mac. The library lives in ~/Aristotle, and every model call goes through
the Claude Code CLI signed in to the user's own subscription (the app walks them through
installing it and signing in). Clicking the Dock icon reopens the window; quitting stops it all.
"""
from __future__ import annotations

import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

CHROMIUM = ["Google Chrome", "Microsoft Edge", "Brave Browser", "Chromium"]


def _free_port(preferred: int = 8765) -> int:
    for port in [preferred, *range(preferred + 1, preferred + 50)]:
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _app_path(name: str) -> Path | None:
    for base in (Path("/Applications"), Path.home() / "Applications"):
        if (base / f"{name}.app").exists():
            return base / f"{name}.app"
    return None


def open_window(url: str, home: Path) -> None:
    """A tabless app window when a Chromium browser is installed (its own profile, so it never
    mixes with the user's tabs), otherwise a tab in the default browser."""
    for name in CHROMIUM:
        if _app_path(name):
            subprocess.Popen(["open", "-na", name, "--args", f"--app={url}",
                              f"--user-data-dir={home / '.window'}", "--no-first-run",
                              "--no-default-browser-check", "--window-size=1320,860"])
            return
    subprocess.Popen(["open", url])


def main() -> None:
    os.environ.setdefault("ARISTOTLE_HOME", str(Path.home() / "Aristotle"))
    home = Path(os.environ["ARISTOTLE_HOME"])
    (home / "thinkers").mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("FASTEMBED_CACHE_PATH", str(home / ".cache" / "fastembed"))
    log = open(home / "aristotle.log", "a", buffering=1)
    if getattr(sys, "frozen", False):  # a bundled app has no terminal to print to
        sys.stdout = sys.stderr = log

    import uvicorn

    from .server import make_app

    port_file = home / ".port"
    try:  # the same port as last time, so an open window reconnects after an update restart
        last = int(port_file.read_text())
    except (OSError, ValueError):
        last = 8765
    port = _free_port(last)
    port_file.write_text(str(port))
    restarted = os.environ.pop("ARISTOTLE_RESTARTED", "") == "1"
    url = f"http://127.0.0.1:{port}/"
    server = uvicorn.Server(uvicorn.Config(make_app(home / "thinkers"), host="127.0.0.1", port=port,
                                           log_level="warning", log_config=None))
    threading.Thread(target=server.run, daemon=True).start()
    for _ in range(300):  # first launch can be slow while macOS checks the app
        try:
            urllib.request.urlopen(url + "api/library", timeout=1)
            break
        except Exception:
            time.sleep(0.2)
    print(f"Aristotle {url}", flush=True)
    from . import updater
    updater.start_background()
    # after an update restart on the same port, the old window reloads itself
    _run_app(url, home, open_first=not (restarted and port == last))


def restart() -> None:
    """Quit and reopen the app, which switches to a downloaded update (see desktop/launch.py)."""
    bundle = Path(sys.executable).resolve().parents[2]
    if bundle.suffix != ".app":
        raise RuntimeError("Restart only works in the Mac app.")
    home = os.environ.get("ARISTOTLE_HOME", "")
    subprocess.Popen(["/bin/sh", "-c", f'sleep 1; open -n "{bundle}" --env ARISTOTLE_RESTARTED=1 --env ARISTOTLE_HOME="{home}"'],
                     start_new_session=True)
    threading.Timer(0.3, lambda: os._exit(0)).start()


def _run_app(url: str, home: Path, open_first: bool = True) -> None:
    """The Cocoa side: Dock icon, a small menu, reopen on Dock click, Cmd-Q to quit."""
    from AppKit import (NSApplication, NSApplicationActivationPolicyRegular, NSMenu, NSMenuItem)
    from Foundation import NSObject

    class Delegate(NSObject):
        def applicationDidFinishLaunching_(self, note):
            if open_first:
                open_window(url, home)

        def applicationShouldHandleReopen_hasVisibleWindows_(self, app, visible):
            open_window(url, home)
            return True

        def openWindow_(self, sender):
            open_window(url, home)

    app = NSApplication.sharedApplication()
    app.setActivationPolicy_(NSApplicationActivationPolicyRegular)
    delegate = Delegate.alloc().init()
    app.setDelegate_(delegate)

    bar, app_item = NSMenu.alloc().init(), NSMenuItem.alloc().init()
    bar.addItem_(app_item)
    menu = NSMenu.alloc().init()
    item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_("Open Aristotle Window", "openWindow:", "n")
    item.setTarget_(delegate)
    menu.addItem_(item)
    menu.addItem_(NSMenuItem.separatorItem())
    menu.addItem_(NSMenuItem.alloc().initWithTitle_action_keyEquivalent_("Quit Aristotle", "terminate:", "q"))
    app_item.setSubmenu_(menu)
    app.setMainMenu_(bar)
    app.run()


if __name__ == "__main__":
    main()
