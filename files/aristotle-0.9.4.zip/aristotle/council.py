"""Councils: several people from the library answer the same question, then reply to each other.

A council is a saved group (`councils.json` in the library folder). A council session holds one
Thinker per member, so each keeps its own context across follow-ups. One question goes:

  ask(question)   every member answers from its own map, in parallel
  respond()       a round: each member reads the others' latest words and replies from its own
                  beliefs (agree, push back, add); citations stay per member and are verified
  summarize()     where they agree and differ, written by the model from what was said. It
                  quotes nothing and cites nothing, and the UI labels it as a summary.
"""
from __future__ import annotations

import json
import re
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .chat import Thinker
from .llm import parse_json
from .system import replace

MIN_MEMBERS, MAX_MEMBERS, MAX_ROUNDS = 2, 5, 3

SUMMARY_SYSTEM = """Several voices answered the user's question, each strictly from one thinker's \
or one tradition's own sources, and may have replied to each other. Summarize the exchange \
for the user, fairly and without picking a winner.

Rules: use only what the voices actually said below; add no outside knowledge or doctrine. \
Name the voice for every position. No quotation marks and no citations: this is your summary, \
not their words. Real differences matter more than polite overlap; don't blur them. If two \
voices reach the same place for different reasons, say so.

Return JSON only:
{"common": [short sentences: where they converge], \
"differ": [{"point": short name of the issue, "positions": {voice name: their position in one sentence}}], \
"open": one sentence on what the user still has to weigh themselves}"""


def plain(text: str) -> str:
    """A member's words as the others see them: citation ids removed."""
    return re.sub(r"\s*\[n\d{4}(?:\s*[,;]\s*n\d{4})*\]", "", text).strip()


# ---------- saved councils ----------

class Store:
    def __init__(self, root: Path):
        self.path = Path(root) / "councils.json"
        self.lock = threading.Lock()

    def all(self) -> list[dict]:
        return json.loads(self.path.read_text()) if self.path.exists() else []

    def _save(self, items: list[dict]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(items, indent=2, ensure_ascii=False) + "\n")
        replace(tmp, self.path)

    def get(self, cid: str) -> dict | None:
        return next((c for c in self.all() if c["id"] == cid), None)

    def create(self, name: str, members: list[str]) -> dict:
        with self.lock:
            items = self.all()
            c = {"id": uuid.uuid4().hex[:10], "name": name.strip()[:80], "members": members}
            self._save(items + [c])
            return c

    def update(self, cid: str, **fields) -> dict | None:
        with self.lock:
            items = self.all()
            for c in items:
                if c["id"] == cid:
                    c.update({k: v for k, v in fields.items() if v is not None})
                    self._save(items)
                    return c
            return None

    def delete(self, cid: str) -> None:
        with self.lock:
            self._save([c for c in self.all() if c["id"] != cid])


def check_members(members: list[str]) -> list[str]:
    members = list(dict.fromkeys(members))
    if not MIN_MEMBERS <= len(members) <= MAX_MEMBERS:
        raise ValueError(f"A council needs {MIN_MEMBERS} to {MAX_MEMBERS} people.")
    return members


# ---------- a conversation with a council ----------

class Session:
    def __init__(self, llm, members: list[tuple[str, str, Thinker]]):
        """members: [(slug, display name, Thinker)]"""
        self.llm, self.members = llm, members
        self.turns: list[dict] = []  # {"question", "answers": {slug: reply}, "rounds": [{slug: reply}]}

    def _each(self, fn) -> dict:
        with ThreadPoolExecutor(len(self.members)) as pool:
            return dict(zip([m[0] for m in self.members], pool.map(fn, self.members)))

    def ask(self, question: str) -> dict:
        answers = self._each(lambda m: m[2].ask(question))
        self.turns.append({"question": question, "answers": answers, "rounds": []})
        return answers

    def latest(self, slug: str) -> dict:
        t = self.turns[-1]
        for r in reversed(t["rounds"]):
            if slug in r:
                return r[slug]
        return t["answers"][slug]

    def respond(self) -> dict:
        if not self.turns:
            raise ValueError("Ask the council a question first.")
        t = self.turns[-1]
        if len(t["rounds"]) >= MAX_ROUNDS:
            raise ValueError(f"That's {MAX_ROUNDS} rounds on this question. Ask a follow-up to go on.")
        # every member replies to the same snapshot, so nobody sees a reply written this round
        said = {slug: self.latest(slug) for slug, _, _ in self.members}
        spoke = {slug: r for slug, r in said.items() if not r.get("not_covered")}

        def one(m):
            slug, _, thinker = m
            others = [(name, plain(spoke[s]["answer"])) for s, name, _ in self.members if s != slug and s in spoke]
            if not others:
                return thinker._not_covered(0.0, "The other voices had nothing grounded to say on this, "
                                                 "so there's nothing to reply to.")
            return thinker.respond(t["question"], others)
        r = self._each(one)
        t["rounds"].append(r)
        return r

    def summarize(self) -> dict:
        if not self.turns:
            raise ValueError("Ask the council a question first.")
        t = self.turns[-1]
        names = {slug: name for slug, name, _ in self.members}
        parts = [f"{names[s]} (answer):\n{plain(r['answer'])}" for s, r in t["answers"].items() if not r.get("not_covered")]
        for i, rnd in enumerate(t["rounds"], 1):
            parts += [f"{names[s]} (reply, round {i}):\n{plain(r['answer'])}" for s, r in rnd.items()
                      if not r.get("not_covered")]
        if len({p.split(" (")[0] for p in parts}) < 2:
            return {"common": [], "differ": [], "open": "Fewer than two voices had grounded answers, so there's nothing to compare."}
        try:
            out = parse_json(self.llm.complete(SUMMARY_SYSTEM, f"QUESTION:\n{t['question']}\n\n" + "\n\n".join(parts)))
        except ValueError:
            out = {}
        if not isinstance(out, dict):
            out = {}
        unquote = lambda s: re.sub(r"[\"“”]", "", str(s))  # its own words, never presented as a quote
        differ = []
        for d in out.get("differ") or []:
            if isinstance(d, dict) and isinstance(d.get("positions"), dict):
                differ.append({"point": unquote(d.get("point", "")),
                               "positions": {unquote(k): unquote(v) for k, v in d["positions"].items()}})
        summary = {"common": [unquote(c) for c in out.get("common") or []], "differ": differ,
                   "open": unquote(out.get("open", ""))}
        t["summary"] = summary
        return summary
