"""Saved conversations, so a chat survives clicking away, reloads, updates and restarts.

Person chats live in <person>/chats/<id>.json: {id, created, updated, title, turns: [{question,
reply}]}. Council chats live in <library>/council_chats/<id>.json with the council id, its members
and the council session's own turns (answers, reply rounds, summary). Coming back to a saved chat
rebuilds the reasoning context from it, so follow-ups still see what was said before.
Owner only: the hosted guest copy never writes them (guests share one server).
"""
from __future__ import annotations

import json
import re
import threading
import time
from pathlib import Path

from .system import replace

_lock = threading.Lock()
SAFE_ID = re.compile(r"^[0-9a-f]{8,40}$")


class Store:
    def __init__(self, folder: Path):
        self.dir = Path(folder)

    def _path(self, cid: str) -> Path | None:
        return self.dir / f"{cid}.json" if cid and SAFE_ID.match(cid) else None

    def get(self, cid: str) -> dict | None:
        p = self._path(cid)
        if not p or not p.exists():
            return None
        try:
            return json.loads(p.read_text())
        except ValueError:
            return None

    def put(self, chat: dict) -> dict:
        p = self._path(chat["id"])
        if not p:
            raise ValueError("bad chat id")
        chat["updated"] = time.time()
        with _lock:
            self.dir.mkdir(parents=True, exist_ok=True)
            tmp = p.with_suffix(".tmp")
            tmp.write_text(json.dumps(chat, ensure_ascii=False))
            replace(tmp, p)
        return chat

    def list(self, **match) -> list[dict]:
        out = []
        for p in self.dir.glob("*.json") if self.dir.exists() else []:
            try:
                c = json.loads(p.read_text())
            except ValueError:
                continue
            if all(c.get(k) == v for k, v in match.items()):
                out.append({"id": c["id"], "title": c.get("title", ""), "created": c.get("created"),
                            "updated": c.get("updated"), "turns": len(c.get("turns") or [])})
        return sorted(out, key=lambda c: -(c["updated"] or 0))

    def delete(self, cid: str) -> None:
        p = self._path(cid)
        if p and p.exists():
            p.unlink()


def title_of(question: str) -> str:
    q = re.sub(r"\s+", " ", question).strip()
    return q if len(q) <= 90 else q[:88].rsplit(" ", 1)[0] + "…"


def add_turn(store: Store, cid: str, question: str, reply: dict, **extra) -> dict:
    chat = store.get(cid) or {"id": cid, "created": time.time(), "title": title_of(question), "turns": [], **extra}
    chat["turns"].append({"question": question, "reply": reply})
    return store.put(chat)


def restore(thinker, turns: list[dict]) -> None:
    """Give a fresh Thinker the context of a saved conversation (what Thinker._reply records)."""
    for t in turns:
        r = t.get("reply") or {}
        thinker.user_turns.append(t["question"])
        thinker.history += [{"role": "user", "content": t["question"]},
                            {"role": "assistant", "content": r.get("answer", "")}]
        thinker.carried = list(r.get("cited") or [])
