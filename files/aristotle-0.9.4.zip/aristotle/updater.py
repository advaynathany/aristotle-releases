"""Self-updates for the Mac app, with stable and beta channels.

Releases live in a public repo (RELEASES): channels/<channel>.json names the current release of
each channel, and files/ holds each release's code as a zip. A release is only accepted if its
manifest carries a valid signature from the release key (PUBLIC_KEY below; the private half never
leaves the maker's Mac) and the zip matches the signed hash.

Beta users get whichever is newer of beta and stable. An update that needs a newer app shell
(min_shell > ARISTOTLE_SHELL) isn't installed; the app offers the new download instead. A manifest
marked "force" (a rollback) installs even though its version is older.

The update is unpacked to <home>/app/<version>/ and named in pending.json; desktop/launch.py
switches to it on the next launch. Running from source (no ARISTOTLE_SHELL), updates are off.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import sys
import shutil
import threading
import time
import zipfile

import httpx

from . import __version__
from .paths import HOME
from .system import replace

RELEASES = "https://raw.githubusercontent.com/advaynathany/aristotle-releases/main"
API = "https://api.github.com/repos/advaynathany/aristotle-releases/contents"
DOWNLOAD = "https://github.com/advaynathany/aristotle-releases/releases/latest/download/" + \
    ("Aristotle-Setup.exe" if sys.platform == "win32" else "Aristotle.dmg")
PUBLIC_KEY = "Zj1DWdxLfRtgphCSeTC7oHnEmF/wIazRkGiuXRZJWPo="  # ed25519, base64; set by `desktop/release.py keygen`
CHANNELS = ("stable", "beta")
SIGNED = ("version", "file", "sha256", "min_shell", "force")

SHELL = int(os.environ.get("ARISTOTLE_SHELL") or 0)
APPS = HOME / "app"
SETTINGS = HOME / "settings.json"
_lock = threading.Lock()
state: dict = {"checking": False, "available": None, "ready": None, "needs_download": None,
               "error": None, "checked_at": None}


def enabled() -> bool:
    return SHELL > 0


def settings() -> dict:
    """~/Aristotle/settings.json: the update channel and the user's appearance choices."""
    try:
        s = json.loads(SETTINGS.read_text())
    except (OSError, ValueError):
        s = {}
    return s if isinstance(s, dict) else {}


def save_setting(key: str, value) -> None:
    s = settings()
    s[key] = value
    SETTINGS.parent.mkdir(parents=True, exist_ok=True)
    SETTINGS.write_text(json.dumps(s, indent=2))


def channel() -> str:
    ch = settings().get("channel")
    return ch if ch in CHANNELS else "stable"


def set_channel(ch: str) -> None:
    if ch not in CHANNELS:
        raise ValueError(f"channel must be one of {CHANNELS}")
    save_setting("channel", ch)


def payload(m: dict) -> bytes:
    """Exactly the bytes that are signed: the fields that decide what gets installed."""
    return json.dumps({k: m.get(k) for k in SIGNED}, sort_keys=True, separators=(",", ":")).encode()


def verify(m: dict, key: str | None = None) -> bool:
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    try:
        Ed25519PublicKey.from_public_bytes(base64.b64decode(key or PUBLIC_KEY)).verify(base64.b64decode(m["signature"]), payload(m))
        return True
    except (InvalidSignature, KeyError, ValueError):
        return False


def _newer(a: str, b: str) -> bool:
    from packaging.version import InvalidVersion, Version
    try:
        return Version(a) > Version(b)
    except InvalidVersion:
        return False


def _fetch(path: str):
    """Channel files change, and GitHub's raw file CDN serves them stale for up to 5 minutes, so
    read those through the API (fresh; 60 calls an hour per address is plenty). Release files
    never change once published, so the CDN is fine for them, and is the fallback for channels."""
    if path.startswith("channels/"):
        try:
            r = httpx.get(f"{API}/{path}", headers={"Accept": "application/vnd.github.raw+json"}, timeout=20)
            if r.status_code == 200:
                return r
        except httpx.HTTPError:
            pass
    r = httpx.get(f"{RELEASES}/{path}", timeout=60, follow_redirects=True)
    r.raise_for_status()
    return r


def _bad() -> set:
    try:
        return set(json.loads((APPS / "bad.json").read_text()))
    except (OSError, ValueError):
        return set()


def latest(ch: str) -> dict | None:
    """The release this channel should be on: beta also takes stable when stable is newer."""
    found = []
    for name in (["beta", "stable"] if ch == "beta" else ["stable"]):
        try:
            m = _fetch(f"channels/{name}.json").json()
        except (httpx.HTTPError, ValueError):
            continue
        if m.get("version") and verify(m):
            found.append(m)
    if not found:
        return None
    forced = [m for m in found if m.get("force")]
    if forced:
        return forced[0]
    from packaging.version import Version
    return max(found, key=lambda m: Version(m["version"]))


def _install(m: dict) -> None:
    blob = _fetch(f"files/{m['file']}").content
    if hashlib.sha256(blob).hexdigest() != m["sha256"]:
        raise ValueError("the download doesn't match its signature")
    dest = APPS / m["version"]
    tmp = APPS / f"{m['version']}.partial"
    shutil.rmtree(tmp, ignore_errors=True)
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        for name in z.namelist():  # nothing outside the folder, only our package
            if not name.startswith("aristotle/") or ".." in name.split("/"):
                raise ValueError(f"unexpected file in update: {name}")
        z.extractall(tmp)
    init = (tmp / "aristotle" / "__init__.py").read_text()
    if f'"{m["version"]}"' not in init:
        raise ValueError("the update's version doesn't match its manifest")
    shutil.rmtree(dest, ignore_errors=True)
    replace(tmp, dest)
    (APPS / "pending.json").write_text(json.dumps({"version": m["version"], "forced": bool(m.get("force"))}))


def check() -> dict:
    """Look for an update on this user's channel and stage it for the next launch."""
    if not enabled():
        return status()
    with _lock:
        state.update(checking=True, error=None)
        try:
            m = latest(channel())
            state.update(available=None, needs_download=None)
            wanted = m and m["version"] != __version__ and m["version"] not in _bad() and (
                m.get("force") or _newer(m["version"], __version__))
            if wanted:
                state["available"] = {k: m.get(k) for k in ("version", "notes", "channel", "published")}
                if int(m.get("min_shell") or 1) > SHELL:
                    state["needs_download"] = DOWNLOAD
                elif state.get("ready") != m["version"]:
                    APPS.mkdir(parents=True, exist_ok=True)
                    _install(m)
                    state["ready"] = m["version"]
        except Exception as e:  # offline, GitHub down, a bad release: try again later
            state["error"] = str(e) or type(e).__name__
        finally:
            state.update(checking=False, checked_at=time.strftime("%Y-%m-%dT%H:%M:%S"))
    return status()


def status() -> dict:
    return {"enabled": enabled(), "version": __version__, "channel": channel(), "shell": SHELL, **state}


def start_background(every_hours: float = 6) -> None:
    if not enabled():
        return

    def loop():
        time.sleep(5)
        while True:
            check()
            time.sleep(every_hours * 3600)
    threading.Thread(target=loop, daemon=True).start()
