"""Load a source file (epub, pdf, txt, md) and split it into dated, tiered chunks.

Chunk text keeps two kinds of line prefix that matter downstream:
  INTERVIEWER: ...   a question someone else asked. Never extracted, never a valid quote.
  TWEET: ...         a tweet quoted in the source (own writing, tier 1).
Citation markers like [12] are kept in the text; `resolve_origin` maps a quote to the original
publication (title, date, tier) through the chunk's citation table.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from .schema import Chunk

INTERVIEWER, TWEET = "INTERVIEWER: ", "TWEET: "
MONTHS = "January|February|March|April|May|June|July|August|September|October|November|December"


@dataclass
class Section:
    title: str
    paras: list[str] = field(default_factory=list)


def clean(s: str) -> str:
    return re.sub(r"\s+", " ", s.replace("\xa0", " ")).strip()


def norm(s: str) -> str:
    """Normalise for verbatim matching: unify quotes and dashes, collapse whitespace, lowercase."""
    s = (s.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
         .replace("—", "-").replace("–", "-").replace("…", "..."))
    return re.sub(r"\s+", " ", s).strip().lower()


# ---------- citations ----------

def parse_citation(ref: str) -> dict:
    """Turn one bibliography line into {ref, date, tier}. Twitter and own blogs are tier 1."""
    m = re.search(rf"({MONTHS}) (\d{{1,2}}), (\d{{4}})", ref)
    if m:
        month = MONTHS.split("|").index(m.group(1)) + 1
        date = f"{m.group(3)}-{month:02d}-{int(m.group(2)):02d}"
    else:
        y = re.findall(r"\b(19[89]\d|20[0-3]\d)\b", ref)
        date = y[0] if y else ""
    if re.search(r"\bTwitter\b", ref):
        return {"ref": "Twitter", "date": date, "tier": 1}
    own = bool(re.search(r"startupboy\.com|Naval ,", ref))  # his own blog posts
    title = re.search(r"[“\"]([^”\"]+)[”\"]", ref)
    short = title.group(1).rstrip(".") if title else ref.split(".")[0]
    return {"ref": clean(short)[:120], "date": date, "tier": 1 if own else 2}


# ---------- loaders ----------

def load_epub(path: Path, skip: list[str]) -> tuple[list[Section], dict]:
    from bs4 import BeautifulSoup
    from ebooklib import ITEM_DOCUMENT, epub

    book = epub.read_epub(str(path))
    items = {i.get_id(): i for i in book.get_items_of_type(ITEM_DOCUMENT)}
    order = [items[i] for i, _ in book.spine if i in items] or list(items.values())
    skip_re = re.compile("|".join(skip), re.I) if skip else None

    sections: list[Section] = []
    citations: dict[str, dict] = {}
    for item in order:
        soup = BeautifulSoup(item.get_content(), "html.parser")
        heads = [clean(h.get_text()) for h in soup.find_all(["h1", "h2"])]
        chapter = next((h for h in heads if h), "")
        if chapter.lower() == "sources":  # the bibliography: parse, don't ingest
            for p in soup.find_all("p"):
                m = re.match(r"\[(\d+)\]\s*(.+)", clean(p.get_text()))
                if m:
                    citations[m.group(1)] = parse_citation(m.group(2))
            continue
        if not chapter or (skip_re and skip_re.search(chapter)):
            continue
        cur = Section(chapter)
        for el in soup.find_all(["h1", "h2", "h3", "p"]):
            if el.name != "p":
                title = clean(el.get_text())
                if title and title != chapter:
                    if cur.paras:
                        sections.append(cur)
                    cur = Section(f"{chapter} › {title}")
                continue
            text = clean(el.get_text())  # get_text("") keeps "long-term" intact across spans
            if not text or text in ("↓", "→"):
                continue
            cls = " ".join(el.get("class") or [])
            bold = " ".join(clean(b.get_text()) for b in el.find_all(class_=re.compile("bold")))
            if bold and len(bold) >= 0.8 * len(text):
                text = INTERVIEWER + text
            elif "callout" in cls:
                text = TWEET + text
            cur.paras.append(text)
        if cur.paras:
            sections.append(cur)
    return sections, citations


def load_text(path: Path) -> tuple[list[Section], dict, dict]:
    """txt/md, with optional front matter lines (title:, date:, url:, tier:) before a '---'."""
    raw = path.read_text(errors="ignore")
    meta = {}
    if "\n---\n" in raw[:2000]:
        head, raw = raw.split("\n---\n", 1)
        for line in head.splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                meta[k.strip().lower()] = v.strip()
    citations = {}
    if "\n=== citations ===\n" in raw:  # "[N] ref | date | tier" lines, written by discover.py
        raw, block = raw.split("\n=== citations ===\n", 1)
        for line in block.splitlines():
            m = re.match(r"\[(\d+)\]\s*(.*?)\s*\|\s*(\S*)\s*\|\s*(\d)\s*$", line)
            if m:
                citations[m.group(1)] = {"ref": m.group(2)[:120], "date": m.group(3), "tier": int(m.group(4))}
    paras = [clean(p) for p in re.split(r"\n\s*\n", raw) if clean(p)]
    return [Section(meta.get("title", path.stem), paras)], citations, meta


def load_pdf(path: Path) -> list[Section]:
    import pdfplumber

    with pdfplumber.open(str(path)) as pdf:
        pages = [(p.extract_text() or "") for p in pdf.pages]
    return [Section(f"{path.stem} p.{i + 1}", [clean(t)]) for i, t in enumerate(pages) if len(t) > 200]


# ---------- chunking ----------

def chunk_text(source_id: str, section: str, text: str, tier: int = 1, date: str = "",
               max_chars: int = 3000, citations: dict | None = None) -> list[Chunk]:
    """Split on paragraph boundaries into chunks of at most ~max_chars."""
    paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    chunks, buf = [], ""
    for p in paras:
        if buf and len(buf) + len(p) > max_chars:
            chunks.append(buf)
            buf = ""
        buf = f"{buf}\n\n{p}".strip()
    if buf:
        chunks.append(buf)
    slug = re.sub(r"[^a-z0-9]+", "-", section.lower()).strip("-")[:40]
    out = []
    for i, c in enumerate(chunks):
        used = {n: citations[n] for n in re.findall(r"\[(\d+)\]", c) if citations and n in citations}
        # an excerpt can run past the chunk boundary; its marker is then the next chunk's first one
        nxt = re.search(r"\[(\d+)\]", "\n\n".join(chunks[i + 1:]))
        if nxt and citations and nxt.group(1) in citations:
            used["_next"] = citations[nxt.group(1)]
        out.append(Chunk(id=f"{source_id}:{slug}:{i}", source_id=source_id, section=section,
                         text=c, tier=tier, date=date, citations=used))
    return out


def drop_origins(paras: list[str], citations: dict, exclude: list[str]) -> list[str]:
    """Remove paragraphs whose excerpt is cited to an excluded publication. An excerpt runs up
    to and including the paragraph holding its citation marker."""
    keep, pending = [], []
    for p in paras:
        pending.append(p)
        m = re.search(r"\[(\d+)\]", p)
        if m:
            ref = citations.get(m.group(1), {}).get("ref", "").lower()
            if not any(x.lower() in ref for x in exclude):
                keep.extend(pending)
            pending = []
    return keep + pending


def ingest(path: str | Path, source_id: str, tier: int = 1, date: str = "",
           skip_sections: list[str] | None = None, min_chars: int = 300,
           exclude_origins: list[str] | None = None, skip_front: float = 0.0) -> list[Chunk]:
    """`skip_front` drops that fraction of a book's opening paragraphs (translator's prefaces and
    introductions are someone else's words)."""
    path = Path(path)
    suffix = path.suffix.lower()
    citations: dict = {}
    if suffix == ".epub":
        sections, citations = load_epub(path, skip_sections or [])
    elif suffix in (".txt", ".md"):
        sections, citations, meta = load_text(path)
        tier, date = int(meta.get("tier", tier)), meta.get("date", date)
    elif suffix == ".pdf":
        sections = load_pdf(path)
    else:
        raise ValueError(f"unsupported source type: {suffix}")
    if skip_front:
        sections = [Section(x.title, x.paras[int(len(x.paras) * skip_front):]) for x in sections]
    if exclude_origins:
        sections = [Section(x.title, drop_origins(x.paras, citations, exclude_origins)) for x in sections]
        sections = [x for x in sections if x.paras]
    # a tiny section is carried into the next section of the same chapter, so chunks have context
    merged: list[Section] = []
    carry: Section | None = None
    for s in sections:
        if carry and carry.title.split(" › ")[0] == s.title.split(" › ")[0]:
            s = Section(s.title, carry.paras + s.paras)
        elif carry:
            merged.append(carry)
        carry = None
        if sum(len(p) for p in s.paras) < min_chars:
            carry = s
        else:
            merged.append(s)
    if carry:
        merged.append(carry)
    out: list[Chunk] = []
    for s in merged:
        out.extend(chunk_text(source_id, s.title, "\n\n".join(s.paras), tier, date, citations=citations))
    return out


# ---------- grounding helpers used by extract.py ----------

def quotable(chunk_text_: str) -> str:
    """The part of a chunk a quote may come from: everything except interviewer lines."""
    paras = [p for p in chunk_text_.split("\n\n") if not p.startswith(INTERVIEWER)]
    return norm("\n\n".join(p.removeprefix(TWEET) for p in paras))


def resolve_origin(chunk: Chunk, quote: str) -> tuple[str, str, int]:
    """Map a verified quote to (origin, date, tier) using the paragraph it sits in.

    Citation markers close an excerpt, so the origin is the first marker at or after the quote's
    paragraph. Tweets carry no marker and resolve to Twitter.
    """
    q = norm(quote)
    paras = chunk.text.split("\n\n")
    for i, p in enumerate(paras):
        if q and q in norm(p.removeprefix(TWEET)):
            if p.startswith(TWEET):
                return "Twitter", "", 1
            for later in paras[i:]:
                m = re.search(r"\[(\d+)\]", later)
                if m and m.group(1) in chunk.citations:
                    c = chunk.citations[m.group(1)]
                    return c["ref"], c["date"], c["tier"]
            if "_next" in chunk.citations:
                c = chunk.citations["_next"]
                return c["ref"], c["date"], c["tier"]
            break
    return "", chunk.date, chunk.tier
