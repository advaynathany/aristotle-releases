"""Build an episteme map: extract -> ground -> dedupe -> link.

Grounding is the key rule: a node survives only if its quote is a verbatim substring of the
thinker's own lines in the chunk it came from (interviewer questions don't count). Hallucinated
beliefs are dropped here.
"""
from __future__ import annotations

import re
from concurrent.futures import ThreadPoolExecutor

import numpy as np

from .embed import Embedder
from .ingest import INTERVIEWER, norm, quotable, resolve_origin
from .llm import parse_json
from .schema import EDGE_KINDS, NODE_KINDS, Chunk, Edge, EpistemeMap, Node, Source

EXTRACT_SYSTEM = """You extract a thinker's beliefs from their own words so they can be mapped as \
a graph and later used to reason about other people's real decisions. The thinker is {thinker}.

The passage may contain lines starting "INTERVIEWER:" (someone else's question; use it only as \
context, never as a belief or a quote) and "TWEET:" (the thinker's own tweet). Bracketed numbers \
like [12] are citation markers; leave them out of quotes.

Return a JSON list. Each item has:
  "kind": one of principle | heuristic | value | case | boundary
     principle = a foundational claim the thinker treats as true ("wealth is assets that earn \
while you sleep")
     heuristic = a rule of thumb for acting ("if you can't decide, the answer is no")
     value = a priority or tradeoff weight: what the thinker ranks above what, and when \
("freedom over income")
     case = a concrete example or application the thinker gives, usable as a precedent
     boundary = a limit the thinker puts on a view, something they say they don't know, a \
caveat, or a view they say changed
  "statement": the belief as one clear, specific, self-contained sentence a reader could act on \
without seeing the passage. Name the concept ("specific knowledge", "leverage") when the \
thinker does. Not a summary of the passage, not vague ("life is complex").
  "quote": an EXACT verbatim excerpt (one or two sentences, under 300 characters) copied \
character for character from the thinker's own lines that best supports the statement

Rules: only beliefs the passage actually states; never add outside knowledge or your own \
interpretation. Prefer fewer, sharper beliefs over many paraphrases of one idea (usually 3 to 10 \
per passage). If nothing qualifies, return []. Return JSON only."""

LINK_SYSTEM = """You link beliefs in {thinker}'s worldview into a graph. You get beliefs, each \
with an id, and for each a list of nearby candidate beliefs. Return a JSON list of relations:
  {{"src": id, "dst": id, "kind": one of {kinds}, "note": short reason}}
supports = src is evidence or a reason for dst
derives_from = src follows from dst (dst is the more fundamental belief)
conflicts_with = they pull in opposite directions in some situations
outweighs = when both apply, {thinker} ranks src above dst
Only use ids you were given. Only link when the relation is clear from the statements \
themselves; most candidates should get no link. Return JSON only."""


def ground(quote: str, haystack: str) -> str | None:
    """Return the cleaned quote if it is verbatim in the haystack, else None."""
    q = re.sub(r"\s*\[\d+\]", "", quote).strip().strip('"“”').strip()
    for prefix in (INTERVIEWER.strip(), "TWEET:"):
        q = q.removeprefix(prefix).strip()
    if len(q) < 12 or norm(q) not in haystack:
        return None
    return q


def extract_chunk(llm, chunk: Chunk, thinker: str) -> tuple[list[Node], int]:
    """Return (grounded nodes, number of rejected items)."""
    try:
        items = parse_json(llm.complete(
            EXTRACT_SYSTEM.format(thinker=thinker),
            f"SECTION: {chunk.section}\n\nPASSAGE:\n{chunk.text}",
        ))
    except ValueError:
        return [], 0
    nodes, rejected = [], 0
    haystack = quotable(chunk.text)
    for it in items if isinstance(items, list) else []:
        if not isinstance(it, dict):
            rejected += 1
            continue
        quote = ground(str(it.get("quote", "")), haystack)
        if not (it.get("kind") in NODE_KINDS and it.get("statement") and quote):
            rejected += 1
            continue
        origin, date, tier = resolve_origin(chunk, quote)
        nodes.append(Node(
            id="",  # assigned after dedupe
            kind=it["kind"],
            statement=str(it["statement"]).strip(),
            sources=[Source(chunk.id, chunk.section, quote, tier, date, origin)],
        ))
    return nodes, rejected


def dedupe(nodes: list[Node], threshold: float | None = None) -> list[Node]:
    """Merge near-duplicate statements of the same kind, pooling their sources."""
    if not nodes:
        return []
    emb = Embedder([n.statement for n in nodes])
    if threshold is None:
        threshold = 0.55 if emb.backend == "tfidf" else 0.86
    sims = emb.matrix @ emb.matrix.T
    kept: list[int] = []
    for i, n in enumerate(nodes):
        target = next((j for j in sorted(kept, key=lambda j: -sims[i, j])
                       if sims[i, j] >= threshold and nodes[j].kind == n.kind), None)
        if target is None:
            kept.append(i)
            continue
        have = {(s.chunk_id, norm(s.quote)) for s in nodes[target].sources}
        nodes[target].sources.extend(s for s in n.sources if (s.chunk_id, norm(s.quote)) not in have)
    out = [nodes[i] for i in kept]
    for i, n in enumerate(out):
        n.id = f"n{i:04d}"
    return out


def link(llm, nodes: list[Node], thinker: str, k: int = 6, batch: int = 10,
         workers: int = 4) -> list[Edge]:
    if len(nodes) < 2:
        return []
    emb = Embedder([n.statement for n in nodes])
    sims = emb.matrix @ emb.matrix.T
    np.fill_diagonal(sims, -1)
    system = LINK_SYSTEM.format(thinker=thinker, kinds=" | ".join(EDGE_KINDS))

    def run(start: int) -> list[Edge]:
        block, allowed = [], {}
        for i in range(start, min(start + batch, len(nodes))):
            cands = list(np.argsort(-sims[i])[:k])
            allowed[nodes[i].id] = {nodes[j].id for j in cands}
            block.append(
                f"[{nodes[i].id}] ({nodes[i].kind}) {nodes[i].statement}\n  candidates:\n"
                + "\n".join(f"  [{nodes[j].id}] ({nodes[j].kind}) {nodes[j].statement}" for j in cands)
            )
        try:
            rels = parse_json(llm.complete(system, "\n\n".join(block)))
        except ValueError:
            return []
        out = []
        for r in rels if isinstance(rels, list) else []:
            if not isinstance(r, dict):
                continue
            src, dst, kind = r.get("src"), r.get("dst"), r.get("kind")
            if kind in EDGE_KINDS and dst in allowed.get(src, set()):
                out.append(Edge(src, dst, kind, str(r.get("note", ""))))
        return out

    edges, seen = [], set()
    with ThreadPoolExecutor(workers) as pool:
        for got in pool.map(run, range(0, len(nodes), batch)):
            for e in got:
                key = (e.src, e.dst, e.kind) if e.kind != "conflicts_with" else \
                    (*sorted((e.src, e.dst)), e.kind)
                if key not in seen:
                    seen.add(key)
                    edges.append(e)
    return edges


def build_map(llm, chunks: list[Chunk], thinker: str, progress=print,
              workers: int = 4, on_nodes=None) -> tuple[EpistemeMap, dict]:
    """`on_nodes`, when given, receives each chunk's grounded nodes as they are extracted."""
    raw_nodes: list[Node] = []
    rejected = done = 0
    with ThreadPoolExecutor(workers) as pool:
        for got, rej in pool.map(lambda ch: extract_chunk(llm, ch, thinker), chunks):
            raw_nodes.extend(got)
            rejected += rej
            if on_nodes and got:
                on_nodes(got)
            done += 1
            progress(f"extracted {done}/{len(chunks)} chunks: {len(raw_nodes)} nodes, {rejected} rejected")
    nodes = dedupe(raw_nodes)
    progress(f"deduped to {len(nodes)} nodes; linking...")
    edges = link(llm, nodes, thinker, workers=workers)
    stats = {
        "chunks": len(chunks),
        "raw_nodes": len(raw_nodes),
        "rejected_ungrounded": rejected,
        "nodes": len(nodes),
        "edges": len(edges),
    }
    return EpistemeMap(thinker, nodes, edges), stats
