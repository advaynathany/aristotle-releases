// A person's sources and their map build: pick what to read, add links or files, and watch
// beliefs arrive as each quote is verified against its source.
import {$, $$, api, avatar, esc, fmt, icon, kdot, plural, toast} from "../ui.js";

const KIND_ICON = {quotes: "quote", book: "book-open", article: "globe", post: "globe", document: "file", source: "file-text"};
const perCall = 1.8;  // keep in step with jobs.py
const estimate = n => ({calls: Math.round(n * perCall), minutes: Math.max(1, Math.round(n * perCall * 15 / 4 / 60))});

export async function mount(view, ctx) {
  let info = ctx.info, choice = null, timer = null, seen = new Set(), alive = true;

  const remaining = () => {
    const total = info.available_passages ?? info.selected_passages;
    return Math.max(0, (total || 0) - (info.built ? info.built_passages : 0));
  };

  function draw() {
    const p = info.profile || {};
    const job = info.job;
    const running = job && ["queued", "running"].includes(job.state);
    view.innerHTML = `<div class="page">
      <div class="profile">${avatar(info, "xl")}<div>
        <h1>${esc(info.name)}</h1><p>${esc(p.description || "")}</p>
        ${p.wikipedia ? `<a href="${esc(p.wikipedia)}" target="_blank" rel="noopener">Wikipedia ${icon("external-link", "sm")}</a>` : ""}
      </div></div>
      <div id="buildbox">${job && job.state !== "none" ? buildBox(job) : ""}</div>
      <div class="split">
        <div>
          <div class="section-head"><h2>Sources</h2><p>${sourceSummary()}</p></div>
          <div class="list" id="srcs">${sourceRows()}</div>
          <div class="section-head" style="margin-top:32px"><h2>Add your own</h2><p>Blog home pages bring in every post</p></div>
          ${p.website ? `<p class="muted" style="margin:0 0 4px;font-size:13px">${esc(info.name.replace(/\s*\(.*\)/, ""))}'s site is
            <a href="${esc(p.website)}" target="_blank" rel="noopener" style="text-decoration:underline">${esc(p.website.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, ""))}</a>.
            Paste its address if it's a blog, or links to individual essays.</p>` : ""}
          <form class="adder" id="linkf"><div class="field-ico" style="flex:1">${icon("link")}
            <input class="input" id="url" placeholder="Paste a link to an essay, a blog, a transcript or a PDF" aria-label="Link to add"></div>
            <button class="btn" id="addlink">Add link</button></form>
          <label class="drop" id="drop">${icon("upload", "lg")}<span><b>Drop a PDF, EPUB, TXT or Markdown file</b>, or click to choose one</span>
            <input type="file" id="file" accept=".pdf,.epub,.txt,.md" class="sr"></label>
        </div>
        <aside class="sticky">${buildPanel(running)}</aside>
      </div></div>`;
    wire();
  }

  function sourceSummary() {
    const on = (info.candidates || []).filter(c => c.selected !== false);
    const legacy = legacyFiles();
    const n = on.length + legacy.length;
    const passages = info.available_passages ?? info.selected_passages;
    return n ? `${plural(n, "source")} selected${passages ? `, about ${fmt(passages)} passages` : ""}` : "None selected";
  }

  function legacyFiles() {  // sources added by the CLI, before candidates existed
    const known = new Set((info.candidates || []).map(c => c.file).filter(Boolean));
    return (info.source_files || []).filter(f => !known.has(f.file));
  }

  function sourceRows() {
    const rows = (info.candidates || []).map(c => {
      const est = c.est_passages ? `about ${fmt(c.est_passages)} passages` : "size unknown until downloaded";
      const state = c.status === "remote" ? "Downloads when you build" : "Downloaded";
      return `<label class="src-row ${c.selected === false ? "off" : ""}">
        <input type="checkbox" class="check" data-pick="${esc(c.id)}" ${c.selected === false ? "" : "checked"} aria-label="Include ${esc(c.title)}">
        ${icon(KIND_ICON[c.kind] || "file-text")}
        <div class="txt"><b>${esc(c.title)}</b><span>${esc(c.detail || "")}${c.date ? `, ${esc(c.date.slice(0, 4))}` : ""}</span></div>
        <span class="faint num" style="font-size:12px;text-align:right">${est}<br>${state}</span></label>`;
    });
    const legacy = legacyFiles();
    if (legacy.length > 8) {
      rows.push(`<div class="src-row"><input type="checkbox" class="check" checked disabled aria-label="Included">${icon("file-text")}
        <div class="txt"><b>${plural(legacy.length, "source file")}</b><span>${esc(legacy.slice(0, 3).map(f => f.title).join(", "))}, and more</span></div>
        <span class="faint" style="font-size:12px">Included</span></div>`);
    } else {
      legacy.forEach(f => rows.push(`<div class="src-row"><input type="checkbox" class="check" checked disabled aria-label="Included">${icon("file-text")}
        <div class="txt"><b>${esc(f.title)}</b><span>${f.tier === 1 ? "Own writing" : "Transcribed speech"}${f.date ? `, ${esc(f.date.slice(0, 4))}` : ""}</span></div>
        <span class="faint" style="font-size:12px">Included</span></div>`));
    }
    return rows.join("") || `<div class="src-row"><span></span>${icon("circle-alert")}<div class="txt"><b>No sources found automatically</b>
      <span>Add a link to their essays, a blog, or a PDF of their writing below.</span></div><span></span></div>`;
  }

  function buildPanel(running) {
    const rem = remaining();
    const opts = info.built
      ? [[Math.min(40, rem), "40 more"], [Math.min(120, rem), "120 more"], [rem, "All the rest"]]
      : [[Math.min(info.starter, rem || info.starter), "Starter"], [Math.min(120, rem || 120), "120"], [rem, "Everything"]];
    const usable = opts.filter(([n]) => n > 0);
    if (choice === null || !usable.some(([n]) => n === choice)) choice = usable[0]?.[0] ?? 0;
    const e = estimate(choice);
    const title = info.built ? "Grow the map" : "Build the map";
    const lead = info.built
      ? `${fmt(info.nodes)} beliefs from ${plural(info.built_passages, "passage")}. Reading more adds beliefs; nothing already read is redone.`
      : "Start small to try them out right away, then grow the map later.";
    if (!rem && info.built) return `<div class="panel"><h3>Map complete</h3><p>${fmt(info.nodes)} beliefs from every selected passage. Add a source to grow it.</p>
      <a class="btn primary" href="#/p/${ctx.slug}/ask">${icon("message-square-text", "sm")} Ask ${esc(info.name.split(" ")[0])}</a></div>`;
    return `<div class="panel"><h3>${title}</h3><p>${lead}</p>
      <div class="seg" role="group" aria-label="How much to read">${usable.map(([n, label]) =>
        `<button data-n="${n}" aria-pressed="${n === choice}">${label}</button>`).join("")}</div>
      <dl class="cost"><dt>Passages to read</dt><dd>${fmt(choice)}</dd><dt>${document.documentElement.classList.contains("guest") ? "Model calls" : "Claude plan calls"}</dt><dd>about ${fmt(e.calls)}</dd>
        <dt>Time</dt><dd>about ${e.minutes} min</dd></dl>
      <button class="btn primary lg" id="build" ${running || !choice ? "disabled" : ""}>${running ? `${icon("loader-circle", "sm spin")} Building` : info.built ? "Read more passages" : "Build map"}</button>
      ${info.built ? `<a class="btn lg" style="width:100%;margin-top:8px" href="#/p/${ctx.slug}/ask">Ask ${esc(info.name.split(" ")[0])}</a>` : ""}
      <p class="fine">${document.documentElement.classList.contains("guest")
        ? "Builds run one at a time for everyone using this copy, and keep going if you close the tab. Every belief is checked word for word against its source."
        : "Builds use your Claude plan, one at a time. Every reply is cached, so an interrupted build picks up where it stopped."}</p></div>`;
  }

  function buildBox(j) {
    const phases = [["fetch", "Download"], ["read", "Split into passages"], ["extract", "Read and verify"], ["link", "Link beliefs"]];
    const at = Math.max(0, phases.findIndex(([k]) => k === j.phase));
    const done = j.state === "done";
    const failed = ["error", "interrupted"].includes(j.state);
    const pct = done ? 100 : j.phase === "link" ? 96 : j.total ? Math.round(88 * j.done / j.total) + 6 : 3;
    const title = done ? `Map built: ${j.message}` : failed ? "The build stopped" : j.state === "queued" ? "Waiting to start" : j.message;
    const feed = (j.recent || []).map(b => {
      const fresh = !seen.has(b.statement); seen.add(b.statement);
      return `<div class="belief ${fresh ? "new" : ""}">${kdot(b.kind)}<div><b>${esc(b.statement)}</b><q>${esc(b.quote)}</q>
        <small>${icon("check", "sm")} Found word for word${b.where ? ` in ${esc(b.where)}` : ""}</small></div></div>`;
    }).join("");
    return `<div class="build" role="status" aria-live="polite"><div class="build-head">
        <div class="row1">${done ? icon("circle-check-big") : failed ? icon("circle-alert") : icon("loader-circle", "spin")}<b>${esc(title)}</b>
          ${done ? `<a class="btn sm primary" href="#/p/${ctx.slug}/ask">Start asking</a>` : failed ? `<span class="err-text">${esc(j.state === "error" ? j.message : "")}</span>` : `<span class="faint num">${j.found ? `${fmt(j.found)} beliefs so far` : ""}</span>`}</div>
        ${failed && j.state === "interrupted" ? `<p class="faint" style="margin:0">${esc(j.message)}</p>` : ""}
        ${done || failed ? "" : `<div class="bar"><i style="width:${pct}%"></i></div>
        <div class="steps">${phases.map(([k, label], i) => `<span class="${i < at ? "done" : i === at ? "now" : ""}">${i < at ? icon("check", "sm") : i === at ? icon("loader-circle", "sm spin") : ""}${label}${k === "extract" && j.total ? ` ${j.done}/${j.total}` : ""}</span>`).join("")}</div>`}
      </div>${feed ? `<div class="feed">${feed}</div>` : ""}</div>`;
  }

  function wire() {
    $$("[data-pick]", view).forEach(c => c.onchange = async () => {
      try { info = await api(`/api/t/${ctx.slug}/candidates`, {id: c.dataset.pick, selected: c.checked}); draw(); }
      catch (e) { toast(e.message, "bad"); }
    });
    $$(".seg button", view).forEach(b => b.onclick = () => { choice = +b.dataset.n; draw(); });
    $("#build", view)?.addEventListener("click", async () => {
      const all = choice >= remaining();
      try {
        info = await api(`/api/t/${ctx.slug}/build`, {passages: all ? null : choice});
        seen = new Set();
        draw(); poll(); ctx.refreshLibrary();
      } catch (e) { toast(e.message, "bad"); }
    });
    $("#linkf", view).onsubmit = async e => {
      e.preventDefault();
      const url = $("#url", view).value.trim();
      if (!url) return;
      const btn = $("#addlink", view);
      btn.disabled = true; btn.innerHTML = `${icon("loader-circle", "sm spin")} Reading`;
      try {
        const r = await api(`/api/t/${ctx.slug}/links`, {url});
        info = r; draw();
        toast(r.added.length > 1 ? `Added ${r.added.length} posts` : `Added ${r.added[0]?.title || "the page"}`);
      } catch (err) { toast(err.message, "bad"); btn.disabled = false; btn.textContent = "Add link"; }
    };
    const drop = $("#drop", view), file = $("#file", view);
    const upload = async f => {
      if (!f) return;
      const fd = new FormData(); fd.append("file", f);
      drop.classList.add("over"); drop.querySelector("span").innerHTML = `${icon("loader-circle", "sm spin")} Adding ${esc(f.name)}`;
      try { info = await api(`/api/t/${ctx.slug}/files`, fd); draw(); toast(`Added ${f.name}`); }
      catch (e) { toast(e.message, "bad"); draw(); }
    };
    file.onchange = () => upload(file.files[0]);
    drop.ondragover = e => { e.preventDefault(); drop.classList.add("over"); };
    drop.ondragleave = () => drop.classList.remove("over");
    drop.ondrop = e => { e.preventDefault(); upload(e.dataTransfer.files[0]); };
  }

  async function poll() {
    clearTimeout(timer);
    if (!alive) return;
    let j;
    try { j = await api(`/api/t/${ctx.slug}/job`); } catch { return; }
    info.job = j;
    const box = $("#buildbox", view);
    if (box) box.innerHTML = buildBox(j);
    if (["queued", "running"].includes(j.state)) timer = setTimeout(poll, 1500);
    else { info = await api(`/api/t/${ctx.slug}`); draw(); ctx.refreshLibrary(); }
  }

  draw();
  if (info.job && ["queued", "running"].includes(info.job.state)) poll();
  return () => { alive = false; clearTimeout(timer); };
}
