// Ask: a decision in, a reasoned answer out, every claim footnoted to the verbatim passage
// beside it. Conversations survive tab switches (kept per person until the page reloads).
import {$, $$, api, avatar, cap, esc, fmt, icon, plural} from "../ui.js";

const threads = new Map();  // slug -> {session, html, turn}
const STARTERS = [
  "I have a stable offer at a big company and a chance to join a friend's seed-stage startup. Which one?",
  "I keep saying yes to every side project and meeting. Is that a problem?",
  "I'm anxious about my career even though I'm doing fine. How do I stop?",
];
let MAP = null, MAPSLUG = null;

export async function mount(view, ctx) {
  const {slug, info} = ctx;
  const first = info.name.replace(/\s*\(.*\)/, "").split(" ")[0];
  const t = threads.get(slug) || {session: null, html: "", turn: 0};
  threads.set(slug, t);
  if (MAPSLUG !== slug) { MAP = null; MAPSLUG = slug; api(`/api/t/${slug}/map`).then(m => { if (MAPSLUG === slug) MAP = m; }).catch(() => {}); }
  const byId = id => MAP?.nodes.find(n => n.id === id);

  const intro = () => `<div class="ask-intro" id="intro">${avatar(info, "xl")}
      <h1>What are you deciding?</h1>
      <p>${esc(info.name)}'s answer is reasoned from ${fmt(info.nodes)} beliefs in ${plural(info.sources, "source")}${info.years ? `, ${info.years[0]} to ${info.years[1]}` : ""}. Every claim points to the passage it came from.</p>
      <div class="starters">${STARTERS.map(s => `<button class="starter" type="button">${esc(s)}${icon("arrow-up", "sm")}</button>`).join("")}</div>
      <p class="fine">A model of ${esc(info.name)}'s published ideas, not ${esc(first)}. Not medical, legal or financial advice. Follow-ups keep the context, so push back when it misses something.</p></div>`;

  view.innerHTML = `<div class="thread" id="thread">${t.html || intro()}</div>
    <div class="composer"><form id="askf"><div class="field">
      <textarea id="q" rows="1" placeholder="Ask ${esc(first)} about a decision" aria-label="Your question"></textarea>
      <button class="send" id="send" disabled aria-label="Send">${icon("arrow-up")}</button></div>
      <div class="under"><span><em>Serif blue</em> is word for word from the sources. The rest is reasoning.</span><span>Shift + Enter for a new line</span></div>
    </form></div>`;
  $("#topbar-actions").innerHTML = `<button class="btn sm ghost ${t.session ? "" : "hidden"}" id="newchat">${icon("plus", "sm")} New conversation</button>`;

  const q = $("#q"), thread = $("#thread");
  const grow = () => { q.style.height = "auto"; q.style.height = q.scrollHeight + "px"; $("#send").disabled = !q.value.trim(); };
  q.addEventListener("input", grow);
  q.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); $("#askf").requestSubmit(); } });
  $$(".starter", view).forEach(b => b.onclick = () => { q.value = b.textContent.trim(); grow(); q.focus(); });
  $("#newchat").onclick = () => { t.session = null; t.html = ""; t.turn = 0; thread.innerHTML = intro(); $$(".starter", view).forEach(b => b.onclick = () => { q.value = b.textContent.trim(); grow(); q.focus(); }); $("#newchat").classList.add("hidden"); q.focus(); };

  function sourceLine(s) {
    const year = (s.date || "").slice(0, 4);
    return `${cap(s.kind || "belief")}${s.origin || s.section ? `, ${esc(s.origin || s.section)}` : ""}${year ? `, ${year}` : ""}`;
  }

  function render(r, n) {
    const nums = new Map();
    const src = id => r.sources?.[id] || (byId(id) && {...byId(id), quote: byId(id).sources[0]?.quote, origin: byId(id).sources[0]?.origin,
      section: byId(id).sources[0]?.section, date: byId(id).sources[0]?.date, n_sources: byId(id).sources.length});
    const para = (text, cls = "", heading = "") => {
      const fresh = [];
      // grouped citations ("[n0014, n0092]") become one bracket per id
      text = String(text).replace(/\[\s*(n\d{4}(?:\s*[,;]\s*n\d{4})+)\s*\]/g, (_, g) => g.split(/\s*[,;]\s*/).map(x => `[${x}]`).join(""));
      // bare ids the model wrote into prose ("n1635 dates from 2010") become "this belief" plus a footnote
      text = String(text).replace(/(^|[.!?]\s+|\s)(?<!\[)\b(n\d{4})\b(?!\])/g, (_, pre, id) => `${pre}${/[.!?]\s+$|^$/.test(pre) ? "This" : "this"} belief [${id}]`);
      const html = esc(text).replace(/\s*((?:\[n\d{4}\])+)/g, (_, g) => `<sup class="fns">${g.match(/n\d{4}/g).map(id => {
        if (!nums.has(id)) { nums.set(id, nums.size + 1); fresh.push(id); }
        return `<a class="fn" data-note="t${n}-${id}" role="button" tabindex="0" aria-label="Source ${nums.get(id)}">${nums.get(id)}</a>`;
      }).join("")}</sup>`);
      const notes = fresh.map(id => {
        const s = src(id);
        if (!s) return "";
        return `<div class="note" id="t${n}-${id}"><span class="n">${nums.get(id)}</span>
          <blockquote title="Show the whole passage">${esc(s.quote)}</blockquote>
          <div class="src"><span>${sourceLine(s)}</span>${s.n_sources > 1 ? `<span>Also in ${plural(s.n_sources - 1, "other source")}</span>` : ""}<a data-open="${id}">Open in map</a></div></div>`;
      }).join("");
      return `<div class="para ${cls}">${heading}<p>${html}</p><div class="notes">${notes}</div></div>`;
    };
    let h = String(r.answer || "").split(/\n\s*\n/).filter(p => p.trim()).map(p => para(p)).join("");
    if (r.tension) h += para(r.tension, "tension", `<h3>${icon("git-merge", "sm")} Where the beliefs pull apart</h3>`);
    if (r.uncertainty) h += para(r.uncertainty, "unsure", `<h3>${icon("circle-alert", "sm")} What the sources don't settle</h3>`);
    if (r.advice_domain && r.advice_domain !== "none")
      h += `<div class="callout">${icon("circle-alert", "sm")}<span>This touches on ${esc(r.advice_domain)} matters. Treat it as one framework's view, not professional advice.</span></div>`;
    const cited = r.cited || [], others = (r.considered || []).filter(id => !cited.includes(id));
    let coda = r.not_covered ? `<span>The sources don't cover this, so there's no answer to give.</span>`
      : `<span class="badge">${plural(cited.length, "belief")} cited</span>` + (r.verified
        ? `<span class="badge ok">${icon("check", "sm")} Every quote checked against its source</span>`
        : `<span class="badge bad">${icon("circle-alert", "sm")} Some claims couldn't be verified</span><span class="err-text">${esc((r.problems || []).join("; "))}</span>`);
    if (others.length) coda += `<details><summary>${plural(others.length, "more belief")} considered but not used</summary><ul>${others.map(id =>
      `<li><a data-open="${id}">${byId(id) ? esc(byId(id).statement) : id}</a></li>`).join("")}</ul></details>`;
    return h + `<div class="coda">${coda}</div>`;
  }

  // Sidenotes sit level with their first footnote, pushed down only to clear the note above.
  const wide = () => matchMedia("(min-width: 1001px)").matches;
  function layout(ans) {
    const notes = $$(".note", ans);
    if (!wide()) { notes.forEach(n => n.style.top = ""); ans.style.minHeight = ""; return; }
    const base = ans.getBoundingClientRect().top;
    let floor = 0;
    for (const note of notes) {
      const fn = $(`.fn[data-note="${note.id}"]`, ans);
      const top = Math.max(fn ? fn.getBoundingClientRect().top - base - 3 : floor, floor);
      note.style.top = top + "px";
      floor = top + note.offsetHeight + 16;
    }
    ans.style.minHeight = floor + "px";
  }
  const layoutAll = () => $$(".answer", thread).forEach(layout);
  layoutAll();
  document.fonts?.ready.then(layoutAll);
  addEventListener("resize", layoutAll);

  $("#askf").onsubmit = async e => {
    e.preventDefault();
    const text = q.value.trim();
    if (!text || $("#send").disabled) return;
    $("#intro")?.remove();
    const n = ++t.turn, turn = document.createElement("article");
    turn.className = "turn";
    turn.innerHTML = `<div class="question">${esc(text)}</div><div class="answer"><div class="thinking" role="status">
      ${icon("loader-circle", "spin")}<span class="shimmer" id="phase">Finding the beliefs in play</span><span class="faint num secs"></span></div></div>`;
    thread.append(turn);
    turn.scrollIntoView({behavior: "smooth", block: "start"});
    q.value = ""; grow(); $("#send").disabled = true;
    const start = Date.now();
    const phases = [[0, "Finding the beliefs in play"], [4, "Reasoning from them"], [10, "Checking every quote against its source"]];
    const tick = setInterval(() => {
      const s = (Date.now() - start) / 1000;
      const ph = turn.querySelector("#phase");
      if (ph) ph.textContent = phases.filter(([at]) => s >= at).at(-1)[1];
      const el = turn.querySelector(".secs"); if (el) el.textContent = `${Math.round(s)}s`;
    }, 500);
    try {
      const r = await api(`/api/t/${slug}/ask`, {session: t.session, message: text});
      t.session = r.session;
      turn.querySelector(".answer").innerHTML = render(r, n);
      layout(turn.querySelector(".answer"));
      $("#newchat").classList.remove("hidden");
    } catch (err) {
      turn.querySelector(".answer").innerHTML = `<div class="callout bad">${icon("circle-alert", "sm")}<span>No answer came back: ${esc(err.message)}. Your question is back in the box, so you can send it again.</span></div>`;
      q.value = text; grow();
    } finally {
      clearInterval(tick);
      t.html = thread.innerHTML.includes('class="turn"') ? thread.innerHTML : "";
      $("#send").disabled = !q.value.trim();
      q.focus();
    }
  };

  const onClick = e => {
    const fn = e.target.closest(".fn");
    if (fn) { const note = document.getElementById(fn.dataset.note); if (note) { note.scrollIntoView({behavior: "smooth", block: "center"}); note.classList.add("lit"); setTimeout(() => note.classList.remove("lit"), 1600); } return; }
    const bq = e.target.closest(".note blockquote");
    if (bq) { bq.parentElement.classList.toggle("open"); layout(bq.closest(".answer")); return; }
    const op = e.target.closest("[data-open]");
    if (op) location.hash = `#/p/${slug}/map/${op.dataset.open}`;
  };
  const onOver = e => {
    $$(".note.hov, .fn.lit", view).forEach(x => x.classList.remove("lit", "hov"));
    const fn = e.target.closest(".fn");
    if (fn) { fn.classList.add("lit"); document.getElementById(fn.dataset.note)?.classList.add("lit", "hov"); }
  };
  view.addEventListener("click", onClick);
  view.addEventListener("mouseover", onOver);
  q.focus();
  return () => { removeEventListener("resize", layoutAll); view.removeEventListener("click", onClick); view.removeEventListener("mouseover", onOver); };
}
