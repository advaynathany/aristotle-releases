// Small shared helpers: escaping, icons, avatars, formatting, toasts, the API client.

export const $ = (s, el = document) => el.querySelector(s);
export const $$ = (s, el = document) => [...el.querySelectorAll(s)];
export const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
export const fmt = n => (n ?? 0).toLocaleString("en-US");
export const cap = s => s ? s[0].toUpperCase() + s.slice(1) : "";
export const plural = (n, one, many = one + "s") => `${fmt(n)} ${n === 1 ? one : many}`;

export const icon = (name, cls = "") => `<svg class="i ${cls}" aria-hidden="true"><use href="/static/icons.svg#i-${name}"/></svg>`;

export const KINDS = ["principle", "heuristic", "value", "case", "boundary"];
export const PLURAL = {principle: "Principles", heuristic: "Heuristics", value: "Values", case: "Cases", boundary: "Boundaries"};
export const kdot = k => `<span class="dot" style="--k:var(--k-${esc(k)})"></span>`;

export function avatar(p, size = "") {
  const initials = (p?.name || p?.title || "?").replace(/\(.*?\)/g, "").trim().split(/\s+/).map(w => w[0]).slice(0, 2).join("");
  return p?.image
    ? `<img class="avatar ${size}" src="${esc(p.image)}" alt="" loading="lazy" referrerpolicy="no-referrer">`
    : `<span class="avatar ${size}" aria-hidden="true">${esc(initials)}</span>`;
}

export function yearsText(y) {
  if (!y) return "";
  return y[0] === y[1] ? y[0] : `${y[0]} to ${y[1]}`;
}

export async function api(path, body, method) {
  const opts = body instanceof FormData ? {method: "POST", body}
    : body !== undefined ? {method: method || "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)}
    : {method: method || "GET"};
  const r = await fetch(path, opts);
  if (r.status === 401) location.href = "/login";  // the password cookie expired
  if (!r.ok) {
    const detail = (await r.json().catch(() => ({}))).detail;
    const err = new Error(typeof detail === "string" ? detail : r.statusText);
    err.status = r.status;
    throw err;
  }
  return r.json();
}

export function toast(msg, kind = "") {
  let box = $(".toasts");
  if (!box) { box = document.createElement("div"); box.className = "toasts"; box.setAttribute("role", "status"); document.body.append(box); }
  const t = document.createElement("div");
  t.className = `toast ${kind}`;
  t.innerHTML = `${icon(kind === "bad" ? "circle-alert" : "circle-check-big")}<span>${esc(msg)}</span>`;
  box.append(t);
  setTimeout(() => t.remove(), kind === "bad" ? 6000 : 3200);
}

export function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

// Whether a keystroke should be left alone because the person is typing somewhere.
export const typing = () => /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName) || document.activeElement?.isContentEditable;
