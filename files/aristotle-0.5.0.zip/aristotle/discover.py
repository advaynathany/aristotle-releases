"""Find a person and their source material, so anyone can be added to the library.

  search_people("seneca")          Wikipedia title search: name, one-line description, portrait
  profile("Seneca the Younger")    Wikipedia summary for the library entry
  discover(folder, profile)        candidate sources: Wikiquote, public-domain books on Project
                                   Gutenberg, and anything already in sources/
  add_url(folder, url, name)       a WordPress blog (every post), a direct pdf/epub/txt, or an
                                   article page (main text extracted)
  materialize(folder, cand)        download a selected candidate into sources/ and config.json

Candidates live in config.json under "candidates" until they are built; built ones are also listed
under "sources", which is what ingest reads. Downloaded text is the author's copyright unless it is
public domain: personal use only, never committed.
"""
from __future__ import annotations

import json
import re
import urllib.parse
import urllib.request
from pathlib import Path

from bs4 import BeautifulSoup

from .ingest import clean

UA = {"User-Agent": "Aristotle/0.2 (personal research tool; https://github.com/)"}
CHARS_PER_PASSAGE = 2600  # ingest packs ~3000-char chunks on paragraph boundaries
SKIP_QUOTE_SECTIONS = re.compile(
    r"disputed|misattributed|attributed|about |quotes about|quotes from others|see also|external|"
    r"sources|references|notes|further reading|dialogue|cast|criticism|commentary", re.I)


def _get(url: str, timeout: int = 30, raw: bool = False):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read()
    return data if raw else json.loads(data.decode())


def slugify(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:48] or "person"


def _thumb(page: dict) -> str:
    t = page.get("thumbnail") or {}
    url = t.get("source") or t.get("url") or ""
    return ("https:" + url) if url.startswith("//") else url


# ---------- who ----------

def search_people(q: str, limit: int = 8) -> list[dict]:
    """People only: Wikipedia prefix and full-text matches, kept when Wikidata says the article is
    about a human (P31 = Q5), so "sene" finds Seneca and not Senegal."""
    if not q.strip():
        return []
    pages: dict[str, dict] = {}
    for gen in ({"generator": "prefixsearch", "gpssearch": q, "gpslimit": 12},
                {"generator": "search", "gsrsearch": q, "gsrlimit": 12}):
        try:
            r = _get("https://en.wikipedia.org/w/api.php?" + urllib.parse.urlencode({
                "action": "query", "format": "json", "prop": "pageprops|pageimages|description",
                "ppprop": "wikibase_item", "piprop": "thumbnail", "pithumbsize": 120, "redirects": 1, **gen}))
        except Exception:
            continue
        for p in sorted((r.get("query") or {}).get("pages", {}).values(), key=lambda p: p.get("index", 99)):
            pages.setdefault(p["title"], p)
    items = {p["pageprops"]["wikibase_item"]: t for t, p in pages.items() if p.get("pageprops", {}).get("wikibase_item")}
    humans = set(items)
    if items:
        try:
            sparql = ("SELECT ?i ?n WHERE { VALUES ?i { " + " ".join(f"wd:{i}" for i in items) +
                      " } ?i wdt:P31 wd:Q5 ; wikibase:sitelinks ?n }")
            r = _get("https://query.wikidata.org/sparql?" + urllib.parse.urlencode({"query": sparql, "format": "json"}), timeout=20)
            fame = {b["i"]["value"].rsplit("/", 1)[-1]: int(b["n"]["value"]) for b in r["results"]["bindings"]}
            humans = set(fame)
            ql = q.lower().strip()
            starts = lambda t: plain_name(t).lower().startswith(ql) or any(w.startswith(ql) for w in t.lower().split())
            # names that start with what was typed first, then the best known
            items = dict(sorted(items.items(), key=lambda kv: (not starts(kv[1]), -fame.get(kv[0], 0))))
        except Exception:
            pass  # Wikidata unreachable: show everything rather than nothing
    out = []
    for qid, title in items.items():
        if qid in humans:
            p = pages[title]
            out.append({"title": title, "description": p.get("description", ""), "image": _thumb(p)})
    return out[:limit]


def profile(title: str) -> dict:
    s = _get("https://en.wikipedia.org/api/rest_v1/page/summary/" +
             urllib.parse.quote(title.replace(" ", "_")))
    website = ""
    if s.get("wikibase_item"):  # official website (P856), for people whose writing lives online
        try:
            c = _get("https://www.wikidata.org/w/api.php?" + urllib.parse.urlencode(
                {"action": "wbgetclaims", "entity": s["wikibase_item"], "property": "P856", "format": "json"}), timeout=15)
            website = c["claims"]["P856"][0]["mainsnak"]["datavalue"]["value"]
        except Exception:
            pass
    return {"title": s.get("title", title), "description": s.get("description", ""), "website": website,
            "extract": s.get("extract", ""), "image": (s.get("thumbnail") or {}).get("source", ""),
            "wikipedia": (s.get("content_urls") or {}).get("desktop", {}).get("page", ""),
            "wikidata": s.get("wikibase_item", "")}


# ---------- what they said ----------

def _year(text: str) -> str:
    m = re.findall(r"\b(1[0-9]{3}|20[0-3][0-9])\b", text)
    return m[0] if m else ""


def wikiquote(name: str) -> dict | None:
    """Sourced quotes from Wikiquote, as text with [N] markers pointing at their citations."""
    page = {}
    for title in dict.fromkeys([name, plain_name(name)]):
        try:
            page = _get("https://en.wikiquote.org/w/api.php?" + urllib.parse.urlencode(
                {"action": "parse", "page": title, "prop": "text", "format": "json", "redirects": 1}))
        except Exception:
            continue
        if "parse" in page:
            name = title
            break
    if "parse" not in page:
        return None
    soup = BeautifulSoup(page["parse"]["text"]["*"], "html.parser")
    root = soup.select_one(".mw-parser-output") or soup
    quotes, cites, heading, work, skipping = [], [], "", "", False
    for el in root.find_all(["h2", "h3", "li"]):  # document order
        if el.name in ("h2", "h3"):
            text = clean(el.get_text())
            if el.name == "h2":
                skipping = bool(SKIP_QUOTE_SECTIONS.search(text))
                work = "" if text.lower() in ("quotes", "sourced") else text
            elif not re.match(r"(book|chapter|part|letter)\b", text, re.I) or not work:
                work = text
            heading = text
            continue
        if skipping or el.find_parent("li") or el.parent is None:
            continue
        if el.find_parent(class_=re.compile("toc|navbox|reflist|mw-references")):
            continue
        nested = el.find("ul")
        # the nested list is usually the citation, but some pages put alternate translations there:
        # keep the shortest line that reads like a reference, else fall back to the section's work
        lines = [clean(li.get_text(" ")) for li in nested.find_all("li")] if nested else []
        refs = [x for x in lines if len(x) <= 140]
        cite = min(refs, key=len) if refs else (work if lines else "")
        own = [c for c in el.children if c is not nested]
        text = clean(" ".join(c.get_text(" ") if hasattr(c, "get_text") else str(c) for c in own))
        text = re.sub(r"\[\s*\d+\s*\]", "", text).strip()
        if len(text) < 40 or not cite:  # unsourced lines are where misattributions live
            continue
        ref = f"{work}, {cite}" if work and len(cite) < 60 and work.lower() not in cite.lower() else cite
        ref = re.sub(r"\s*\|\s*", " / ", ref)
        cites.append(f"{ref[:200]} | {_year(cite) or _year(work)} | 2")
        quotes.append(f"{text} [{len(cites)}]")
    if len(quotes) < 3:
        return None
    return {"title": f"{name} on Wikiquote", "url": f"https://en.wikiquote.org/wiki/{urllib.parse.quote(name.replace(' ', '_'))}",
            "text": "\n\n".join(quotes), "citations": cites}


def plain_name(name: str) -> str:
    """'Paul Graham (programmer)' -> 'Paul Graham'; 'Seneca the Younger' -> 'Seneca'."""
    name = re.sub(r"\s*\(.*?\)", "", name)
    return re.sub(r"\b(the (younger|elder|great))\b", "", name, flags=re.I).strip()


def gutenberg(name: str, limit: int = 4) -> list[dict]:
    """Public-domain books whose author matches the person, most-downloaded first, one per title.
    Uses Project Gutenberg's own OPDS search (fast and current)."""
    import xml.etree.ElementTree as ET

    name = plain_name(name)
    try:
        raw = _get("https://www.gutenberg.org/ebooks/search.opds/?" +
                   urllib.parse.urlencode({"query": name, "sort_order": "downloads"}), timeout=20, raw=True)
        feed = ET.fromstring(raw)
    except Exception:
        return []
    ns = {"a": "http://www.w3.org/2005/Atom"}
    want = {w for w in re.findall(r"[a-z]+", name.lower()) if len(w) > 2}
    out, keys, main_author = [], [], None
    stop = want | {"the", "of", "and", "a", "an", "emperor", "on", "by", "complete", "works", "volume", "vol"}
    for e in feed.findall("a:entry", ns):
        m = re.search(r"/ebooks/(\d+)\.opds", e.findtext("a:id", "", ns))
        title = clean(e.findtext("a:title", "", ns))
        author = (e.findtext("a:content", "", ns) or "").lower()
        if not m or not want or not want <= set(re.findall(r"[a-z]+", author)):
            continue
        main_author = main_author or author  # the most-downloaded match decides who "they" are
        if author != main_author or title.lower().startswith("index of") or \
                re.search(r"\((german|french|spanish|italian|latin|greek|dutch|finnish|portuguese|swedish|esperanto|hungarian|polish|czech|russian|danish|norwegian|catalan|japanese|chinese|welsh|tagalog)\)\s*$", title, re.I):
            continue
        key = {w for w in re.findall(r"[a-z]+", title.lower()) if w not in stop}
        if any(key <= k or k <= key for k in keys):  # another edition or translation of a book we have
            continue
        keys.append(key)
        n = m.group(1)
        out.append({"id": f"gutenberg-{n}", "kind": "book", "title": title[:140],
                    "url": f"https://www.gutenberg.org/cache/epub/{n}/pg{n}.txt",
                    "detail": "Public-domain book from Project Gutenberg", "est_passages": None})
        if len(out) >= limit:
            break
    return out


def _size(url: str) -> int | None:
    try:
        req = urllib.request.Request(url, headers=UA, method="HEAD")
        with urllib.request.urlopen(req, timeout=15) as r:
            n = r.headers.get("Content-Length")
            return int(n) if n else None
    except Exception:
        return None


# ---------- config plumbing ----------

def load_cfg(folder: Path) -> dict:
    return json.loads((Path(folder) / "config.json").read_text())


def save_cfg(folder: Path, cfg: dict) -> None:
    (Path(folder) / "config.json").write_text(json.dumps(cfg, indent=2, ensure_ascii=False) + "\n")


def _register(folder: Path, cfg: dict, entry: dict, cand: dict | None = None) -> None:
    if not any(s["file"] == entry["file"] for s in cfg["sources"]):
        cfg["sources"].append(entry)
    if cand:
        cand.update(status="ready", file=entry["file"])
        if not any(c["id"] == cand["id"] for c in cfg.setdefault("candidates", [])):
            cfg["candidates"].append(cand)


def passages_in(folder: Path, file: str) -> int:
    p = Path(folder) / "sources" / file
    return max(1, round(p.stat().st_size / CHARS_PER_PASSAGE)) if p.exists() else 0


def create_person(root: Path, title: str) -> tuple[str, dict]:
    """Make thinkers/<slug>/ from a Wikipedia title and discover candidate sources."""
    prof = profile(title)
    slug = slugify(prof["title"])
    folder = Path(root) / slug
    if (folder / "config.json").exists():
        return slug, load_cfg(folder)
    (folder / "sources").mkdir(parents=True, exist_ok=True)
    cfg = {"name": prof["title"], "voice": "third", "profile": prof, "sources": [], "candidates": []}
    save_cfg(folder, cfg)
    discover(folder)
    return slug, load_cfg(folder)


def discover(folder: Path) -> list[dict]:
    folder = Path(folder)
    cfg = load_cfg(folder)
    cfg.setdefault("candidates", [])
    name = cfg["name"]
    have = {c["id"] for c in cfg["candidates"]}
    wq = wikiquote(name)
    if wq and "wikiquote" not in have:
        file = "wikiquote.md"
        body = (f"title: {wq['title']}\nurl: {wq['url']}\ntier: 2\n---\n{wq['text']}\n\n"
                "=== citations ===\n" + "\n".join(f"[{i + 1}] {c}" for i, c in enumerate(wq["citations"])))
        (folder / "sources" / file).write_text(body)
        _register(folder, cfg, {"id": "wikiquote", "file": file, "tier": 2, "date": "", "title": wq["title"]},
                  {"id": "wikiquote", "kind": "quotes", "title": "Sourced quotations",
                   "detail": f"{len(wq['citations'])} quotes with citations, from Wikiquote",
                   "url": wq["url"], "selected": True})
    for i, b in enumerate(gutenberg(name)):
        if b["id"] in have:
            continue
        n = _size(b["url"])
        # the best-known book is on by default; the rest are one tick away, so a starter build isn't
        # spread across several translations of the same work
        b.update(selected=i == 0, status="remote", est_passages=round(n / CHARS_PER_PASSAGE) if n else None)
        cfg.setdefault("candidates", []).append(b)
    for c in cfg.get("candidates", []):
        if c.get("file"):
            c["est_passages"] = passages_in(folder, c["file"])
    save_cfg(folder, cfg)
    return cfg["candidates"]


def _strip_gutenberg(text: str) -> str:
    start = re.search(r"\*\*\*\s*START OF (THE|THIS) PROJECT GUTENBERG.*?\*\*\*", text, re.I | re.S)
    end = re.search(r"\*\*\*\s*END OF (THE|THIS) PROJECT GUTENBERG", text, re.I)
    text = text[start.end() if start else 0: end.start() if end else len(text)]
    # Gutenberg hard-wraps lines; rejoin them so paragraphs are paragraphs
    paras = [re.sub(r"\s*\n\s*", " ", p).strip() for p in re.split(r"\n\s*\n", text.replace("\r", ""))]
    return "\n\n".join(p for p in paras if p)


def materialize(folder: Path, cand: dict) -> bool:
    """Download a remote candidate into sources/. Returns True when it is ready to ingest."""
    folder = Path(folder)
    if cand.get("status") == "ready":
        return True
    cfg = load_cfg(folder)
    c = next(x for x in cfg["candidates"] if x["id"] == cand["id"])
    if c["kind"] == "book":
        raw = _get(c["url"], timeout=120, raw=True).decode("utf-8", errors="ignore")
        file = f"{c['id']}.md"
        (folder / "sources" / file).write_text(f"title: {c['title']}\nurl: {c['url']}\ntier: 1\n---\n" + _strip_gutenberg(raw))
        _register(folder, cfg, {"id": c["id"], "file": file, "tier": 1, "date": "", "title": c["title"],
                                "skip_front": 0.06}, None)
        c.update(status="ready", file=file, est_passages=passages_in(folder, file))
    save_cfg(folder, cfg)
    return c.get("status") == "ready"


# ---------- your own links and files ----------

def add_url(folder: Path, url: str) -> list[dict]:
    """Add a WordPress blog (all posts), a direct document, or one article. Returns new candidates."""
    folder = Path(folder)
    cfg = load_cfg(folder)
    url = url.strip()
    if not re.match(r"https?://", url):
        url = "https://" + url
    parsed = urllib.parse.urlparse(url)
    host = parsed.netloc.replace("www.", "")
    added: list[dict] = []
    if parsed.path.lower().endswith((".pdf", ".epub", ".txt", ".md")):
        ext = Path(parsed.path).suffix.lower()
        file = slugify(host + "-" + Path(parsed.path).stem) + ext
        (folder / "sources" / file).write_bytes(_get(url, timeout=120, raw=True))
        cid = Path(file).stem
        _register(folder, cfg, {"id": cid, "file": file, "tier": 1, "date": "", "title": Path(parsed.path).stem},
                  {"id": cid, "kind": "document", "title": Path(parsed.path).name, "url": url,
                   "detail": f"Document from {host}", "selected": True})
        added.append(cfg["candidates"][-1])
    elif parsed.path in ("", "/") and _is_wordpress(url):
        from .fetch import fetch_wordpress
        save_cfg(folder, cfg)
        speaker = cfg["name"].split()[0]
        entries = fetch_wordpress(folder, url, speaker)
        cfg = load_cfg(folder)
        for e in entries:
            cand = {"id": e["id"], "kind": "post", "title": e["title"], "url": url, "date": e["date"],
                    "detail": f"{'Transcript' if e['tier'] == 2 else 'Post'} from {host}", "selected": True,
                    "status": "ready", "file": e["file"]}
            if not any(c["id"] == cand["id"] for c in cfg.setdefault("candidates", [])):
                cfg["candidates"].append(cand)
                added.append(cand)
    else:
        import trafilatura

        html = _get(url, timeout=60, raw=True).decode("utf-8", errors="ignore")
        doc = trafilatura.bare_extraction(html, url=url, with_metadata=True, include_comments=False)
        doc = doc.as_dict() if hasattr(doc, "as_dict") else (doc or {})
        text = (doc.get("text") or "").strip()
        if len(text) < 600:
            raise ValueError("Couldn't find enough article text on that page. Try a direct link to the post or a PDF.")
        title = clean(doc.get("title") or host)
        date = (doc.get("date") or "")[:10]
        paras = [clean(p) for p in re.split(r"\n+", text) if clean(p)]
        cid = slugify(host + "-" + (parsed.path.strip("/").split("/")[-1] or title))[:60]
        file = f"{cid}.md"
        (folder / "sources" / file).write_text(f"title: {title}\ndate: {date}\nurl: {url}\ntier: 1\n---\n" + "\n\n".join(paras))
        _register(folder, cfg, {"id": cid, "file": file, "tier": 1, "date": date, "title": title},
                  {"id": cid, "kind": "article", "title": title, "url": url, "date": date,
                   "detail": f"Article from {host}", "selected": True})
        added.append(cfg["candidates"][-1])
    for c in added:
        c["est_passages"] = passages_in(folder, c["file"])
    save_cfg(folder, cfg)
    return added


def _is_wordpress(url: str) -> bool:
    try:
        _get(url.rstrip("/") + "/wp-json/wp/v2/posts?per_page=1&_fields=id", timeout=15)
        return True
    except Exception:
        return False


def add_file(folder: Path, filename: str, data: bytes) -> dict:
    folder = Path(folder)
    ext = Path(filename).suffix.lower()
    if ext not in (".pdf", ".epub", ".txt", ".md"):
        raise ValueError("Upload a PDF, EPUB, TXT or Markdown file.")
    cid = slugify(Path(filename).stem)
    file = cid + ext
    (folder / "sources" / file).write_bytes(data)
    cfg = load_cfg(folder)
    cand = {"id": cid, "kind": "document", "title": Path(filename).name, "detail": "Uploaded file",
            "selected": True}
    _register(folder, cfg, {"id": cid, "file": file, "tier": 1, "date": "", "title": Path(filename).stem}, cand)
    cand["est_passages"] = passages_in(folder, file)
    save_cfg(folder, cfg)
    return cand
