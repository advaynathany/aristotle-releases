title: The Gospel According to John (KJV)
url: https://www.gutenberg.org/cache/epub/8043/pg8043.txt
tier: 1
---
§ John 1

In the beginning was the Word, and the Word was with God, and the Word was God. [1]

The same was in the beginning with God. [2]

All things were made by him; and without him was not any thing made that was made. [3]

In him was life; and the life was the light of men. [4]

And the light shineth in darkness; and the darkness comprehended it not. [5]

There was a man sent from God, whose name was John. [6]

The same came for a witness, to bear witness of the Light, that all men through him might believe. [7]

He was not that Light, but was sent to bear witness of that Light. [8]

That was the true Light, which lighteth every man that cometh into the world. [9]

He was in the world, and the world was made by him, and the world knew him not. [10]

He came unto his own, and his own received him not. [11]

But as many as received him, to them gave he power to become the sons of God, even to them that believe on his name: [12]

Which were born, not of blood, nor of the will of the flesh, nor of the will of man, but of God. [13]

And the Word was made flesh, and dwelt among us, (and we beheld his glory, the glory as of the only begotten of the Father,) full of grace and truth. [14]

John bare witness of him, and cried, saying, This was he of whom I spake, He that cometh after me is preferred before me: for he was before me. [15]

And of his fulness have all we received, and grace for grace. [16]

For the law was given by Moses, but grace and truth came by Jesus Christ. [17]

No man hath seen God at any time, the only begotten Son, which is in the bosom of the Father, he hath declared him. [18]

And this is the record of John, when the Jews sent priests and Levites from Jerusalem to ask him, Who art thou? [19]

And he confessed, and denied not; but confessed, I am not the Christ. [20]

And they asked him, What then? Art thou Elias? And he saith, I am not. Art thou that prophet? And he answered, No. [21]

Then said they unto him, Who art thou? that we may give an answer to them that sent us. What sayest thou of thyself? [22]

He said, I am the voice of one crying in the wilderness, Make straight the way of the Lord, as said the prophet Esaias. [23]

And they which were sent were of the Pharisees. [24]

And they asked him, and said unto him, Why baptizest thou then, if thou be not that Christ, nor Elias, neither that prophet? [25]

John answered them, saying, I baptize with water: but there standeth one among you, whom ye know not; [26]

He it is, who coming after me is preferred before me, whose shoe's latchet I am not worthy to unloose. [27]

These things were done in Bethabara beyond Jordan, where John was baptizing. [28]

The next day John seeth Jesus coming unto him, and saith, Behold the Lamb of God, which taketh away the sin of the world. [29]

This is he of whom I said, After me cometh a man which is preferred before me: for he was before me. [30]

And I knew him not: but that he should be made manifest to Israel, therefore am I come baptizing with water. [31]

And John bare record, saying, I saw the Spirit descending from heaven like a dove, and it abode upon him. [32]

And I knew him not: but he that sent me to baptize with water, the same said unto me, Upon whom thou shalt see the Spirit descending, and remaining on him, the same is he which baptizeth with the Holy Ghost. [33]

And I saw, and bare record that this is the Son of God. [34]

Again the next day after John stood, and two of his disciples; [35]

And looking upon Jesus as he walked, he saith, Behold the Lamb of God! [36]

And the two disciples heard him speak, and they followed Jesus. [37]

Then Jesus turned, and saw them following, and saith unto them, What seek ye? They said unto him, Rabbi, (which is to say, being interpreted, Master,) where dwellest thou? [38]

He saith unto them, Come and see. They came and saw where he dwelt, and abode with him that day: for it was about the tenth hour. [39]

One of the two which heard John speak, and followed him, was Andrew, Simon Peter's brother. [40]

He first findeth his own brother Simon, and saith unto him, We have found the Messias, which is, being interpreted, the Christ. [41]

And he brought him to Jesus. And when Jesus beheld him, he said, Thou art Simon the son of Jona: thou shalt be called Cephas, which is by interpretation, A stone. [42]

The day following Jesus would go forth into Galilee, and findeth Philip, and saith unto him, Follow me. [43]

Now Philip was of Bethsaida, the city of Andrew and Peter. [44]

Philip findeth Nathanael, and saith unto him, We have found him, of whom Moses in the law, and the prophets, did write, Jesus of Nazareth, the son of Joseph. [45]

And Nathanael said unto him, Can there any good thing come out of Nazareth? Philip saith unto him, Come and see. [46]

Jesus saw Nathanael coming to him, and saith of him, Behold an Israelite indeed, in whom is no guile! [47]

Nathanael saith unto him, Whence knowest thou me? Jesus answered and said unto him, Before that Philip called thee, when thou wast under the fig tree, I saw thee. [48]

Nathanael answered and saith unto him, Rabbi, thou art the Son of God; thou art the King of Israel. [49]

Jesus answered and said unto him, Because I said unto thee, I saw thee under the fig tree, believest thou? thou shalt see greater things than these. [50]

And he saith unto him, Verily, verily, I say unto you, Hereafter ye shall see heaven open, and the angels of God ascending and descending upon the Son of man. [51]

§ John 2

And the third day there was a marriage in Cana of Galilee; and the mother of Jesus was there: [52]

And both Jesus was called, and his disciples, to the marriage. [53]

And when they wanted wine, the mother of Jesus saith unto him, They have no wine. [54]

Jesus saith unto her, Woman, what have I to do with thee? mine hour is not yet come. [55]

His mother saith unto the servants, Whatsoever he saith unto you, do it. [56]

And there were set there six waterpots of stone, after the manner of the purifying of the Jews, containing two or three firkins apiece. [57]

Jesus saith unto them, Fill the waterpots with water. And they filled them up to the brim. [58]

And he saith unto them, Draw out now, and bear unto the governor of the feast. And they bare it. [59]

When the ruler of the feast had tasted the water that was made wine, and knew not whence it was: (but the servants which drew the water knew;) the governor of the feast called the bridegroom, [60]

And saith unto him, Every man at the beginning doth set forth good wine; and when men have well drunk, then that which is worse: but thou hast kept the good wine until now. [61]

This beginning of miracles did Jesus in Cana of Galilee, and manifested forth his glory; and his disciples believed on him. [62]

After this he went down to Capernaum, he, and his mother, and his brethren, and his disciples: and they continued there not many days. [63]

And the Jews' passover was at hand, and Jesus went up to Jerusalem. [64]

And found in the temple those that sold oxen and sheep and doves, and the changers of money sitting: [65]

And when he had made a scourge of small cords, he drove them all out of the temple, and the sheep, and the oxen; and poured out the changers' money, and overthrew the tables; [66]

And said unto them that sold doves, Take these things hence; make not my Father's house an house of merchandise. [67]

And his disciples remembered that it was written, The zeal of thine house hath eaten me up. [68]

Then answered the Jews and said unto him, What sign shewest thou unto us, seeing that thou doest these things? [69]

Jesus answered and said unto them, Destroy this temple, and in three days I will raise it up. [70]

Then said the Jews, Forty and six years was this temple in building, and wilt thou rear it up in three days? [71]

But he spake of the temple of his body. [72]

When therefore he was risen from the dead, his disciples remembered that he had said this unto them; and they believed the scripture, and the word which Jesus had said. [73]

Now when he was in Jerusalem at the passover, in the feast day, many believed in his name, when they saw the miracles which he did. [74]

But Jesus did not commit himself unto them, because he knew all men, [75]

And needed not that any should testify of man: for he knew what was in man. [76]

§ John 3

There was a man of the Pharisees, named Nicodemus, a ruler of the Jews: [77]

The same came to Jesus by night, and said unto him, Rabbi, we know that thou art a teacher come from God: for no man can do these miracles that thou doest, except God be with him. [78]

Jesus answered and said unto him, Verily, verily, I say unto thee, Except a man be born again, he cannot see the kingdom of God. [79]

Nicodemus saith unto him, How can a man be born when he is old? can he enter the second time into his mother's womb, and be born? [80]

Jesus answered, Verily, verily, I say unto thee, Except a man be born of water and of the Spirit, he cannot enter into the kingdom of God. [81]

That which is born of the flesh is flesh; and that which is born of the Spirit is spirit. [82]

Marvel not that I said unto thee, Ye must be born again. [83]

The wind bloweth where it listeth, and thou hearest the sound thereof, but canst not tell whence it cometh, and whither it goeth: so is every one that is born of the Spirit. [84]

Nicodemus answered and said unto him, How can these things be? [85]

Jesus answered and said unto him, Art thou a master of Israel, and knowest not these things? [86]

Verily, verily, I say unto thee, We speak that we do know, and testify that we have seen; and ye receive not our witness. [87]

If I have told you earthly things, and ye believe not, how shall ye believe, if I tell you of heavenly things? [88]

And no man hath ascended up to heaven, but he that came down from heaven, even the Son of man which is in heaven. [89]

And as Moses lifted up the serpent in the wilderness, even so must the Son of man be lifted up: [90]

That whosoever believeth in him should not perish, but have eternal life. [91]

For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life. [92]

For God sent not his Son into the world to condemn the world; but that the world through him might be saved. [93]

He that believeth on him is not condemned: but he that believeth not is condemned already, because he hath not believed in the name of the only begotten Son of God. [94]

And this is the condemnation, that light is come into the world, and men loved darkness rather than light, because their deeds were evil. [95]

For every one that doeth evil hateth the light, neither cometh to the light, lest his deeds should be reproved. [96]

But he that doeth truth cometh to the light, that his deeds may be made manifest, that they are wrought in God. [97]

After these things came Jesus and his disciples into the land of Judaea; and there he tarried with them, and baptized. [98]

And John also was baptizing in Aenon near to Salim, because there was much water there: and they came, and were baptized. [99]

For John was not yet cast into prison. [100]

Then there arose a question between some of John's disciples and the Jews about purifying. [101]

And they came unto John, and said unto him, Rabbi, he that was with thee beyond Jordan, to whom thou barest witness, behold, the same baptizeth, and all men come to him. [102]

John answered and said, A man can receive nothing, except it be given him from heaven. [103]

Ye yourselves bear me witness, that I said, I am not the Christ, but that I am sent before him. [104]

He that hath the bride is the bridegroom: but the friend of the bridegroom, which standeth and heareth him, rejoiceth greatly because of the bridegroom's voice: this my joy therefore is fulfilled. [105]

He must increase, but I must decrease. [106]

He that cometh from above is above all: he that is of the earth is earthly, and speaketh of the earth: he that cometh from heaven is above all. [107]

And what he hath seen and heard, that he testifieth; and no man receiveth his testimony. [108]

He that hath received his testimony hath set to his seal that God is true. [109]

For he whom God hath sent speaketh the words of God: for God giveth not the Spirit by measure unto him. [110]

The Father loveth the Son, and hath given all things into his hand. [111]

He that believeth on the Son hath everlasting life: and he that believeth not the Son shall not see life; but the wrath of God abideth on him. [112]

§ John 4

When therefore the LORD knew how the Pharisees had heard that Jesus made and baptized more disciples than John, [113]

(Though Jesus himself baptized not, but his disciples,) [114]

He left Judaea, and departed again into Galilee. [115]

And he must needs go through Samaria. [116]

Then cometh he to a city of Samaria, which is called Sychar, near to the parcel of ground that Jacob gave to his son Joseph. [117]

Now Jacob's well was there. Jesus therefore, being wearied with his journey, sat thus on the well: and it was about the sixth hour. [118]

There cometh a woman of Samaria to draw water: Jesus saith unto her, Give me to drink. [119]

(For his disciples were gone away unto the city to buy meat.) [120]

Then saith the woman of Samaria unto him, How is it that thou, being a Jew, askest drink of me, which am a woman of Samaria? for the Jews have no dealings with the Samaritans. [121]

Jesus answered and said unto her, If thou knewest the gift of God, and who it is that saith to thee, Give me to drink; thou wouldest have asked of him, and he would have given thee living water. [122]

The woman saith unto him, Sir, thou hast nothing to draw with, and the well is deep: from whence then hast thou that living water? [123]

Art thou greater than our father Jacob, which gave us the well, and drank thereof himself, and his children, and his cattle? [124]

Jesus answered and said unto her, Whosoever drinketh of this water shall thirst again: [125]

But whosoever drinketh of the water that I shall give him shall never thirst; but the water that I shall give him shall be in him a well of water springing up into everlasting life. [126]

The woman saith unto him, Sir, give me this water, that I thirst not, neither come hither to draw. [127]

Jesus saith unto her, Go, call thy husband, and come hither. [128]

The woman answered and said, I have no husband. Jesus said unto her, Thou hast well said, I have no husband: [129]

For thou hast had five husbands; and he whom thou now hast is not thy husband: in that saidst thou truly. [130]

The woman saith unto him, Sir, I perceive that thou art a prophet. [131]

Our fathers worshipped in this mountain; and ye say, that in Jerusalem is the place where men ought to worship. [132]

Jesus saith unto her, Woman, believe me, the hour cometh, when ye shall neither in this mountain, nor yet at Jerusalem, worship the Father. [133]

Ye worship ye know not what: we know what we worship: for salvation is of the Jews. [134]

But the hour cometh, and now is, when the true worshippers shall worship the Father in spirit and in truth: for the Father seeketh such to worship him. [135]

God is a Spirit: and they that worship him must worship him in spirit and in truth. [136]

The woman saith unto him, I know that Messias cometh, which is called Christ: when he is come, he will tell us all things. [137]

Jesus saith unto her, I that speak unto thee am he. [138]

And upon this came his disciples, and marvelled that he talked with the woman: yet no man said, What seekest thou? or, Why talkest thou with her? [139]

The woman then left her waterpot, and went her way into the city, and saith to the men, [140]

Come, see a man, which told me all things that ever I did: is not this the Christ? [141]

Then they went out of the city, and came unto him. [142]

In the mean while his disciples prayed him, saying, Master, eat. [143]

But he said unto them, I have meat to eat that ye know not of. [144]

Therefore said the disciples one to another, Hath any man brought him ought to eat? [145]

Jesus saith unto them, My meat is to do the will of him that sent me, and to finish his work. [146]

Say not ye, There are yet four months, and then cometh harvest? behold, I say unto you, Lift up your eyes, and look on the fields; for they are white already to harvest. [147]

And he that reapeth receiveth wages, and gathereth fruit unto life eternal: that both he that soweth and he that reapeth may rejoice together. [148]

And herein is that saying true, One soweth, and another reapeth. [149]

I sent you to reap that whereon ye bestowed no labour: other men laboured, and ye are entered into their labours. [150]

And many of the Samaritans of that city believed on him for the saying of the woman, which testified, He told me all that ever I did. [151]

So when the Samaritans were come unto him, they besought him that he would tarry with them: and he abode there two days. [152]

And many more believed because of his own word; [153]

And said unto the woman, Now we believe, not because of thy saying: for we have heard him ourselves, and know that this is indeed the Christ, the Saviour of the world. [154]

Now after two days he departed thence, and went into Galilee. [155]

For Jesus himself testified, that a prophet hath no honour in his own country. [156]

Then when he was come into Galilee, the Galilaeans received him, having seen all the things that he did at Jerusalem at the feast: for they also went unto the feast. [157]

So Jesus came again into Cana of Galilee, where he made the water wine. And there was a certain nobleman, whose son was sick at Capernaum. [158]

When he heard that Jesus was come out of Judaea into Galilee, he went unto him, and besought him that he would come down, and heal his son: for he was at the point of death. [159]

Then said Jesus unto him, Except ye see signs and wonders, ye will not believe. [160]

The nobleman saith unto him, Sir, come down ere my child die. [161]

Jesus saith unto him, Go thy way; thy son liveth. And the man believed the word that Jesus had spoken unto him, and he went his way. [162]

And as he was now going down, his servants met him, and told him, saying, Thy son liveth. [163]

Then enquired he of them the hour when he began to amend. And they said unto him, Yesterday at the seventh hour the fever left him. [164]

So the father knew that it was at the same hour, in the which Jesus said unto him, Thy son liveth: and himself believed, and his whole house. [165]

This is again the second miracle that Jesus did, when he was come out of Judaea into Galilee. [166]

§ John 5

After this there was a feast of the Jews; and Jesus went up to Jerusalem. [167]

Now there is at Jerusalem by the sheep market a pool, which is called in the Hebrew tongue Bethesda, having five porches. [168]

In these lay a great multitude of impotent folk, of blind, halt, withered, waiting for the moving of the water. [169]

For an angel went down at a certain season into the pool, and troubled the water: whosoever then first after the troubling of the water stepped in was made whole of whatsoever disease he had. [170]

And a certain man was there, which had an infirmity thirty and eight years. [171]

When Jesus saw him lie, and knew that he had been now a long time in that case, he saith unto him, Wilt thou be made whole? [172]

The impotent man answered him, Sir, I have no man, when the water is troubled, to put me into the pool: but while I am coming, another steppeth down before me. [173]

Jesus saith unto him, Rise, take up thy bed, and walk. [174]

And immediately the man was made whole, and took up his bed, and walked: and on the same day was the sabbath. [175]

The Jews therefore said unto him that was cured, It is the sabbath day: it is not lawful for thee to carry thy bed. [176]

He answered them, He that made me whole, the same said unto me, Take up thy bed, and walk. [177]

Then asked they him, What man is that which said unto thee, Take up thy bed, and walk? [178]

And he that was healed wist not who it was: for Jesus had conveyed himself away, a multitude being in that place. [179]

Afterward Jesus findeth him in the temple, and said unto him, Behold, thou art made whole: sin no more, lest a worse thing come unto thee. [180]

The man departed, and told the Jews that it was Jesus, which had made him whole. [181]

And therefore did the Jews persecute Jesus, and sought to slay him, because he had done these things on the sabbath day. [182]

But Jesus answered them, My Father worketh hitherto, and I work. [183]

Therefore the Jews sought the more to kill him, because he not only had broken the sabbath, but said also that God was his Father, making himself equal with God. [184]

Then answered Jesus and said unto them, Verily, verily, I say unto you, The Son can do nothing of himself, but what he seeth the Father do: for what things soever he doeth, these also doeth the Son likewise. [185]

For the Father loveth the Son, and sheweth him all things that himself doeth: and he will shew him greater works than these, that ye may marvel. [186]

For as the Father raiseth up the dead, and quickeneth them; even so the Son quickeneth whom he will. [187]

For the Father judgeth no man, but hath committed all judgment unto the Son: [188]

That all men should honour the Son, even as they honour the Father. He that honoureth not the Son honoureth not the Father which hath sent him. [189]

Verily, verily, I say unto you, He that heareth my word, and believeth on him that sent me, hath everlasting life, and shall not come into condemnation; but is passed from death unto life. [190]

Verily, verily, I say unto you, The hour is coming, and now is, when the dead shall hear the voice of the Son of God: and they that hear shall live. [191]

For as the Father hath life in himself; so hath he given to the Son to have life in himself; [192]

And hath given him authority to execute judgment also, because he is the Son of man. [193]

Marvel not at this: for the hour is coming, in the which all that are in the graves shall hear his voice, [194]

And shall come forth; they that have done good, unto the resurrection of life; and they that have done evil, unto the resurrection of damnation. [195]

I can of mine own self do nothing: as I hear, I judge: and my judgment is just; because I seek not mine own will, but the will of the Father which hath sent me. [196]

If I bear witness of myself, my witness is not true. [197]

There is another that beareth witness of me; and I know that the witness which he witnesseth of me is true. [198]

Ye sent unto John, and he bare witness unto the truth. [199]

But I receive not testimony from man: but these things I say, that ye might be saved. [200]

He was a burning and a shining light: and ye were willing for a season to rejoice in his light. [201]

But I have greater witness than that of John: for the works which the Father hath given me to finish, the same works that I do, bear witness of me, that the Father hath sent me. [202]

And the Father himself, which hath sent me, hath borne witness of me. Ye have neither heard his voice at any time, nor seen his shape. [203]

And ye have not his word abiding in you: for whom he hath sent, him ye believe not. [204]

Search the scriptures; for in them ye think ye have eternal life: and they are they which testify of me. [205]

And ye will not come to me, that ye might have life. [206]

I receive not honour from men. [207]

But I know you, that ye have not the love of God in you. [208]

I am come in my Father's name, and ye receive me not: if another shall come in his own name, him ye will receive. [209]

How can ye believe, which receive honour one of another, and seek not the honour that cometh from God only? [210]

Do not think that I will accuse you to the Father: there is one that accuseth you, even Moses, in whom ye trust. [211]

For had ye believed Moses, ye would have believed me; for he wrote of me. [212]

But if ye believe not his writings, how shall ye believe my words? [213]

§ John 6

After these things Jesus went over the sea of Galilee, which is the sea of Tiberias. [214]

And a great multitude followed him, because they saw his miracles which he did on them that were diseased. [215]

And Jesus went up into a mountain, and there he sat with his disciples. [216]

And the passover, a feast of the Jews, was nigh. [217]

When Jesus then lifted up his eyes, and saw a great company come unto him, he saith unto Philip, Whence shall we buy bread, that these may eat? [218]

And this he said to prove him: for he himself knew what he would do. [219]

Philip answered him, Two hundred pennyworth of bread is not sufficient for them, that every one of them may take a little. [220]

One of his disciples, Andrew, Simon Peter's brother, saith unto him, [221]

There is a lad here, which hath five barley loaves, and two small fishes: but what are they among so many? [222]

And Jesus said, Make the men sit down. Now there was much grass in the place. So the men sat down, in number about five thousand. [223]

And Jesus took the loaves; and when he had given thanks, he distributed to the disciples, and the disciples to them that were set down; and likewise of the fishes as much as they would. [224]

When they were filled, he said unto his disciples, Gather up the fragments that remain, that nothing be lost. [225]

Therefore they gathered them together, and filled twelve baskets with the fragments of the five barley loaves, which remained over and above unto them that had eaten. [226]

Then those men, when they had seen the miracle that Jesus did, said, This is of a truth that prophet that should come into the world. [227]

When Jesus therefore perceived that they would come and take him by force, to make him a king, he departed again into a mountain himself alone. [228]

And when even was now come, his disciples went down unto the sea, [229]

And entered into a ship, and went over the sea toward Capernaum. And it was now dark, and Jesus was not come to them. [230]

And the sea arose by reason of a great wind that blew. [231]

So when they had rowed about five and twenty or thirty furlongs, they see Jesus walking on the sea, and drawing nigh unto the ship: and they were afraid. [232]

But he saith unto them, It is I; be not afraid. [233]

Then they willingly received him into the ship: and immediately the ship was at the land whither they went. [234]

The day following, when the people which stood on the other side of the sea saw that there was none other boat there, save that one whereinto his disciples were entered, and that Jesus went not with his disciples into the boat, but that his disciples were gone away alone; [235]

(Howbeit there came other boats from Tiberias nigh unto the place where they did eat bread, after that the Lord had given thanks:) [236]

When the people therefore saw that Jesus was not there, neither his disciples, they also took shipping, and came to Capernaum, seeking for Jesus. [237]

And when they had found him on the other side of the sea, they said unto him, Rabbi, when camest thou hither? [238]

Jesus answered them and said, Verily, verily, I say unto you, Ye seek me, not because ye saw the miracles, but because ye did eat of the loaves, and were filled. [239]

Labour not for the meat which perisheth, but for that meat which endureth unto everlasting life, which the Son of man shall give unto you: for him hath God the Father sealed. [240]

Then said they unto him, What shall we do, that we might work the works of God? [241]

Jesus answered and said unto them, This is the work of God, that ye believe on him whom he hath sent. [242]

They said therefore unto him, What sign shewest thou then, that we may see, and believe thee? what dost thou work? [243]

Our fathers did eat manna in the desert; as it is written, He gave them bread from heaven to eat. [244]

Then Jesus said unto them, Verily, verily, I say unto you, Moses gave you not that bread from heaven; but my Father giveth you the true bread from heaven. [245]

For the bread of God is he which cometh down from heaven, and giveth life unto the world. [246]

Then said they unto him, Lord, evermore give us this bread. [247]

And Jesus said unto them, I am the bread of life: he that cometh to me shall never hunger; and he that believeth on me shall never thirst. [248]

But I said unto you, That ye also have seen me, and believe not. [249]

All that the Father giveth me shall come to me; and him that cometh to me I will in no wise cast out. [250]

For I came down from heaven, not to do mine own will, but the will of him that sent me. [251]

And this is the Father's will which hath sent me, that of all which he hath given me I should lose nothing, but should raise it up again at the last day. [252]

And this is the will of him that sent me, that every one which seeth the Son, and believeth on him, may have everlasting life: and I will raise him up at the last day. [253]

The Jews then murmured at him, because he said, I am the bread which came down from heaven. [254]

And they said, Is not this Jesus, the son of Joseph, whose father and mother we know? how is it then that he saith, I came down from heaven? [255]

Jesus therefore answered and said unto them, Murmur not among yourselves. [256]

No man can come to me, except the Father which hath sent me draw him: and I will raise him up at the last day. [257]

It is written in the prophets, And they shall be all taught of God. Every man therefore that hath heard, and hath learned of the Father, cometh unto me. [258]

Not that any man hath seen the Father, save he which is of God, he hath seen the Father. [259]

Verily, verily, I say unto you, He that believeth on me hath everlasting life. [260]

I am that bread of life. [261]

Your fathers did eat manna in the wilderness, and are dead. [262]

This is the bread which cometh down from heaven, that a man may eat thereof, and not die. [263]

I am the living bread which came down from heaven: if any man eat of this bread, he shall live for ever: and the bread that I will give is my flesh, which I will give for the life of the world. [264]

The Jews therefore strove among themselves, saying, How can this man give us his flesh to eat? [265]

Then Jesus said unto them, Verily, verily, I say unto you, Except ye eat the flesh of the Son of man, and drink his blood, ye have no life in you. [266]

Whoso eateth my flesh, and drinketh my blood, hath eternal life; and I will raise him up at the last day. [267]

For my flesh is meat indeed, and my blood is drink indeed. [268]

He that eateth my flesh, and drinketh my blood, dwelleth in me, and I in him. [269]

As the living Father hath sent me, and I live by the Father: so he that eateth me, even he shall live by me. [270]

This is that bread which came down from heaven: not as your fathers did eat manna, and are dead: he that eateth of this bread shall live for ever. [271]

These things said he in the synagogue, as he taught in Capernaum. [272]

Many therefore of his disciples, when they had heard this, said, This is an hard saying; who can hear it? [273]

When Jesus knew in himself that his disciples murmured at it, he said unto them, Doth this offend you? [274]

What and if ye shall see the Son of man ascend up where he was before? [275]

It is the spirit that quickeneth; the flesh profiteth nothing: the words that I speak unto you, they are spirit, and they are life. [276]

But there are some of you that believe not. For Jesus knew from the beginning who they were that believed not, and who should betray him. [277]

And he said, Therefore said I unto you, that no man can come unto me, except it were given unto him of my Father. [278]

From that time many of his disciples went back, and walked no more with him. [279]

Then said Jesus unto the twelve, Will ye also go away? [280]

Then Simon Peter answered him, Lord, to whom shall we go? thou hast the words of eternal life. [281]

And we believe and are sure that thou art that Christ, the Son of the living God. [282]

Jesus answered them, Have not I chosen you twelve, and one of you is a devil? [283]

He spake of Judas Iscariot the son of Simon: for he it was that should betray him, being one of the twelve. [284]

§ John 7

After these things Jesus walked in Galilee: for he would not walk in Jewry, because the Jews sought to kill him. [285]

Now the Jew's feast of tabernacles was at hand. [286]

His brethren therefore said unto him, Depart hence, and go into Judaea, that thy disciples also may see the works that thou doest. [287]

For there is no man that doeth any thing in secret, and he himself seeketh to be known openly. If thou do these things, shew thyself to the world. [288]

For neither did his brethren believe in him. [289]

Then Jesus said unto them, My time is not yet come: but your time is alway ready. [290]

The world cannot hate you; but me it hateth, because I testify of it, that the works thereof are evil. [291]

Go ye up unto this feast: I go not up yet unto this feast: for my time is not yet full come. [292]

When he had said these words unto them, he abode still in Galilee. [293]

But when his brethren were gone up, then went he also up unto the feast, not openly, but as it were in secret. [294]

Then the Jews sought him at the feast, and said, Where is he? [295]

And there was much murmuring among the people concerning him: for some said, He is a good man: others said, Nay; but he deceiveth the people. [296]

Howbeit no man spake openly of him for fear of the Jews. [297]

Now about the midst of the feast Jesus went up into the temple, and taught. [298]

And the Jews marvelled, saying, How knoweth this man letters, having never learned? [299]

Jesus answered them, and said, My doctrine is not mine, but his that sent me. [300]

If any man will do his will, he shall know of the doctrine, whether it be of God, or whether I speak of myself. [301]

He that speaketh of himself seeketh his own glory: but he that seeketh his glory that sent him, the same is true, and no unrighteousness is in him. [302]

Did not Moses give you the law, and yet none of you keepeth the law? Why go ye about to kill me? [303]

The people answered and said, Thou hast a devil: who goeth about to kill thee? [304]

Jesus answered and said unto them, I have done one work, and ye all marvel. [305]

Moses therefore gave unto you circumcision; (not because it is of Moses, but of the fathers;) and ye on the sabbath day circumcise a man. [306]

If a man on the sabbath day receive circumcision, that the law of Moses should not be broken; are ye angry at me, because I have made a man every whit whole on the sabbath day? [307]

Judge not according to the appearance, but judge righteous judgment. [308]

Then said some of them of Jerusalem, Is not this he, whom they seek to kill? [309]

But, lo, he speaketh boldly, and they say nothing unto him. Do the rulers know indeed that this is the very Christ? [310]

Howbeit we know this man whence he is: but when Christ cometh, no man knoweth whence he is. [311]

Then cried Jesus in the temple as he taught, saying, Ye both know me, and ye know whence I am: and I am not come of myself, but he that sent me is true, whom ye know not. [312]

But I know him: for I am from him, and he hath sent me. [313]

Then they sought to take him: but no man laid hands on him, because his hour was not yet come. [314]

And many of the people believed on him, and said, When Christ cometh, will he do more miracles than these which this man hath done? [315]

The Pharisees heard that the people murmured such things concerning him; and the Pharisees and the chief priests sent officers to take him. [316]

Then said Jesus unto them, Yet a little while am I with you, and then I go unto him that sent me. [317]

Ye shall seek me, and shall not find me: and where I am, thither ye cannot come. [318]

Then said the Jews among themselves, Whither will he go, that we shall not find him? will he go unto the dispersed among the Gentiles, and teach the Gentiles? [319]

What manner of saying is this that he said, Ye shall seek me, and shall not find me: and where I am, thither ye cannot come? [320]

In the last day, that great day of the feast, Jesus stood and cried, saying, If any man thirst, let him come unto me, and drink. [321]

He that believeth on me, as the scripture hath said, out of his belly shall flow rivers of living water. [322]

(But this spake he of the Spirit, which they that believe on him should receive: for the Holy Ghost was not yet given; because that Jesus was not yet glorified.) [323]

Many of the people therefore, when they heard this saying, said, Of a truth this is the Prophet. [324]

Others said, This is the Christ. But some said, Shall Christ come out of Galilee? [325]

Hath not the scripture said, That Christ cometh of the seed of David, and out of the town of Bethlehem, where David was? [326]

So there was a division among the people because of him. [327]

And some of them would have taken him; but no man laid hands on him. [328]

Then came the officers to the chief priests and Pharisees; and they said unto them, Why have ye not brought him? [329]

The officers answered, Never man spake like this man. [330]

Then answered them the Pharisees, Are ye also deceived? [331]

Have any of the rulers or of the Pharisees believed on him? [332]

But this people who knoweth not the law are cursed. [333]

Nicodemus saith unto them, (he that came to Jesus by night, being one of them,) [334]

Doth our law judge any man, before it hear him, and know what he doeth? [335]

They answered and said unto him, Art thou also of Galilee? Search, and look: for out of Galilee ariseth no prophet. [336]

And every man went unto his own house. [337]

§ John 8

Jesus went unto the mount of Olives. [338]

And early in the morning he came again into the temple, and all the people came unto him; and he sat down, and taught them. [339]

And the scribes and Pharisees brought unto him a woman taken in adultery; and when they had set her in the midst, [340]

They say unto him, Master, this woman was taken in adultery, in the very act. [341]

Now Moses in the law commanded us, that such should be stoned: but what sayest thou? [342]

This they said, tempting him, that they might have to accuse him. But Jesus stooped down, and with his finger wrote on the ground, as though he heard them not. [343]

So when they continued asking him, he lifted up himself, and said unto them, He that is without sin among you, let him first cast a stone at her. [344]

And again he stooped down, and wrote on the ground. [345]

And they which heard it, being convicted by their own conscience, went out one by one, beginning at the eldest, even unto the last: and Jesus was left alone, and the woman standing in the midst. [346]

When Jesus had lifted up himself, and saw none but the woman, he said unto her, Woman, where are those thine accusers? hath no man condemned thee? [347]

She said, No man, Lord. And Jesus said unto her, Neither do I condemn thee: go, and sin no more. [348]

Then spake Jesus again unto them, saying, I am the light of the world: he that followeth me shall not walk in darkness, but shall have the light of life. [349]

The Pharisees therefore said unto him, Thou bearest record of thyself; thy record is not true. [350]

Jesus answered and said unto them, Though I bear record of myself, yet my record is true: for I know whence I came, and whither I go; but ye cannot tell whence I come, and whither I go. [351]

Ye judge after the flesh; I judge no man. [352]

And yet if I judge, my judgment is true: for I am not alone, but I and the Father that sent me. [353]

It is also written in your law, that the testimony of two men is true. [354]

I am one that bear witness of myself, and the Father that sent me beareth witness of me. [355]

Then said they unto him, Where is thy Father? Jesus answered, Ye neither know me, nor my Father: if ye had known me, ye should have known my Father also. [356]

These words spake Jesus in the treasury, as he taught in the temple: and no man laid hands on him; for his hour was not yet come. [357]

Then said Jesus again unto them, I go my way, and ye shall seek me, and shall die in your sins: whither I go, ye cannot come. [358]

Then said the Jews, Will he kill himself? because he saith, Whither I go, ye cannot come. [359]

And he said unto them, Ye are from beneath; I am from above: ye are of this world; I am not of this world. [360]

I said therefore unto you, that ye shall die in your sins: for if ye believe not that I am he, ye shall die in your sins. [361]

Then said they unto him, Who art thou? And Jesus saith unto them, Even the same that I said unto you from the beginning. [362]

I have many things to say and to judge of you: but he that sent me is true; and I speak to the world those things which I have heard of him. [363]

They understood not that he spake to them of the Father. [364]

Then said Jesus unto them, When ye have lifted up the Son of man, then shall ye know that I am he, and that I do nothing of myself; but as my Father hath taught me, I speak these things. [365]

And he that sent me is with me: the Father hath not left me alone; for I do always those things that please him. [366]

As he spake these words, many believed on him. [367]

Then said Jesus to those Jews which believed on him, If ye continue in my word, then are ye my disciples indeed; [368]

And ye shall know the truth, and the truth shall make you free. [369]

They answered him, We be Abraham's seed, and were never in bondage to any man: how sayest thou, Ye shall be made free? [370]

Jesus answered them, Verily, verily, I say unto you, Whosoever committeth sin is the servant of sin. [371]

And the servant abideth not in the house for ever: but the Son abideth ever. [372]

If the Son therefore shall make you free, ye shall be free indeed. [373]

I know that ye are Abraham's seed; but ye seek to kill me, because my word hath no place in you. [374]

I speak that which I have seen with my Father: and ye do that which ye have seen with your father. [375]

They answered and said unto him, Abraham is our father. Jesus saith unto them, If ye were Abraham's children, ye would do the works of Abraham. [376]

But now ye seek to kill me, a man that hath told you the truth, which I have heard of God: this did not Abraham. [377]

Ye do the deeds of your father. Then said they to him, We be not born of fornication; we have one Father, even God. [378]

Jesus said unto them, If God were your Father, ye would love me: for I proceeded forth and came from God; neither came I of myself, but he sent me. [379]

Why do ye not understand my speech? even because ye cannot hear my word. [380]

Ye are of your father the devil, and the lusts of your father ye will do. He was a murderer from the beginning, and abode not in the truth, because there is no truth in him. When he speaketh a lie, he speaketh of his own: for he is a liar, and the father of it. [381]

And because I tell you the truth, ye believe me not. [382]

Which of you convinceth me of sin? And if I say the truth, why do ye not believe me? [383]

He that is of God heareth God's words: ye therefore hear them not, because ye are not of God. [384]

Then answered the Jews, and said unto him, Say we not well that thou art a Samaritan, and hast a devil? [385]

Jesus answered, I have not a devil; but I honour my Father, and ye do dishonour me. [386]

And I seek not mine own glory: there is one that seeketh and judgeth. [387]

Verily, verily, I say unto you, If a man keep my saying, he shall never see death. [388]

Then said the Jews unto him, Now we know that thou hast a devil. Abraham is dead, and the prophets; and thou sayest, If a man keep my saying, he shall never taste of death. [389]

Art thou greater than our father Abraham, which is dead? and the prophets are dead: whom makest thou thyself? [390]

Jesus answered, If I honour myself, my honour is nothing: it is my Father that honoureth me; of whom ye say, that he is your God: [391]

Yet ye have not known him; but I know him: and if I should say, I know him not, I shall be a liar like unto you: but I know him, and keep his saying. [392]

Your father Abraham rejoiced to see my day: and he saw it, and was glad. [393]

Then said the Jews unto him, Thou art not yet fifty years old, and hast thou seen Abraham? [394]

Jesus said unto them, Verily, verily, I say unto you, Before Abraham was, I am. [395]

Then took they up stones to cast at him: but Jesus hid himself, and went out of the temple, going through the midst of them, and so passed by. [396]

§ John 9

And as Jesus passed by, he saw a man which was blind from his birth. [397]

And his disciples asked him, saying, Master, who did sin, this man, or his parents, that he was born blind? [398]

Jesus answered, Neither hath this man sinned, nor his parents: but that the works of God should be made manifest in him. [399]

I must work the works of him that sent me, while it is day: the night cometh, when no man can work. [400]

As long as I am in the world, I am the light of the world. [401]

When he had thus spoken, he spat on the ground, and made clay of the spittle, and he anointed the eyes of the blind man with the clay, [402]

And said unto him, Go, wash in the pool of Siloam, (which is by interpretation, Sent.) He went his way therefore, and washed, and came seeing. [403]

The neighbours therefore, and they which before had seen him that he was blind, said, Is not this he that sat and begged? [404]

Some said, This is he: others said, He is like him: but he said, I am he. [405]

Therefore said they unto him, How were thine eyes opened? [406]

He answered and said, A man that is called Jesus made clay, and anointed mine eyes, and said unto me, Go to the pool of Siloam, and wash: and I went and washed, and I received sight. [407]

Then said they unto him, Where is he? He said, I know not. [408]

They brought to the Pharisees him that aforetime was blind. [409]

And it was the sabbath day when Jesus made the clay, and opened his eyes. [410]

Then again the Pharisees also asked him how he had received his sight. He said unto them, He put clay upon mine eyes, and I washed, and do see. [411]

Therefore said some of the Pharisees, This man is not of God, because he keepeth not the sabbath day. Others said, How can a man that is a sinner do such miracles? And there was a division among them. [412]

They say unto the blind man again, What sayest thou of him, that he hath opened thine eyes? He said, He is a prophet. [413]

But the Jews did not believe concerning him, that he had been blind, and received his sight, until they called the parents of him that had received his sight. [414]

And they asked them, saying, Is this your son, who ye say was born blind? how then doth he now see? [415]

His parents answered them and said, We know that this is our son, and that he was born blind: [416]

But by what means he now seeth, we know not; or who hath opened his eyes, we know not: he is of age; ask him: he shall speak for himself. [417]

These words spake his parents, because they feared the Jews: for the Jews had agreed already, that if any man did confess that he was Christ, he should be put out of the synagogue. [418]

Therefore said his parents, He is of age; ask him. [419]

Then again called they the man that was blind, and said unto him, Give God the praise: we know that this man is a sinner. [420]

He answered and said, Whether he be a sinner or no, I know not: one thing I know, that, whereas I was blind, now I see. [421]

Then said they to him again, What did he to thee? how opened he thine eyes? [422]

He answered them, I have told you already, and ye did not hear: wherefore would ye hear it again? will ye also be his disciples? [423]

Then they reviled him, and said, Thou art his disciple; but we are Moses' disciples. [424]

We know that God spake unto Moses: as for this fellow, we know not from whence he is. [425]

The man answered and said unto them, Why herein is a marvellous thing, that ye know not from whence he is, and yet he hath opened mine eyes. [426]

Now we know that God heareth not sinners: but if any man be a worshipper of God, and doeth his will, him he heareth. [427]

Since the world began was it not heard that any man opened the eyes of one that was born blind. [428]

If this man were not of God, he could do nothing. [429]

They answered and said unto him, Thou wast altogether born in sins, and dost thou teach us? And they cast him out. [430]

Jesus heard that they had cast him out; and when he had found him, he said unto him, Dost thou believe on the Son of God? [431]

He answered and said, Who is he, Lord, that I might believe on him? [432]

And Jesus said unto him, Thou hast both seen him, and it is he that talketh with thee. [433]

And he said, Lord, I believe. And he worshipped him. [434]

And Jesus said, For judgment I am come into this world, that they which see not might see; and that they which see might be made blind. [435]

And some of the Pharisees which were with him heard these words, and said unto him, Are we blind also? [436]

Jesus said unto them, If ye were blind, ye should have no sin: but now ye say, We see; therefore your sin remaineth. [437]

§ John 10

Verily, verily, I say unto you, He that entereth not by the door into the sheepfold, but climbeth up some other way, the same is a thief and a robber. [438]

But he that entereth in by the door is the shepherd of the sheep. [439]

To him the porter openeth; and the sheep hear his voice: and he calleth his own sheep by name, and leadeth them out. [440]

And when he putteth forth his own sheep, he goeth before them, and the sheep follow him: for they know his voice. [441]

And a stranger will they not follow, but will flee from him: for they know not the voice of strangers. [442]

This parable spake Jesus unto them: but they understood not what things they were which he spake unto them. [443]

Then said Jesus unto them again, Verily, verily, I say unto you, I am the door of the sheep. [444]

All that ever came before me are thieves and robbers: but the sheep did not hear them. [445]

I am the door: by me if any man enter in, he shall be saved, and shall go in and out, and find pasture. [446]

The thief cometh not, but for to steal, and to kill, and to destroy: I am come that they might have life, and that they might have it more abundantly. [447]

I am the good shepherd: the good shepherd giveth his life for the sheep. [448]

But he that is an hireling, and not the shepherd, whose own the sheep are not, seeth the wolf coming, and leaveth the sheep, and fleeth: and the wolf catcheth them, and scattereth the sheep. [449]

The hireling fleeth, because he is an hireling, and careth not for the sheep. [450]

I am the good shepherd, and know my sheep, and am known of mine. [451]

As the Father knoweth me, even so know I the Father: and I lay down my life for the sheep. [452]

And other sheep I have, which are not of this fold: them also I must bring, and they shall hear my voice; and there shall be one fold, and one shepherd. [453]

Therefore doth my Father love me, because I lay down my life, that I might take it again. [454]

No man taketh it from me, but I lay it down of myself. I have power to lay it down, and I have power to take it again. This commandment have I received of my Father. [455]

There was a division therefore again among the Jews for these sayings. [456]

And many of them said, He hath a devil, and is mad; why hear ye him? [457]

Others said, These are not the words of him that hath a devil. Can a devil open the eyes of the blind? [458]

And it was at Jerusalem the feast of the dedication, and it was winter. [459]

And Jesus walked in the temple in Solomon's porch. [460]

Then came the Jews round about him, and said unto him, How long dost thou make us to doubt? If thou be the Christ, tell us plainly. [461]

Jesus answered them, I told you, and ye believed not: the works that I do in my Father's name, they bear witness of me. [462]

But ye believe not, because ye are not of my sheep, as I said unto you. [463]

My sheep hear my voice, and I know them, and they follow me: [464]

And I give unto them eternal life; and they shall never perish, neither shall any man pluck them out of my hand. [465]

My Father, which gave them me, is greater than all; and no man is able to pluck them out of my Father's hand. [466]

I and my Father are one. [467]

Then the Jews took up stones again to stone him. [468]

Jesus answered them, Many good works have I shewed you from my Father; for which of those works do ye stone me? [469]

The Jews answered him, saying, For a good work we stone thee not; but for blasphemy; and because that thou, being a man, makest thyself God. [470]

Jesus answered them, Is it not written in your law, I said, Ye are gods? [471]

If he called them gods, unto whom the word of God came, and the scripture cannot be broken; [472]

Say ye of him, whom the Father hath sanctified, and sent into the world, Thou blasphemest; because I said, I am the Son of God? [473]

If I do not the works of my Father, believe me not. [474]

But if I do, though ye believe not me, believe the works: that ye may know, and believe, that the Father is in me, and I in him. [475]

Therefore they sought again to take him: but he escaped out of their hand, [476]

And went away again beyond Jordan into the place where John at first baptized; and there he abode. [477]

And many resorted unto him, and said, John did no miracle: but all things that John spake of this man were true. [478]

And many believed on him there. [479]

§ John 11

Now a certain man was sick, named Lazarus, of Bethany, the town of Mary and her sister Martha. [480]

(It was that Mary which anointed the Lord with ointment, and wiped his feet with her hair, whose brother Lazarus was sick.) [481]

Therefore his sisters sent unto him, saying, Lord, behold, he whom thou lovest is sick. [482]

When Jesus heard that, he said, This sickness is not unto death, but for the glory of God, that the Son of God might be glorified thereby. [483]

Now Jesus loved Martha, and her sister, and Lazarus. [484]

When he had heard therefore that he was sick, he abode two days still in the same place where he was. [485]

Then after that saith he to his disciples, Let us go into Judaea again. [486]

His disciples say unto him, Master, the Jews of late sought to stone thee; and goest thou thither again? [487]

Jesus answered, Are there not twelve hours in the day? If any man walk in the day, he stumbleth not, because he seeth the light of this world. [488]

But if a man walk in the night, he stumbleth, because there is no light in him. [489]

These things said he: and after that he saith unto them, Our friend Lazarus sleepeth; but I go, that I may awake him out of sleep. [490]

Then said his disciples, Lord, if he sleep, he shall do well. [491]

Howbeit Jesus spake of his death: but they thought that he had spoken of taking of rest in sleep. [492]

Then said Jesus unto them plainly, Lazarus is dead. [493]

And I am glad for your sakes that I was not there, to the intent ye may believe; nevertheless let us go unto him. [494]

Then said Thomas, which is called Didymus, unto his fellowdisciples, Let us also go, that we may die with him. [495]

Then when Jesus came, he found that he had lain in the grave four days already. [496]

Now Bethany was nigh unto Jerusalem, about fifteen furlongs off: [497]

And many of the Jews came to Martha and Mary, to comfort them concerning their brother. [498]

Then Martha, as soon as she heard that Jesus was coming, went and met him: but Mary sat still in the house. [499]

Then said Martha unto Jesus, Lord, if thou hadst been here, my brother had not died. [500]

But I know, that even now, whatsoever thou wilt ask of God, God will give it thee. [501]

Jesus saith unto her, Thy brother shall rise again. [502]

Martha saith unto him, I know that he shall rise again in the resurrection at the last day. [503]

Jesus said unto her, I am the resurrection, and the life: he that believeth in me, though he were dead, yet shall he live: [504]

And whosoever liveth and believeth in me shall never die. Believest thou this? [505]

She saith unto him, Yea, Lord: I believe that thou art the Christ, the Son of God, which should come into the world. [506]

And when she had so said, she went her way, and called Mary her sister secretly, saying, The Master is come, and calleth for thee. [507]

As soon as she heard that, she arose quickly, and came unto him. [508]

Now Jesus was not yet come into the town, but was in that place where Martha met him. [509]

The Jews then which were with her in the house, and comforted her, when they saw Mary, that she rose up hastily and went out, followed her, saying, She goeth unto the grave to weep there. [510]

Then when Mary was come where Jesus was, and saw him, she fell down at his feet, saying unto him, Lord, if thou hadst been here, my brother had not died. [511]

When Jesus therefore saw her weeping, and the Jews also weeping which came with her, he groaned in the spirit, and was troubled. [512]

And said, Where have ye laid him? They said unto him, Lord, come and see. [513]

Jesus wept. [514]

Then said the Jews, Behold how he loved him! [515]

And some of them said, Could not this man, which opened the eyes of the blind, have caused that even this man should not have died? [516]

Jesus therefore again groaning in himself cometh to the grave. It was a cave, and a stone lay upon it. [517]

Jesus said, Take ye away the stone. Martha, the sister of him that was dead, saith unto him, Lord, by this time he stinketh: for he hath been dead four days. [518]

Jesus saith unto her, Said I not unto thee, that, if thou wouldest believe, thou shouldest see the glory of God? [519]

Then they took away the stone from the place where the dead was laid. And Jesus lifted up his eyes, and said, Father, I thank thee that thou hast heard me. [520]

And I knew that thou hearest me always: but because of the people which stand by I said it, that they may believe that thou hast sent me. [521]

And when he thus had spoken, he cried with a loud voice, Lazarus, come forth. [522]

And he that was dead came forth, bound hand and foot with graveclothes: and his face was bound about with a napkin. Jesus saith unto them, Loose him, and let him go. [523]

Then many of the Jews which came to Mary, and had seen the things which Jesus did, believed on him. [524]

But some of them went their ways to the Pharisees, and told them what things Jesus had done. [525]

Then gathered the chief priests and the Pharisees a council, and said, What do we? for this man doeth many miracles. [526]

If we let him thus alone, all men will believe on him: and the Romans shall come and take away both our place and nation. [527]

And one of them, named Caiaphas, being the high priest that same year, said unto them, Ye know nothing at all, [528]

Nor consider that it is expedient for us, that one man should die for the people, and that the whole nation perish not. [529]

And this spake he not of himself: but being high priest that year, he prophesied that Jesus should die for that nation; [530]

And not for that nation only, but that also he should gather together in one the children of God that were scattered abroad. [531]

Then from that day forth they took counsel together for to put him to death. [532]

Jesus therefore walked no more openly among the Jews; but went thence unto a country near to the wilderness, into a city called Ephraim, and there continued with his disciples. [533]

And the Jews' passover was nigh at hand: and many went out of the country up to Jerusalem before the passover, to purify themselves. [534]

Then sought they for Jesus, and spake among themselves, as they stood in the temple, What think ye, that he will not come to the feast? [535]

Now both the chief priests and the Pharisees had given a commandment, that, if any man knew where he were, he should shew it, that they might take him. [536]

§ John 12

Then Jesus six days before the passover came to Bethany, where Lazarus was, which had been dead, whom he raised from the dead. [537]

There they made him a supper; and Martha served: but Lazarus was one of them that sat at the table with him. [538]

Then took Mary a pound of ointment of spikenard, very costly, and anointed the feet of Jesus, and wiped his feet with her hair: and the house was filled with the odour of the ointment. [539]

Then saith one of his disciples, Judas Iscariot, Simon's son, which should betray him, [540]

Why was not this ointment sold for three hundred pence, and given to the poor? [541]

This he said, not that he cared for the poor; but because he was a thief, and had the bag, and bare what was put therein. [542]

Then said Jesus, Let her alone: against the day of my burying hath she kept this. [543]

For the poor always ye have with you; but me ye have not always. [544]

Much people of the Jews therefore knew that he was there: and they came not for Jesus' sake only, but that they might see Lazarus also, whom he had raised from the dead. [545]

But the chief priests consulted that they might put Lazarus also to death; [546]

Because that by reason of him many of the Jews went away, and believed on Jesus. [547]

On the next day much people that were come to the feast, when they heard that Jesus was coming to Jerusalem, [548]

Took branches of palm trees, and went forth to meet him, and cried, Hosanna: Blessed is the King of Israel that cometh in the name of the Lord. [549]

And Jesus, when he had found a young ass, sat thereon; as it is written, [550]

Fear not, daughter of Sion: behold, thy King cometh, sitting on an ass's colt. [551]

These things understood not his disciples at the first: but when Jesus was glorified, then remembered they that these things were written of him, and that they had done these things unto him. [552]

The people therefore that was with him when he called Lazarus out of his grave, and raised him from the dead, bare record. [553]

For this cause the people also met him, for that they heard that he had done this miracle. [554]

The Pharisees therefore said among themselves, Perceive ye how ye prevail nothing? behold, the world is gone after him. [555]

And there were certain Greeks among them that came up to worship at the feast: [556]

The same came therefore to Philip, which was of Bethsaida of Galilee, and desired him, saying, Sir, we would see Jesus. [557]

Philip cometh and telleth Andrew: and again Andrew and Philip tell Jesus. [558]

And Jesus answered them, saying, The hour is come, that the Son of man should be glorified. [559]

Verily, verily, I say unto you, Except a corn of wheat fall into the ground and die, it abideth alone: but if it die, it bringeth forth much fruit. [560]

He that loveth his life shall lose it; and he that hateth his life in this world shall keep it unto life eternal. [561]

If any man serve me, let him follow me; and where I am, there shall also my servant be: if any man serve me, him will my Father honour. [562]

Now is my soul troubled; and what shall I say? Father, save me from this hour: but for this cause came I unto this hour. [563]

Father, glorify thy name. Then came there a voice from heaven, saying, I have both glorified it, and will glorify it again. [564]

The people therefore, that stood by, and heard it, said that it thundered: others said, An angel spake to him. [565]

Jesus answered and said, This voice came not because of me, but for your sakes. [566]

Now is the judgment of this world: now shall the prince of this world be cast out. [567]

And I, if I be lifted up from the earth, will draw all men unto me. [568]

This he said, signifying what death he should die. [569]

The people answered him, We have heard out of the law that Christ abideth for ever: and how sayest thou, The Son of man must be lifted up? who is this Son of man? [570]

Then Jesus said unto them, Yet a little while is the light with you. Walk while ye have the light, lest darkness come upon you: for he that walketh in darkness knoweth not whither he goeth. [571]

While ye have light, believe in the light, that ye may be the children of light. These things spake Jesus, and departed, and did hide himself from them. [572]

But though he had done so many miracles before them, yet they believed not on him: [573]

That the saying of Esaias the prophet might be fulfilled, which he spake, Lord, who hath believed our report? and to whom hath the arm of the Lord been revealed? [574]

Therefore they could not believe, because that Esaias said again, [575]

He hath blinded their eyes, and hardened their heart; that they should not see with their eyes, nor understand with their heart, and be converted, and I should heal them. [576]

These things said Esaias, when he saw his glory, and spake of him. [577]

Nevertheless among the chief rulers also many believed on him; but because of the Pharisees they did not confess him, lest they should be put out of the synagogue: [578]

For they loved the praise of men more than the praise of God. [579]

Jesus cried and said, He that believeth on me, believeth not on me, but on him that sent me. [580]

And he that seeth me seeth him that sent me. [581]

I am come a light into the world, that whosoever believeth on me should not abide in darkness. [582]

And if any man hear my words, and believe not, I judge him not: for I came not to judge the world, but to save the world. [583]

He that rejecteth me, and receiveth not my words, hath one that judgeth him: the word that I have spoken, the same shall judge him in the last day. [584]

For I have not spoken of myself; but the Father which sent me, he gave me a commandment, what I should say, and what I should speak. [585]

And I know that his commandment is life everlasting: whatsoever I speak therefore, even as the Father said unto me, so I speak. [586]

§ John 13

Now before the feast of the passover, when Jesus knew that his hour was come that he should depart out of this world unto the Father, having loved his own which were in the world, he loved them unto the end. [587]

And supper being ended, the devil having now put into the heart of Judas Iscariot, Simon's son, to betray him; [588]

Jesus knowing that the Father had given all things into his hands, and that he was come from God, and went to God; [589]

He riseth from supper, and laid aside his garments; and took a towel, and girded himself. [590]

After that he poureth water into a bason, and began to wash the disciples' feet, and to wipe them with the towel wherewith he was girded. [591]

Then cometh he to Simon Peter: and Peter saith unto him, Lord, dost thou wash my feet? [592]

Jesus answered and said unto him, What I do thou knowest not now; but thou shalt know hereafter. [593]

Peter saith unto him, Thou shalt never wash my feet. Jesus answered him, If I wash thee not, thou hast no part with me. [594]

Simon Peter saith unto him, Lord, not my feet only, but also my hands and my head. [595]

Jesus saith to him, He that is washed needeth not save to wash his feet, but is clean every whit: and ye are clean, but not all. [596]

For he knew who should betray him; therefore said he, Ye are not all clean. [597]

So after he had washed their feet, and had taken his garments, and was set down again, he said unto them, Know ye what I have done to you? [598]

Ye call me Master and Lord: and ye say well; for so I am. [599]

If I then, your Lord and Master, have washed your feet; ye also ought to wash one another's feet. [600]

For I have given you an example, that ye should do as I have done to you. [601]

Verily, verily, I say unto you, The servant is not greater than his lord; neither he that is sent greater than he that sent him. [602]

If ye know these things, happy are ye if ye do them. [603]

I speak not of you all: I know whom I have chosen: but that the scripture may be fulfilled, He that eateth bread with me hath lifted up his heel against me. [604]

Now I tell you before it come, that, when it is come to pass, ye may believe that I am he. [605]

Verily, verily, I say unto you, He that receiveth whomsoever I send receiveth me; and he that receiveth me receiveth him that sent me. [606]

When Jesus had thus said, he was troubled in spirit, and testified, and said, Verily, verily, I say unto you, that one of you shall betray me. [607]

Then the disciples looked one on another, doubting of whom he spake. [608]

Now there was leaning on Jesus' bosom one of his disciples, whom Jesus loved. [609]

Simon Peter therefore beckoned to him, that he should ask who it should be of whom he spake. [610]

He then lying on Jesus' breast saith unto him, Lord, who is it? [611]

Jesus answered, He it is, to whom I shall give a sop, when I have dipped it. And when he had dipped the sop, he gave it to Judas Iscariot, the son of Simon. [612]

And after the sop Satan entered into him. Then said Jesus unto him, That thou doest, do quickly. [613]

Now no man at the table knew for what intent he spake this unto him. [614]

For some of them thought, because Judas had the bag, that Jesus had said unto him, Buy those things that we have need of against the feast; or, that he should give something to the poor. [615]

He then having received the sop went immediately out: and it was night. [616]

Therefore, when he was gone out, Jesus said, Now is the Son of man glorified, and God is glorified in him. [617]

If God be glorified in him, God shall also glorify him in himself, and shall straightway glorify him. [618]

Little children, yet a little while I am with you. Ye shall seek me: and as I said unto the Jews, Whither I go, ye cannot come; so now I say to you. [619]

A new commandment I give unto you, That ye love one another; as I have loved you, that ye also love one another. [620]

By this shall all men know that ye are my disciples, if ye have love one to another. [621]

Simon Peter said unto him, Lord, whither goest thou? Jesus answered him, Whither I go, thou canst not follow me now; but thou shalt follow me afterwards. [622]

Peter said unto him, Lord, why cannot I follow thee now? I will lay down my life for thy sake. [623]

Jesus answered him, Wilt thou lay down thy life for my sake? Verily, verily, I say unto thee, The cock shall not crow, till thou hast denied me thrice. [624]

§ John 14

Let not your heart be troubled: ye believe in God, believe also in me. [625]

In my Father's house are many mansions: if it were not so, I would have told you. I go to prepare a place for you. [626]

And if I go and prepare a place for you, I will come again, and receive you unto myself; that where I am, there ye may be also. [627]

And whither I go ye know, and the way ye know. [628]

Thomas saith unto him, Lord, we know not whither thou goest; and how can we know the way? [629]

Jesus saith unto him, I am the way, the truth, and the life: no man cometh unto the Father, but by me. [630]

If ye had known me, ye should have known my Father also: and from henceforth ye know him, and have seen him. [631]

Philip saith unto him, Lord, shew us the Father, and it sufficeth us. [632]

Jesus saith unto him, Have I been so long time with you, and yet hast thou not known me, Philip? he that hath seen me hath seen the Father; and how sayest thou then, Shew us the Father? [633]

Believest thou not that I am in the Father, and the Father in me? the words that I speak unto you I speak not of myself: but the Father that dwelleth in me, he doeth the works. [634]

Believe me that I am in the Father, and the Father in me: or else believe me for the very works' sake. [635]

Verily, verily, I say unto you, He that believeth on me, the works that I do shall he do also; and greater works than these shall he do; because I go unto my Father. [636]

And whatsoever ye shall ask in my name, that will I do, that the Father may be glorified in the Son. [637]

If ye shall ask any thing in my name, I will do it. [638]

If ye love me, keep my commandments. [639]

And I will pray the Father, and he shall give you another Comforter, that he may abide with you for ever; [640]

Even the Spirit of truth; whom the world cannot receive, because it seeth him not, neither knoweth him: but ye know him; for he dwelleth with you, and shall be in you. [641]

I will not leave you comfortless: I will come to you. [642]

Yet a little while, and the world seeth me no more; but ye see me: because I live, ye shall live also. [643]

At that day ye shall know that I am in my Father, and ye in me, and I in you. [644]

He that hath my commandments, and keepeth them, he it is that loveth me: and he that loveth me shall be loved of my Father, and I will love him, and will manifest myself to him. [645]

Judas saith unto him, not Iscariot, Lord, how is it that thou wilt manifest thyself unto us, and not unto the world? [646]

Jesus answered and said unto him, If a man love me, he will keep my words: and my Father will love him, and we will come unto him, and make our abode with him. [647]

He that loveth me not keepeth not my sayings: and the word which ye hear is not mine, but the Father's which sent me. [648]

These things have I spoken unto you, being yet present with you. [649]

But the Comforter, which is the Holy Ghost, whom the Father will send in my name, he shall teach you all things, and bring all things to your remembrance, whatsoever I have said unto you. [650]

Peace I leave with you, my peace I give unto you: not as the world giveth, give I unto you. Let not your heart be troubled, neither let it be afraid. [651]

Ye have heard how I said unto you, I go away, and come again unto you. If ye loved me, ye would rejoice, because I said, I go unto the Father: for my Father is greater than I. [652]

And now I have told you before it come to pass, that, when it is come to pass, ye might believe. [653]

Hereafter I will not talk much with you: for the prince of this world cometh, and hath nothing in me. [654]

But that the world may know that I love the Father; and as the Father gave me commandment, even so I do. Arise, let us go hence. [655]

§ John 15

I am the true vine, and my Father is the husbandman. [656]

Every branch in me that beareth not fruit he taketh away: and every branch that beareth fruit, he purgeth it, that it may bring forth more fruit. [657]

Now ye are clean through the word which I have spoken unto you. [658]

Abide in me, and I in you. As the branch cannot bear fruit of itself, except it abide in the vine; no more can ye, except ye abide in me. [659]

I am the vine, ye are the branches: He that abideth in me, and I in him, the same bringeth forth much fruit: for without me ye can do nothing. [660]

If a man abide not in me, he is cast forth as a branch, and is withered; and men gather them, and cast them into the fire, and they are burned. [661]

If ye abide in me, and my words abide in you, ye shall ask what ye will, and it shall be done unto you. [662]

Herein is my Father glorified, that ye bear much fruit; so shall ye be my disciples. [663]

As the Father hath loved me, so have I loved you: continue ye in my love. [664]

If ye keep my commandments, ye shall abide in my love; even as I have kept my Father's commandments, and abide in his love. [665]

These things have I spoken unto you, that my joy might remain in you, and that your joy might be full. [666]

This is my commandment, That ye love one another, as I have loved you. [667]

Greater love hath no man than this, that a man lay down his life for his friends. [668]

Ye are my friends, if ye do whatsoever I command you. [669]

Henceforth I call you not servants; for the servant knoweth not what his lord doeth: but I have called you friends; for all things that I have heard of my Father I have made known unto you. [670]

Ye have not chosen me, but I have chosen you, and ordained you, that ye should go and bring forth fruit, and that your fruit should remain: that whatsoever ye shall ask of the Father in my name, he may give it you. [671]

These things I command you, that ye love one another. [672]

If the world hate you, ye know that it hated me before it hated you. [673]

If ye were of the world, the world would love his own: but because ye are not of the world, but I have chosen you out of the world, therefore the world hateth you. [674]

Remember the word that I said unto you, The servant is not greater than his lord. If they have persecuted me, they will also persecute you; if they have kept my saying, they will keep yours also. [675]

But all these things will they do unto you for my name's sake, because they know not him that sent me. [676]

If I had not come and spoken unto them, they had not had sin: but now they have no cloak for their sin. [677]

He that hateth me hateth my Father also. [678]

If I had not done among them the works which none other man did, they had not had sin: but now have they both seen and hated both me and my Father. [679]

But this cometh to pass, that the word might be fulfilled that is written in their law, They hated me without a cause. [680]

But when the Comforter is come, whom I will send unto you from the Father, even the Spirit of truth, which proceedeth from the Father, he shall testify of me: [681]

And ye also shall bear witness, because ye have been with me from the beginning. [682]

§ John 16

These things have I spoken unto you, that ye should not be offended. [683]

They shall put you out of the synagogues: yea, the time cometh, that whosoever killeth you will think that he doeth God service. [684]

And these things will they do unto you, because they have not known the Father, nor me. [685]

But these things have I told you, that when the time shall come, ye may remember that I told you of them. And these things I said not unto you at the beginning, because I was with you. [686]

But now I go my way to him that sent me; and none of you asketh me, Whither goest thou? [687]

But because I have said these things unto you, sorrow hath filled your heart. [688]

Nevertheless I tell you the truth; It is expedient for you that I go away: for if I go not away, the Comforter will not come unto you; but if I depart, I will send him unto you. [689]

And when he is come, he will reprove the world of sin, and of righteousness, and of judgment: [690]

Of sin, because they believe not on me; [691]

Of righteousness, because I go to my Father, and ye see me no more; [692]

Of judgment, because the prince of this world is judged. [693]

I have yet many things to say unto you, but ye cannot bear them now. [694]

Howbeit when he, the Spirit of truth, is come, he will guide you into all truth: for he shall not speak of himself; but whatsoever he shall hear, that shall he speak: and he will shew you things to come. [695]

He shall glorify me: for he shall receive of mine, and shall shew it unto you. [696]

All things that the Father hath are mine: therefore said I, that he shall take of mine, and shall shew it unto you. [697]

A little while, and ye shall not see me: and again, a little while, and ye shall see me, because I go to the Father. [698]

Then said some of his disciples among themselves, What is this that he saith unto us, A little while, and ye shall not see me: and again, a little while, and ye shall see me: and, Because I go to the Father? [699]

They said therefore, What is this that he saith, A little while? we cannot tell what he saith. [700]

Now Jesus knew that they were desirous to ask him, and said unto them, Do ye enquire among yourselves of that I said, A little while, and ye shall not see me: and again, a little while, and ye shall see me? [701]

Verily, verily, I say unto you, That ye shall weep and lament, but the world shall rejoice: and ye shall be sorrowful, but your sorrow shall be turned into joy. [702]

A woman when she is in travail hath sorrow, because her hour is come: but as soon as she is delivered of the child, she remembereth no more the anguish, for joy that a man is born into the world. [703]

And ye now therefore have sorrow: but I will see you again, and your heart shall rejoice, and your joy no man taketh from you. [704]

And in that day ye shall ask me nothing. Verily, verily, I say unto you, Whatsoever ye shall ask the Father in my name, he will give it you. [705]

Hitherto have ye asked nothing in my name: ask, and ye shall receive, that your joy may be full. [706]

These things have I spoken unto you in proverbs: but the time cometh, when I shall no more speak unto you in proverbs, but I shall shew you plainly of the Father. [707]

At that day ye shall ask in my name: and I say not unto you, that I will pray the Father for you: [708]

For the Father himself loveth you, because ye have loved me, and have believed that I came out from God. [709]

I came forth from the Father, and am come into the world: again, I leave the world, and go to the Father. [710]

His disciples said unto him, Lo, now speakest thou plainly, and speakest no proverb. [711]

Now are we sure that thou knowest all things, and needest not that any man should ask thee: by this we believe that thou camest forth from God. [712]

Jesus answered them, Do ye now believe? [713]

Behold, the hour cometh, yea, is now come, that ye shall be scattered, every man to his own, and shall leave me alone: and yet I am not alone, because the Father is with me. [714]

These things I have spoken unto you, that in me ye might have peace. In the world ye shall have tribulation: but be of good cheer; I have overcome the world. [715]

§ John 17

These words spake Jesus, and lifted up his eyes to heaven, and said, Father, the hour is come; glorify thy Son, that thy Son also may glorify thee: [716]

As thou hast given him power over all flesh, that he should give eternal life to as many as thou hast given him. [717]

And this is life eternal, that they might know thee the only true God, and Jesus Christ, whom thou hast sent. [718]

I have glorified thee on the earth: I have finished the work which thou gavest me to do. [719]

And now, O Father, glorify thou me with thine own self with the glory which I had with thee before the world was. [720]

I have manifested thy name unto the men which thou gavest me out of the world: thine they were, and thou gavest them me; and they have kept thy word. [721]

Now they have known that all things whatsoever thou hast given me are of thee. [722]

For I have given unto them the words which thou gavest me; and they have received them, and have known surely that I came out from thee, and they have believed that thou didst send me. [723]

I pray for them: I pray not for the world, but for them which thou hast given me; for they are thine. [724]

And all mine are thine, and thine are mine; and I am glorified in them. [725]

And now I am no more in the world, but these are in the world, and I come to thee. Holy Father, keep through thine own name those whom thou hast given me, that they may be one, as we are. [726]

While I was with them in the world, I kept them in thy name: those that thou gavest me I have kept, and none of them is lost, but the son of perdition; that the scripture might be fulfilled. [727]

And now come I to thee; and these things I speak in the world, that they might have my joy fulfilled in themselves. [728]

I have given them thy word; and the world hath hated them, because they are not of the world, even as I am not of the world. [729]

I pray not that thou shouldest take them out of the world, but that thou shouldest keep them from the evil. [730]

They are not of the world, even as I am not of the world. [731]

Sanctify them through thy truth: thy word is truth. [732]

As thou hast sent me into the world, even so have I also sent them into the world. [733]

And for their sakes I sanctify myself, that they also might be sanctified through the truth. [734]

Neither pray I for these alone, but for them also which shall believe on me through their word; [735]

That they all may be one; as thou, Father, art in me, and I in thee, that they also may be one in us: that the world may believe that thou hast sent me. [736]

And the glory which thou gavest me I have given them; that they may be one, even as we are one: [737]

I in them, and thou in me, that they may be made perfect in one; and that the world may know that thou hast sent me, and hast loved them, as thou hast loved me. [738]

Father, I will that they also, whom thou hast given me, be with me where I am; that they may behold my glory, which thou hast given me: for thou lovedst me before the foundation of the world. [739]

O righteous Father, the world hath not known thee: but I have known thee, and these have known that thou hast sent me. [740]

And I have declared unto them thy name, and will declare it: that the love wherewith thou hast loved me may be in them, and I in them. [741]

§ John 18

When Jesus had spoken these words, he went forth with his disciples over the brook Cedron, where was a garden, into the which he entered, and his disciples. [742]

And Judas also, which betrayed him, knew the place: for Jesus ofttimes resorted thither with his disciples. [743]

Judas then, having received a band of men and officers from the chief priests and Pharisees, cometh thither with lanterns and torches and weapons. [744]

Jesus therefore, knowing all things that should come upon him, went forth, and said unto them, Whom seek ye? [745]

They answered him, Jesus of Nazareth. Jesus saith unto them, I am he. And Judas also, which betrayed him, stood with them. [746]

As soon then as he had said unto them, I am he, they went backward, and fell to the ground. [747]

Then asked he them again, Whom seek ye? And they said, Jesus of Nazareth. [748]

Jesus answered, I have told you that I am he: if therefore ye seek me, let these go their way: [749]

That the saying might be fulfilled, which he spake, Of them which thou gavest me have I lost none. [750]

Then Simon Peter having a sword drew it, and smote the high priest's servant, and cut off his right ear. The servant's name was Malchus. [751]

Then said Jesus unto Peter, Put up thy sword into the sheath: the cup which my Father hath given me, shall I not drink it? [752]

Then the band and the captain and officers of the Jews took Jesus, and bound him, [753]

And led him away to Annas first; for he was father in law to Caiaphas, which was the high priest that same year. [754]

Now Caiaphas was he, which gave counsel to the Jews, that it was expedient that one man should die for the people. [755]

And Simon Peter followed Jesus, and so did another disciple: that disciple was known unto the high priest, and went in with Jesus into the palace of the high priest. [756]

But Peter stood at the door without. Then went out that other disciple, which was known unto the high priest, and spake unto her that kept the door, and brought in Peter. [757]

Then saith the damsel that kept the door unto Peter, Art not thou also one of this man's disciples? He saith, I am not. [758]

And the servants and officers stood there, who had made a fire of coals; for it was cold: and they warmed themselves: and Peter stood with them, and warmed himself. [759]

The high priest then asked Jesus of his disciples, and of his doctrine. [760]

Jesus answered him, I spake openly to the world; I ever taught in the synagogue, and in the temple, whither the Jews always resort; and in secret have I said nothing. [761]

Why askest thou me? ask them which heard me, what I have said unto them: behold, they know what I said. [762]

And when he had thus spoken, one of the officers which stood by struck Jesus with the palm of his hand, saying, Answerest thou the high priest so? [763]

Jesus answered him, If I have spoken evil, bear witness of the evil: but if well, why smitest thou me? [764]

Now Annas had sent him bound unto Caiaphas the high priest. [765]

And Simon Peter stood and warmed himself. They said therefore unto him, Art not thou also one of his disciples? He denied it, and said, I am not. [766]

One of the servants of the high priest, being his kinsman whose ear Peter cut off, saith, Did not I see thee in the garden with him? [767]

Peter then denied again: and immediately the cock crew. [768]

Then led they Jesus from Caiaphas unto the hall of judgment: and it was early; and they themselves went not into the judgment hall, lest they should be defiled; but that they might eat the passover. [769]

Pilate then went out unto them, and said, What accusation bring ye against this man? [770]

They answered and said unto him, If he were not a malefactor, we would not have delivered him up unto thee. [771]

Then said Pilate unto them, Take ye him, and judge him according to your law. The Jews therefore said unto him, It is not lawful for us to put any man to death: [772]

That the saying of Jesus might be fulfilled, which he spake, signifying what death he should die. [773]

Then Pilate entered into the judgment hall again, and called Jesus, and said unto him, Art thou the King of the Jews? [774]

Jesus answered him, Sayest thou this thing of thyself, or did others tell it thee of me? [775]

Pilate answered, Am I a Jew? Thine own nation and the chief priests have delivered thee unto me: what hast thou done? [776]

Jesus answered, My kingdom is not of this world: if my kingdom were of this world, then would my servants fight, that I should not be delivered to the Jews: but now is my kingdom not from hence. [777]

Pilate therefore said unto him, Art thou a king then? Jesus answered, Thou sayest that I am a king. To this end was I born, and for this cause came I into the world, that I should bear witness unto the truth. Every one that is of the truth heareth my voice. [778]

Pilate saith unto him, What is truth? And when he had said this, he went out again unto the Jews, and saith unto them, I find in him no fault at all. [779]

But ye have a custom, that I should release unto you one at the passover: will ye therefore that I release unto you the King of the Jews? [780]

Then cried they all again, saying, Not this man, but Barabbas. Now Barabbas was a robber. [781]

§ John 19

Then Pilate therefore took Jesus, and scourged him. [782]

And the soldiers platted a crown of thorns, and put it on his head, and they put on him a purple robe, [783]

And said, Hail, King of the Jews! and they smote him with their hands. [784]

Pilate therefore went forth again, and saith unto them, Behold, I bring him forth to you, that ye may know that I find no fault in him. [785]

Then came Jesus forth, wearing the crown of thorns, and the purple robe. And Pilate saith unto them, Behold the man! [786]

When the chief priests therefore and officers saw him, they cried out, saying, Crucify him, crucify him. Pilate saith unto them, Take ye him, and crucify him: for I find no fault in him. [787]

The Jews answered him, We have a law, and by our law he ought to die, because he made himself the Son of God. [788]

When Pilate therefore heard that saying, he was the more afraid; [789]

And went again into the judgment hall, and saith unto Jesus, Whence art thou? But Jesus gave him no answer. [790]

Then saith Pilate unto him, Speakest thou not unto me? knowest thou not that I have power to crucify thee, and have power to release thee? [791]

Jesus answered, Thou couldest have no power at all against me, except it were given thee from above: therefore he that delivered me unto thee hath the greater sin. [792]

And from thenceforth Pilate sought to release him: but the Jews cried out, saying, If thou let this man go, thou art not Caesar's friend: whosoever maketh himself a king speaketh against Caesar. [793]

When Pilate therefore heard that saying, he brought Jesus forth, and sat down in the judgment seat in a place that is called the Pavement, but in the Hebrew, Gabbatha. [794]

And it was the preparation of the passover, and about the sixth hour: and he saith unto the Jews, Behold your King! [795]

But they cried out, Away with him, away with him, crucify him. Pilate saith unto them, Shall I crucify your King? The chief priests answered, We have no king but Caesar. [796]

Then delivered he him therefore unto them to be crucified. And they took Jesus, and led him away. [797]

And he bearing his cross went forth into a place called the place of a skull, which is called in the Hebrew Golgotha: [798]

Where they crucified him, and two other with him, on either side one, and Jesus in the midst. [799]

And Pilate wrote a title, and put it on the cross. And the writing was JESUS OF NAZARETH THE KING OF THE JEWS. [800]

This title then read many of the Jews: for the place where Jesus was crucified was nigh to the city: and it was written in Hebrew, and Greek, and Latin. [801]

Then said the chief priests of the Jews to Pilate, Write not, The King of the Jews; but that he said, I am King of the Jews. [802]

Pilate answered, What I have written I have written. [803]

Then the soldiers, when they had crucified Jesus, took his garments, and made four parts, to every soldier a part; and also his coat: now the coat was without seam, woven from the top throughout. [804]

They said therefore among themselves, Let us not rend it, but cast lots for it, whose it shall be: that the scripture might be fulfilled, which saith, They parted my raiment among them, and for my vesture they did cast lots. These things therefore the soldiers did. [805]

Now there stood by the cross of Jesus his mother, and his mother's sister, Mary the wife of Cleophas, and Mary Magdalene. [806]

When Jesus therefore saw his mother, and the disciple standing by, whom he loved, he saith unto his mother, Woman, behold thy son! [807]

Then saith he to the disciple, Behold thy mother! And from that hour that disciple took her unto his own home. [808]

After this, Jesus knowing that all things were now accomplished, that the scripture might be fulfilled, saith, I thirst. [809]

Now there was set a vessel full of vinegar: and they filled a spunge with vinegar, and put it upon hyssop, and put it to his mouth. [810]

When Jesus therefore had received the vinegar, he said, It is finished: and he bowed his head, and gave up the ghost. [811]

The Jews therefore, because it was the preparation, that the bodies should not remain upon the cross on the sabbath day, (for that sabbath day was an high day,) besought Pilate that their legs might be broken, and that they might be taken away. [812]

Then came the soldiers, and brake the legs of the first, and of the other which was crucified with him. [813]

But when they came to Jesus, and saw that he was dead already, they brake not his legs: [814]

But one of the soldiers with a spear pierced his side, and forthwith came there out blood and water. [815]

And he that saw it bare record, and his record is true: and he knoweth that he saith true, that ye might believe. [816]

For these things were done, that the scripture should be fulfilled, A bone of him shall not be broken. [817]

And again another scripture saith, They shall look on him whom they pierced. [818]

And after this Joseph of Arimathaea, being a disciple of Jesus, but secretly for fear of the Jews, besought Pilate that he might take away the body of Jesus: and Pilate gave him leave. He came therefore, and took the body of Jesus. [819]

And there came also Nicodemus, which at the first came to Jesus by night, and brought a mixture of myrrh and aloes, about an hundred pound weight. [820]

Then took they the body of Jesus, and wound it in linen clothes with the spices, as the manner of the Jews is to bury. [821]

Now in the place where he was crucified there was a garden; and in the garden a new sepulchre, wherein was never man yet laid. [822]

There laid they Jesus therefore because of the Jews' preparation day; for the sepulchre was nigh at hand. [823]

§ John 20

The first day of the week cometh Mary Magdalene early, when it was yet dark, unto the sepulchre, and seeth the stone taken away from the sepulchre. [824]

Then she runneth, and cometh to Simon Peter, and to the other disciple, whom Jesus loved, and saith unto them, They have taken away the LORD out of the sepulchre, and we know not where they have laid him. [825]

Peter therefore went forth, and that other disciple, and came to the sepulchre. [826]

So they ran both together: and the other disciple did outrun Peter, and came first to the sepulchre. [827]

And he stooping down, and looking in, saw the linen clothes lying; yet went he not in. [828]

Then cometh Simon Peter following him, and went into the sepulchre, and seeth the linen clothes lie, [829]

And the napkin, that was about his head, not lying with the linen clothes, but wrapped together in a place by itself. [830]

Then went in also that other disciple, which came first to the sepulchre, and he saw, and believed. [831]

For as yet they knew not the scripture, that he must rise again from the dead. [832]

Then the disciples went away again unto their own home. [833]

But Mary stood without at the sepulchre weeping: and as she wept, she stooped down, and looked into the sepulchre, [834]

And seeth two angels in white sitting, the one at the head, and the other at the feet, where the body of Jesus had lain. [835]

And they say unto her, Woman, why weepest thou? She saith unto them, Because they have taken away my LORD, and I know not where they have laid him. [836]

And when she had thus said, she turned herself back, and saw Jesus standing, and knew not that it was Jesus. [837]

Jesus saith unto her, Woman, why weepest thou? whom seekest thou? She, supposing him to be the gardener, saith unto him, Sir, if thou have borne him hence, tell me where thou hast laid him, and I will take him away. [838]

Jesus saith unto her, Mary. She turned herself, and saith unto him, Rabboni; which is to say, Master. [839]

Jesus saith unto her, Touch me not; for I am not yet ascended to my Father: but go to my brethren, and say unto them, I ascend unto my Father, and your Father; and to my God, and your God. [840]

Mary Magdalene came and told the disciples that she had seen the LORD, and that he had spoken these things unto her. [841]

Then the same day at evening, being the first day of the week, when the doors were shut where the disciples were assembled for fear of the Jews, came Jesus and stood in the midst, and saith unto them, Peace be unto you. [842]

And when he had so said, he shewed unto them his hands and his side. Then were the disciples glad, when they saw the LORD. [843]

Then said Jesus to them again, Peace be unto you: as my Father hath sent me, even so send I you. [844]

And when he had said this, he breathed on them, and saith unto them, Receive ye the Holy Ghost: [845]

Whose soever sins ye remit, they are remitted unto them; and whose soever sins ye retain, they are retained. [846]

But Thomas, one of the twelve, called Didymus, was not with them when Jesus came. [847]

The other disciples therefore said unto him, We have seen the LORD. But he said unto them, Except I shall see in his hands the print of the nails, and put my finger into the print of the nails, and thrust my hand into his side, I will not believe. [848]

And after eight days again his disciples were within, and Thomas with them: then came Jesus, the doors being shut, and stood in the midst, and said, Peace be unto you. [849]

Then saith he to Thomas, Reach hither thy finger, and behold my hands; and reach hither thy hand, and thrust it into my side: and be not faithless, but believing. [850]

And Thomas answered and said unto him, My LORD and my God. [851]

Jesus saith unto him, Thomas, because thou hast seen me, thou hast believed: blessed are they that have not seen, and yet have believed. [852]

And many other signs truly did Jesus in the presence of his disciples, which are not written in this book: [853]

But these are written, that ye might believe that Jesus is the Christ, the Son of God; and that believing ye might have life through his name. [854]

§ John 21

After these things Jesus shewed himself again to the disciples at the sea of Tiberias; and on this wise shewed he himself. [855]

There were together Simon Peter, and Thomas called Didymus, and Nathanael of Cana in Galilee, and the sons of Zebedee, and two other of his disciples. [856]

Simon Peter saith unto them, I go a fishing. They say unto him, We also go with thee. They went forth, and entered into a ship immediately; and that night they caught nothing. [857]

But when the morning was now come, Jesus stood on the shore: but the disciples knew not that it was Jesus. [858]

Then Jesus saith unto them, Children, have ye any meat? They answered him, No. [859]

And he said unto them, Cast the net on the right side of the ship, and ye shall find. They cast therefore, and now they were not able to draw it for the multitude of fishes. [860]

Therefore that disciple whom Jesus loved saith unto Peter, It is the Lord. Now when Simon Peter heard that it was the Lord, he girt his fisher's coat unto him, (for he was naked,) and did cast himself into the sea. [861]

And the other disciples came in a little ship; (for they were not far from land, but as it were two hundred cubits,) dragging the net with fishes. [862]

As soon then as they were come to land, they saw a fire of coals there, and fish laid thereon, and bread. [863]

Jesus saith unto them, Bring of the fish which ye have now caught. [864]

Simon Peter went up, and drew the net to land full of great fishes, an hundred and fifty and three: and for all there were so many, yet was not the net broken. [865]

Jesus saith unto them, Come and dine. And none of the disciples durst ask him, Who art thou? knowing that it was the Lord. [866]

Jesus then cometh, and taketh bread, and giveth them, and fish likewise. [867]

This is now the third time that Jesus shewed himself to his disciples, after that he was risen from the dead. [868]

So when they had dined, Jesus saith to Simon Peter, Simon, son of Jonas, lovest thou me more than these? He saith unto him, Yea, Lord; thou knowest that I love thee. He saith unto him, Feed my lambs. [869]

He saith to him again the second time, Simon, son of Jonas, lovest thou me? He saith unto him, Yea, Lord; thou knowest that I love thee. He saith unto him, Feed my sheep. [870]

He saith unto him the third time, Simon, son of Jonas, lovest thou me? Peter was grieved because he said unto him the third time, Lovest thou me? And he said unto him, Lord, thou knowest all things; thou knowest that I love thee. Jesus saith unto him, Feed my sheep. [871]

Verily, verily, I say unto thee, When thou wast young, thou girdest thyself, and walkedst whither thou wouldest: but when thou shalt be old, thou shalt stretch forth thy hands, and another shall gird thee, and carry thee whither thou wouldest not. [872]

This spake he, signifying by what death he should glorify God. And when he had spoken this, he saith unto him, Follow me. [873]

Then Peter, turning about, seeth the disciple whom Jesus loved following; which also leaned on his breast at supper, and said, Lord, which is he that betrayeth thee? [874]

Peter seeing him saith to Jesus, Lord, and what shall this man do? [875]

Jesus saith unto him, If I will that he tarry till I come, what is that to thee? follow thou me. [876]

Then went this saying abroad among the brethren, that that disciple should not die: yet Jesus said not unto him, He shall not die; but, If I will that he tarry till I come, what is that to thee? [877]

This is the disciple which testifieth of these things, and wrote these things: and we know that his testimony is true. [878]

And there are also many other things which Jesus did, the which, if they should be written every one, I suppose that even the world itself could not contain the books that should be written. Amen. [879]

=== citations ===
[1] John 1:1 (KJV) | | 1
[2] John 1:2 (KJV) | | 1
[3] John 1:3 (KJV) | | 1
[4] John 1:4 (KJV) | | 1
[5] John 1:5 (KJV) | | 1
[6] John 1:6 (KJV) | | 1
[7] John 1:7 (KJV) | | 1
[8] John 1:8 (KJV) | | 1
[9] John 1:9 (KJV) | | 1
[10] John 1:10 (KJV) | | 1
[11] John 1:11 (KJV) | | 1
[12] John 1:12 (KJV) | | 1
[13] John 1:13 (KJV) | | 1
[14] John 1:14 (KJV) | | 1
[15] John 1:15 (KJV) | | 1
[16] John 1:16 (KJV) | | 1
[17] John 1:17 (KJV) | | 1
[18] John 1:18 (KJV) | | 1
[19] John 1:19 (KJV) | | 1
[20] John 1:20 (KJV) | | 1
[21] John 1:21 (KJV) | | 1
[22] John 1:22 (KJV) | | 1
[23] John 1:23 (KJV) | | 1
[24] John 1:24 (KJV) | | 1
[25] John 1:25 (KJV) | | 1
[26] John 1:26 (KJV) | | 1
[27] John 1:27 (KJV) | | 1
[28] John 1:28 (KJV) | | 1
[29] John 1:29 (KJV) | | 1
[30] John 1:30 (KJV) | | 1
[31] John 1:31 (KJV) | | 1
[32] John 1:32 (KJV) | | 1
[33] John 1:33 (KJV) | | 1
[34] John 1:34 (KJV) | | 1
[35] John 1:35 (KJV) | | 1
[36] John 1:36 (KJV) | | 1
[37] John 1:37 (KJV) | | 1
[38] John 1:38 (KJV) | | 1
[39] John 1:39 (KJV) | | 1
[40] John 1:40 (KJV) | | 1
[41] John 1:41 (KJV) | | 1
[42] John 1:42 (KJV) | | 1
[43] John 1:43 (KJV) | | 1
[44] John 1:44 (KJV) | | 1
[45] John 1:45 (KJV) | | 1
[46] John 1:46 (KJV) | | 1
[47] John 1:47 (KJV) | | 1
[48] John 1:48 (KJV) | | 1
[49] John 1:49 (KJV) | | 1
[50] John 1:50 (KJV) | | 1
[51] John 1:51 (KJV) | | 1
[52] John 2:1 (KJV) | | 1
[53] John 2:2 (KJV) | | 1
[54] John 2:3 (KJV) | | 1
[55] John 2:4 (KJV) | | 1
[56] John 2:5 (KJV) | | 1
[57] John 2:6 (KJV) | | 1
[58] John 2:7 (KJV) | | 1
[59] John 2:8 (KJV) | | 1
[60] John 2:9 (KJV) | | 1
[61] John 2:10 (KJV) | | 1
[62] John 2:11 (KJV) | | 1
[63] John 2:12 (KJV) | | 1
[64] John 2:13 (KJV) | | 1
[65] John 2:14 (KJV) | | 1
[66] John 2:15 (KJV) | | 1
[67] John 2:16 (KJV) | | 1
[68] John 2:17 (KJV) | | 1
[69] John 2:18 (KJV) | | 1
[70] John 2:19 (KJV) | | 1
[71] John 2:20 (KJV) | | 1
[72] John 2:21 (KJV) | | 1
[73] John 2:22 (KJV) | | 1
[74] John 2:23 (KJV) | | 1
[75] John 2:24 (KJV) | | 1
[76] John 2:25 (KJV) | | 1
[77] John 3:1 (KJV) | | 1
[78] John 3:2 (KJV) | | 1
[79] John 3:3 (KJV) | | 1
[80] John 3:4 (KJV) | | 1
[81] John 3:5 (KJV) | | 1
[82] John 3:6 (KJV) | | 1
[83] John 3:7 (KJV) | | 1
[84] John 3:8 (KJV) | | 1
[85] John 3:9 (KJV) | | 1
[86] John 3:10 (KJV) | | 1
[87] John 3:11 (KJV) | | 1
[88] John 3:12 (KJV) | | 1
[89] John 3:13 (KJV) | | 1
[90] John 3:14 (KJV) | | 1
[91] John 3:15 (KJV) | | 1
[92] John 3:16 (KJV) | | 1
[93] John 3:17 (KJV) | | 1
[94] John 3:18 (KJV) | | 1
[95] John 3:19 (KJV) | | 1
[96] John 3:20 (KJV) | | 1
[97] John 3:21 (KJV) | | 1
[98] John 3:22 (KJV) | | 1
[99] John 3:23 (KJV) | | 1
[100] John 3:24 (KJV) | | 1
[101] John 3:25 (KJV) | | 1
[102] John 3:26 (KJV) | | 1
[103] John 3:27 (KJV) | | 1
[104] John 3:28 (KJV) | | 1
[105] John 3:29 (KJV) | | 1
[106] John 3:30 (KJV) | | 1
[107] John 3:31 (KJV) | | 1
[108] John 3:32 (KJV) | | 1
[109] John 3:33 (KJV) | | 1
[110] John 3:34 (KJV) | | 1
[111] John 3:35 (KJV) | | 1
[112] John 3:36 (KJV) | | 1
[113] John 4:1 (KJV) | | 1
[114] John 4:2 (KJV) | | 1
[115] John 4:3 (KJV) | | 1
[116] John 4:4 (KJV) | | 1
[117] John 4:5 (KJV) | | 1
[118] John 4:6 (KJV) | | 1
[119] John 4:7 (KJV) | | 1
[120] John 4:8 (KJV) | | 1
[121] John 4:9 (KJV) | | 1
[122] John 4:10 (KJV) | | 1
[123] John 4:11 (KJV) | | 1
[124] John 4:12 (KJV) | | 1
[125] John 4:13 (KJV) | | 1
[126] John 4:14 (KJV) | | 1
[127] John 4:15 (KJV) | | 1
[128] John 4:16 (KJV) | | 1
[129] John 4:17 (KJV) | | 1
[130] John 4:18 (KJV) | | 1
[131] John 4:19 (KJV) | | 1
[132] John 4:20 (KJV) | | 1
[133] John 4:21 (KJV) | | 1
[134] John 4:22 (KJV) | | 1
[135] John 4:23 (KJV) | | 1
[136] John 4:24 (KJV) | | 1
[137] John 4:25 (KJV) | | 1
[138] John 4:26 (KJV) | | 1
[139] John 4:27 (KJV) | | 1
[140] John 4:28 (KJV) | | 1
[141] John 4:29 (KJV) | | 1
[142] John 4:30 (KJV) | | 1
[143] John 4:31 (KJV) | | 1
[144] John 4:32 (KJV) | | 1
[145] John 4:33 (KJV) | | 1
[146] John 4:34 (KJV) | | 1
[147] John 4:35 (KJV) | | 1
[148] John 4:36 (KJV) | | 1
[149] John 4:37 (KJV) | | 1
[150] John 4:38 (KJV) | | 1
[151] John 4:39 (KJV) | | 1
[152] John 4:40 (KJV) | | 1
[153] John 4:41 (KJV) | | 1
[154] John 4:42 (KJV) | | 1
[155] John 4:43 (KJV) | | 1
[156] John 4:44 (KJV) | | 1
[157] John 4:45 (KJV) | | 1
[158] John 4:46 (KJV) | | 1
[159] John 4:47 (KJV) | | 1
[160] John 4:48 (KJV) | | 1
[161] John 4:49 (KJV) | | 1
[162] John 4:50 (KJV) | | 1
[163] John 4:51 (KJV) | | 1
[164] John 4:52 (KJV) | | 1
[165] John 4:53 (KJV) | | 1
[166] John 4:54 (KJV) | | 1
[167] John 5:1 (KJV) | | 1
[168] John 5:2 (KJV) | | 1
[169] John 5:3 (KJV) | | 1
[170] John 5:4 (KJV) | | 1
[171] John 5:5 (KJV) | | 1
[172] John 5:6 (KJV) | | 1
[173] John 5:7 (KJV) | | 1
[174] John 5:8 (KJV) | | 1
[175] John 5:9 (KJV) | | 1
[176] John 5:10 (KJV) | | 1
[177] John 5:11 (KJV) | | 1
[178] John 5:12 (KJV) | | 1
[179] John 5:13 (KJV) | | 1
[180] John 5:14 (KJV) | | 1
[181] John 5:15 (KJV) | | 1
[182] John 5:16 (KJV) | | 1
[183] John 5:17 (KJV) | | 1
[184] John 5:18 (KJV) | | 1
[185] John 5:19 (KJV) | | 1
[186] John 5:20 (KJV) | | 1
[187] John 5:21 (KJV) | | 1
[188] John 5:22 (KJV) | | 1
[189] John 5:23 (KJV) | | 1
[190] John 5:24 (KJV) | | 1
[191] John 5:25 (KJV) | | 1
[192] John 5:26 (KJV) | | 1
[193] John 5:27 (KJV) | | 1
[194] John 5:28 (KJV) | | 1
[195] John 5:29 (KJV) | | 1
[196] John 5:30 (KJV) | | 1
[197] John 5:31 (KJV) | | 1
[198] John 5:32 (KJV) | | 1
[199] John 5:33 (KJV) | | 1
[200] John 5:34 (KJV) | | 1
[201] John 5:35 (KJV) | | 1
[202] John 5:36 (KJV) | | 1
[203] John 5:37 (KJV) | | 1
[204] John 5:38 (KJV) | | 1
[205] John 5:39 (KJV) | | 1
[206] John 5:40 (KJV) | | 1
[207] John 5:41 (KJV) | | 1
[208] John 5:42 (KJV) | | 1
[209] John 5:43 (KJV) | | 1
[210] John 5:44 (KJV) | | 1
[211] John 5:45 (KJV) | | 1
[212] John 5:46 (KJV) | | 1
[213] John 5:47 (KJV) | | 1
[214] John 6:1 (KJV) | | 1
[215] John 6:2 (KJV) | | 1
[216] John 6:3 (KJV) | | 1
[217] John 6:4 (KJV) | | 1
[218] John 6:5 (KJV) | | 1
[219] John 6:6 (KJV) | | 1
[220] John 6:7 (KJV) | | 1
[221] John 6:8 (KJV) | | 1
[222] John 6:9 (KJV) | | 1
[223] John 6:10 (KJV) | | 1
[224] John 6:11 (KJV) | | 1
[225] John 6:12 (KJV) | | 1
[226] John 6:13 (KJV) | | 1
[227] John 6:14 (KJV) | | 1
[228] John 6:15 (KJV) | | 1
[229] John 6:16 (KJV) | | 1
[230] John 6:17 (KJV) | | 1
[231] John 6:18 (KJV) | | 1
[232] John 6:19 (KJV) | | 1
[233] John 6:20 (KJV) | | 1
[234] John 6:21 (KJV) | | 1
[235] John 6:22 (KJV) | | 1
[236] John 6:23 (KJV) | | 1
[237] John 6:24 (KJV) | | 1
[238] John 6:25 (KJV) | | 1
[239] John 6:26 (KJV) | | 1
[240] John 6:27 (KJV) | | 1
[241] John 6:28 (KJV) | | 1
[242] John 6:29 (KJV) | | 1
[243] John 6:30 (KJV) | | 1
[244] John 6:31 (KJV) | | 1
[245] John 6:32 (KJV) | | 1
[246] John 6:33 (KJV) | | 1
[247] John 6:34 (KJV) | | 1
[248] John 6:35 (KJV) | | 1
[249] John 6:36 (KJV) | | 1
[250] John 6:37 (KJV) | | 1
[251] John 6:38 (KJV) | | 1
[252] John 6:39 (KJV) | | 1
[253] John 6:40 (KJV) | | 1
[254] John 6:41 (KJV) | | 1
[255] John 6:42 (KJV) | | 1
[256] John 6:43 (KJV) | | 1
[257] John 6:44 (KJV) | | 1
[258] John 6:45 (KJV) | | 1
[259] John 6:46 (KJV) | | 1
[260] John 6:47 (KJV) | | 1
[261] John 6:48 (KJV) | | 1
[262] John 6:49 (KJV) | | 1
[263] John 6:50 (KJV) | | 1
[264] John 6:51 (KJV) | | 1
[265] John 6:52 (KJV) | | 1
[266] John 6:53 (KJV) | | 1
[267] John 6:54 (KJV) | | 1
[268] John 6:55 (KJV) | | 1
[269] John 6:56 (KJV) | | 1
[270] John 6:57 (KJV) | | 1
[271] John 6:58 (KJV) | | 1
[272] John 6:59 (KJV) | | 1
[273] John 6:60 (KJV) | | 1
[274] John 6:61 (KJV) | | 1
[275] John 6:62 (KJV) | | 1
[276] John 6:63 (KJV) | | 1
[277] John 6:64 (KJV) | | 1
[278] John 6:65 (KJV) | | 1
[279] John 6:66 (KJV) | | 1
[280] John 6:67 (KJV) | | 1
[281] John 6:68 (KJV) | | 1
[282] John 6:69 (KJV) | | 1
[283] John 6:70 (KJV) | | 1
[284] John 6:71 (KJV) | | 1
[285] John 7:1 (KJV) | | 1
[286] John 7:2 (KJV) | | 1
[287] John 7:3 (KJV) | | 1
[288] John 7:4 (KJV) | | 1
[289] John 7:5 (KJV) | | 1
[290] John 7:6 (KJV) | | 1
[291] John 7:7 (KJV) | | 1
[292] John 7:8 (KJV) | | 1
[293] John 7:9 (KJV) | | 1
[294] John 7:10 (KJV) | | 1
[295] John 7:11 (KJV) | | 1
[296] John 7:12 (KJV) | | 1
[297] John 7:13 (KJV) | | 1
[298] John 7:14 (KJV) | | 1
[299] John 7:15 (KJV) | | 1
[300] John 7:16 (KJV) | | 1
[301] John 7:17 (KJV) | | 1
[302] John 7:18 (KJV) | | 1
[303] John 7:19 (KJV) | | 1
[304] John 7:20 (KJV) | | 1
[305] John 7:21 (KJV) | | 1
[306] John 7:22 (KJV) | | 1
[307] John 7:23 (KJV) | | 1
[308] John 7:24 (KJV) | | 1
[309] John 7:25 (KJV) | | 1
[310] John 7:26 (KJV) | | 1
[311] John 7:27 (KJV) | | 1
[312] John 7:28 (KJV) | | 1
[313] John 7:29 (KJV) | | 1
[314] John 7:30 (KJV) | | 1
[315] John 7:31 (KJV) | | 1
[316] John 7:32 (KJV) | | 1
[317] John 7:33 (KJV) | | 1
[318] John 7:34 (KJV) | | 1
[319] John 7:35 (KJV) | | 1
[320] John 7:36 (KJV) | | 1
[321] John 7:37 (KJV) | | 1
[322] John 7:38 (KJV) | | 1
[323] John 7:39 (KJV) | | 1
[324] John 7:40 (KJV) | | 1
[325] John 7:41 (KJV) | | 1
[326] John 7:42 (KJV) | | 1
[327] John 7:43 (KJV) | | 1
[328] John 7:44 (KJV) | | 1
[329] John 7:45 (KJV) | | 1
[330] John 7:46 (KJV) | | 1
[331] John 7:47 (KJV) | | 1
[332] John 7:48 (KJV) | | 1
[333] John 7:49 (KJV) | | 1
[334] John 7:50 (KJV) | | 1
[335] John 7:51 (KJV) | | 1
[336] John 7:52 (KJV) | | 1
[337] John 7:53 (KJV) | | 1
[338] John 8:1 (KJV) | | 1
[339] John 8:2 (KJV) | | 1
[340] John 8:3 (KJV) | | 1
[341] John 8:4 (KJV) | | 1
[342] John 8:5 (KJV) | | 1
[343] John 8:6 (KJV) | | 1
[344] John 8:7 (KJV) | | 1
[345] John 8:8 (KJV) | | 1
[346] John 8:9 (KJV) | | 1
[347] John 8:10 (KJV) | | 1
[348] John 8:11 (KJV) | | 1
[349] John 8:12 (KJV) | | 1
[350] John 8:13 (KJV) | | 1
[351] John 8:14 (KJV) | | 1
[352] John 8:15 (KJV) | | 1
[353] John 8:16 (KJV) | | 1
[354] John 8:17 (KJV) | | 1
[355] John 8:18 (KJV) | | 1
[356] John 8:19 (KJV) | | 1
[357] John 8:20 (KJV) | | 1
[358] John 8:21 (KJV) | | 1
[359] John 8:22 (KJV) | | 1
[360] John 8:23 (KJV) | | 1
[361] John 8:24 (KJV) | | 1
[362] John 8:25 (KJV) | | 1
[363] John 8:26 (KJV) | | 1
[364] John 8:27 (KJV) | | 1
[365] John 8:28 (KJV) | | 1
[366] John 8:29 (KJV) | | 1
[367] John 8:30 (KJV) | | 1
[368] John 8:31 (KJV) | | 1
[369] John 8:32 (KJV) | | 1
[370] John 8:33 (KJV) | | 1
[371] John 8:34 (KJV) | | 1
[372] John 8:35 (KJV) | | 1
[373] John 8:36 (KJV) | | 1
[374] John 8:37 (KJV) | | 1
[375] John 8:38 (KJV) | | 1
[376] John 8:39 (KJV) | | 1
[377] John 8:40 (KJV) | | 1
[378] John 8:41 (KJV) | | 1
[379] John 8:42 (KJV) | | 1
[380] John 8:43 (KJV) | | 1
[381] John 8:44 (KJV) | | 1
[382] John 8:45 (KJV) | | 1
[383] John 8:46 (KJV) | | 1
[384] John 8:47 (KJV) | | 1
[385] John 8:48 (KJV) | | 1
[386] John 8:49 (KJV) | | 1
[387] John 8:50 (KJV) | | 1
[388] John 8:51 (KJV) | | 1
[389] John 8:52 (KJV) | | 1
[390] John 8:53 (KJV) | | 1
[391] John 8:54 (KJV) | | 1
[392] John 8:55 (KJV) | | 1
[393] John 8:56 (KJV) | | 1
[394] John 8:57 (KJV) | | 1
[395] John 8:58 (KJV) | | 1
[396] John 8:59 (KJV) | | 1
[397] John 9:1 (KJV) | | 1
[398] John 9:2 (KJV) | | 1
[399] John 9:3 (KJV) | | 1
[400] John 9:4 (KJV) | | 1
[401] John 9:5 (KJV) | | 1
[402] John 9:6 (KJV) | | 1
[403] John 9:7 (KJV) | | 1
[404] John 9:8 (KJV) | | 1
[405] John 9:9 (KJV) | | 1
[406] John 9:10 (KJV) | | 1
[407] John 9:11 (KJV) | | 1
[408] John 9:12 (KJV) | | 1
[409] John 9:13 (KJV) | | 1
[410] John 9:14 (KJV) | | 1
[411] John 9:15 (KJV) | | 1
[412] John 9:16 (KJV) | | 1
[413] John 9:17 (KJV) | | 1
[414] John 9:18 (KJV) | | 1
[415] John 9:19 (KJV) | | 1
[416] John 9:20 (KJV) | | 1
[417] John 9:21 (KJV) | | 1
[418] John 9:22 (KJV) | | 1
[419] John 9:23 (KJV) | | 1
[420] John 9:24 (KJV) | | 1
[421] John 9:25 (KJV) | | 1
[422] John 9:26 (KJV) | | 1
[423] John 9:27 (KJV) | | 1
[424] John 9:28 (KJV) | | 1
[425] John 9:29 (KJV) | | 1
[426] John 9:30 (KJV) | | 1
[427] John 9:31 (KJV) | | 1
[428] John 9:32 (KJV) | | 1
[429] John 9:33 (KJV) | | 1
[430] John 9:34 (KJV) | | 1
[431] John 9:35 (KJV) | | 1
[432] John 9:36 (KJV) | | 1
[433] John 9:37 (KJV) | | 1
[434] John 9:38 (KJV) | | 1
[435] John 9:39 (KJV) | | 1
[436] John 9:40 (KJV) | | 1
[437] John 9:41 (KJV) | | 1
[438] John 10:1 (KJV) | | 1
[439] John 10:2 (KJV) | | 1
[440] John 10:3 (KJV) | | 1
[441] John 10:4 (KJV) | | 1
[442] John 10:5 (KJV) | | 1
[443] John 10:6 (KJV) | | 1
[444] John 10:7 (KJV) | | 1
[445] John 10:8 (KJV) | | 1
[446] John 10:9 (KJV) | | 1
[447] John 10:10 (KJV) | | 1
[448] John 10:11 (KJV) | | 1
[449] John 10:12 (KJV) | | 1
[450] John 10:13 (KJV) | | 1
[451] John 10:14 (KJV) | | 1
[452] John 10:15 (KJV) | | 1
[453] John 10:16 (KJV) | | 1
[454] John 10:17 (KJV) | | 1
[455] John 10:18 (KJV) | | 1
[456] John 10:19 (KJV) | | 1
[457] John 10:20 (KJV) | | 1
[458] John 10:21 (KJV) | | 1
[459] John 10:22 (KJV) | | 1
[460] John 10:23 (KJV) | | 1
[461] John 10:24 (KJV) | | 1
[462] John 10:25 (KJV) | | 1
[463] John 10:26 (KJV) | | 1
[464] John 10:27 (KJV) | | 1
[465] John 10:28 (KJV) | | 1
[466] John 10:29 (KJV) | | 1
[467] John 10:30 (KJV) | | 1
[468] John 10:31 (KJV) | | 1
[469] John 10:32 (KJV) | | 1
[470] John 10:33 (KJV) | | 1
[471] John 10:34 (KJV) | | 1
[472] John 10:35 (KJV) | | 1
[473] John 10:36 (KJV) | | 1
[474] John 10:37 (KJV) | | 1
[475] John 10:38 (KJV) | | 1
[476] John 10:39 (KJV) | | 1
[477] John 10:40 (KJV) | | 1
[478] John 10:41 (KJV) | | 1
[479] John 10:42 (KJV) | | 1
[480] John 11:1 (KJV) | | 1
[481] John 11:2 (KJV) | | 1
[482] John 11:3 (KJV) | | 1
[483] John 11:4 (KJV) | | 1
[484] John 11:5 (KJV) | | 1
[485] John 11:6 (KJV) | | 1
[486] John 11:7 (KJV) | | 1
[487] John 11:8 (KJV) | | 1
[488] John 11:9 (KJV) | | 1
[489] John 11:10 (KJV) | | 1
[490] John 11:11 (KJV) | | 1
[491] John 11:12 (KJV) | | 1
[492] John 11:13 (KJV) | | 1
[493] John 11:14 (KJV) | | 1
[494] John 11:15 (KJV) | | 1
[495] John 11:16 (KJV) | | 1
[496] John 11:17 (KJV) | | 1
[497] John 11:18 (KJV) | | 1
[498] John 11:19 (KJV) | | 1
[499] John 11:20 (KJV) | | 1
[500] John 11:21 (KJV) | | 1
[501] John 11:22 (KJV) | | 1
[502] John 11:23 (KJV) | | 1
[503] John 11:24 (KJV) | | 1
[504] John 11:25 (KJV) | | 1
[505] John 11:26 (KJV) | | 1
[506] John 11:27 (KJV) | | 1
[507] John 11:28 (KJV) | | 1
[508] John 11:29 (KJV) | | 1
[509] John 11:30 (KJV) | | 1
[510] John 11:31 (KJV) | | 1
[511] John 11:32 (KJV) | | 1
[512] John 11:33 (KJV) | | 1
[513] John 11:34 (KJV) | | 1
[514] John 11:35 (KJV) | | 1
[515] John 11:36 (KJV) | | 1
[516] John 11:37 (KJV) | | 1
[517] John 11:38 (KJV) | | 1
[518] John 11:39 (KJV) | | 1
[519] John 11:40 (KJV) | | 1
[520] John 11:41 (KJV) | | 1
[521] John 11:42 (KJV) | | 1
[522] John 11:43 (KJV) | | 1
[523] John 11:44 (KJV) | | 1
[524] John 11:45 (KJV) | | 1
[525] John 11:46 (KJV) | | 1
[526] John 11:47 (KJV) | | 1
[527] John 11:48 (KJV) | | 1
[528] John 11:49 (KJV) | | 1
[529] John 11:50 (KJV) | | 1
[530] John 11:51 (KJV) | | 1
[531] John 11:52 (KJV) | | 1
[532] John 11:53 (KJV) | | 1
[533] John 11:54 (KJV) | | 1
[534] John 11:55 (KJV) | | 1
[535] John 11:56 (KJV) | | 1
[536] John 11:57 (KJV) | | 1
[537] John 12:1 (KJV) | | 1
[538] John 12:2 (KJV) | | 1
[539] John 12:3 (KJV) | | 1
[540] John 12:4 (KJV) | | 1
[541] John 12:5 (KJV) | | 1
[542] John 12:6 (KJV) | | 1
[543] John 12:7 (KJV) | | 1
[544] John 12:8 (KJV) | | 1
[545] John 12:9 (KJV) | | 1
[546] John 12:10 (KJV) | | 1
[547] John 12:11 (KJV) | | 1
[548] John 12:12 (KJV) | | 1
[549] John 12:13 (KJV) | | 1
[550] John 12:14 (KJV) | | 1
[551] John 12:15 (KJV) | | 1
[552] John 12:16 (KJV) | | 1
[553] John 12:17 (KJV) | | 1
[554] John 12:18 (KJV) | | 1
[555] John 12:19 (KJV) | | 1
[556] John 12:20 (KJV) | | 1
[557] John 12:21 (KJV) | | 1
[558] John 12:22 (KJV) | | 1
[559] John 12:23 (KJV) | | 1
[560] John 12:24 (KJV) | | 1
[561] John 12:25 (KJV) | | 1
[562] John 12:26 (KJV) | | 1
[563] John 12:27 (KJV) | | 1
[564] John 12:28 (KJV) | | 1
[565] John 12:29 (KJV) | | 1
[566] John 12:30 (KJV) | | 1
[567] John 12:31 (KJV) | | 1
[568] John 12:32 (KJV) | | 1
[569] John 12:33 (KJV) | | 1
[570] John 12:34 (KJV) | | 1
[571] John 12:35 (KJV) | | 1
[572] John 12:36 (KJV) | | 1
[573] John 12:37 (KJV) | | 1
[574] John 12:38 (KJV) | | 1
[575] John 12:39 (KJV) | | 1
[576] John 12:40 (KJV) | | 1
[577] John 12:41 (KJV) | | 1
[578] John 12:42 (KJV) | | 1
[579] John 12:43 (KJV) | | 1
[580] John 12:44 (KJV) | | 1
[581] John 12:45 (KJV) | | 1
[582] John 12:46 (KJV) | | 1
[583] John 12:47 (KJV) | | 1
[584] John 12:48 (KJV) | | 1
[585] John 12:49 (KJV) | | 1
[586] John 12:50 (KJV) | | 1
[587] John 13:1 (KJV) | | 1
[588] John 13:2 (KJV) | | 1
[589] John 13:3 (KJV) | | 1
[590] John 13:4 (KJV) | | 1
[591] John 13:5 (KJV) | | 1
[592] John 13:6 (KJV) | | 1
[593] John 13:7 (KJV) | | 1
[594] John 13:8 (KJV) | | 1
[595] John 13:9 (KJV) | | 1
[596] John 13:10 (KJV) | | 1
[597] John 13:11 (KJV) | | 1
[598] John 13:12 (KJV) | | 1
[599] John 13:13 (KJV) | | 1
[600] John 13:14 (KJV) | | 1
[601] John 13:15 (KJV) | | 1
[602] John 13:16 (KJV) | | 1
[603] John 13:17 (KJV) | | 1
[604] John 13:18 (KJV) | | 1
[605] John 13:19 (KJV) | | 1
[606] John 13:20 (KJV) | | 1
[607] John 13:21 (KJV) | | 1
[608] John 13:22 (KJV) | | 1
[609] John 13:23 (KJV) | | 1
[610] John 13:24 (KJV) | | 1
[611] John 13:25 (KJV) | | 1
[612] John 13:26 (KJV) | | 1
[613] John 13:27 (KJV) | | 1
[614] John 13:28 (KJV) | | 1
[615] John 13:29 (KJV) | | 1
[616] John 13:30 (KJV) | | 1
[617] John 13:31 (KJV) | | 1
[618] John 13:32 (KJV) | | 1
[619] John 13:33 (KJV) | | 1
[620] John 13:34 (KJV) | | 1
[621] John 13:35 (KJV) | | 1
[622] John 13:36 (KJV) | | 1
[623] John 13:37 (KJV) | | 1
[624] John 13:38 (KJV) | | 1
[625] John 14:1 (KJV) | | 1
[626] John 14:2 (KJV) | | 1
[627] John 14:3 (KJV) | | 1
[628] John 14:4 (KJV) | | 1
[629] John 14:5 (KJV) | | 1
[630] John 14:6 (KJV) | | 1
[631] John 14:7 (KJV) | | 1
[632] John 14:8 (KJV) | | 1
[633] John 14:9 (KJV) | | 1
[634] John 14:10 (KJV) | | 1
[635] John 14:11 (KJV) | | 1
[636] John 14:12 (KJV) | | 1
[637] John 14:13 (KJV) | | 1
[638] John 14:14 (KJV) | | 1
[639] John 14:15 (KJV) | | 1
[640] John 14:16 (KJV) | | 1
[641] John 14:17 (KJV) | | 1
[642] John 14:18 (KJV) | | 1
[643] John 14:19 (KJV) | | 1
[644] John 14:20 (KJV) | | 1
[645] John 14:21 (KJV) | | 1
[646] John 14:22 (KJV) | | 1
[647] John 14:23 (KJV) | | 1
[648] John 14:24 (KJV) | | 1
[649] John 14:25 (KJV) | | 1
[650] John 14:26 (KJV) | | 1
[651] John 14:27 (KJV) | | 1
[652] John 14:28 (KJV) | | 1
[653] John 14:29 (KJV) | | 1
[654] John 14:30 (KJV) | | 1
[655] John 14:31 (KJV) | | 1
[656] John 15:1 (KJV) | | 1
[657] John 15:2 (KJV) | | 1
[658] John 15:3 (KJV) | | 1
[659] John 15:4 (KJV) | | 1
[660] John 15:5 (KJV) | | 1
[661] John 15:6 (KJV) | | 1
[662] John 15:7 (KJV) | | 1
[663] John 15:8 (KJV) | | 1
[664] John 15:9 (KJV) | | 1
[665] John 15:10 (KJV) | | 1
[666] John 15:11 (KJV) | | 1
[667] John 15:12 (KJV) | | 1
[668] John 15:13 (KJV) | | 1
[669] John 15:14 (KJV) | | 1
[670] John 15:15 (KJV) | | 1
[671] John 15:16 (KJV) | | 1
[672] John 15:17 (KJV) | | 1
[673] John 15:18 (KJV) | | 1
[674] John 15:19 (KJV) | | 1
[675] John 15:20 (KJV) | | 1
[676] John 15:21 (KJV) | | 1
[677] John 15:22 (KJV) | | 1
[678] John 15:23 (KJV) | | 1
[679] John 15:24 (KJV) | | 1
[680] John 15:25 (KJV) | | 1
[681] John 15:26 (KJV) | | 1
[682] John 15:27 (KJV) | | 1
[683] John 16:1 (KJV) | | 1
[684] John 16:2 (KJV) | | 1
[685] John 16:3 (KJV) | | 1
[686] John 16:4 (KJV) | | 1
[687] John 16:5 (KJV) | | 1
[688] John 16:6 (KJV) | | 1
[689] John 16:7 (KJV) | | 1
[690] John 16:8 (KJV) | | 1
[691] John 16:9 (KJV) | | 1
[692] John 16:10 (KJV) | | 1
[693] John 16:11 (KJV) | | 1
[694] John 16:12 (KJV) | | 1
[695] John 16:13 (KJV) | | 1
[696] John 16:14 (KJV) | | 1
[697] John 16:15 (KJV) | | 1
[698] John 16:16 (KJV) | | 1
[699] John 16:17 (KJV) | | 1
[700] John 16:18 (KJV) | | 1
[701] John 16:19 (KJV) | | 1
[702] John 16:20 (KJV) | | 1
[703] John 16:21 (KJV) | | 1
[704] John 16:22 (KJV) | | 1
[705] John 16:23 (KJV) | | 1
[706] John 16:24 (KJV) | | 1
[707] John 16:25 (KJV) | | 1
[708] John 16:26 (KJV) | | 1
[709] John 16:27 (KJV) | | 1
[710] John 16:28 (KJV) | | 1
[711] John 16:29 (KJV) | | 1
[712] John 16:30 (KJV) | | 1
[713] John 16:31 (KJV) | | 1
[714] John 16:32 (KJV) | | 1
[715] John 16:33 (KJV) | | 1
[716] John 17:1 (KJV) | | 1
[717] John 17:2 (KJV) | | 1
[718] John 17:3 (KJV) | | 1
[719] John 17:4 (KJV) | | 1
[720] John 17:5 (KJV) | | 1
[721] John 17:6 (KJV) | | 1
[722] John 17:7 (KJV) | | 1
[723] John 17:8 (KJV) | | 1
[724] John 17:9 (KJV) | | 1
[725] John 17:10 (KJV) | | 1
[726] John 17:11 (KJV) | | 1
[727] John 17:12 (KJV) | | 1
[728] John 17:13 (KJV) | | 1
[729] John 17:14 (KJV) | | 1
[730] John 17:15 (KJV) | | 1
[731] John 17:16 (KJV) | | 1
[732] John 17:17 (KJV) | | 1
[733] John 17:18 (KJV) | | 1
[734] John 17:19 (KJV) | | 1
[735] John 17:20 (KJV) | | 1
[736] John 17:21 (KJV) | | 1
[737] John 17:22 (KJV) | | 1
[738] John 17:23 (KJV) | | 1
[739] John 17:24 (KJV) | | 1
[740] John 17:25 (KJV) | | 1
[741] John 17:26 (KJV) | | 1
[742] John 18:1 (KJV) | | 1
[743] John 18:2 (KJV) | | 1
[744] John 18:3 (KJV) | | 1
[745] John 18:4 (KJV) | | 1
[746] John 18:5 (KJV) | | 1
[747] John 18:6 (KJV) | | 1
[748] John 18:7 (KJV) | | 1
[749] John 18:8 (KJV) | | 1
[750] John 18:9 (KJV) | | 1
[751] John 18:10 (KJV) | | 1
[752] John 18:11 (KJV) | | 1
[753] John 18:12 (KJV) | | 1
[754] John 18:13 (KJV) | | 1
[755] John 18:14 (KJV) | | 1
[756] John 18:15 (KJV) | | 1
[757] John 18:16 (KJV) | | 1
[758] John 18:17 (KJV) | | 1
[759] John 18:18 (KJV) | | 1
[760] John 18:19 (KJV) | | 1
[761] John 18:20 (KJV) | | 1
[762] John 18:21 (KJV) | | 1
[763] John 18:22 (KJV) | | 1
[764] John 18:23 (KJV) | | 1
[765] John 18:24 (KJV) | | 1
[766] John 18:25 (KJV) | | 1
[767] John 18:26 (KJV) | | 1
[768] John 18:27 (KJV) | | 1
[769] John 18:28 (KJV) | | 1
[770] John 18:29 (KJV) | | 1
[771] John 18:30 (KJV) | | 1
[772] John 18:31 (KJV) | | 1
[773] John 18:32 (KJV) | | 1
[774] John 18:33 (KJV) | | 1
[775] John 18:34 (KJV) | | 1
[776] John 18:35 (KJV) | | 1
[777] John 18:36 (KJV) | | 1
[778] John 18:37 (KJV) | | 1
[779] John 18:38 (KJV) | | 1
[780] John 18:39 (KJV) | | 1
[781] John 18:40 (KJV) | | 1
[782] John 19:1 (KJV) | | 1
[783] John 19:2 (KJV) | | 1
[784] John 19:3 (KJV) | | 1
[785] John 19:4 (KJV) | | 1
[786] John 19:5 (KJV) | | 1
[787] John 19:6 (KJV) | | 1
[788] John 19:7 (KJV) | | 1
[789] John 19:8 (KJV) | | 1
[790] John 19:9 (KJV) | | 1
[791] John 19:10 (KJV) | | 1
[792] John 19:11 (KJV) | | 1
[793] John 19:12 (KJV) | | 1
[794] John 19:13 (KJV) | | 1
[795] John 19:14 (KJV) | | 1
[796] John 19:15 (KJV) | | 1
[797] John 19:16 (KJV) | | 1
[798] John 19:17 (KJV) | | 1
[799] John 19:18 (KJV) | | 1
[800] John 19:19 (KJV) | | 1
[801] John 19:20 (KJV) | | 1
[802] John 19:21 (KJV) | | 1
[803] John 19:22 (KJV) | | 1
[804] John 19:23 (KJV) | | 1
[805] John 19:24 (KJV) | | 1
[806] John 19:25 (KJV) | | 1
[807] John 19:26 (KJV) | | 1
[808] John 19:27 (KJV) | | 1
[809] John 19:28 (KJV) | | 1
[810] John 19:29 (KJV) | | 1
[811] John 19:30 (KJV) | | 1
[812] John 19:31 (KJV) | | 1
[813] John 19:32 (KJV) | | 1
[814] John 19:33 (KJV) | | 1
[815] John 19:34 (KJV) | | 1
[816] John 19:35 (KJV) | | 1
[817] John 19:36 (KJV) | | 1
[818] John 19:37 (KJV) | | 1
[819] John 19:38 (KJV) | | 1
[820] John 19:39 (KJV) | | 1
[821] John 19:40 (KJV) | | 1
[822] John 19:41 (KJV) | | 1
[823] John 19:42 (KJV) | | 1
[824] John 20:1 (KJV) | | 1
[825] John 20:2 (KJV) | | 1
[826] John 20:3 (KJV) | | 1
[827] John 20:4 (KJV) | | 1
[828] John 20:5 (KJV) | | 1
[829] John 20:6 (KJV) | | 1
[830] John 20:7 (KJV) | | 1
[831] John 20:8 (KJV) | | 1
[832] John 20:9 (KJV) | | 1
[833] John 20:10 (KJV) | | 1
[834] John 20:11 (KJV) | | 1
[835] John 20:12 (KJV) | | 1
[836] John 20:13 (KJV) | | 1
[837] John 20:14 (KJV) | | 1
[838] John 20:15 (KJV) | | 1
[839] John 20:16 (KJV) | | 1
[840] John 20:17 (KJV) | | 1
[841] John 20:18 (KJV) | | 1
[842] John 20:19 (KJV) | | 1
[843] John 20:20 (KJV) | | 1
[844] John 20:21 (KJV) | | 1
[845] John 20:22 (KJV) | | 1
[846] John 20:23 (KJV) | | 1
[847] John 20:24 (KJV) | | 1
[848] John 20:25 (KJV) | | 1
[849] John 20:26 (KJV) | | 1
[850] John 20:27 (KJV) | | 1
[851] John 20:28 (KJV) | | 1
[852] John 20:29 (KJV) | | 1
[853] John 20:30 (KJV) | | 1
[854] John 20:31 (KJV) | | 1
[855] John 21:1 (KJV) | | 1
[856] John 21:2 (KJV) | | 1
[857] John 21:3 (KJV) | | 1
[858] John 21:4 (KJV) | | 1
[859] John 21:5 (KJV) | | 1
[860] John 21:6 (KJV) | | 1
[861] John 21:7 (KJV) | | 1
[862] John 21:8 (KJV) | | 1
[863] John 21:9 (KJV) | | 1
[864] John 21:10 (KJV) | | 1
[865] John 21:11 (KJV) | | 1
[866] John 21:12 (KJV) | | 1
[867] John 21:13 (KJV) | | 1
[868] John 21:14 (KJV) | | 1
[869] John 21:15 (KJV) | | 1
[870] John 21:16 (KJV) | | 1
[871] John 21:17 (KJV) | | 1
[872] John 21:18 (KJV) | | 1
[873] John 21:19 (KJV) | | 1
[874] John 21:20 (KJV) | | 1
[875] John 21:21 (KJV) | | 1
[876] John 21:22 (KJV) | | 1
[877] John 21:23 (KJV) | | 1
[878] John 21:24 (KJV) | | 1
[879] John 21:25 (KJV) | | 1