title: The Gospel According to Matthew (KJV)
url: https://www.gutenberg.org/cache/epub/8040/pg8040.txt
tier: 1
---
§ Matthew 1

The book of the generation of Jesus Christ, the son of David, the son of Abraham. [1]

Abraham begat Isaac; and Isaac begat Jacob; and Jacob begat Judas and his brethren; [2]

And Judas begat Phares and Zara of Thamar; and Phares begat Esrom; and Esrom begat Aram; [3]

And Aram begat Aminadab; and Aminadab begat Naasson; and Naasson begat Salmon; [4]

And Salmon begat Booz of Rachab; and Booz begat Obed of Ruth; and Obed begat Jesse; [5]

And Jesse begat David the king; and David the king begat Solomon of her that had been the wife of Urias; [6]

And Solomon begat Roboam; and Roboam begat Abia; and Abia begat Asa; [7]

And Asa begat Josaphat; and Josaphat begat Joram; and Joram begat Ozias; [8]

And Ozias begat Joatham; and Joatham begat Achaz; and Achaz begat Ezekias; [9]

And Ezekias begat Manasses; and Manasses begat Amon; and Amon begat Josias; [10]

And Josias begat Jechonias and his brethren, about the time they were carried away to Babylon: [11]

And after they were brought to Babylon, Jechonias begat Salathiel; and Salathiel begat Zorobabel; [12]

And Zorobabel begat Abiud; and Abiud begat Eliakim; and Eliakim begat Azor; [13]

And Azor begat Sadoc; and Sadoc begat Achim; and Achim begat Eliud; [14]

And Eliud begat Eleazar; and Eleazar begat Matthan; and Matthan begat Jacob; [15]

And Jacob begat Joseph the husband of Mary, of whom was born Jesus, who is called Christ. [16]

So all the generations from Abraham to David are fourteen generations; and from David until the carrying away into Babylon are fourteen generations; and from the carrying away into Babylon unto Christ are fourteen generations. [17]

Now the birth of Jesus Christ was on this wise: When as his mother Mary was espoused to Joseph, before they came together, she was found with child of the Holy Ghost. [18]

Then Joseph her husband, being a just man, and not willing to make her a publick example, was minded to put her away privily. [19]

But while he thought on these things, behold, the angel of the LORD appeared unto him in a dream, saying, Joseph, thou son of David, fear not to take unto thee Mary thy wife: for that which is conceived in her is of the Holy Ghost. [20]

And she shall bring forth a son, and thou shalt call his name JESUS: for he shall save his people from their sins. [21]

Now all this was done, that it might be fulfilled which was spoken of the Lord by the prophet, saying, [22]

Behold, a virgin shall be with child, and shall bring forth a son, and they shall call his name Emmanuel, which being interpreted is, God with us. [23]

Then Joseph being raised from sleep did as the angel of the Lord had bidden him, and took unto him his wife: [24]

And knew her not till she had brought forth her firstborn son: and he called his name JESUS. [25]

§ Matthew 2

Now when Jesus was born in Bethlehem of Judaea in the days of Herod the king, behold, there came wise men from the east to Jerusalem, [26]

Saying, Where is he that is born King of the Jews? for we have seen his star in the east, and are come to worship him. [27]

When Herod the king had heard these things, he was troubled, and all Jerusalem with him. [28]

And when he had gathered all the chief priests and scribes of the people together, he demanded of them where Christ should be born. [29]

And they said unto him, In Bethlehem of Judaea: for thus it is written by the prophet, [30]

And thou Bethlehem, in the land of Juda, art not the least among the princes of Juda: for out of thee shall come a Governor, that shall rule my people Israel. [31]

Then Herod, when he had privily called the wise men, enquired of them diligently what time the star appeared. [32]

And he sent them to Bethlehem, and said, Go and search diligently for the young child; and when ye have found him, bring me word again, that I may come and worship him also. [33]

When they had heard the king, they departed; and, lo, the star, which they saw in the east, went before them, till it came and stood over where the young child was. [34]

When they saw the star, they rejoiced with exceeding great joy. [35]

And when they were come into the house, they saw the young child with Mary his mother, and fell down, and worshipped him: and when they had opened their treasures, they presented unto him gifts; gold, and frankincense and myrrh. [36]

And being warned of God in a dream that they should not return to Herod, they departed into their own country another way. [37]

And when they were departed, behold, the angel of the Lord appeareth to Joseph in a dream, saying, Arise, and take the young child and his mother, and flee into Egypt, and be thou there until I bring thee word: for Herod will seek the young child to destroy him. [38]

When he arose, he took the young child and his mother by night, and departed into Egypt: [39]

And was there until the death of Herod: that it might be fulfilled which was spoken of the Lord by the prophet, saying, Out of Egypt have I called my son. [40]

Then Herod, when he saw that he was mocked of the wise men, was exceeding wroth, and sent forth, and slew all the children that were in Bethlehem, and in all the coasts thereof, from two years old and under, according to the time which he had diligently enquired of the wise men. [41]

Then was fulfilled that which was spoken by Jeremy the prophet, saying, [42]

In Rama was there a voice heard, lamentation, and weeping, and great mourning, Rachel weeping for her children, and would not be comforted, because they are not. [43]

But when Herod was dead, behold, an angel of the Lord appeareth in a dream to Joseph in Egypt, [44]

Saying, Arise, and take the young child and his mother, and go into the land of Israel: for they are dead which sought the young child's life. [45]

And he arose, and took the young child and his mother, and came into the land of Israel. [46]

But when he heard that Archelaus did reign in Judaea in the room of his father Herod, he was afraid to go thither: notwithstanding, being warned of God in a dream, he turned aside into the parts of Galilee: [47]

And he came and dwelt in a city called Nazareth: that it might be fulfilled which was spoken by the prophets, He shall be called a Nazarene. [48]

§ Matthew 3

In those days came John the Baptist, preaching in the wilderness of Judaea, [49]

And saying, Repent ye: for the kingdom of heaven is at hand. [50]

For this is he that was spoken of by the prophet Esaias, saying, The voice of one crying in the wilderness, Prepare ye the way of the Lord, make his paths straight. [51]

And the same John had his raiment of camel's hair, and a leathern girdle about his loins; and his meat was locusts and wild honey. [52]

Then went out to him Jerusalem, and all Judaea, and all the region round about Jordan, [53]

And were baptized of him in Jordan, confessing their sins. [54]

But when he saw many of the Pharisees and Sadducees come to his baptism, he said unto them, O generation of vipers, who hath warned you to flee from the wrath to come? [55]

Bring forth therefore fruits meet for repentance: [56]

And think not to say within yourselves, We have Abraham to our father: for I say unto you, that God is able of these stones to raise up children unto Abraham. [57]

And now also the axe is laid unto the root of the trees: therefore every tree which bringeth not forth good fruit is hewn down, and cast into the fire. [58]

I indeed baptize you with water unto repentance: but he that cometh after me is mightier than I, whose shoes I am not worthy to bear: he shall baptize you with the Holy Ghost, and with fire: [59]

Whose fan is in his hand, and he will throughly purge his floor, and gather his wheat into the garner; but he will burn up the chaff with unquenchable fire. [60]

Then cometh Jesus from Galilee to Jordan unto John, to be baptized of him. [61]

But John forbad him, saying, I have need to be baptized of thee, and comest thou to me? [62]

And Jesus answering said unto him, Suffer it to be so now: for thus it becometh us to fulfil all righteousness. Then he suffered him. [63]

And Jesus, when he was baptized, went up straightway out of the water: and, lo, the heavens were opened unto him, and he saw the Spirit of God descending like a dove, and lighting upon him: [64]

And lo a voice from heaven, saying, This is my beloved Son, in whom I am well pleased. [65]

§ Matthew 4

Then was Jesus led up of the spirit into the wilderness to be tempted of the devil. [66]

And when he had fasted forty days and forty nights, he was afterward an hungred. [67]

And when the tempter came to him, he said, If thou be the Son of God, command that these stones be made bread. [68]

But he answered and said, It is written, Man shall not live by bread alone, but by every word that proceedeth out of the mouth of God. [69]

Then the devil taketh him up into the holy city, and setteth him on a pinnacle of the temple, [70]

And saith unto him, If thou be the Son of God, cast thyself down: for it is written, He shall give his angels charge concerning thee: and in their hands they shall bear thee up, lest at any time thou dash thy foot against a stone. [71]

Jesus said unto him, It is written again, Thou shalt not tempt the Lord thy God. [72]

Again, the devil taketh him up into an exceeding high mountain, and sheweth him all the kingdoms of the world, and the glory of them; [73]

And saith unto him, All these things will I give thee, if thou wilt fall down and worship me. [74]

Then saith Jesus unto him, Get thee hence, Satan: for it is written, Thou shalt worship the Lord thy God, and him only shalt thou serve. [75]

Then the devil leaveth him, and, behold, angels came and ministered unto him. [76]

Now when Jesus had heard that John was cast into prison, he departed into Galilee; [77]

And leaving Nazareth, he came and dwelt in Capernaum, which is upon the sea coast, in the borders of Zabulon and Nephthalim: [78]

That it might be fulfilled which was spoken by Esaias the prophet, saying, [79]

The land of Zabulon, and the land of Nephthalim, by the way of the sea, beyond Jordan, Galilee of the Gentiles; [80]

The people which sat in darkness saw great light; and to them which sat in the region and shadow of death light is sprung up. [81]

From that time Jesus began to preach, and to say, Repent: for the kingdom of heaven is at hand. [82]

And Jesus, walking by the sea of Galilee, saw two brethren, Simon called Peter, and Andrew his brother, casting a net into the sea: for they were fishers. [83]

And he saith unto them, Follow me, and I will make you fishers of men. [84]

And they straightway left their nets, and followed him. [85]

And going on from thence, he saw other two brethren, James the son of Zebedee, and John his brother, in a ship with Zebedee their father, mending their nets; and he called them. [86]

And they immediately left the ship and their father, and followed him. [87]

And Jesus went about all Galilee, teaching in their synagogues, and preaching the gospel of the kingdom, and healing all manner of sickness and all manner of disease among the people. [88]

And his fame went throughout all Syria: and they brought unto him all sick people that were taken with divers diseases and torments, and those which were possessed with devils, and those which were lunatick, and those that had the palsy; and he healed them. [89]

And there followed him great multitudes of people from Galilee, and from Decapolis, and from Jerusalem, and from Judaea, and from beyond Jordan. [90]

§ Matthew 5

And seeing the multitudes, he went up into a mountain: and when he was set, his disciples came unto him: [91]

And he opened his mouth, and taught them, saying, [92]

Blessed are the poor in spirit: for theirs is the kingdom of heaven. [93]

Blessed are they that mourn: for they shall be comforted. [94]

Blessed are the meek: for they shall inherit the earth. [95]

Blessed are they which do hunger and thirst after righteousness: for they shall be filled. [96]

Blessed are the merciful: for they shall obtain mercy. [97]

Blessed are the pure in heart: for they shall see God. [98]

Blessed are the peacemakers: for they shall be called the children of God. [99]

Blessed are they which are persecuted for righteousness' sake: for theirs is the kingdom of heaven. [100]

Blessed are ye, when men shall revile you, and persecute you, and shall say all manner of evil against you falsely, for my sake. [101]

Rejoice, and be exceeding glad: for great is your reward in heaven: for so persecuted they the prophets which were before you. [102]

Ye are the salt of the earth: but if the salt have lost his savour, wherewith shall it be salted? it is thenceforth good for nothing, but to be cast out, and to be trodden under foot of men. [103]

Ye are the light of the world. A city that is set on an hill cannot be hid. [104]

Neither do men light a candle, and put it under a bushel, but on a candlestick; and it giveth light unto all that are in the house. [105]

Let your light so shine before men, that they may see your good works, and glorify your Father which is in heaven. [106]

Think not that I am come to destroy the law, or the prophets: I am not come to destroy, but to fulfil. [107]

For verily I say unto you, Till heaven and earth pass, one jot or one tittle shall in no wise pass from the law, till all be fulfilled. [108]

Whosoever therefore shall break one of these least commandments, and shall teach men so, he shall be called the least in the kingdom of heaven: but whosoever shall do and teach them, the same shall be called great in the kingdom of heaven. [109]

For I say unto you, That except your righteousness shall exceed the righteousness of the scribes and Pharisees, ye shall in no case enter into the kingdom of heaven. [110]

Ye have heard that it was said of them of old time, Thou shalt not kill; and whosoever shall kill shall be in danger of the judgment: [111]

But I say unto you, That whosoever is angry with his brother without a cause shall be in danger of the judgment: and whosoever shall say to his brother, Raca, shall be in danger of the council: but whosoever shall say, Thou fool, shall be in danger of hell fire. [112]

Therefore if thou bring thy gift to the altar, and there rememberest that thy brother hath ought against thee; [113]

Leave there thy gift before the altar, and go thy way; first be reconciled to thy brother, and then come and offer thy gift. [114]

Agree with thine adversary quickly, whiles thou art in the way with him; lest at any time the adversary deliver thee to the judge, and the judge deliver thee to the officer, and thou be cast into prison. [115]

Verily I say unto thee, Thou shalt by no means come out thence, till thou hast paid the uttermost farthing. [116]

Ye have heard that it was said by them of old time, Thou shalt not commit adultery: [117]

But I say unto you, That whosoever looketh on a woman to lust after her hath committed adultery with her already in his heart. [118]

And if thy right eye offend thee, pluck it out, and cast it from thee: for it is profitable for thee that one of thy members should perish, and not that thy whole body should be cast into hell. [119]

And if thy right hand offend thee, cut it off, and cast it from thee: for it is profitable for thee that one of thy members should perish, and not that thy whole body should be cast into hell. [120]

It hath been said, Whosoever shall put away his wife, let him give her a writing of divorcement: [121]

But I say unto you, That whosoever shall put away his wife, saving for the cause of fornication, causeth her to commit adultery: and whosoever shall marry her that is divorced committeth adultery. [122]

Again, ye have heard that it hath been said by them of old time, Thou shalt not forswear thyself, but shalt perform unto the Lord thine oaths: [123]

But I say unto you, Swear not at all; neither by heaven; for it is God's throne: [124]

Nor by the earth; for it is his footstool: neither by Jerusalem; for it is the city of the great King. [125]

Neither shalt thou swear by thy head, because thou canst not make one hair white or black. [126]

But let your communication be, Yea, yea; Nay, nay: for whatsoever is more than these cometh of evil. [127]

Ye have heard that it hath been said, An eye for an eye, and a tooth for a tooth: [128]

But I say unto you, That ye resist not evil: but whosoever shall smite thee on thy right cheek, turn to him the other also. [129]

And if any man will sue thee at the law, and take away thy coat, let him have thy cloak also. [130]

And whosoever shall compel thee to go a mile, go with him twain. [131]

Give to him that asketh thee, and from him that would borrow of thee turn not thou away. [132]

Ye have heard that it hath been said, Thou shalt love thy neighbour, and hate thine enemy. [133]

But I say unto you, Love your enemies, bless them that curse you, do good to them that hate you, and pray for them which despitefully use you, and persecute you; [134]

That ye may be the children of your Father which is in heaven: for he maketh his sun to rise on the evil and on the good, and sendeth rain on the just and on the unjust. [135]

For if ye love them which love you, what reward have ye? do not even the publicans the same? [136]

And if ye salute your brethren only, what do ye more than others? do not even the publicans so? [137]

Be ye therefore perfect, even as your Father which is in heaven is perfect. [138]

§ Matthew 6

Take heed that ye do not your alms before men, to be seen of them: otherwise ye have no reward of your Father which is in heaven. [139]

Therefore when thou doest thine alms, do not sound a trumpet before thee, as the hypocrites do in the synagogues and in the streets, that they may have glory of men. Verily I say unto you, They have their reward. [140]

But when thou doest alms, let not thy left hand know what thy right hand doeth: [141]

That thine alms may be in secret: and thy Father which seeth in secret himself shall reward thee openly. [142]

And when thou prayest, thou shalt not be as the hypocrites are: for they love to pray standing in the synagogues and in the corners of the streets, that they may be seen of men. Verily I say unto you, They have their reward. [143]

But thou, when thou prayest, enter into thy closet, and when thou hast shut thy door, pray to thy Father which is in secret; and thy Father which seeth in secret shall reward thee openly. [144]

But when ye pray, use not vain repetitions, as the heathen do: for they think that they shall be heard for their much speaking. [145]

Be not ye therefore like unto them: for your Father knoweth what things ye have need of, before ye ask him. [146]

After this manner therefore pray ye: Our Father which art in heaven, Hallowed be thy name. [147]

Thy kingdom come, Thy will be done in earth, as it is in heaven. [148]

Give us this day our daily bread. [149]

And forgive us our debts, as we forgive our debtors. [150]

And lead us not into temptation, but deliver us from evil: For thine is the kingdom, and the power, and the glory, for ever. Amen. [151]

For if ye forgive men their trespasses, your heavenly Father will also forgive you: [152]

But if ye forgive not men their trespasses, neither will your Father forgive your trespasses. [153]

Moreover when ye fast, be not, as the hypocrites, of a sad countenance: for they disfigure their faces, that they may appear unto men to fast. Verily I say unto you, They have their reward. [154]

But thou, when thou fastest, anoint thine head, and wash thy face; [155]

That thou appear not unto men to fast, but unto thy Father which is in secret: and thy Father, which seeth in secret, shall reward thee openly. [156]

Lay not up for yourselves treasures upon earth, where moth and rust doth corrupt, and where thieves break through and steal: [157]

But lay up for yourselves treasures in heaven, where neither moth nor rust doth corrupt, and where thieves do not break through nor steal: [158]

For where your treasure is, there will your heart be also. [159]

The light of the body is the eye: if therefore thine eye be single, thy whole body shall be full of light. [160]

But if thine eye be evil, thy whole body shall be full of darkness. If therefore the light that is in thee be darkness, how great is that darkness! [161]

No man can serve two masters: for either he will hate the one, and love the other; or else he will hold to the one, and despise the other. Ye cannot serve God and mammon. [162]

Therefore I say unto you, Take no thought for your life, what ye shall eat, or what ye shall drink; nor yet for your body, what ye shall put on. Is not the life more than meat, and the body than raiment? [163]

Behold the fowls of the air: for they sow not, neither do they reap, nor gather into barns; yet your heavenly Father feedeth them. Are ye not much better than they? [164]

Which of you by taking thought can add one cubit unto his stature? [165]

And why take ye thought for raiment? Consider the lilies of the field, how they grow; they toil not, neither do they spin: [166]

And yet I say unto you, That even Solomon in all his glory was not arrayed like one of these. [167]

Wherefore, if God so clothe the grass of the field, which to day is, and to morrow is cast into the oven, shall he not much more clothe you, O ye of little faith? [168]

Therefore take no thought, saying, What shall we eat? or, What shall we drink? or, Wherewithal shall we be clothed? [169]

(For after all these things do the Gentiles seek:) for your heavenly Father knoweth that ye have need of all these things. [170]

But seek ye first the kingdom of God, and his righteousness; and all these things shall be added unto you. [171]

Take therefore no thought for the morrow: for the morrow shall take thought for the things of itself. Sufficient unto the day is the evil thereof. [172]

§ Matthew 7

Judge not, that ye be not judged. [173]

For with what judgment ye judge, ye shall be judged: and with what measure ye mete, it shall be measured to you again. [174]

And why beholdest thou the mote that is in thy brother's eye, but considerest not the beam that is in thine own eye? [175]

Or how wilt thou say to thy brother, Let me pull out the mote out of thine eye; and, behold, a beam is in thine own eye? [176]

Thou hypocrite, first cast out the beam out of thine own eye; and then shalt thou see clearly to cast out the mote out of thy brother's eye. [177]

Give not that which is holy unto the dogs, neither cast ye your pearls before swine, lest they trample them under their feet, and turn again and rend you. [178]

Ask, and it shall be given you; seek, and ye shall find; knock, and it shall be opened unto you: [179]

For every one that asketh receiveth; and he that seeketh findeth; and to him that knocketh it shall be opened. [180]

Or what man is there of you, whom if his son ask bread, will he give him a stone? [181]

Or if he ask a fish, will he give him a serpent? [182]

If ye then, being evil, know how to give good gifts unto your children, how much more shall your Father which is in heaven give good things to them that ask him? [183]

Therefore all things whatsoever ye would that men should do to you, do ye even so to them: for this is the law and the prophets. [184]

Enter ye in at the strait gate: for wide is the gate, and broad is the way, that leadeth to destruction, and many there be which go in thereat: [185]

Because strait is the gate, and narrow is the way, which leadeth unto life, and few there be that find it. [186]

Beware of false prophets, which come to you in sheep's clothing, but inwardly they are ravening wolves. [187]

Ye shall know them by their fruits. Do men gather grapes of thorns, or figs of thistles? [188]

Even so every good tree bringeth forth good fruit; but a corrupt tree bringeth forth evil fruit. [189]

A good tree cannot bring forth evil fruit, neither can a corrupt tree bring forth good fruit. [190]

Every tree that bringeth not forth good fruit is hewn down, and cast into the fire. [191]

Wherefore by their fruits ye shall know them. [192]

Not every one that saith unto me, Lord, Lord, shall enter into the kingdom of heaven; but he that doeth the will of my Father which is in heaven. [193]

Many will say to me in that day, Lord, Lord, have we not prophesied in thy name? and in thy name have cast out devils? and in thy name done many wonderful works? [194]

And then will I profess unto them, I never knew you: depart from me, ye that work iniquity. [195]

Therefore whosoever heareth these sayings of mine, and doeth them, I will liken him unto a wise man, which built his house upon a rock: [196]

And the rain descended, and the floods came, and the winds blew, and beat upon that house; and it fell not: for it was founded upon a rock. [197]

And every one that heareth these sayings of mine, and doeth them not, shall be likened unto a foolish man, which built his house upon the sand: [198]

And the rain descended, and the floods came, and the winds blew, and beat upon that house; and it fell: and great was the fall of it. [199]

And it came to pass, when Jesus had ended these sayings, the people were astonished at his doctrine: [200]

For he taught them as one having authority, and not as the scribes. [201]

§ Matthew 8

When he was come down from the mountain, great multitudes followed him. [202]

And, behold, there came a leper and worshipped him, saying, Lord, if thou wilt, thou canst make me clean. [203]

And Jesus put forth his hand, and touched him, saying, I will; be thou clean. And immediately his leprosy was cleansed. [204]

And Jesus saith unto him, See thou tell no man; but go thy way, shew thyself to the priest, and offer the gift that Moses commanded, for a testimony unto them. [205]

And when Jesus was entered into Capernaum, there came unto him a centurion, beseeching him, [206]

And saying, Lord, my servant lieth at home sick of the palsy, grievously tormented. [207]

And Jesus saith unto him, I will come and heal him. [208]

The centurion answered and said, Lord, I am not worthy that thou shouldest come under my roof: but speak the word only, and my servant shall be healed. [209]

For I am a man under authority, having soldiers under me: and I say to this man, Go, and he goeth; and to another, Come, and he cometh; and to my servant, Do this, and he doeth it. [210]

When Jesus heard it, he marvelled, and said to them that followed, Verily I say unto you, I have not found so great faith, no, not in Israel. [211]

And I say unto you, That many shall come from the east and west, and shall sit down with Abraham, and Isaac, and Jacob, in the kingdom of heaven. [212]

But the children of the kingdom shall be cast out into outer darkness: there shall be weeping and gnashing of teeth. [213]

And Jesus said unto the centurion, Go thy way; and as thou hast believed, so be it done unto thee. And his servant was healed in the selfsame hour. [214]

And when Jesus was come into Peter's house, he saw his wife's mother laid, and sick of a fever. [215]

And he touched her hand, and the fever left her: and she arose, and ministered unto them. [216]

When the even was come, they brought unto him many that were possessed with devils: and he cast out the spirits with his word, and healed all that were sick: [217]

That it might be fulfilled which was spoken by Esaias the prophet, saying, Himself took our infirmities, and bare our sicknesses. [218]

Now when Jesus saw great multitudes about him, he gave commandment to depart unto the other side. [219]

And a certain scribe came, and said unto him, Master, I will follow thee whithersoever thou goest. [220]

And Jesus saith unto him, The foxes have holes, and the birds of the air have nests; but the Son of man hath not where to lay his head. [221]

And another of his disciples said unto him, Lord, suffer me first to go and bury my father. [222]

But Jesus said unto him, Follow me; and let the dead bury their dead. [223]

And when he was entered into a ship, his disciples followed him. [224]

And, behold, there arose a great tempest in the sea, insomuch that the ship was covered with the waves: but he was asleep. [225]

And his disciples came to him, and awoke him, saying, Lord, save us: we perish. [226]

And he saith unto them, Why are ye fearful, O ye of little faith? Then he arose, and rebuked the winds and the sea; and there was a great calm. [227]

But the men marvelled, saying, What manner of man is this, that even the winds and the sea obey him! [228]

And when he was come to the other side into the country of the Gergesenes, there met him two possessed with devils, coming out of the tombs, exceeding fierce, so that no man might pass by that way. [229]

And, behold, they cried out, saying, What have we to do with thee, Jesus, thou Son of God? art thou come hither to torment us before the time? [230]

And there was a good way off from them an herd of many swine feeding. [231]

So the devils besought him, saying, If thou cast us out, suffer us to go away into the herd of swine. [232]

And he said unto them, Go. And when they were come out, they went into the herd of swine: and, behold, the whole herd of swine ran violently down a steep place into the sea, and perished in the waters. [233]

And they that kept them fled, and went their ways into the city, and told every thing, and what was befallen to the possessed of the devils. [234]

And, behold, the whole city came out to meet Jesus: and when they saw him, they besought him that he would depart out of their coasts. [235]

§ Matthew 9

And he entered into a ship, and passed over, and came into his own city. [236]

And, behold, they brought to him a man sick of the palsy, lying on a bed: and Jesus seeing their faith said unto the sick of the palsy; Son, be of good cheer; thy sins be forgiven thee. [237]

And, behold, certain of the scribes said within themselves, This man blasphemeth. [238]

And Jesus knowing their thoughts said, Wherefore think ye evil in your hearts? [239]

For whether is easier, to say, Thy sins be forgiven thee; or to say, Arise, and walk? [240]

But that ye may know that the Son of man hath power on earth to forgive sins, (then saith he to the sick of the palsy,) Arise, take up thy bed, and go unto thine house. [241]

And he arose, and departed to his house. [242]

But when the multitudes saw it, they marvelled, and glorified God, which had given such power unto men. [243]

And as Jesus passed forth from thence, he saw a man, named Matthew, sitting at the receipt of custom: and he saith unto him, Follow me. And he arose, and followed him. [244]

And it came to pass, as Jesus sat at meat in the house, behold, many publicans and sinners came and sat down with him and his disciples. [245]

And when the Pharisees saw it, they said unto his disciples, Why eateth your Master with publicans and sinners? [246]

But when Jesus heard that, he said unto them, They that be whole need not a physician, but they that are sick. [247]

But go ye and learn what that meaneth, I will have mercy, and not sacrifice: for I am not come to call the righteous, but sinners to repentance. [248]

Then came to him the disciples of John, saying, Why do we and the Pharisees fast oft, but thy disciples fast not? [249]

And Jesus said unto them, Can the children of the bridechamber mourn, as long as the bridegroom is with them? but the days will come, when the bridegroom shall be taken from them, and then shall they fast. [250]

No man putteth a piece of new cloth unto an old garment, for that which is put in to fill it up taketh from the garment, and the rent is made worse. [251]

Neither do men put new wine into old bottles: else the bottles break, and the wine runneth out, and the bottles perish: but they put new wine into new bottles, and both are preserved. [252]

While he spake these things unto them, behold, there came a certain ruler, and worshipped him, saying, My daughter is even now dead: but come and lay thy hand upon her, and she shall live. [253]

And Jesus arose, and followed him, and so did his disciples. [254]

And, behold, a woman, which was diseased with an issue of blood twelve years, came behind him, and touched the hem of his garment: [255]

For she said within herself, If I may but touch his garment, I shall be whole. [256]

But Jesus turned him about, and when he saw her, he said, Daughter, be of good comfort; thy faith hath made thee whole. And the woman was made whole from that hour. [257]

And when Jesus came into the ruler's house, and saw the minstrels and the people making a noise, [258]

He said unto them, Give place: for the maid is not dead, but sleepeth. And they laughed him to scorn. [259]

But when the people were put forth, he went in, and took her by the hand, and the maid arose. [260]

And the fame hereof went abroad into all that land. [261]

And when Jesus departed thence, two blind men followed him, crying, and saying, Thou son of David, have mercy on us. [262]

And when he was come into the house, the blind men came to him: and Jesus saith unto them, Believe ye that I am able to do this? They said unto him, Yea, Lord. [263]

Then touched he their eyes, saying, According to your faith be it unto you. [264]

And their eyes were opened; and Jesus straitly charged them, saying, See that no man know it. [265]

But they, when they were departed, spread abroad his fame in all that country. [266]

As they went out, behold, they brought to him a dumb man possessed with a devil. [267]

And when the devil was cast out, the dumb spake: and the multitudes marvelled, saying, It was never so seen in Israel. [268]

But the Pharisees said, He casteth out devils through the prince of the devils. [269]

And Jesus went about all the cities and villages, teaching in their synagogues, and preaching the gospel of the kingdom, and healing every sickness and every disease among the people. [270]

But when he saw the multitudes, he was moved with compassion on them, because they fainted, and were scattered abroad, as sheep having no shepherd. [271]

Then saith he unto his disciples, The harvest truly is plenteous, but the labourers are few; [272]

Pray ye therefore the Lord of the harvest, that he will send forth labourers into his harvest. [273]

§ Matthew 10

And when he had called unto him his twelve disciples, he gave them power against unclean spirits, to cast them out, and to heal all manner of sickness and all manner of disease. [274]

Now the names of the twelve apostles are these; The first, Simon, who is called Peter, and Andrew his brother; James the son of Zebedee, and John his brother; [275]

Philip, and Bartholomew; Thomas, and Matthew the publican; James the son of Alphaeus, and Lebbaeus, whose surname was Thaddaeus; [276]

Simon the Canaanite, and Judas Iscariot, who also betrayed him. [277]

These twelve Jesus sent forth, and commanded them, saying, Go not into the way of the Gentiles, and into any city of the Samaritans enter ye not: [278]

But go rather to the lost sheep of the house of Israel. [279]

And as ye go, preach, saying, The kingdom of heaven is at hand. [280]

Heal the sick, cleanse the lepers, raise the dead, cast out devils: freely ye have received, freely give. [281]

Provide neither gold, nor silver, nor brass in your purses, [282]

Nor scrip for your journey, neither two coats, neither shoes, nor yet staves: for the workman is worthy of his meat. [283]

And into whatsoever city or town ye shall enter, enquire who in it is worthy; and there abide till ye go thence. [284]

And when ye come into an house, salute it. [285]

And if the house be worthy, let your peace come upon it: but if it be not worthy, let your peace return to you. [286]

And whosoever shall not receive you, nor hear your words, when ye depart out of that house or city, shake off the dust of your feet. [287]

Verily I say unto you, It shall be more tolerable for the land of Sodom and Gomorrha in the day of judgment, than for that city. [288]

Behold, I send you forth as sheep in the midst of wolves: be ye therefore wise as serpents, and harmless as doves. [289]

But beware of men: for they will deliver you up to the councils, and they will scourge you in their synagogues; [290]

And ye shall be brought before governors and kings for my sake, for a testimony against them and the Gentiles. [291]

But when they deliver you up, take no thought how or what ye shall speak: for it shall be given you in that same hour what ye shall speak. [292]

For it is not ye that speak, but the Spirit of your Father which speaketh in you. [293]

And the brother shall deliver up the brother to death, and the father the child: and the children shall rise up against their parents, and cause them to be put to death. [294]

And ye shall be hated of all men for my name's sake: but he that endureth to the end shall be saved. [295]

But when they persecute you in this city, flee ye into another: for verily I say unto you, Ye shall not have gone over the cities of Israel, till the Son of man be come. [296]

The disciple is not above his master, nor the servant above his lord. [297]

It is enough for the disciple that he be as his master, and the servant as his lord. If they have called the master of the house Beelzebub, how much more shall they call them of his household? [298]

Fear them not therefore: for there is nothing covered, that shall not be revealed; and hid, that shall not be known. [299]

What I tell you in darkness, that speak ye in light: and what ye hear in the ear, that preach ye upon the housetops. [300]

And fear not them which kill the body, but are not able to kill the soul: but rather fear him which is able to destroy both soul and body in hell. [301]

Are not two sparrows sold for a farthing? and one of them shall not fall on the ground without your Father. [302]

But the very hairs of your head are all numbered. [303]

Fear ye not therefore, ye are of more value than many sparrows. [304]

Whosoever therefore shall confess me before men, him will I confess also before my Father which is in heaven. [305]

But whosoever shall deny me before men, him will I also deny before my Father which is in heaven. [306]

Think not that I am come to send peace on earth: I came not to send peace, but a sword. [307]

For I am come to set a man at variance against his father, and the daughter against her mother, and the daughter in law against her mother in law. [308]

And a man's foes shall be they of his own household. [309]

He that loveth father or mother more than me is not worthy of me: and he that loveth son or daughter more than me is not worthy of me. [310]

And he that taketh not his cross, and followeth after me, is not worthy of me. [311]

He that findeth his life shall lose it: and he that loseth his life for my sake shall find it. [312]

He that receiveth you receiveth me, and he that receiveth me receiveth him that sent me. [313]

He that receiveth a prophet in the name of a prophet shall receive a prophet's reward; and he that receiveth a righteous man in the name of a righteous man shall receive a righteous man's reward. [314]

And whosoever shall give to drink unto one of these little ones a cup of cold water only in the name of a disciple, verily I say unto you, he shall in no wise lose his reward. [315]

§ Matthew 11

And it came to pass, when Jesus had made an end of commanding his twelve disciples, he departed thence to teach and to preach in their cities. [316]

Now when John had heard in the prison the works of Christ, he sent two of his disciples, [317]

And said unto him, Art thou he that should come, or do we look for another? [318]

Jesus answered and said unto them, Go and shew John again those things which ye do hear and see: [319]

The blind receive their sight, and the lame walk, the lepers are cleansed, and the deaf hear, the dead are raised up, and the poor have the gospel preached to them. [320]

And blessed is he, whosoever shall not be offended in me. [321]

And as they departed, Jesus began to say unto the multitudes concerning John, What went ye out into the wilderness to see? A reed shaken with the wind? [322]

But what went ye out for to see? A man clothed in soft raiment? behold, they that wear soft clothing are in kings' houses. [323]

But what went ye out for to see? A prophet? yea, I say unto you, and more than a prophet. [324]

For this is he, of whom it is written, Behold, I send my messenger before thy face, which shall prepare thy way before thee. [325]

Verily I say unto you, Among them that are born of women there hath not risen a greater than John the Baptist: notwithstanding he that is least in the kingdom of heaven is greater than he. [326]

And from the days of John the Baptist until now the kingdom of heaven suffereth violence, and the violent take it by force. [327]

For all the prophets and the law prophesied until John. [328]

And if ye will receive it, this is Elias, which was for to come. [329]

He that hath ears to hear, let him hear. [330]

But whereunto shall I liken this generation? It is like unto children sitting in the markets, and calling unto their fellows, [331]

And saying, We have piped unto you, and ye have not danced; we have mourned unto you, and ye have not lamented. [332]

For John came neither eating nor drinking, and they say, He hath a devil. [333]

The Son of man came eating and drinking, and they say, Behold a man gluttonous, and a winebibber, a friend of publicans and sinners. But wisdom is justified of her children. [334]

Then began he to upbraid the cities wherein most of his mighty works were done, because they repented not: [335]

Woe unto thee, Chorazin! woe unto thee, Bethsaida! for if the mighty works, which were done in you, had been done in Tyre and Sidon, they would have repented long ago in sackcloth and ashes. [336]

But I say unto you, It shall be more tolerable for Tyre and Sidon at the day of judgment, than for you. [337]

And thou, Capernaum, which art exalted unto heaven, shalt be brought down to hell: for if the mighty works, which have been done in thee, had been done in Sodom, it would have remained until this day. [338]

But I say unto you, That it shall be more tolerable for the land of Sodom in the day of judgment, than for thee. [339]

At that time Jesus answered and said, I thank thee, O Father, Lord of heaven and earth, because thou hast hid these things from the wise and prudent, and hast revealed them unto babes. [340]

Even so, Father: for so it seemed good in thy sight. [341]

All things are delivered unto me of my Father: and no man knoweth the Son, but the Father; neither knoweth any man the Father, save the Son, and he to whomsoever the Son will reveal him. [342]

Come unto me, all ye that labour and are heavy laden, and I will give you rest. [343]

Take my yoke upon you, and learn of me; for I am meek and lowly in heart: and ye shall find rest unto your souls. [344]

For my yoke is easy, and my burden is light. [345]

§ Matthew 12

At that time Jesus went on the sabbath day through the corn; and his disciples were an hungred, and began to pluck the ears of corn and to eat. [346]

But when the Pharisees saw it, they said unto him, Behold, thy disciples do that which is not lawful to do upon the sabbath day. [347]

But he said unto them, Have ye not read what David did, when he was an hungred, and they that were with him; [348]

How he entered into the house of God, and did eat the shewbread, which was not lawful for him to eat, neither for them which were with him, but only for the priests? [349]

Or have ye not read in the law, how that on the sabbath days the priests in the temple profane the sabbath, and are blameless? [350]

But I say unto you, That in this place is one greater than the temple. [351]

But if ye had known what this meaneth, I will have mercy, and not sacrifice, ye would not have condemned the guiltless. [352]

For the Son of man is Lord even of the sabbath day. [353]

And when he was departed thence, he went into their synagogue: [354]

And, behold, there was a man which had his hand withered. And they asked him, saying, Is it lawful to heal on the sabbath days? that they might accuse him. [355]

And he said unto them, What man shall there be among you, that shall have one sheep, and if it fall into a pit on the sabbath day, will he not lay hold on it, and lift it out? [356]

How much then is a man better than a sheep? Wherefore it is lawful to do well on the sabbath days. [357]

Then saith he to the man, Stretch forth thine hand. And he stretched it forth; and it was restored whole, like as the other. [358]

Then the Pharisees went out, and held a council against him, how they might destroy him. [359]

But when Jesus knew it, he withdrew himself from thence: and great multitudes followed him, and he healed them all; [360]

And charged them that they should not make him known: [361]

That it might be fulfilled which was spoken by Esaias the prophet, saying, [362]

Behold my servant, whom I have chosen; my beloved, in whom my soul is well pleased: I will put my spirit upon him, and he shall shew judgment to the Gentiles. [363]

He shall not strive, nor cry; neither shall any man hear his voice in the streets. [364]

A bruised reed shall he not break, and smoking flax shall he not quench, till he send forth judgment unto victory. [365]

And in his name shall the Gentiles trust. [366]

Then was brought unto him one possessed with a devil, blind, and dumb: and he healed him, insomuch that the blind and dumb both spake and saw. [367]

And all the people were amazed, and said, Is not this the son of David? [368]

But when the Pharisees heard it, they said, This fellow doth not cast out devils, but by Beelzebub the prince of the devils. [369]

And Jesus knew their thoughts, and said unto them, Every kingdom divided against itself is brought to desolation; and every city or house divided against itself shall not stand: [370]

And if Satan cast out Satan, he is divided against himself; how shall then his kingdom stand? [371]

And if I by Beelzebub cast out devils, by whom do your children cast them out? therefore they shall be your judges. [372]

But if I cast out devils by the Spirit of God, then the kingdom of God is come unto you. [373]

Or else how can one enter into a strong man's house, and spoil his goods, except he first bind the strong man? and then he will spoil his house. [374]

He that is not with me is against me; and he that gathereth not with me scattereth abroad. [375]

Wherefore I say unto you, All manner of sin and blasphemy shall be forgiven unto men: but the blasphemy against the Holy Ghost shall not be forgiven unto men. [376]

And whosoever speaketh a word against the Son of man, it shall be forgiven him: but whosoever speaketh against the Holy Ghost, it shall not be forgiven him, neither in this world, neither in the world to come. [377]

Either make the tree good, and his fruit good; or else make the tree corrupt, and his fruit corrupt: for the tree is known by his fruit. [378]

O generation of vipers, how can ye, being evil, speak good things? for out of the abundance of the heart the mouth speaketh. [379]

A good man out of the good treasure of the heart bringeth forth good things: and an evil man out of the evil treasure bringeth forth evil things. [380]

But I say unto you, That every idle word that men shall speak, they shall give account thereof in the day of judgment. [381]

For by thy words thou shalt be justified, and by thy words thou shalt be condemned. [382]

Then certain of the scribes and of the Pharisees answered, saying, Master, we would see a sign from thee. [383]

But he answered and said unto them, An evil and adulterous generation seeketh after a sign; and there shall no sign be given to it, but the sign of the prophet Jonas: [384]

For as Jonas was three days and three nights in the whale's belly; so shall the Son of man be three days and three nights in the heart of the earth. [385]

The men of Nineveh shall rise in judgment with this generation, and shall condemn it: because they repented at the preaching of Jonas; and, behold, a greater than Jonas is here. [386]

The queen of the south shall rise up in the judgment with this generation, and shall condemn it: for she came from the uttermost parts of the earth to hear the wisdom of Solomon; and, behold, a greater than Solomon is here. [387]

When the unclean spirit is gone out of a man, he walketh through dry places, seeking rest, and findeth none. [388]

Then he saith, I will return into my house from whence I came out; and when he is come, he findeth it empty, swept, and garnished. [389]

Then goeth he, and taketh with himself seven other spirits more wicked than himself, and they enter in and dwell there: and the last state of that man is worse than the first. Even so shall it be also unto this wicked generation. [390]

While he yet talked to the people, behold, his mother and his brethren stood without, desiring to speak with him. [391]

Then one said unto him, Behold, thy mother and thy brethren stand without, desiring to speak with thee. [392]

But he answered and said unto him that told him, Who is my mother? and who are my brethren? [393]

And he stretched forth his hand toward his disciples, and said, Behold my mother and my brethren! [394]

For whosoever shall do the will of my Father which is in heaven, the same is my brother, and sister, and mother. [395]

§ Matthew 13

The same day went Jesus out of the house, and sat by the sea side. [396]

And great multitudes were gathered together unto him, so that he went into a ship, and sat; and the whole multitude stood on the shore. [397]

And he spake many things unto them in parables, saying, Behold, a sower went forth to sow; [398]

And when he sowed, some seeds fell by the way side, and the fowls came and devoured them up: [399]

Some fell upon stony places, where they had not much earth: and forthwith they sprung up, because they had no deepness of earth: [400]

And when the sun was up, they were scorched; and because they had no root, they withered away. [401]

And some fell among thorns; and the thorns sprung up, and choked them: [402]

But other fell into good ground, and brought forth fruit, some an hundredfold, some sixtyfold, some thirtyfold. [403]

Who hath ears to hear, let him hear. [404]

And the disciples came, and said unto him, Why speakest thou unto them in parables? [405]

He answered and said unto them, Because it is given unto you to know the mysteries of the kingdom of heaven, but to them it is not given. [406]

For whosoever hath, to him shall be given, and he shall have more abundance: but whosoever hath not, from him shall be taken away even that he hath. [407]

Therefore speak I to them in parables: because they seeing see not; and hearing they hear not, neither do they understand. [408]

And in them is fulfilled the prophecy of Esaias, which saith, By hearing ye shall hear, and shall not understand; and seeing ye shall see, and shall not perceive: [409]

For this people's heart is waxed gross, and their ears are dull of hearing, and their eyes they have closed; lest at any time they should see with their eyes and hear with their ears, and should understand with their heart, and should be converted, and I should heal them. [410]

But blessed are your eyes, for they see: and your ears, for they hear. [411]

For verily I say unto you, That many prophets and righteous men have desired to see those things which ye see, and have not seen them; and to hear those things which ye hear, and have not heard them. [412]

Hear ye therefore the parable of the sower. [413]

When any one heareth the word of the kingdom, and understandeth it not, then cometh the wicked one, and catcheth away that which was sown in his heart. This is he which received seed by the way side. [414]

But he that received the seed into stony places, the same is he that heareth the word, and anon with joy receiveth it; [415]

Yet hath he not root in himself, but dureth for a while: for when tribulation or persecution ariseth because of the word, by and by he is offended. [416]

He also that received seed among the thorns is he that heareth the word; and the care of this world, and the deceitfulness of riches, choke the word, and he becometh unfruitful. [417]

But he that received seed into the good ground is he that heareth the word, and understandeth it; which also beareth fruit, and bringeth forth, some an hundredfold, some sixty, some thirty. [418]

Another parable put he forth unto them, saying, The kingdom of heaven is likened unto a man which sowed good seed in his field: [419]

But while men slept, his enemy came and sowed tares among the wheat, and went his way. [420]

But when the blade was sprung up, and brought forth fruit, then appeared the tares also. [421]

So the servants of the householder came and said unto him, Sir, didst not thou sow good seed in thy field? from whence then hath it tares? [422]

He said unto them, An enemy hath done this. The servants said unto him, Wilt thou then that we go and gather them up? [423]

But he said, Nay; lest while ye gather up the tares, ye root up also the wheat with them. [424]

Let both grow together until the harvest: and in the time of harvest I will say to the reapers, Gather ye together first the tares, and bind them in bundles to burn them: but gather the wheat into my barn. [425]

Another parable put he forth unto them, saying, The kingdom of heaven is like to a grain of mustard seed, which a man took, and sowed in his field: [426]

Which indeed is the least of all seeds: but when it is grown, it is the greatest among herbs, and becometh a tree, so that the birds of the air come and lodge in the branches thereof. [427]

Another parable spake he unto them; The kingdom of heaven is like unto leaven, which a woman took, and hid in three measures of meal, till the whole was leavened. [428]

All these things spake Jesus unto the multitude in parables; and without a parable spake he not unto them: [429]

That it might be fulfilled which was spoken by the prophet, saying, I will open my mouth in parables; I will utter things which have been kept secret from the foundation of the world. [430]

Then Jesus sent the multitude away, and went into the house: and his disciples came unto him, saying, Declare unto us the parable of the tares of the field. [431]

He answered and said unto them, He that soweth the good seed is the Son of man; [432]

The field is the world; the good seed are the children of the kingdom; but the tares are the children of the wicked one; [433]

The enemy that sowed them is the devil; the harvest is the end of the world; and the reapers are the angels. [434]

As therefore the tares are gathered and burned in the fire; so shall it be in the end of this world. [435]

The Son of man shall send forth his angels, and they shall gather out of his kingdom all things that offend, and them which do iniquity; [436]

And shall cast them into a furnace of fire: there shall be wailing and gnashing of teeth. [437]

Then shall the righteous shine forth as the sun in the kingdom of their Father. Who hath ears to hear, let him hear. [438]

Again, the kingdom of heaven is like unto treasure hid in a field; the which when a man hath found, he hideth, and for joy thereof goeth and selleth all that he hath, and buyeth that field. [439]

Again, the kingdom of heaven is like unto a merchant man, seeking goodly pearls: [440]

Who, when he had found one pearl of great price, went and sold all that he had, and bought it. [441]

Again, the kingdom of heaven is like unto a net, that was cast into the sea, and gathered of every kind: [442]

Which, when it was full, they drew to shore, and sat down, and gathered the good into vessels, but cast the bad away. [443]

So shall it be at the end of the world: the angels shall come forth, and sever the wicked from among the just, [444]

And shall cast them into the furnace of fire: there shall be wailing and gnashing of teeth. [445]

Jesus saith unto them, Have ye understood all these things? They say unto him, Yea, Lord. [446]

Then said he unto them, Therefore every scribe which is instructed unto the kingdom of heaven is like unto a man that is an householder, which bringeth forth out of his treasure things new and old. [447]

And it came to pass, that when Jesus had finished these parables, he departed thence. [448]

And when he was come into his own country, he taught them in their synagogue, insomuch that they were astonished, and said, Whence hath this man this wisdom, and these mighty works? [449]

Is not this the carpenter's son? is not his mother called Mary? and his brethren, James, and Joses, and Simon, and Judas? [450]

And his sisters, are they not all with us? Whence then hath this man all these things? [451]

And they were offended in him. But Jesus said unto them, A prophet is not without honour, save in his own country, and in his own house. [452]

And he did not many mighty works there because of their unbelief. [453]

§ Matthew 14

At that time Herod the tetrarch heard of the fame of Jesus, [454]

And said unto his servants, This is John the Baptist; he is risen from the dead; and therefore mighty works do shew forth themselves in him. [455]

For Herod had laid hold on John, and bound him, and put him in prison for Herodias' sake, his brother Philip's wife. [456]

For John said unto him, It is not lawful for thee to have her. [457]

And when he would have put him to death, he feared the multitude, because they counted him as a prophet. [458]

But when Herod's birthday was kept, the daughter of Herodias danced before them, and pleased Herod. [459]

Whereupon he promised with an oath to give her whatsoever she would ask. [460]

And she, being before instructed of her mother, said, Give me here John Baptist's head in a charger. [461]

And the king was sorry: nevertheless for the oath's sake, and them which sat with him at meat, he commanded it to be given her. [462]

And he sent, and beheaded John in the prison. [463]

And his head was brought in a charger, and given to the damsel: and she brought it to her mother. [464]

And his disciples came, and took up the body, and buried it, and went and told Jesus. [465]

When Jesus heard of it, he departed thence by ship into a desert place apart: and when the people had heard thereof, they followed him on foot out of the cities. [466]

And Jesus went forth, and saw a great multitude, and was moved with compassion toward them, and he healed their sick. [467]

And when it was evening, his disciples came to him, saying, This is a desert place, and the time is now past; send the multitude away, that they may go into the villages, and buy themselves victuals. [468]

But Jesus said unto them, They need not depart; give ye them to eat. [469]

And they say unto him, We have here but five loaves, and two fishes. [470]

He said, Bring them hither to me. [471]

And he commanded the multitude to sit down on the grass, and took the five loaves, and the two fishes, and looking up to heaven, he blessed, and brake, and gave the loaves to his disciples, and the disciples to the multitude. [472]

And they did all eat, and were filled: and they took up of the fragments that remained twelve baskets full. [473]

And they that had eaten were about five thousand men, beside women and children. [474]

And straightway Jesus constrained his disciples to get into a ship, and to go before him unto the other side, while he sent the multitudes away. [475]

And when he had sent the multitudes away, he went up into a mountain apart to pray: and when the evening was come, he was there alone. [476]

But the ship was now in the midst of the sea, tossed with waves: for the wind was contrary. [477]

And in the fourth watch of the night Jesus went unto them, walking on the sea. [478]

And when the disciples saw him walking on the sea, they were troubled, saying, It is a spirit; and they cried out for fear. [479]

But straightway Jesus spake unto them, saying, Be of good cheer; it is I; be not afraid. [480]

And Peter answered him and said, Lord, if it be thou, bid me come unto thee on the water. [481]

And he said, Come. And when Peter was come down out of the ship, he walked on the water, to go to Jesus. [482]

But when he saw the wind boisterous, he was afraid; and beginning to sink, he cried, saying, Lord, save me. [483]

And immediately Jesus stretched forth his hand, and caught him, and said unto him, O thou of little faith, wherefore didst thou doubt? [484]

And when they were come into the ship, the wind ceased. [485]

Then they that were in the ship came and worshipped him, saying, Of a truth thou art the Son of God. [486]

And when they were gone over, they came into the land of Gennesaret. [487]

And when the men of that place had knowledge of him, they sent out into all that country round about, and brought unto him all that were diseased; [488]

And besought him that they might only touch the hem of his garment: and as many as touched were made perfectly whole. [489]

§ Matthew 15

Then came to Jesus scribes and Pharisees, which were of Jerusalem, saying, [490]

Why do thy disciples transgress the tradition of the elders? for they wash not their hands when they eat bread. [491]

But he answered and said unto them, Why do ye also transgress the commandment of God by your tradition? [492]

For God commanded, saying, Honour thy father and mother: and, He that curseth father or mother, let him die the death. [493]

But ye say, Whosoever shall say to his father or his mother, It is a gift, by whatsoever thou mightest be profited by me; [494]

And honour not his father or his mother, he shall be free. Thus have ye made the commandment of God of none effect by your tradition. [495]

Ye hypocrites, well did Esaias prophesy of you, saying, [496]

This people draweth nigh unto me with their mouth, and honoureth me with their lips; but their heart is far from me. [497]

But in vain they do worship me, teaching for doctrines the commandments of men. [498]

And he called the multitude, and said unto them, Hear, and understand: [499]

Not that which goeth into the mouth defileth a man; but that which cometh out of the mouth, this defileth a man. [500]

Then came his disciples, and said unto him, Knowest thou that the Pharisees were offended, after they heard this saying? [501]

But he answered and said, Every plant, which my heavenly Father hath not planted, shall be rooted up. [502]

Let them alone: they be blind leaders of the blind. And if the blind lead the blind, both shall fall into the ditch. [503]

Then answered Peter and said unto him, Declare unto us this parable. [504]

And Jesus said, Are ye also yet without understanding? [505]

Do not ye yet understand, that whatsoever entereth in at the mouth goeth into the belly, and is cast out into the draught? [506]

But those things which proceed out of the mouth come forth from the heart; and they defile the man. [507]

For out of the heart proceed evil thoughts, murders, adulteries, fornications, thefts, false witness, blasphemies: [508]

These are the things which defile a man: but to eat with unwashen hands defileth not a man. [509]

Then Jesus went thence, and departed into the coasts of Tyre and Sidon. [510]

And, behold, a woman of Canaan came out of the same coasts, and cried unto him, saying, Have mercy on me, O Lord, thou son of David; my daughter is grievously vexed with a devil. [511]

But he answered her not a word. And his disciples came and besought him, saying, Send her away; for she crieth after us. [512]

But he answered and said, I am not sent but unto the lost sheep of the house of Israel. [513]

Then came she and worshipped him, saying, Lord, help me. [514]

But he answered and said, It is not meet to take the children's bread, and to cast it to dogs. [515]

And she said, Truth, Lord: yet the dogs eat of the crumbs which fall from their masters' table. [516]

Then Jesus answered and said unto her, O woman, great is thy faith: be it unto thee even as thou wilt. And her daughter was made whole from that very hour. [517]

And Jesus departed from thence, and came nigh unto the sea of Galilee; and went up into a mountain, and sat down there. [518]

And great multitudes came unto him, having with them those that were lame, blind, dumb, maimed, and many others, and cast them down at Jesus' feet; and he healed them: [519]

Insomuch that the multitude wondered, when they saw the dumb to speak, the maimed to be whole, the lame to walk, and the blind to see: and they glorified the God of Israel. [520]

Then Jesus called his disciples unto him, and said, I have compassion on the multitude, because they continue with me now three days, and have nothing to eat: and I will not send them away fasting, lest they faint in the way. [521]

And his disciples say unto him, Whence should we have so much bread in the wilderness, as to fill so great a multitude? [522]

And Jesus saith unto them, How many loaves have ye? And they said, Seven, and a few little fishes. [523]

And he commanded the multitude to sit down on the ground. [524]

And he took the seven loaves and the fishes, and gave thanks, and brake them, and gave to his disciples, and the disciples to the multitude. [525]

And they did all eat, and were filled: and they took up of the broken meat that was left seven baskets full. [526]

And they that did eat were four thousand men, beside women and children. [527]

And he sent away the multitude, and took ship, and came into the coasts of Magdala. [528]

§ Matthew 16

The Pharisees also with the Sadducees came, and tempting desired him that he would shew them a sign from heaven. [529]

He answered and said unto them, When it is evening, ye say, It will be fair weather: for the sky is red. [530]

And in the morning, It will be foul weather to day: for the sky is red and lowering. O ye hypocrites, ye can discern the face of the sky; but can ye not discern the signs of the times? [531]

A wicked and adulterous generation seeketh after a sign; and there shall no sign be given unto it, but the sign of the prophet Jonas. And he left them, and departed. [532]

And when his disciples were come to the other side, they had forgotten to take bread. [533]

Then Jesus said unto them, Take heed and beware of the leaven of the Pharisees and of the Sadducees. [534]

And they reasoned among themselves, saying, It is because we have taken no bread. [535]

Which when Jesus perceived, he said unto them, O ye of little faith, why reason ye among yourselves, because ye have brought no bread? [536]

Do ye not yet understand, neither remember the five loaves of the five thousand, and how many baskets ye took up? [537]

Neither the seven loaves of the four thousand, and how many baskets ye took up? [538]

How is it that ye do not understand that I spake it not to you concerning bread, that ye should beware of the leaven of the Pharisees and of the Sadducees? [539]

Then understood they how that he bade them not beware of the leaven of bread, but of the doctrine of the Pharisees and of the Sadducees. [540]

When Jesus came into the coasts of Caesarea Philippi, he asked his disciples, saying, Whom do men say that I the Son of man am? [541]

And they said, Some say that thou art John the Baptist: some, Elias; and others, Jeremias, or one of the prophets. [542]

He saith unto them, But whom say ye that I am? [543]

And Simon Peter answered and said, Thou art the Christ, the Son of the living God. [544]

And Jesus answered and said unto him, Blessed art thou, Simon Barjona: for flesh and blood hath not revealed it unto thee, but my Father which is in heaven. [545]

And I say also unto thee, That thou art Peter, and upon this rock I will build my church; and the gates of hell shall not prevail against it. [546]

And I will give unto thee the keys of the kingdom of heaven: and whatsoever thou shalt bind on earth shall be bound in heaven: and whatsoever thou shalt loose on earth shall be loosed in heaven. [547]

Then charged he his disciples that they should tell no man that he was Jesus the Christ. [548]

From that time forth began Jesus to shew unto his disciples, how that he must go unto Jerusalem, and suffer many things of the elders and chief priests and scribes, and be killed, and be raised again the third day. [549]

Then Peter took him, and began to rebuke him, saying, Be it far from thee, Lord: this shall not be unto thee. [550]

But he turned, and said unto Peter, Get thee behind me, Satan: thou art an offence unto me: for thou savourest not the things that be of God, but those that be of men. [551]

Then said Jesus unto his disciples, If any man will come after me, let him deny himself, and take up his cross, and follow me. [552]

For whosoever will save his life shall lose it: and whosoever will lose his life for my sake shall find it. [553]

For what is a man profited, if he shall gain the whole world, and lose his own soul? or what shall a man give in exchange for his soul? [554]

For the Son of man shall come in the glory of his Father with his angels; and then he shall reward every man according to his works. [555]

Verily I say unto you, There be some standing here, which shall not taste of death, till they see the Son of man coming in his kingdom. [556]

§ Matthew 17

And after six days Jesus taketh Peter, James, and John his brother, and bringeth them up into an high mountain apart, [557]

And was transfigured before them: and his face did shine as the sun, and his raiment was white as the light. [558]

And, behold, there appeared unto them Moses and Elias talking with him. [559]

Then answered Peter, and said unto Jesus, Lord, it is good for us to be here: if thou wilt, let us make here three tabernacles; one for thee, and one for Moses, and one for Elias. [560]

While he yet spake, behold, a bright cloud overshadowed them: and behold a voice out of the cloud, which said, This is my beloved Son, in whom I am well pleased; hear ye him. [561]

And when the disciples heard it, they fell on their face, and were sore afraid. [562]

And Jesus came and touched them, and said, Arise, and be not afraid. [563]

And when they had lifted up their eyes, they saw no man, save Jesus only. [564]

And as they came down from the mountain, Jesus charged them, saying, Tell the vision to no man, until the Son of man be risen again from the dead. [565]

And his disciples asked him, saying, Why then say the scribes that Elias must first come? [566]

And Jesus answered and said unto them, Elias truly shall first come, and restore all things. [567]

But I say unto you, That Elias is come already, and they knew him not, but have done unto him whatsoever they listed. Likewise shall also the Son of man suffer of them. [568]

Then the disciples understood that he spake unto them of John the Baptist. [569]

And when they were come to the multitude, there came to him a certain man, kneeling down to him, and saying, [570]

Lord, have mercy on my son: for he is lunatick, and sore vexed: for ofttimes he falleth into the fire, and oft into the water. [571]

And I brought him to thy disciples, and they could not cure him. [572]

Then Jesus answered and said, O faithless and perverse generation, how long shall I be with you? how long shall I suffer you? bring him hither to me. [573]

And Jesus rebuked the devil; and he departed out of him: and the child was cured from that very hour. [574]

Then came the disciples to Jesus apart, and said, Why could not we cast him out? [575]

And Jesus said unto them, Because of your unbelief: for verily I say unto you, If ye have faith as a grain of mustard seed, ye shall say unto this mountain, Remove hence to yonder place; and it shall remove; and nothing shall be impossible unto you. [576]

Howbeit this kind goeth not out but by prayer and fasting. [577]

And while they abode in Galilee, Jesus said unto them, The Son of man shall be betrayed into the hands of men: [578]

And they shall kill him, and the third day he shall be raised again. And they were exceeding sorry. [579]

And when they were come to Capernaum, they that received tribute money came to Peter, and said, Doth not your master pay tribute? [580]

He saith, Yes. And when he was come into the house, Jesus prevented him, saying, What thinkest thou, Simon? of whom do the kings of the earth take custom or tribute? of their own children, or of strangers? [581]

Peter saith unto him, Of strangers. Jesus saith unto him, Then are the children free. [582]

Notwithstanding, lest we should offend them, go thou to the sea, and cast an hook, and take up the fish that first cometh up; and when thou hast opened his mouth, thou shalt find a piece of money: that take, and give unto them for me and thee. [583]

§ Matthew 18

At the same time came the disciples unto Jesus, saying, Who is the greatest in the kingdom of heaven? [584]

And Jesus called a little child unto him, and set him in the midst of them, [585]

And said, Verily I say unto you, Except ye be converted, and become as little children, ye shall not enter into the kingdom of heaven. [586]

Whosoever therefore shall humble himself as this little child, the same is greatest in the kingdom of heaven. [587]

And whoso shall receive one such little child in my name receiveth me. [588]

But whoso shall offend one of these little ones which believe in me, it were better for him that a millstone were hanged about his neck, and that he were drowned in the depth of the sea. [589]

Woe unto the world because of offences! for it must needs be that offences come; but woe to that man by whom the offence cometh! [590]

Wherefore if thy hand or thy foot offend thee, cut them off, and cast them from thee: it is better for thee to enter into life halt or maimed, rather than having two hands or two feet to be cast into everlasting fire. [591]

And if thine eye offend thee, pluck it out, and cast it from thee: it is better for thee to enter into life with one eye, rather than having two eyes to be cast into hell fire. [592]

Take heed that ye despise not one of these little ones; for I say unto you, That in heaven their angels do always behold the face of my Father which is in heaven. [593]

For the Son of man is come to save that which was lost. [594]

How think ye? if a man have an hundred sheep, and one of them be gone astray, doth he not leave the ninety and nine, and goeth into the mountains, and seeketh that which is gone astray? [595]

And if so be that he find it, verily I say unto you, he rejoiceth more of that sheep, than of the ninety and nine which went not astray. [596]

Even so it is not the will of your Father which is in heaven, that one of these little ones should perish. [597]

Moreover if thy brother shall trespass against thee, go and tell him his fault between thee and him alone: if he shall hear thee, thou hast gained thy brother. [598]

But if he will not hear thee, then take with thee one or two more, that in the mouth of two or three witnesses every word may be established. [599]

And if he shall neglect to hear them, tell it unto the church: but if he neglect to hear the church, let him be unto thee as an heathen man and a publican. [600]

Verily I say unto you, Whatsoever ye shall bind on earth shall be bound in heaven: and whatsoever ye shall loose on earth shall be loosed in heaven. [601]

Again I say unto you, That if two of you shall agree on earth as touching any thing that they shall ask, it shall be done for them of my Father which is in heaven. [602]

For where two or three are gathered together in my name, there am I in the midst of them. [603]

Then came Peter to him, and said, Lord, how oft shall my brother sin against me, and I forgive him? till seven times? [604]

Jesus saith unto him, I say not unto thee, Until seven times: but, Until seventy times seven. [605]

Therefore is the kingdom of heaven likened unto a certain king, which would take account of his servants. [606]

And when he had begun to reckon, one was brought unto him, which owed him ten thousand talents. [607]

But forasmuch as he had not to pay, his lord commanded him to be sold, and his wife, and children, and all that he had, and payment to be made. [608]

The servant therefore fell down, and worshipped him, saying, Lord, have patience with me, and I will pay thee all. [609]

Then the lord of that servant was moved with compassion, and loosed him, and forgave him the debt. [610]

But the same servant went out, and found one of his fellowservants, which owed him an hundred pence: and he laid hands on him, and took him by the throat, saying, Pay me that thou owest. [611]

And his fellowservant fell down at his feet, and besought him, saying, Have patience with me, and I will pay thee all. [612]

And he would not: but went and cast him into prison, till he should pay the debt. [613]

So when his fellowservants saw what was done, they were very sorry, and came and told unto their lord all that was done. [614]

Then his lord, after that he had called him, said unto him, O thou wicked servant, I forgave thee all that debt, because thou desiredst me: [615]

Shouldest not thou also have had compassion on thy fellowservant, even as I had pity on thee? [616]

And his lord was wroth, and delivered him to the tormentors, till he should pay all that was due unto him. [617]

So likewise shall my heavenly Father do also unto you, if ye from your hearts forgive not every one his brother their trespasses. [618]

§ Matthew 19

And it came to pass, that when Jesus had finished these sayings, he departed from Galilee, and came into the coasts of Judaea beyond Jordan; [619]

And great multitudes followed him; and he healed them there. [620]

The Pharisees also came unto him, tempting him, and saying unto him, Is it lawful for a man to put away his wife for every cause? [621]

And he answered and said unto them, Have ye not read, that he which made them at the beginning made them male and female, [622]

And said, For this cause shall a man leave father and mother, and shall cleave to his wife: and they twain shall be one flesh? [623]

Wherefore they are no more twain, but one flesh. What therefore God hath joined together, let not man put asunder. [624]

They say unto him, Why did Moses then command to give a writing of divorcement, and to put her away? [625]

He saith unto them, Moses because of the hardness of your hearts suffered you to put away your wives: but from the beginning it was not so. [626]

And I say unto you, Whosoever shall put away his wife, except it be for fornication, and shall marry another, committeth adultery: and whoso marrieth her which is put away doth commit adultery. [627]

His disciples say unto him, If the case of the man be so with his wife, it is not good to marry. [628]

But he said unto them, All men cannot receive this saying, save they to whom it is given. [629]

For there are some eunuchs, which were so born from their mother's womb: and there are some eunuchs, which were made eunuchs of men: and there be eunuchs, which have made themselves eunuchs for the kingdom of heaven's sake. He that is able to receive it, let him receive it. [630]

Then were there brought unto him little children, that he should put his hands on them, and pray: and the disciples rebuked them. [631]

But Jesus said, Suffer little children, and forbid them not, to come unto me: for of such is the kingdom of heaven. [632]

And he laid his hands on them, and departed thence. [633]

And, behold, one came and said unto him, Good Master, what good thing shall I do, that I may have eternal life? [634]

And he said unto him, Why callest thou me good? there is none good but one, that is, God: but if thou wilt enter into life, keep the commandments. [635]

He saith unto him, Which? Jesus said, Thou shalt do no murder, Thou shalt not commit adultery, Thou shalt not steal, Thou shalt not bear false witness, [636]

Honour thy father and thy mother: and, Thou shalt love thy neighbour as thyself. [637]

The young man saith unto him, All these things have I kept from my youth up: what lack I yet? [638]

Jesus said unto him, If thou wilt be perfect, go and sell that thou hast, and give to the poor, and thou shalt have treasure in heaven: and come and follow me. [639]

But when the young man heard that saying, he went away sorrowful: for he had great possessions. [640]

Then said Jesus unto his disciples, Verily I say unto you, That a rich man shall hardly enter into the kingdom of heaven. [641]

And again I say unto you, It is easier for a camel to go through the eye of a needle, than for a rich man to enter into the kingdom of God. [642]

When his disciples heard it, they were exceedingly amazed, saying, Who then can be saved? [643]

But Jesus beheld them, and said unto them, With men this is impossible; but with God all things are possible. [644]

Then answered Peter and said unto him, Behold, we have forsaken all, and followed thee; what shall we have therefore? [645]

And Jesus said unto them, Verily I say unto you, That ye which have followed me, in the regeneration when the Son of man shall sit in the throne of his glory, ye also shall sit upon twelve thrones, judging the twelve tribes of Israel. [646]

And every one that hath forsaken houses, or brethren, or sisters, or father, or mother, or wife, or children, or lands, for my name's sake, shall receive an hundredfold, and shall inherit everlasting life. [647]

But many that are first shall be last; and the last shall be first. [648]

§ Matthew 20

For the kingdom of heaven is like unto a man that is an householder, which went out early in the morning to hire labourers into his vineyard. [649]

And when he had agreed with the labourers for a penny a day, he sent them into his vineyard. [650]

And he went out about the third hour, and saw others standing idle in the marketplace, [651]

And said unto them; Go ye also into the vineyard, and whatsoever is right I will give you. And they went their way. [652]

Again he went out about the sixth and ninth hour, and did likewise. [653]

And about the eleventh hour he went out, and found others standing idle, and saith unto them, Why stand ye here all the day idle? [654]

They say unto him, Because no man hath hired us. He saith unto them, Go ye also into the vineyard; and whatsoever is right, that shall ye receive. [655]

So when even was come, the lord of the vineyard saith unto his steward, Call the labourers, and give them their hire, beginning from the last unto the first. [656]

And when they came that were hired about the eleventh hour, they received every man a penny. [657]

But when the first came, they supposed that they should have received more; and they likewise received every man a penny. [658]

And when they had received it, they murmured against the goodman of the house, [659]

Saying, These last have wrought but one hour, and thou hast made them equal unto us, which have borne the burden and heat of the day. [660]

But he answered one of them, and said, Friend, I do thee no wrong: didst not thou agree with me for a penny? [661]

Take that thine is, and go thy way: I will give unto this last, even as unto thee. [662]

Is it not lawful for me to do what I will with mine own? Is thine eye evil, because I am good? [663]

So the last shall be first, and the first last: for many be called, but few chosen. [664]

And Jesus going up to Jerusalem took the twelve disciples apart in the way, and said unto them, [665]

Behold, we go up to Jerusalem; and the Son of man shall be betrayed unto the chief priests and unto the scribes, and they shall condemn him to death, [666]

And shall deliver him to the Gentiles to mock, and to scourge, and to crucify him: and the third day he shall rise again. [667]

Then came to him the mother of Zebedees children with her sons, worshipping him, and desiring a certain thing of him. [668]

And he said unto her, What wilt thou? She saith unto him, Grant that these my two sons may sit, the one on thy right hand, and the other on the left, in thy kingdom. [669]

But Jesus answered and said, Ye know not what ye ask. Are ye able to drink of the cup that I shall drink of, and to be baptized with the baptism that I am baptized with? They say unto him, We are able. [670]

And he saith unto them, Ye shall drink indeed of my cup, and be baptized with the baptism that I am baptized with: but to sit on my right hand, and on my left, is not mine to give, but it shall be given to them for whom it is prepared of my Father. [671]

And when the ten heard it, they were moved with indignation against the two brethren. [672]

But Jesus called them unto him, and said, Ye know that the princes of the Gentiles exercise dominion over them, and they that are great exercise authority upon them. [673]

But it shall not be so among you: but whosoever will be great among you, let him be your minister; [674]

And whosoever will be chief among you, let him be your servant: [675]

Even as the Son of man came not to be ministered unto, but to minister, and to give his life a ransom for many. [676]

And as they departed from Jericho, a great multitude followed him. [677]

And, behold, two blind men sitting by the way side, when they heard that Jesus passed by, cried out, saying, Have mercy on us, O Lord, thou son of David. [678]

And the multitude rebuked them, because they should hold their peace: but they cried the more, saying, Have mercy on us, O Lord, thou son of David. [679]

And Jesus stood still, and called them, and said, What will ye that I shall do unto you? [680]

They say unto him, Lord, that our eyes may be opened. [681]

So Jesus had compassion on them, and touched their eyes: and immediately their eyes received sight, and they followed him. [682]

§ Matthew 21

And when they drew nigh unto Jerusalem, and were come to Bethphage, unto the mount of Olives, then sent Jesus two disciples, [683]

Saying unto them, Go into the village over against you, and straightway ye shall find an ass tied, and a colt with her: loose them, and bring them unto me. [684]

And if any man say ought unto you, ye shall say, The Lord hath need of them; and straightway he will send them. [685]

All this was done, that it might be fulfilled which was spoken by the prophet, saying, [686]

Tell ye the daughter of Sion, Behold, thy King cometh unto thee, meek, and sitting upon an ass, and a colt the foal of an ass. [687]

And the disciples went, and did as Jesus commanded them, [688]

And brought the ass, and the colt, and put on them their clothes, and they set him thereon. [689]

And a very great multitude spread their garments in the way; others cut down branches from the trees, and strawed them in the way. [690]

And the multitudes that went before, and that followed, cried, saying, Hosanna to the son of David: Blessed is he that cometh in the name of the Lord; Hosanna in the highest. [691]

And when he was come into Jerusalem, all the city was moved, saying, Who is this? [692]

And the multitude said, This is Jesus the prophet of Nazareth of Galilee. [693]

And Jesus went into the temple of God, and cast out all them that sold and bought in the temple, and overthrew the tables of the moneychangers, and the seats of them that sold doves, [694]

And said unto them, It is written, My house shall be called the house of prayer; but ye have made it a den of thieves. [695]

And the blind and the lame came to him in the temple; and he healed them. [696]

And when the chief priests and scribes saw the wonderful things that he did, and the children crying in the temple, and saying, Hosanna to the son of David; they were sore displeased, [697]

And said unto him, Hearest thou what these say? And Jesus saith unto them, Yea; have ye never read, Out of the mouth of babes and sucklings thou hast perfected praise? [698]

And he left them, and went out of the city into Bethany; and he lodged there. [699]

Now in the morning as he returned into the city, he hungered. [700]

And when he saw a fig tree in the way, he came to it, and found nothing thereon, but leaves only, and said unto it, Let no fruit grow on thee henceforward for ever. And presently the fig tree withered away. [701]

And when the disciples saw it, they marvelled, saying, How soon is the fig tree withered away! [702]

Jesus answered and said unto them, Verily I say unto you, If ye have faith, and doubt not, ye shall not only do this which is done to the fig tree, but also if ye shall say unto this mountain, Be thou removed, and be thou cast into the sea; it shall be done. [703]

And all things, whatsoever ye shall ask in prayer, believing, ye shall receive. [704]

And when he was come into the temple, the chief priests and the elders of the people came unto him as he was teaching, and said, By what authority doest thou these things? and who gave thee this authority? [705]

And Jesus answered and said unto them, I also will ask you one thing, which if ye tell me, I in like wise will tell you by what authority I do these things. [706]

The baptism of John, whence was it? from heaven, or of men? And they reasoned with themselves, saying, If we shall say, From heaven; he will say unto us, Why did ye not then believe him? [707]

But if we shall say, Of men; we fear the people; for all hold John as a prophet. [708]

And they answered Jesus, and said, We cannot tell. And he said unto them, Neither tell I you by what authority I do these things. [709]

But what think ye? A certain man had two sons; and he came to the first, and said, Son, go work to day in my vineyard. [710]

He answered and said, I will not: but afterward he repented, and went. [711]

And he came to the second, and said likewise. And he answered and said, I go, sir: and went not. [712]

Whether of them twain did the will of his father? They say unto him, The first. Jesus saith unto them, Verily I say unto you, That the publicans and the harlots go into the kingdom of God before you. [713]

For John came unto you in the way of righteousness, and ye believed him not: but the publicans and the harlots believed him: and ye, when ye had seen it, repented not afterward, that ye might believe him. [714]

Hear another parable: There was a certain householder, which planted a vineyard, and hedged it round about, and digged a winepress in it, and built a tower, and let it out to husbandmen, and went into a far country: [715]

And when the time of the fruit drew near, he sent his servants to the husbandmen, that they might receive the fruits of it. [716]

And the husbandmen took his servants, and beat one, and killed another, and stoned another. [717]

Again, he sent other servants more than the first: and they did unto them likewise. [718]

But last of all he sent unto them his son, saying, They will reverence my son. [719]

But when the husbandmen saw the son, they said among themselves, This is the heir; come, let us kill him, and let us seize on his inheritance. [720]

And they caught him, and cast him out of the vineyard, and slew him. [721]

When the lord therefore of the vineyard cometh, what will he do unto those husbandmen? [722]

They say unto him, He will miserably destroy those wicked men, and will let out his vineyard unto other husbandmen, which shall render him the fruits in their seasons. [723]

Jesus saith unto them, Did ye never read in the scriptures, The stone which the builders rejected, the same is become the head of the corner: this is the Lord's doing, and it is marvellous in our eyes? [724]

Therefore say I unto you, The kingdom of God shall be taken from you, and given to a nation bringing forth the fruits thereof. [725]

And whosoever shall fall on this stone shall be broken: but on whomsoever it shall fall, it will grind him to powder. [726]

And when the chief priests and Pharisees had heard his parables, they perceived that he spake of them. [727]

But when they sought to lay hands on him, they feared the multitude, because they took him for a prophet. [728]

§ Matthew 22

And Jesus answered and spake unto them again by parables, and said, [729]

The kingdom of heaven is like unto a certain king, which made a marriage for his son, [730]

And sent forth his servants to call them that were bidden to the wedding: and they would not come. [731]

Again, he sent forth other servants, saying, Tell them which are bidden, Behold, I have prepared my dinner: my oxen and my fatlings are killed, and all things are ready: come unto the marriage. [732]

But they made light of it, and went their ways, one to his farm, another to his merchandise: [733]

And the remnant took his servants, and entreated them spitefully, and slew them. [734]

But when the king heard thereof, he was wroth: and he sent forth his armies, and destroyed those murderers, and burned up their city. [735]

Then saith he to his servants, The wedding is ready, but they which were bidden were not worthy. [736]

Go ye therefore into the highways, and as many as ye shall find, bid to the marriage. [737]

So those servants went out into the highways, and gathered together all as many as they found, both bad and good: and the wedding was furnished with guests. [738]

And when the king came in to see the guests, he saw there a man which had not on a wedding garment: [739]

And he saith unto him, Friend, how camest thou in hither not having a wedding garment? And he was speechless. [740]

Then said the king to the servants, Bind him hand and foot, and take him away, and cast him into outer darkness, there shall be weeping and gnashing of teeth. [741]

For many are called, but few are chosen. [742]

Then went the Pharisees, and took counsel how they might entangle him in his talk. [743]

And they sent out unto him their disciples with the Herodians, saying, Master, we know that thou art true, and teachest the way of God in truth, neither carest thou for any man: for thou regardest not the person of men. [744]

Tell us therefore, What thinkest thou? Is it lawful to give tribute unto Caesar, or not? [745]

But Jesus perceived their wickedness, and said, Why tempt ye me, ye hypocrites? [746]

Shew me the tribute money. And they brought unto him a penny. [747]

And he saith unto them, Whose is this image and superscription? [748]

They say unto him, Caesar's. Then saith he unto them, Render therefore unto Caesar the things which are Caesar's; and unto God the things that are God's. [749]

When they had heard these words, they marvelled, and left him, and went their way. [750]

The same day came to him the Sadducees, which say that there is no resurrection, and asked him, [751]

Saying, Master, Moses said, If a man die, having no children, his brother shall marry his wife, and raise up seed unto his brother. [752]

Now there were with us seven brethren: and the first, when he had married a wife, deceased, and, having no issue, left his wife unto his brother: [753]

Likewise the second also, and the third, unto the seventh. [754]

And last of all the woman died also. [755]

Therefore in the resurrection whose wife shall she be of the seven? for they all had her. [756]

Jesus answered and said unto them, Ye do err, not knowing the scriptures, nor the power of God. [757]

For in the resurrection they neither marry, nor are given in marriage, but are as the angels of God in heaven. [758]

But as touching the resurrection of the dead, have ye not read that which was spoken unto you by God, saying, [759]

I am the God of Abraham, and the God of Isaac, and the God of Jacob? God is not the God of the dead, but of the living. [760]

And when the multitude heard this, they were astonished at his doctrine. [761]

But when the Pharisees had heard that he had put the Sadducees to silence, they were gathered together. [762]

Then one of them, which was a lawyer, asked him a question, tempting him, and saying, [763]

Master, which is the great commandment in the law? [764]

Jesus said unto him, Thou shalt love the Lord thy God with all thy heart, and with all thy soul, and with all thy mind. [765]

This is the first and great commandment. [766]

And the second is like unto it, Thou shalt love thy neighbour as thyself. [767]

On these two commandments hang all the law and the prophets. [768]

While the Pharisees were gathered together, Jesus asked them, [769]

Saying, What think ye of Christ? whose son is he? They say unto him, The son of David. [770]

He saith unto them, How then doth David in spirit call him Lord, saying, [771]

The LORD said unto my Lord, Sit thou on my right hand, till I make thine enemies thy footstool? [772]

If David then call him Lord, how is he his son? [773]

And no man was able to answer him a word, neither durst any man from that day forth ask him any more questions. [774]

§ Matthew 23

Then spake Jesus to the multitude, and to his disciples, [775]

Saying The scribes and the Pharisees sit in Moses' seat: [776]

All therefore whatsoever they bid you observe, that observe and do; but do not ye after their works: for they say, and do not. [777]

For they bind heavy burdens and grievous to be borne, and lay them on men's shoulders; but they themselves will not move them with one of their fingers. [778]

But all their works they do for to be seen of men: they make broad their phylacteries, and enlarge the borders of their garments, [779]

And love the uppermost rooms at feasts, and the chief seats in the synagogues, [780]

And greetings in the markets, and to be called of men, Rabbi, Rabbi. [781]

But be not ye called Rabbi: for one is your Master, even Christ; and all ye are brethren. [782]

And call no man your father upon the earth: for one is your Father, which is in heaven. [783]

Neither be ye called masters: for one is your Master, even Christ. [784]

But he that is greatest among you shall be your servant. [785]

And whosoever shall exalt himself shall be abased; and he that shall humble himself shall be exalted. [786]

But woe unto you, scribes and Pharisees, hypocrites! for ye shut up the kingdom of heaven against men: for ye neither go in yourselves, neither suffer ye them that are entering to go in. [787]

Woe unto you, scribes and Pharisees, hypocrites! for ye devour widows' houses, and for a pretence make long prayer: therefore ye shall receive the greater damnation. [788]

Woe unto you, scribes and Pharisees, hypocrites! for ye compass sea and land to make one proselyte, and when he is made, ye make him twofold more the child of hell than yourselves. [789]

Woe unto you, ye blind guides, which say, Whosoever shall swear by the temple, it is nothing; but whosoever shall swear by the gold of the temple, he is a debtor! [790]

Ye fools and blind: for whether is greater, the gold, or the temple that sanctifieth the gold? [791]

And, Whosoever shall swear by the altar, it is nothing; but whosoever sweareth by the gift that is upon it, he is guilty. [792]

Ye fools and blind: for whether is greater, the gift, or the altar that sanctifieth the gift? [793]

Whoso therefore shall swear by the altar, sweareth by it, and by all things thereon. [794]

And whoso shall swear by the temple, sweareth by it, and by him that dwelleth therein. [795]

And he that shall swear by heaven, sweareth by the throne of God, and by him that sitteth thereon. [796]

Woe unto you, scribes and Pharisees, hypocrites! for ye pay tithe of mint and anise and cummin, and have omitted the weightier matters of the law, judgment, mercy, and faith: these ought ye to have done, and not to leave the other undone. [797]

Ye blind guides, which strain at a gnat, and swallow a camel. [798]

Woe unto you, scribes and Pharisees, hypocrites! for ye make clean the outside of the cup and of the platter, but within they are full of extortion and excess. [799]

Thou blind Pharisee, cleanse first that which is within the cup and platter, that the outside of them may be clean also. [800]

Woe unto you, scribes and Pharisees, hypocrites! for ye are like unto whited sepulchres, which indeed appear beautiful outward, but are within full of dead men's bones, and of all uncleanness. [801]

Even so ye also outwardly appear righteous unto men, but within ye are full of hypocrisy and iniquity. [802]

Woe unto you, scribes and Pharisees, hypocrites! because ye build the tombs of the prophets, and garnish the sepulchres of the righteous, [803]

And say, If we had been in the days of our fathers, we would not have been partakers with them in the blood of the prophets. [804]

Wherefore ye be witnesses unto yourselves, that ye are the children of them which killed the prophets. [805]

Fill ye up then the measure of your fathers. [806]

Ye serpents, ye generation of vipers, how can ye escape the damnation of hell? [807]

Wherefore, behold, I send unto you prophets, and wise men, and scribes: and some of them ye shall kill and crucify; and some of them shall ye scourge in your synagogues, and persecute them from city to city: [808]

That upon you may come all the righteous blood shed upon the earth, from the blood of righteous Abel unto the blood of Zacharias son of Barachias, whom ye slew between the temple and the altar. [809]

Verily I say unto you, All these things shall come upon this generation. [810]

O Jerusalem, Jerusalem, thou that killest the prophets, and stonest them which are sent unto thee, how often would I have gathered thy children together, even as a hen gathereth her chickens under her wings, and ye would not! [811]

Behold, your house is left unto you desolate. [812]

For I say unto you, Ye shall not see me henceforth, till ye shall say, Blessed is he that cometh in the name of the Lord. [813]

§ Matthew 24

And Jesus went out, and departed from the temple: and his disciples came to him for to shew him the buildings of the temple. [814]

And Jesus said unto them, See ye not all these things? verily I say unto you, There shall not be left here one stone upon another, that shall not be thrown down. [815]

And as he sat upon the mount of Olives, the disciples came unto him privately, saying, Tell us, when shall these things be? and what shall be the sign of thy coming, and of the end of the world? [816]

And Jesus answered and said unto them, Take heed that no man deceive you. [817]

For many shall come in my name, saying, I am Christ; and shall deceive many. [818]

And ye shall hear of wars and rumours of wars: see that ye be not troubled: for all these things must come to pass, but the end is not yet. [819]

For nation shall rise against nation, and kingdom against kingdom: and there shall be famines, and pestilences, and earthquakes, in divers places. [820]

All these are the beginning of sorrows. [821]

Then shall they deliver you up to be afflicted, and shall kill you: and ye shall be hated of all nations for my name's sake. [822]

And then shall many be offended, and shall betray one another, and shall hate one another. [823]

And many false prophets shall rise, and shall deceive many. [824]

And because iniquity shall abound, the love of many shall wax cold. [825]

But he that shall endure unto the end, the same shall be saved. [826]

And this gospel of the kingdom shall be preached in all the world for a witness unto all nations; and then shall the end come. [827]

When ye therefore shall see the abomination of desolation, spoken of by Daniel the prophet, stand in the holy place, (whoso readeth, let him understand:) [828]

Then let them which be in Judaea flee into the mountains: [829]

Let him which is on the housetop not come down to take any thing out of his house: [830]

Neither let him which is in the field return back to take his clothes. [831]

And woe unto them that are with child, and to them that give suck in those days! [832]

But pray ye that your flight be not in the winter, neither on the sabbath day: [833]

For then shall be great tribulation, such as was not since the beginning of the world to this time, no, nor ever shall be. [834]

And except those days should be shortened, there should no flesh be saved: but for the elect's sake those days shall be shortened. [835]

Then if any man shall say unto you, Lo, here is Christ, or there; believe it not. [836]

For there shall arise false Christs, and false prophets, and shall shew great signs and wonders; insomuch that, if it were possible, they shall deceive the very elect. [837]

Behold, I have told you before. [838]

Wherefore if they shall say unto you, Behold, he is in the desert; go not forth: behold, he is in the secret chambers; believe it not. [839]

For as the lightning cometh out of the east, and shineth even unto the west; so shall also the coming of the Son of man be. [840]

For wheresoever the carcase is, there will the eagles be gathered together. [841]

Immediately after the tribulation of those days shall the sun be darkened, and the moon shall not give her light, and the stars shall fall from heaven, and the powers of the heavens shall be shaken: [842]

And then shall appear the sign of the Son of man in heaven: and then shall all the tribes of the earth mourn, and they shall see the Son of man coming in the clouds of heaven with power and great glory. [843]

And he shall send his angels with a great sound of a trumpet, and they shall gather together his elect from the four winds, from one end of heaven to the other. [844]

Now learn a parable of the fig tree; When his branch is yet tender, and putteth forth leaves, ye know that summer is nigh: [845]

So likewise ye, when ye shall see all these things, know that it is near, even at the doors. [846]

Verily I say unto you, This generation shall not pass, till all these things be fulfilled. [847]

Heaven and earth shall pass away, but my words shall not pass away. [848]

But of that day and hour knoweth no man, no, not the angels of heaven, but my Father only. [849]

But as the days of Noe were, so shall also the coming of the Son of man be. [850]

For as in the days that were before the flood they were eating and drinking, marrying and giving in marriage, until the day that Noe entered into the ark, [851]

And knew not until the flood came, and took them all away; so shall also the coming of the Son of man be. [852]

Then shall two be in the field; the one shall be taken, and the other left. [853]

Two women shall be grinding at the mill; the one shall be taken, and the other left. [854]

Watch therefore: for ye know not what hour your Lord doth come. [855]

But know this, that if the goodman of the house had known in what watch the thief would come, he would have watched, and would not have suffered his house to be broken up. [856]

Therefore be ye also ready: for in such an hour as ye think not the Son of man cometh. [857]

Who then is a faithful and wise servant, whom his lord hath made ruler over his household, to give them meat in due season? [858]

Blessed is that servant, whom his lord when he cometh shall find so doing. [859]

Verily I say unto you, That he shall make him ruler over all his goods. [860]

But and if that evil servant shall say in his heart, My lord delayeth his coming; [861]

And shall begin to smite his fellowservants, and to eat and drink with the drunken; [862]

The lord of that servant shall come in a day when he looketh not for him, and in an hour that he is not aware of, [863]

And shall cut him asunder, and appoint him his portion with the hypocrites: there shall be weeping and gnashing of teeth. [864]

§ Matthew 25

Then shall the kingdom of heaven be likened unto ten virgins, which took their lamps, and went forth to meet the bridegroom. [865]

And five of them were wise, and five were foolish. [866]

They that were foolish took their lamps, and took no oil with them: [867]

But the wise took oil in their vessels with their lamps. [868]

While the bridegroom tarried, they all slumbered and slept. [869]

And at midnight there was a cry made, Behold, the bridegroom cometh; go ye out to meet him. [870]

Then all those virgins arose, and trimmed their lamps. [871]

And the foolish said unto the wise, Give us of your oil; for our lamps are gone out. [872]

But the wise answered, saying, Not so; lest there be not enough for us and you: but go ye rather to them that sell, and buy for yourselves. [873]

And while they went to buy, the bridegroom came; and they that were ready went in with him to the marriage: and the door was shut. [874]

Afterward came also the other virgins, saying, Lord, Lord, open to us. [875]

But he answered and said, Verily I say unto you, I know you not. [876]

Watch therefore, for ye know neither the day nor the hour wherein the Son of man cometh. [877]

For the kingdom of heaven is as a man travelling into a far country, who called his own servants, and delivered unto them his goods. [878]

And unto one he gave five talents, to another two, and to another one; to every man according to his several ability; and straightway took his journey. [879]

Then he that had received the five talents went and traded with the same, and made them other five talents. [880]

And likewise he that had received two, he also gained other two. [881]

But he that had received one went and digged in the earth, and hid his lord's money. [882]

After a long time the lord of those servants cometh, and reckoneth with them. [883]

And so he that had received five talents came and brought other five talents, saying, Lord, thou deliveredst unto me five talents: behold, I have gained beside them five talents more. [884]

His lord said unto him, Well done, thou good and faithful servant: thou hast been faithful over a few things, I will make thee ruler over many things: enter thou into the joy of thy lord. [885]

He also that had received two talents came and said, Lord, thou deliveredst unto me two talents: behold, I have gained two other talents beside them. [886]

His lord said unto him, Well done, good and faithful servant; thou hast been faithful over a few things, I will make thee ruler over many things: enter thou into the joy of thy lord. [887]

Then he which had received the one talent came and said, Lord, I knew thee that thou art an hard man, reaping where thou hast not sown, and gathering where thou hast not strawed: [888]

And I was afraid, and went and hid thy talent in the earth: lo, there thou hast that is thine. [889]

His lord answered and said unto him, Thou wicked and slothful servant, thou knewest that I reap where I sowed not, and gather where I have not strawed: [890]

Thou oughtest therefore to have put my money to the exchangers, and then at my coming I should have received mine own with usury. [891]

Take therefore the talent from him, and give it unto him which hath ten talents. [892]

For unto every one that hath shall be given, and he shall have abundance: but from him that hath not shall be taken away even that which he hath. [893]

And cast ye the unprofitable servant into outer darkness: there shall be weeping and gnashing of teeth. [894]

When the Son of man shall come in his glory, and all the holy angels with him, then shall he sit upon the throne of his glory: [895]

And before him shall be gathered all nations: and he shall separate them one from another, as a shepherd divideth his sheep from the goats: [896]

And he shall set the sheep on his right hand, but the goats on the left. [897]

Then shall the King say unto them on his right hand, Come, ye blessed of my Father, inherit the kingdom prepared for you from the foundation of the world: [898]

For I was an hungred, and ye gave me meat: I was thirsty, and ye gave me drink: I was a stranger, and ye took me in: [899]

Naked, and ye clothed me: I was sick, and ye visited me: I was in prison, and ye came unto me. [900]

Then shall the righteous answer him, saying, Lord, when saw we thee an hungred, and fed thee? or thirsty, and gave thee drink? [901]

When saw we thee a stranger, and took thee in? or naked, and clothed thee? [902]

Or when saw we thee sick, or in prison, and came unto thee? [903]

And the King shall answer and say unto them, Verily I say unto you, Inasmuch as ye have done it unto one of the least of these my brethren, ye have done it unto me. [904]

Then shall he say also unto them on the left hand, Depart from me, ye cursed, into everlasting fire, prepared for the devil and his angels: [905]

For I was an hungred, and ye gave me no meat: I was thirsty, and ye gave me no drink: [906]

I was a stranger, and ye took me not in: naked, and ye clothed me not: sick, and in prison, and ye visited me not. [907]

Then shall they also answer him, saying, Lord, when saw we thee an hungred, or athirst, or a stranger, or naked, or sick, or in prison, and did not minister unto thee? [908]

Then shall he answer them, saying, Verily I say unto you, Inasmuch as ye did it not to one of the least of these, ye did it not to me. [909]

And these shall go away into everlasting punishment: but the righteous into life eternal. [910]

§ Matthew 26

And it came to pass, when Jesus had finished all these sayings, he said unto his disciples, [911]

Ye know that after two days is the feast of the passover, and the Son of man is betrayed to be crucified. [912]

Then assembled together the chief priests, and the scribes, and the elders of the people, unto the palace of the high priest, who was called Caiaphas, [913]

And consulted that they might take Jesus by subtilty, and kill him. [914]

But they said, Not on the feast day, lest there be an uproar among the people. [915]

Now when Jesus was in Bethany, in the house of Simon the leper, [916]

There came unto him a woman having an alabaster box of very precious ointment, and poured it on his head, as he sat at meat. [917]

But when his disciples saw it, they had indignation, saying, To what purpose is this waste? [918]

For this ointment might have been sold for much, and given to the poor. [919]

When Jesus understood it, he said unto them, Why trouble ye the woman? for she hath wrought a good work upon me. [920]

For ye have the poor always with you; but me ye have not always. [921]

For in that she hath poured this ointment on my body, she did it for my burial. [922]

Verily I say unto you, Wheresoever this gospel shall be preached in the whole world, there shall also this, that this woman hath done, be told for a memorial of her. [923]

Then one of the twelve, called Judas Iscariot, went unto the chief priests, [924]

And said unto them, What will ye give me, and I will deliver him unto you? And they covenanted with him for thirty pieces of silver. [925]

And from that time he sought opportunity to betray him. [926]

Now the first day of the feast of unleavened bread the disciples came to Jesus, saying unto him, Where wilt thou that we prepare for thee to eat the passover? [927]

And he said, Go into the city to such a man, and say unto him, The Master saith, My time is at hand; I will keep the passover at thy house with my disciples. [928]

And the disciples did as Jesus had appointed them; and they made ready the passover. [929]

Now when the even was come, he sat down with the twelve. [930]

And as they did eat, he said, Verily I say unto you, that one of you shall betray me. [931]

And they were exceeding sorrowful, and began every one of them to say unto him, Lord, is it I? [932]

And he answered and said, He that dippeth his hand with me in the dish, the same shall betray me. [933]

The Son of man goeth as it is written of him: but woe unto that man by whom the Son of man is betrayed! it had been good for that man if he had not been born. [934]

Then Judas, which betrayed him, answered and said, Master, is it I? He said unto him, Thou hast said. [935]

And as they were eating, Jesus took bread, and blessed it, and brake it, and gave it to the disciples, and said, Take, eat; this is my body. [936]

And he took the cup, and gave thanks, and gave it to them, saying, Drink ye all of it; [937]

For this is my blood of the new testament, which is shed for many for the remission of sins. [938]

But I say unto you, I will not drink henceforth of this fruit of the vine, until that day when I drink it new with you in my Father's kingdom. [939]

And when they had sung an hymn, they went out into the mount of Olives. [940]

Then saith Jesus unto them, All ye shall be offended because of me this night: for it is written, I will smite the shepherd, and the sheep of the flock shall be scattered abroad. [941]

But after I am risen again, I will go before you into Galilee. [942]

Peter answered and said unto him, Though all men shall be offended because of thee, yet will I never be offended. [943]

Jesus said unto him, Verily I say unto thee, That this night, before the cock crow, thou shalt deny me thrice. [944]

Peter said unto him, Though I should die with thee, yet will I not deny thee. Likewise also said all the disciples. [945]

Then cometh Jesus with them unto a place called Gethsemane, and saith unto the disciples, Sit ye here, while I go and pray yonder. [946]

And he took with him Peter and the two sons of Zebedee, and began to be sorrowful and very heavy. [947]

Then saith he unto them, My soul is exceeding sorrowful, even unto death: tarry ye here, and watch with me. [948]

And he went a little farther, and fell on his face, and prayed, saying, O my Father, if it be possible, let this cup pass from me: nevertheless not as I will, but as thou wilt. [949]

And he cometh unto the disciples, and findeth them asleep, and saith unto Peter, What, could ye not watch with me one hour? [950]

Watch and pray, that ye enter not into temptation: the spirit indeed is willing, but the flesh is weak. [951]

He went away again the second time, and prayed, saying, O my Father, if this cup may not pass away from me, except I drink it, thy will be done. [952]

And he came and found them asleep again: for their eyes were heavy. [953]

And he left them, and went away again, and prayed the third time, saying the same words. [954]

Then cometh he to his disciples, and saith unto them, Sleep on now, and take your rest: behold, the hour is at hand, and the Son of man is betrayed into the hands of sinners. [955]

Rise, let us be going: behold, he is at hand that doth betray me. [956]

And while he yet spake, lo, Judas, one of the twelve, came, and with him a great multitude with swords and staves, from the chief priests and elders of the people. [957]

Now he that betrayed him gave them a sign, saying, Whomsoever I shall kiss, that same is he: hold him fast. [958]

And forthwith he came to Jesus, and said, Hail, master; and kissed him. [959]

And Jesus said unto him, Friend, wherefore art thou come? Then came they, and laid hands on Jesus and took him. [960]

And, behold, one of them which were with Jesus stretched out his hand, and drew his sword, and struck a servant of the high priest's, and smote off his ear. [961]

Then said Jesus unto him, Put up again thy sword into his place: for all they that take the sword shall perish with the sword. [962]

Thinkest thou that I cannot now pray to my Father, and he shall presently give me more than twelve legions of angels? [963]

But how then shall the scriptures be fulfilled, that thus it must be? [964]

In that same hour said Jesus to the multitudes, Are ye come out as against a thief with swords and staves for to take me? I sat daily with you teaching in the temple, and ye laid no hold on me. [965]

But all this was done, that the scriptures of the prophets might be fulfilled. Then all the disciples forsook him, and fled. [966]

And they that had laid hold on Jesus led him away to Caiaphas the high priest, where the scribes and the elders were assembled. [967]

But Peter followed him afar off unto the high priest's palace, and went in, and sat with the servants, to see the end. [968]

Now the chief priests, and elders, and all the council, sought false witness against Jesus, to put him to death; [969]

But found none: yea, though many false witnesses came, yet found they none. At the last came two false witnesses, [970]

And said, This fellow said, I am able to destroy the temple of God, and to build it in three days. [971]

And the high priest arose, and said unto him, Answerest thou nothing? what is it which these witness against thee? [972]

But Jesus held his peace, And the high priest answered and said unto him, I adjure thee by the living God, that thou tell us whether thou be the Christ, the Son of God. [973]

Jesus saith unto him, Thou hast said: nevertheless I say unto you, Hereafter shall ye see the Son of man sitting on the right hand of power, and coming in the clouds of heaven. [974]

Then the high priest rent his clothes, saying, He hath spoken blasphemy; what further need have we of witnesses? behold, now ye have heard his blasphemy. [975]

What think ye? They answered and said, He is guilty of death. [976]

Then did they spit in his face, and buffeted him; and others smote him with the palms of their hands, [977]

Saying, Prophesy unto us, thou Christ, Who is he that smote thee? [978]

Now Peter sat without in the palace: and a damsel came unto him, saying, Thou also wast with Jesus of Galilee. [979]

But he denied before them all, saying, I know not what thou sayest. [980]

And when he was gone out into the porch, another maid saw him, and said unto them that were there, This fellow was also with Jesus of Nazareth. [981]

And again he denied with an oath, I do not know the man. [982]

And after a while came unto him they that stood by, and said to Peter, Surely thou also art one of them; for thy speech bewrayeth thee. [983]

Then began he to curse and to swear, saying, I know not the man. And immediately the cock crew. [984]

And Peter remembered the word of Jesus, which said unto him, Before the cock crow, thou shalt deny me thrice. And he went out, and wept bitterly. [985]

§ Matthew 27

When the morning was come, all the chief priests and elders of the people took counsel against Jesus to put him to death: [986]

And when they had bound him, they led him away, and delivered him to Pontius Pilate the governor. [987]

Then Judas, which had betrayed him, when he saw that he was condemned, repented himself, and brought again the thirty pieces of silver to the chief priests and elders, [988]

Saying, I have sinned in that I have betrayed the innocent blood. And they said, What is that to us? see thou to that. [989]

And he cast down the pieces of silver in the temple, and departed, and went and hanged himself. [990]

And the chief priests took the silver pieces, and said, It is not lawful for to put them into the treasury, because it is the price of blood. [991]

And they took counsel, and bought with them the potter's field, to bury strangers in. [992]

Wherefore that field was called, The field of blood, unto this day. [993]

Then was fulfilled that which was spoken by Jeremy the prophet, saying, And they took the thirty pieces of silver, the price of him that was valued, whom they of the children of Israel did value; [994]

And gave them for the potter's field, as the Lord appointed me. [995]

And Jesus stood before the governor: and the governor asked him, saying, Art thou the King of the Jews? And Jesus said unto him, Thou sayest. [996]

And when he was accused of the chief priests and elders, he answered nothing. [997]

Then said Pilate unto him, Hearest thou not how many things they witness against thee? [998]

And he answered him to never a word; insomuch that the governor marvelled greatly. [999]

Now at that feast the governor was wont to release unto the people a prisoner, whom they would. [1000]

And they had then a notable prisoner, called Barabbas. [1001]

Therefore when they were gathered together, Pilate said unto them, Whom will ye that I release unto you? Barabbas, or Jesus which is called Christ? [1002]

For he knew that for envy they had delivered him. [1003]

When he was set down on the judgment seat, his wife sent unto him, saying, Have thou nothing to do with that just man: for I have suffered many things this day in a dream because of him. [1004]

But the chief priests and elders persuaded the multitude that they should ask Barabbas, and destroy Jesus. [1005]

The governor answered and said unto them, Whether of the twain will ye that I release unto you? They said, Barabbas. [1006]

Pilate saith unto them, What shall I do then with Jesus which is called Christ? They all say unto him, Let him be crucified. [1007]

And the governor said, Why, what evil hath he done? But they cried out the more, saying, Let him be crucified. [1008]

When Pilate saw that he could prevail nothing, but that rather a tumult was made, he took water, and washed his hands before the multitude, saying, I am innocent of the blood of this just person: see ye to it. [1009]

Then answered all the people, and said, His blood be on us, and on our children. [1010]

Then released he Barabbas unto them: and when he had scourged Jesus, he delivered him to be crucified. [1011]

Then the soldiers of the governor took Jesus into the common hall, and gathered unto him the whole band of soldiers. [1012]

And they stripped him, and put on him a scarlet robe. [1013]

And when they had platted a crown of thorns, they put it upon his head, and a reed in his right hand: and they bowed the knee before him, and mocked him, saying, Hail, King of the Jews! [1014]

And they spit upon him, and took the reed, and smote him on the head. [1015]

And after that they had mocked him, they took the robe off from him, and put his own raiment on him, and led him away to crucify him. [1016]

And as they came out, they found a man of Cyrene, Simon by name: him they compelled to bear his cross. [1017]

And when they were come unto a place called Golgotha, that is to say, a place of a skull, [1018]

They gave him vinegar to drink mingled with gall: and when he had tasted thereof, he would not drink. [1019]

And they crucified him, and parted his garments, casting lots: that it might be fulfilled which was spoken by the prophet, They parted my garments among them, and upon my vesture did they cast lots. [1020]

And sitting down they watched him there; [1021]

And set up over his head his accusation written, THIS IS JESUS THE KING OF THE JEWS. [1022]

Then were there two thieves crucified with him, one on the right hand, and another on the left. [1023]

And they that passed by reviled him, wagging their heads, [1024]

And saying, Thou that destroyest the temple, and buildest it in three days, save thyself. If thou be the Son of God, come down from the cross. [1025]

Likewise also the chief priests mocking him, with the scribes and elders, said, [1026]

He saved others; himself he cannot save. If he be the King of Israel, let him now come down from the cross, and we will believe him. [1027]

He trusted in God; let him deliver him now, if he will have him: for he said, I am the Son of God. [1028]

The thieves also, which were crucified with him, cast the same in his teeth. [1029]

Now from the sixth hour there was darkness over all the land unto the ninth hour. [1030]

And about the ninth hour Jesus cried with a loud voice, saying, Eli, Eli, lama sabachthani? that is to say, My God, my God, why hast thou forsaken me? [1031]

Some of them that stood there, when they heard that, said, This man calleth for Elias. [1032]

And straightway one of them ran, and took a spunge, and filled it with vinegar, and put it on a reed, and gave him to drink. [1033]

The rest said, Let be, let us see whether Elias will come to save him. [1034]

Jesus, when he had cried again with a loud voice, yielded up the ghost. [1035]

And, behold, the veil of the temple was rent in twain from the top to the bottom; and the earth did quake, and the rocks rent; [1036]

And the graves were opened; and many bodies of the saints which slept arose, [1037]

And came out of the graves after his resurrection, and went into the holy city, and appeared unto many. [1038]

Now when the centurion, and they that were with him, watching Jesus, saw the earthquake, and those things that were done, they feared greatly, saying, Truly this was the Son of God. [1039]

And many women were there beholding afar off, which followed Jesus from Galilee, ministering unto him: [1040]

Among which was Mary Magdalene, and Mary the mother of James and Joses, and the mother of Zebedees children. [1041]

When the even was come, there came a rich man of Arimathaea, named Joseph, who also himself was Jesus' disciple: [1042]

He went to Pilate, and begged the body of Jesus. Then Pilate commanded the body to be delivered. [1043]

And when Joseph had taken the body, he wrapped it in a clean linen cloth, [1044]

And laid it in his own new tomb, which he had hewn out in the rock: and he rolled a great stone to the door of the sepulchre, and departed. [1045]

And there was Mary Magdalene, and the other Mary, sitting over against the sepulchre. [1046]

Now the next day, that followed the day of the preparation, the chief priests and Pharisees came together unto Pilate, [1047]

Saying, Sir, we remember that that deceiver said, while he was yet alive, After three days I will rise again. [1048]

Command therefore that the sepulchre be made sure until the third day, lest his disciples come by night, and steal him away, and say unto the people, He is risen from the dead: so the last error shall be worse than the first. [1049]

Pilate said unto them, Ye have a watch: go your way, make it as sure as ye can. [1050]

So they went, and made the sepulchre sure, sealing the stone, and setting a watch. [1051]

§ Matthew 28

In the end of the sabbath, as it began to dawn toward the first day of the week, came Mary Magdalene and the other Mary to see the sepulchre. [1052]

And, behold, there was a great earthquake: for the angel of the Lord descended from heaven, and came and rolled back the stone from the door, and sat upon it. [1053]

His countenance was like lightning, and his raiment white as snow: [1054]

And for fear of him the keepers did shake, and became as dead men. [1055]

And the angel answered and said unto the women, Fear not ye: for I know that ye seek Jesus, which was crucified. [1056]

He is not here: for he is risen, as he said. Come, see the place where the Lord lay. [1057]

And go quickly, and tell his disciples that he is risen from the dead; and, behold, he goeth before you into Galilee; there shall ye see him: lo, I have told you. [1058]

And they departed quickly from the sepulchre with fear and great joy; and did run to bring his disciples word. [1059]

And as they went to tell his disciples, behold, Jesus met them, saying, All hail. And they came and held him by the feet, and worshipped him. [1060]

Then said Jesus unto them, Be not afraid: go tell my brethren that they go into Galilee, and there shall they see me. [1061]

Now when they were going, behold, some of the watch came into the city, and shewed unto the chief priests all the things that were done. [1062]

And when they were assembled with the elders, and had taken counsel, they gave large money unto the soldiers, [1063]

Saying, Say ye, His disciples came by night, and stole him away while we slept. [1064]

And if this come to the governor's ears, we will persuade him, and secure you. [1065]

So they took the money, and did as they were taught: and this saying is commonly reported among the Jews until this day. [1066]

Then the eleven disciples went away into Galilee, into a mountain where Jesus had appointed them. [1067]

And when they saw him, they worshipped him: but some doubted. [1068]

And Jesus came and spake unto them, saying, All power is given unto me in heaven and in earth. [1069]

Go ye therefore, and teach all nations, baptizing them in the name of the Father, and of the Son, and of the Holy Ghost: [1070]

Teaching them to observe all things whatsoever I have commanded you: and, lo, I am with you alway, even unto the end of the world. Amen. [1071]

=== citations ===
[1] Matthew 1:1 (KJV) | | 1
[2] Matthew 1:2 (KJV) | | 1
[3] Matthew 1:3 (KJV) | | 1
[4] Matthew 1:4 (KJV) | | 1
[5] Matthew 1:5 (KJV) | | 1
[6] Matthew 1:6 (KJV) | | 1
[7] Matthew 1:7 (KJV) | | 1
[8] Matthew 1:8 (KJV) | | 1
[9] Matthew 1:9 (KJV) | | 1
[10] Matthew 1:10 (KJV) | | 1
[11] Matthew 1:11 (KJV) | | 1
[12] Matthew 1:12 (KJV) | | 1
[13] Matthew 1:13 (KJV) | | 1
[14] Matthew 1:14 (KJV) | | 1
[15] Matthew 1:15 (KJV) | | 1
[16] Matthew 1:16 (KJV) | | 1
[17] Matthew 1:17 (KJV) | | 1
[18] Matthew 1:18 (KJV) | | 1
[19] Matthew 1:19 (KJV) | | 1
[20] Matthew 1:20 (KJV) | | 1
[21] Matthew 1:21 (KJV) | | 1
[22] Matthew 1:22 (KJV) | | 1
[23] Matthew 1:23 (KJV) | | 1
[24] Matthew 1:24 (KJV) | | 1
[25] Matthew 1:25 (KJV) | | 1
[26] Matthew 2:1 (KJV) | | 1
[27] Matthew 2:2 (KJV) | | 1
[28] Matthew 2:3 (KJV) | | 1
[29] Matthew 2:4 (KJV) | | 1
[30] Matthew 2:5 (KJV) | | 1
[31] Matthew 2:6 (KJV) | | 1
[32] Matthew 2:7 (KJV) | | 1
[33] Matthew 2:8 (KJV) | | 1
[34] Matthew 2:9 (KJV) | | 1
[35] Matthew 2:10 (KJV) | | 1
[36] Matthew 2:11 (KJV) | | 1
[37] Matthew 2:12 (KJV) | | 1
[38] Matthew 2:13 (KJV) | | 1
[39] Matthew 2:14 (KJV) | | 1
[40] Matthew 2:15 (KJV) | | 1
[41] Matthew 2:16 (KJV) | | 1
[42] Matthew 2:17 (KJV) | | 1
[43] Matthew 2:18 (KJV) | | 1
[44] Matthew 2:19 (KJV) | | 1
[45] Matthew 2:20 (KJV) | | 1
[46] Matthew 2:21 (KJV) | | 1
[47] Matthew 2:22 (KJV) | | 1
[48] Matthew 2:23 (KJV) | | 1
[49] Matthew 3:1 (KJV) | | 1
[50] Matthew 3:2 (KJV) | | 1
[51] Matthew 3:3 (KJV) | | 1
[52] Matthew 3:4 (KJV) | | 1
[53] Matthew 3:5 (KJV) | | 1
[54] Matthew 3:6 (KJV) | | 1
[55] Matthew 3:7 (KJV) | | 1
[56] Matthew 3:8 (KJV) | | 1
[57] Matthew 3:9 (KJV) | | 1
[58] Matthew 3:10 (KJV) | | 1
[59] Matthew 3:11 (KJV) | | 1
[60] Matthew 3:12 (KJV) | | 1
[61] Matthew 3:13 (KJV) | | 1
[62] Matthew 3:14 (KJV) | | 1
[63] Matthew 3:15 (KJV) | | 1
[64] Matthew 3:16 (KJV) | | 1
[65] Matthew 3:17 (KJV) | | 1
[66] Matthew 4:1 (KJV) | | 1
[67] Matthew 4:2 (KJV) | | 1
[68] Matthew 4:3 (KJV) | | 1
[69] Matthew 4:4 (KJV) | | 1
[70] Matthew 4:5 (KJV) | | 1
[71] Matthew 4:6 (KJV) | | 1
[72] Matthew 4:7 (KJV) | | 1
[73] Matthew 4:8 (KJV) | | 1
[74] Matthew 4:9 (KJV) | | 1
[75] Matthew 4:10 (KJV) | | 1
[76] Matthew 4:11 (KJV) | | 1
[77] Matthew 4:12 (KJV) | | 1
[78] Matthew 4:13 (KJV) | | 1
[79] Matthew 4:14 (KJV) | | 1
[80] Matthew 4:15 (KJV) | | 1
[81] Matthew 4:16 (KJV) | | 1
[82] Matthew 4:17 (KJV) | | 1
[83] Matthew 4:18 (KJV) | | 1
[84] Matthew 4:19 (KJV) | | 1
[85] Matthew 4:20 (KJV) | | 1
[86] Matthew 4:21 (KJV) | | 1
[87] Matthew 4:22 (KJV) | | 1
[88] Matthew 4:23 (KJV) | | 1
[89] Matthew 4:24 (KJV) | | 1
[90] Matthew 4:25 (KJV) | | 1
[91] Matthew 5:1 (KJV) | | 1
[92] Matthew 5:2 (KJV) | | 1
[93] Matthew 5:3 (KJV) | | 1
[94] Matthew 5:4 (KJV) | | 1
[95] Matthew 5:5 (KJV) | | 1
[96] Matthew 5:6 (KJV) | | 1
[97] Matthew 5:7 (KJV) | | 1
[98] Matthew 5:8 (KJV) | | 1
[99] Matthew 5:9 (KJV) | | 1
[100] Matthew 5:10 (KJV) | | 1
[101] Matthew 5:11 (KJV) | | 1
[102] Matthew 5:12 (KJV) | | 1
[103] Matthew 5:13 (KJV) | | 1
[104] Matthew 5:14 (KJV) | | 1
[105] Matthew 5:15 (KJV) | | 1
[106] Matthew 5:16 (KJV) | | 1
[107] Matthew 5:17 (KJV) | | 1
[108] Matthew 5:18 (KJV) | | 1
[109] Matthew 5:19 (KJV) | | 1
[110] Matthew 5:20 (KJV) | | 1
[111] Matthew 5:21 (KJV) | | 1
[112] Matthew 5:22 (KJV) | | 1
[113] Matthew 5:23 (KJV) | | 1
[114] Matthew 5:24 (KJV) | | 1
[115] Matthew 5:25 (KJV) | | 1
[116] Matthew 5:26 (KJV) | | 1
[117] Matthew 5:27 (KJV) | | 1
[118] Matthew 5:28 (KJV) | | 1
[119] Matthew 5:29 (KJV) | | 1
[120] Matthew 5:30 (KJV) | | 1
[121] Matthew 5:31 (KJV) | | 1
[122] Matthew 5:32 (KJV) | | 1
[123] Matthew 5:33 (KJV) | | 1
[124] Matthew 5:34 (KJV) | | 1
[125] Matthew 5:35 (KJV) | | 1
[126] Matthew 5:36 (KJV) | | 1
[127] Matthew 5:37 (KJV) | | 1
[128] Matthew 5:38 (KJV) | | 1
[129] Matthew 5:39 (KJV) | | 1
[130] Matthew 5:40 (KJV) | | 1
[131] Matthew 5:41 (KJV) | | 1
[132] Matthew 5:42 (KJV) | | 1
[133] Matthew 5:43 (KJV) | | 1
[134] Matthew 5:44 (KJV) | | 1
[135] Matthew 5:45 (KJV) | | 1
[136] Matthew 5:46 (KJV) | | 1
[137] Matthew 5:47 (KJV) | | 1
[138] Matthew 5:48 (KJV) | | 1
[139] Matthew 6:1 (KJV) | | 1
[140] Matthew 6:2 (KJV) | | 1
[141] Matthew 6:3 (KJV) | | 1
[142] Matthew 6:4 (KJV) | | 1
[143] Matthew 6:5 (KJV) | | 1
[144] Matthew 6:6 (KJV) | | 1
[145] Matthew 6:7 (KJV) | | 1
[146] Matthew 6:8 (KJV) | | 1
[147] Matthew 6:9 (KJV) | | 1
[148] Matthew 6:10 (KJV) | | 1
[149] Matthew 6:11 (KJV) | | 1
[150] Matthew 6:12 (KJV) | | 1
[151] Matthew 6:13 (KJV) | | 1
[152] Matthew 6:14 (KJV) | | 1
[153] Matthew 6:15 (KJV) | | 1
[154] Matthew 6:16 (KJV) | | 1
[155] Matthew 6:17 (KJV) | | 1
[156] Matthew 6:18 (KJV) | | 1
[157] Matthew 6:19 (KJV) | | 1
[158] Matthew 6:20 (KJV) | | 1
[159] Matthew 6:21 (KJV) | | 1
[160] Matthew 6:22 (KJV) | | 1
[161] Matthew 6:23 (KJV) | | 1
[162] Matthew 6:24 (KJV) | | 1
[163] Matthew 6:25 (KJV) | | 1
[164] Matthew 6:26 (KJV) | | 1
[165] Matthew 6:27 (KJV) | | 1
[166] Matthew 6:28 (KJV) | | 1
[167] Matthew 6:29 (KJV) | | 1
[168] Matthew 6:30 (KJV) | | 1
[169] Matthew 6:31 (KJV) | | 1
[170] Matthew 6:32 (KJV) | | 1
[171] Matthew 6:33 (KJV) | | 1
[172] Matthew 6:34 (KJV) | | 1
[173] Matthew 7:1 (KJV) | | 1
[174] Matthew 7:2 (KJV) | | 1
[175] Matthew 7:3 (KJV) | | 1
[176] Matthew 7:4 (KJV) | | 1
[177] Matthew 7:5 (KJV) | | 1
[178] Matthew 7:6 (KJV) | | 1
[179] Matthew 7:7 (KJV) | | 1
[180] Matthew 7:8 (KJV) | | 1
[181] Matthew 7:9 (KJV) | | 1
[182] Matthew 7:10 (KJV) | | 1
[183] Matthew 7:11 (KJV) | | 1
[184] Matthew 7:12 (KJV) | | 1
[185] Matthew 7:13 (KJV) | | 1
[186] Matthew 7:14 (KJV) | | 1
[187] Matthew 7:15 (KJV) | | 1
[188] Matthew 7:16 (KJV) | | 1
[189] Matthew 7:17 (KJV) | | 1
[190] Matthew 7:18 (KJV) | | 1
[191] Matthew 7:19 (KJV) | | 1
[192] Matthew 7:20 (KJV) | | 1
[193] Matthew 7:21 (KJV) | | 1
[194] Matthew 7:22 (KJV) | | 1
[195] Matthew 7:23 (KJV) | | 1
[196] Matthew 7:24 (KJV) | | 1
[197] Matthew 7:25 (KJV) | | 1
[198] Matthew 7:26 (KJV) | | 1
[199] Matthew 7:27 (KJV) | | 1
[200] Matthew 7:28 (KJV) | | 1
[201] Matthew 7:29 (KJV) | | 1
[202] Matthew 8:1 (KJV) | | 1
[203] Matthew 8:2 (KJV) | | 1
[204] Matthew 8:3 (KJV) | | 1
[205] Matthew 8:4 (KJV) | | 1
[206] Matthew 8:5 (KJV) | | 1
[207] Matthew 8:6 (KJV) | | 1
[208] Matthew 8:7 (KJV) | | 1
[209] Matthew 8:8 (KJV) | | 1
[210] Matthew 8:9 (KJV) | | 1
[211] Matthew 8:10 (KJV) | | 1
[212] Matthew 8:11 (KJV) | | 1
[213] Matthew 8:12 (KJV) | | 1
[214] Matthew 8:13 (KJV) | | 1
[215] Matthew 8:14 (KJV) | | 1
[216] Matthew 8:15 (KJV) | | 1
[217] Matthew 8:16 (KJV) | | 1
[218] Matthew 8:17 (KJV) | | 1
[219] Matthew 8:18 (KJV) | | 1
[220] Matthew 8:19 (KJV) | | 1
[221] Matthew 8:20 (KJV) | | 1
[222] Matthew 8:21 (KJV) | | 1
[223] Matthew 8:22 (KJV) | | 1
[224] Matthew 8:23 (KJV) | | 1
[225] Matthew 8:24 (KJV) | | 1
[226] Matthew 8:25 (KJV) | | 1
[227] Matthew 8:26 (KJV) | | 1
[228] Matthew 8:27 (KJV) | | 1
[229] Matthew 8:28 (KJV) | | 1
[230] Matthew 8:29 (KJV) | | 1
[231] Matthew 8:30 (KJV) | | 1
[232] Matthew 8:31 (KJV) | | 1
[233] Matthew 8:32 (KJV) | | 1
[234] Matthew 8:33 (KJV) | | 1
[235] Matthew 8:34 (KJV) | | 1
[236] Matthew 9:1 (KJV) | | 1
[237] Matthew 9:2 (KJV) | | 1
[238] Matthew 9:3 (KJV) | | 1
[239] Matthew 9:4 (KJV) | | 1
[240] Matthew 9:5 (KJV) | | 1
[241] Matthew 9:6 (KJV) | | 1
[242] Matthew 9:7 (KJV) | | 1
[243] Matthew 9:8 (KJV) | | 1
[244] Matthew 9:9 (KJV) | | 1
[245] Matthew 9:10 (KJV) | | 1
[246] Matthew 9:11 (KJV) | | 1
[247] Matthew 9:12 (KJV) | | 1
[248] Matthew 9:13 (KJV) | | 1
[249] Matthew 9:14 (KJV) | | 1
[250] Matthew 9:15 (KJV) | | 1
[251] Matthew 9:16 (KJV) | | 1
[252] Matthew 9:17 (KJV) | | 1
[253] Matthew 9:18 (KJV) | | 1
[254] Matthew 9:19 (KJV) | | 1
[255] Matthew 9:20 (KJV) | | 1
[256] Matthew 9:21 (KJV) | | 1
[257] Matthew 9:22 (KJV) | | 1
[258] Matthew 9:23 (KJV) | | 1
[259] Matthew 9:24 (KJV) | | 1
[260] Matthew 9:25 (KJV) | | 1
[261] Matthew 9:26 (KJV) | | 1
[262] Matthew 9:27 (KJV) | | 1
[263] Matthew 9:28 (KJV) | | 1
[264] Matthew 9:29 (KJV) | | 1
[265] Matthew 9:30 (KJV) | | 1
[266] Matthew 9:31 (KJV) | | 1
[267] Matthew 9:32 (KJV) | | 1
[268] Matthew 9:33 (KJV) | | 1
[269] Matthew 9:34 (KJV) | | 1
[270] Matthew 9:35 (KJV) | | 1
[271] Matthew 9:36 (KJV) | | 1
[272] Matthew 9:37 (KJV) | | 1
[273] Matthew 9:38 (KJV) | | 1
[274] Matthew 10:1 (KJV) | | 1
[275] Matthew 10:2 (KJV) | | 1
[276] Matthew 10:3 (KJV) | | 1
[277] Matthew 10:4 (KJV) | | 1
[278] Matthew 10:5 (KJV) | | 1
[279] Matthew 10:6 (KJV) | | 1
[280] Matthew 10:7 (KJV) | | 1
[281] Matthew 10:8 (KJV) | | 1
[282] Matthew 10:9 (KJV) | | 1
[283] Matthew 10:10 (KJV) | | 1
[284] Matthew 10:11 (KJV) | | 1
[285] Matthew 10:12 (KJV) | | 1
[286] Matthew 10:13 (KJV) | | 1
[287] Matthew 10:14 (KJV) | | 1
[288] Matthew 10:15 (KJV) | | 1
[289] Matthew 10:16 (KJV) | | 1
[290] Matthew 10:17 (KJV) | | 1
[291] Matthew 10:18 (KJV) | | 1
[292] Matthew 10:19 (KJV) | | 1
[293] Matthew 10:20 (KJV) | | 1
[294] Matthew 10:21 (KJV) | | 1
[295] Matthew 10:22 (KJV) | | 1
[296] Matthew 10:23 (KJV) | | 1
[297] Matthew 10:24 (KJV) | | 1
[298] Matthew 10:25 (KJV) | | 1
[299] Matthew 10:26 (KJV) | | 1
[300] Matthew 10:27 (KJV) | | 1
[301] Matthew 10:28 (KJV) | | 1
[302] Matthew 10:29 (KJV) | | 1
[303] Matthew 10:30 (KJV) | | 1
[304] Matthew 10:31 (KJV) | | 1
[305] Matthew 10:32 (KJV) | | 1
[306] Matthew 10:33 (KJV) | | 1
[307] Matthew 10:34 (KJV) | | 1
[308] Matthew 10:35 (KJV) | | 1
[309] Matthew 10:36 (KJV) | | 1
[310] Matthew 10:37 (KJV) | | 1
[311] Matthew 10:38 (KJV) | | 1
[312] Matthew 10:39 (KJV) | | 1
[313] Matthew 10:40 (KJV) | | 1
[314] Matthew 10:41 (KJV) | | 1
[315] Matthew 10:42 (KJV) | | 1
[316] Matthew 11:1 (KJV) | | 1
[317] Matthew 11:2 (KJV) | | 1
[318] Matthew 11:3 (KJV) | | 1
[319] Matthew 11:4 (KJV) | | 1
[320] Matthew 11:5 (KJV) | | 1
[321] Matthew 11:6 (KJV) | | 1
[322] Matthew 11:7 (KJV) | | 1
[323] Matthew 11:8 (KJV) | | 1
[324] Matthew 11:9 (KJV) | | 1
[325] Matthew 11:10 (KJV) | | 1
[326] Matthew 11:11 (KJV) | | 1
[327] Matthew 11:12 (KJV) | | 1
[328] Matthew 11:13 (KJV) | | 1
[329] Matthew 11:14 (KJV) | | 1
[330] Matthew 11:15 (KJV) | | 1
[331] Matthew 11:16 (KJV) | | 1
[332] Matthew 11:17 (KJV) | | 1
[333] Matthew 11:18 (KJV) | | 1
[334] Matthew 11:19 (KJV) | | 1
[335] Matthew 11:20 (KJV) | | 1
[336] Matthew 11:21 (KJV) | | 1
[337] Matthew 11:22 (KJV) | | 1
[338] Matthew 11:23 (KJV) | | 1
[339] Matthew 11:24 (KJV) | | 1
[340] Matthew 11:25 (KJV) | | 1
[341] Matthew 11:26 (KJV) | | 1
[342] Matthew 11:27 (KJV) | | 1
[343] Matthew 11:28 (KJV) | | 1
[344] Matthew 11:29 (KJV) | | 1
[345] Matthew 11:30 (KJV) | | 1
[346] Matthew 12:1 (KJV) | | 1
[347] Matthew 12:2 (KJV) | | 1
[348] Matthew 12:3 (KJV) | | 1
[349] Matthew 12:4 (KJV) | | 1
[350] Matthew 12:5 (KJV) | | 1
[351] Matthew 12:6 (KJV) | | 1
[352] Matthew 12:7 (KJV) | | 1
[353] Matthew 12:8 (KJV) | | 1
[354] Matthew 12:9 (KJV) | | 1
[355] Matthew 12:10 (KJV) | | 1
[356] Matthew 12:11 (KJV) | | 1
[357] Matthew 12:12 (KJV) | | 1
[358] Matthew 12:13 (KJV) | | 1
[359] Matthew 12:14 (KJV) | | 1
[360] Matthew 12:15 (KJV) | | 1
[361] Matthew 12:16 (KJV) | | 1
[362] Matthew 12:17 (KJV) | | 1
[363] Matthew 12:18 (KJV) | | 1
[364] Matthew 12:19 (KJV) | | 1
[365] Matthew 12:20 (KJV) | | 1
[366] Matthew 12:21 (KJV) | | 1
[367] Matthew 12:22 (KJV) | | 1
[368] Matthew 12:23 (KJV) | | 1
[369] Matthew 12:24 (KJV) | | 1
[370] Matthew 12:25 (KJV) | | 1
[371] Matthew 12:26 (KJV) | | 1
[372] Matthew 12:27 (KJV) | | 1
[373] Matthew 12:28 (KJV) | | 1
[374] Matthew 12:29 (KJV) | | 1
[375] Matthew 12:30 (KJV) | | 1
[376] Matthew 12:31 (KJV) | | 1
[377] Matthew 12:32 (KJV) | | 1
[378] Matthew 12:33 (KJV) | | 1
[379] Matthew 12:34 (KJV) | | 1
[380] Matthew 12:35 (KJV) | | 1
[381] Matthew 12:36 (KJV) | | 1
[382] Matthew 12:37 (KJV) | | 1
[383] Matthew 12:38 (KJV) | | 1
[384] Matthew 12:39 (KJV) | | 1
[385] Matthew 12:40 (KJV) | | 1
[386] Matthew 12:41 (KJV) | | 1
[387] Matthew 12:42 (KJV) | | 1
[388] Matthew 12:43 (KJV) | | 1
[389] Matthew 12:44 (KJV) | | 1
[390] Matthew 12:45 (KJV) | | 1
[391] Matthew 12:46 (KJV) | | 1
[392] Matthew 12:47 (KJV) | | 1
[393] Matthew 12:48 (KJV) | | 1
[394] Matthew 12:49 (KJV) | | 1
[395] Matthew 12:50 (KJV) | | 1
[396] Matthew 13:1 (KJV) | | 1
[397] Matthew 13:2 (KJV) | | 1
[398] Matthew 13:3 (KJV) | | 1
[399] Matthew 13:4 (KJV) | | 1
[400] Matthew 13:5 (KJV) | | 1
[401] Matthew 13:6 (KJV) | | 1
[402] Matthew 13:7 (KJV) | | 1
[403] Matthew 13:8 (KJV) | | 1
[404] Matthew 13:9 (KJV) | | 1
[405] Matthew 13:10 (KJV) | | 1
[406] Matthew 13:11 (KJV) | | 1
[407] Matthew 13:12 (KJV) | | 1
[408] Matthew 13:13 (KJV) | | 1
[409] Matthew 13:14 (KJV) | | 1
[410] Matthew 13:15 (KJV) | | 1
[411] Matthew 13:16 (KJV) | | 1
[412] Matthew 13:17 (KJV) | | 1
[413] Matthew 13:18 (KJV) | | 1
[414] Matthew 13:19 (KJV) | | 1
[415] Matthew 13:20 (KJV) | | 1
[416] Matthew 13:21 (KJV) | | 1
[417] Matthew 13:22 (KJV) | | 1
[418] Matthew 13:23 (KJV) | | 1
[419] Matthew 13:24 (KJV) | | 1
[420] Matthew 13:25 (KJV) | | 1
[421] Matthew 13:26 (KJV) | | 1
[422] Matthew 13:27 (KJV) | | 1
[423] Matthew 13:28 (KJV) | | 1
[424] Matthew 13:29 (KJV) | | 1
[425] Matthew 13:30 (KJV) | | 1
[426] Matthew 13:31 (KJV) | | 1
[427] Matthew 13:32 (KJV) | | 1
[428] Matthew 13:33 (KJV) | | 1
[429] Matthew 13:34 (KJV) | | 1
[430] Matthew 13:35 (KJV) | | 1
[431] Matthew 13:36 (KJV) | | 1
[432] Matthew 13:37 (KJV) | | 1
[433] Matthew 13:38 (KJV) | | 1
[434] Matthew 13:39 (KJV) | | 1
[435] Matthew 13:40 (KJV) | | 1
[436] Matthew 13:41 (KJV) | | 1
[437] Matthew 13:42 (KJV) | | 1
[438] Matthew 13:43 (KJV) | | 1
[439] Matthew 13:44 (KJV) | | 1
[440] Matthew 13:45 (KJV) | | 1
[441] Matthew 13:46 (KJV) | | 1
[442] Matthew 13:47 (KJV) | | 1
[443] Matthew 13:48 (KJV) | | 1
[444] Matthew 13:49 (KJV) | | 1
[445] Matthew 13:50 (KJV) | | 1
[446] Matthew 13:51 (KJV) | | 1
[447] Matthew 13:52 (KJV) | | 1
[448] Matthew 13:53 (KJV) | | 1
[449] Matthew 13:54 (KJV) | | 1
[450] Matthew 13:55 (KJV) | | 1
[451] Matthew 13:56 (KJV) | | 1
[452] Matthew 13:57 (KJV) | | 1
[453] Matthew 13:58 (KJV) | | 1
[454] Matthew 14:1 (KJV) | | 1
[455] Matthew 14:2 (KJV) | | 1
[456] Matthew 14:3 (KJV) | | 1
[457] Matthew 14:4 (KJV) | | 1
[458] Matthew 14:5 (KJV) | | 1
[459] Matthew 14:6 (KJV) | | 1
[460] Matthew 14:7 (KJV) | | 1
[461] Matthew 14:8 (KJV) | | 1
[462] Matthew 14:9 (KJV) | | 1
[463] Matthew 14:10 (KJV) | | 1
[464] Matthew 14:11 (KJV) | | 1
[465] Matthew 14:12 (KJV) | | 1
[466] Matthew 14:13 (KJV) | | 1
[467] Matthew 14:14 (KJV) | | 1
[468] Matthew 14:15 (KJV) | | 1
[469] Matthew 14:16 (KJV) | | 1
[470] Matthew 14:17 (KJV) | | 1
[471] Matthew 14:18 (KJV) | | 1
[472] Matthew 14:19 (KJV) | | 1
[473] Matthew 14:20 (KJV) | | 1
[474] Matthew 14:21 (KJV) | | 1
[475] Matthew 14:22 (KJV) | | 1
[476] Matthew 14:23 (KJV) | | 1
[477] Matthew 14:24 (KJV) | | 1
[478] Matthew 14:25 (KJV) | | 1
[479] Matthew 14:26 (KJV) | | 1
[480] Matthew 14:27 (KJV) | | 1
[481] Matthew 14:28 (KJV) | | 1
[482] Matthew 14:29 (KJV) | | 1
[483] Matthew 14:30 (KJV) | | 1
[484] Matthew 14:31 (KJV) | | 1
[485] Matthew 14:32 (KJV) | | 1
[486] Matthew 14:33 (KJV) | | 1
[487] Matthew 14:34 (KJV) | | 1
[488] Matthew 14:35 (KJV) | | 1
[489] Matthew 14:36 (KJV) | | 1
[490] Matthew 15:1 (KJV) | | 1
[491] Matthew 15:2 (KJV) | | 1
[492] Matthew 15:3 (KJV) | | 1
[493] Matthew 15:4 (KJV) | | 1
[494] Matthew 15:5 (KJV) | | 1
[495] Matthew 15:6 (KJV) | | 1
[496] Matthew 15:7 (KJV) | | 1
[497] Matthew 15:8 (KJV) | | 1
[498] Matthew 15:9 (KJV) | | 1
[499] Matthew 15:10 (KJV) | | 1
[500] Matthew 15:11 (KJV) | | 1
[501] Matthew 15:12 (KJV) | | 1
[502] Matthew 15:13 (KJV) | | 1
[503] Matthew 15:14 (KJV) | | 1
[504] Matthew 15:15 (KJV) | | 1
[505] Matthew 15:16 (KJV) | | 1
[506] Matthew 15:17 (KJV) | | 1
[507] Matthew 15:18 (KJV) | | 1
[508] Matthew 15:19 (KJV) | | 1
[509] Matthew 15:20 (KJV) | | 1
[510] Matthew 15:21 (KJV) | | 1
[511] Matthew 15:22 (KJV) | | 1
[512] Matthew 15:23 (KJV) | | 1
[513] Matthew 15:24 (KJV) | | 1
[514] Matthew 15:25 (KJV) | | 1
[515] Matthew 15:26 (KJV) | | 1
[516] Matthew 15:27 (KJV) | | 1
[517] Matthew 15:28 (KJV) | | 1
[518] Matthew 15:29 (KJV) | | 1
[519] Matthew 15:30 (KJV) | | 1
[520] Matthew 15:31 (KJV) | | 1
[521] Matthew 15:32 (KJV) | | 1
[522] Matthew 15:33 (KJV) | | 1
[523] Matthew 15:34 (KJV) | | 1
[524] Matthew 15:35 (KJV) | | 1
[525] Matthew 15:36 (KJV) | | 1
[526] Matthew 15:37 (KJV) | | 1
[527] Matthew 15:38 (KJV) | | 1
[528] Matthew 15:39 (KJV) | | 1
[529] Matthew 16:1 (KJV) | | 1
[530] Matthew 16:2 (KJV) | | 1
[531] Matthew 16:3 (KJV) | | 1
[532] Matthew 16:4 (KJV) | | 1
[533] Matthew 16:5 (KJV) | | 1
[534] Matthew 16:6 (KJV) | | 1
[535] Matthew 16:7 (KJV) | | 1
[536] Matthew 16:8 (KJV) | | 1
[537] Matthew 16:9 (KJV) | | 1
[538] Matthew 16:10 (KJV) | | 1
[539] Matthew 16:11 (KJV) | | 1
[540] Matthew 16:12 (KJV) | | 1
[541] Matthew 16:13 (KJV) | | 1
[542] Matthew 16:14 (KJV) | | 1
[543] Matthew 16:15 (KJV) | | 1
[544] Matthew 16:16 (KJV) | | 1
[545] Matthew 16:17 (KJV) | | 1
[546] Matthew 16:18 (KJV) | | 1
[547] Matthew 16:19 (KJV) | | 1
[548] Matthew 16:20 (KJV) | | 1
[549] Matthew 16:21 (KJV) | | 1
[550] Matthew 16:22 (KJV) | | 1
[551] Matthew 16:23 (KJV) | | 1
[552] Matthew 16:24 (KJV) | | 1
[553] Matthew 16:25 (KJV) | | 1
[554] Matthew 16:26 (KJV) | | 1
[555] Matthew 16:27 (KJV) | | 1
[556] Matthew 16:28 (KJV) | | 1
[557] Matthew 17:1 (KJV) | | 1
[558] Matthew 17:2 (KJV) | | 1
[559] Matthew 17:3 (KJV) | | 1
[560] Matthew 17:4 (KJV) | | 1
[561] Matthew 17:5 (KJV) | | 1
[562] Matthew 17:6 (KJV) | | 1
[563] Matthew 17:7 (KJV) | | 1
[564] Matthew 17:8 (KJV) | | 1
[565] Matthew 17:9 (KJV) | | 1
[566] Matthew 17:10 (KJV) | | 1
[567] Matthew 17:11 (KJV) | | 1
[568] Matthew 17:12 (KJV) | | 1
[569] Matthew 17:13 (KJV) | | 1
[570] Matthew 17:14 (KJV) | | 1
[571] Matthew 17:15 (KJV) | | 1
[572] Matthew 17:16 (KJV) | | 1
[573] Matthew 17:17 (KJV) | | 1
[574] Matthew 17:18 (KJV) | | 1
[575] Matthew 17:19 (KJV) | | 1
[576] Matthew 17:20 (KJV) | | 1
[577] Matthew 17:21 (KJV) | | 1
[578] Matthew 17:22 (KJV) | | 1
[579] Matthew 17:23 (KJV) | | 1
[580] Matthew 17:24 (KJV) | | 1
[581] Matthew 17:25 (KJV) | | 1
[582] Matthew 17:26 (KJV) | | 1
[583] Matthew 17:27 (KJV) | | 1
[584] Matthew 18:1 (KJV) | | 1
[585] Matthew 18:2 (KJV) | | 1
[586] Matthew 18:3 (KJV) | | 1
[587] Matthew 18:4 (KJV) | | 1
[588] Matthew 18:5 (KJV) | | 1
[589] Matthew 18:6 (KJV) | | 1
[590] Matthew 18:7 (KJV) | | 1
[591] Matthew 18:8 (KJV) | | 1
[592] Matthew 18:9 (KJV) | | 1
[593] Matthew 18:10 (KJV) | | 1
[594] Matthew 18:11 (KJV) | | 1
[595] Matthew 18:12 (KJV) | | 1
[596] Matthew 18:13 (KJV) | | 1
[597] Matthew 18:14 (KJV) | | 1
[598] Matthew 18:15 (KJV) | | 1
[599] Matthew 18:16 (KJV) | | 1
[600] Matthew 18:17 (KJV) | | 1
[601] Matthew 18:18 (KJV) | | 1
[602] Matthew 18:19 (KJV) | | 1
[603] Matthew 18:20 (KJV) | | 1
[604] Matthew 18:21 (KJV) | | 1
[605] Matthew 18:22 (KJV) | | 1
[606] Matthew 18:23 (KJV) | | 1
[607] Matthew 18:24 (KJV) | | 1
[608] Matthew 18:25 (KJV) | | 1
[609] Matthew 18:26 (KJV) | | 1
[610] Matthew 18:27 (KJV) | | 1
[611] Matthew 18:28 (KJV) | | 1
[612] Matthew 18:29 (KJV) | | 1
[613] Matthew 18:30 (KJV) | | 1
[614] Matthew 18:31 (KJV) | | 1
[615] Matthew 18:32 (KJV) | | 1
[616] Matthew 18:33 (KJV) | | 1
[617] Matthew 18:34 (KJV) | | 1
[618] Matthew 18:35 (KJV) | | 1
[619] Matthew 19:1 (KJV) | | 1
[620] Matthew 19:2 (KJV) | | 1
[621] Matthew 19:3 (KJV) | | 1
[622] Matthew 19:4 (KJV) | | 1
[623] Matthew 19:5 (KJV) | | 1
[624] Matthew 19:6 (KJV) | | 1
[625] Matthew 19:7 (KJV) | | 1
[626] Matthew 19:8 (KJV) | | 1
[627] Matthew 19:9 (KJV) | | 1
[628] Matthew 19:10 (KJV) | | 1
[629] Matthew 19:11 (KJV) | | 1
[630] Matthew 19:12 (KJV) | | 1
[631] Matthew 19:13 (KJV) | | 1
[632] Matthew 19:14 (KJV) | | 1
[633] Matthew 19:15 (KJV) | | 1
[634] Matthew 19:16 (KJV) | | 1
[635] Matthew 19:17 (KJV) | | 1
[636] Matthew 19:18 (KJV) | | 1
[637] Matthew 19:19 (KJV) | | 1
[638] Matthew 19:20 (KJV) | | 1
[639] Matthew 19:21 (KJV) | | 1
[640] Matthew 19:22 (KJV) | | 1
[641] Matthew 19:23 (KJV) | | 1
[642] Matthew 19:24 (KJV) | | 1
[643] Matthew 19:25 (KJV) | | 1
[644] Matthew 19:26 (KJV) | | 1
[645] Matthew 19:27 (KJV) | | 1
[646] Matthew 19:28 (KJV) | | 1
[647] Matthew 19:29 (KJV) | | 1
[648] Matthew 19:30 (KJV) | | 1
[649] Matthew 20:1 (KJV) | | 1
[650] Matthew 20:2 (KJV) | | 1
[651] Matthew 20:3 (KJV) | | 1
[652] Matthew 20:4 (KJV) | | 1
[653] Matthew 20:5 (KJV) | | 1
[654] Matthew 20:6 (KJV) | | 1
[655] Matthew 20:7 (KJV) | | 1
[656] Matthew 20:8 (KJV) | | 1
[657] Matthew 20:9 (KJV) | | 1
[658] Matthew 20:10 (KJV) | | 1
[659] Matthew 20:11 (KJV) | | 1
[660] Matthew 20:12 (KJV) | | 1
[661] Matthew 20:13 (KJV) | | 1
[662] Matthew 20:14 (KJV) | | 1
[663] Matthew 20:15 (KJV) | | 1
[664] Matthew 20:16 (KJV) | | 1
[665] Matthew 20:17 (KJV) | | 1
[666] Matthew 20:18 (KJV) | | 1
[667] Matthew 20:19 (KJV) | | 1
[668] Matthew 20:20 (KJV) | | 1
[669] Matthew 20:21 (KJV) | | 1
[670] Matthew 20:22 (KJV) | | 1
[671] Matthew 20:23 (KJV) | | 1
[672] Matthew 20:24 (KJV) | | 1
[673] Matthew 20:25 (KJV) | | 1
[674] Matthew 20:26 (KJV) | | 1
[675] Matthew 20:27 (KJV) | | 1
[676] Matthew 20:28 (KJV) | | 1
[677] Matthew 20:29 (KJV) | | 1
[678] Matthew 20:30 (KJV) | | 1
[679] Matthew 20:31 (KJV) | | 1
[680] Matthew 20:32 (KJV) | | 1
[681] Matthew 20:33 (KJV) | | 1
[682] Matthew 20:34 (KJV) | | 1
[683] Matthew 21:1 (KJV) | | 1
[684] Matthew 21:2 (KJV) | | 1
[685] Matthew 21:3 (KJV) | | 1
[686] Matthew 21:4 (KJV) | | 1
[687] Matthew 21:5 (KJV) | | 1
[688] Matthew 21:6 (KJV) | | 1
[689] Matthew 21:7 (KJV) | | 1
[690] Matthew 21:8 (KJV) | | 1
[691] Matthew 21:9 (KJV) | | 1
[692] Matthew 21:10 (KJV) | | 1
[693] Matthew 21:11 (KJV) | | 1
[694] Matthew 21:12 (KJV) | | 1
[695] Matthew 21:13 (KJV) | | 1
[696] Matthew 21:14 (KJV) | | 1
[697] Matthew 21:15 (KJV) | | 1
[698] Matthew 21:16 (KJV) | | 1
[699] Matthew 21:17 (KJV) | | 1
[700] Matthew 21:18 (KJV) | | 1
[701] Matthew 21:19 (KJV) | | 1
[702] Matthew 21:20 (KJV) | | 1
[703] Matthew 21:21 (KJV) | | 1
[704] Matthew 21:22 (KJV) | | 1
[705] Matthew 21:23 (KJV) | | 1
[706] Matthew 21:24 (KJV) | | 1
[707] Matthew 21:25 (KJV) | | 1
[708] Matthew 21:26 (KJV) | | 1
[709] Matthew 21:27 (KJV) | | 1
[710] Matthew 21:28 (KJV) | | 1
[711] Matthew 21:29 (KJV) | | 1
[712] Matthew 21:30 (KJV) | | 1
[713] Matthew 21:31 (KJV) | | 1
[714] Matthew 21:32 (KJV) | | 1
[715] Matthew 21:33 (KJV) | | 1
[716] Matthew 21:34 (KJV) | | 1
[717] Matthew 21:35 (KJV) | | 1
[718] Matthew 21:36 (KJV) | | 1
[719] Matthew 21:37 (KJV) | | 1
[720] Matthew 21:38 (KJV) | | 1
[721] Matthew 21:39 (KJV) | | 1
[722] Matthew 21:40 (KJV) | | 1
[723] Matthew 21:41 (KJV) | | 1
[724] Matthew 21:42 (KJV) | | 1
[725] Matthew 21:43 (KJV) | | 1
[726] Matthew 21:44 (KJV) | | 1
[727] Matthew 21:45 (KJV) | | 1
[728] Matthew 21:46 (KJV) | | 1
[729] Matthew 22:1 (KJV) | | 1
[730] Matthew 22:2 (KJV) | | 1
[731] Matthew 22:3 (KJV) | | 1
[732] Matthew 22:4 (KJV) | | 1
[733] Matthew 22:5 (KJV) | | 1
[734] Matthew 22:6 (KJV) | | 1
[735] Matthew 22:7 (KJV) | | 1
[736] Matthew 22:8 (KJV) | | 1
[737] Matthew 22:9 (KJV) | | 1
[738] Matthew 22:10 (KJV) | | 1
[739] Matthew 22:11 (KJV) | | 1
[740] Matthew 22:12 (KJV) | | 1
[741] Matthew 22:13 (KJV) | | 1
[742] Matthew 22:14 (KJV) | | 1
[743] Matthew 22:15 (KJV) | | 1
[744] Matthew 22:16 (KJV) | | 1
[745] Matthew 22:17 (KJV) | | 1
[746] Matthew 22:18 (KJV) | | 1
[747] Matthew 22:19 (KJV) | | 1
[748] Matthew 22:20 (KJV) | | 1
[749] Matthew 22:21 (KJV) | | 1
[750] Matthew 22:22 (KJV) | | 1
[751] Matthew 22:23 (KJV) | | 1
[752] Matthew 22:24 (KJV) | | 1
[753] Matthew 22:25 (KJV) | | 1
[754] Matthew 22:26 (KJV) | | 1
[755] Matthew 22:27 (KJV) | | 1
[756] Matthew 22:28 (KJV) | | 1
[757] Matthew 22:29 (KJV) | | 1
[758] Matthew 22:30 (KJV) | | 1
[759] Matthew 22:31 (KJV) | | 1
[760] Matthew 22:32 (KJV) | | 1
[761] Matthew 22:33 (KJV) | | 1
[762] Matthew 22:34 (KJV) | | 1
[763] Matthew 22:35 (KJV) | | 1
[764] Matthew 22:36 (KJV) | | 1
[765] Matthew 22:37 (KJV) | | 1
[766] Matthew 22:38 (KJV) | | 1
[767] Matthew 22:39 (KJV) | | 1
[768] Matthew 22:40 (KJV) | | 1
[769] Matthew 22:41 (KJV) | | 1
[770] Matthew 22:42 (KJV) | | 1
[771] Matthew 22:43 (KJV) | | 1
[772] Matthew 22:44 (KJV) | | 1
[773] Matthew 22:45 (KJV) | | 1
[774] Matthew 22:46 (KJV) | | 1
[775] Matthew 23:1 (KJV) | | 1
[776] Matthew 23:2 (KJV) | | 1
[777] Matthew 23:3 (KJV) | | 1
[778] Matthew 23:4 (KJV) | | 1
[779] Matthew 23:5 (KJV) | | 1
[780] Matthew 23:6 (KJV) | | 1
[781] Matthew 23:7 (KJV) | | 1
[782] Matthew 23:8 (KJV) | | 1
[783] Matthew 23:9 (KJV) | | 1
[784] Matthew 23:10 (KJV) | | 1
[785] Matthew 23:11 (KJV) | | 1
[786] Matthew 23:12 (KJV) | | 1
[787] Matthew 23:13 (KJV) | | 1
[788] Matthew 23:14 (KJV) | | 1
[789] Matthew 23:15 (KJV) | | 1
[790] Matthew 23:16 (KJV) | | 1
[791] Matthew 23:17 (KJV) | | 1
[792] Matthew 23:18 (KJV) | | 1
[793] Matthew 23:19 (KJV) | | 1
[794] Matthew 23:20 (KJV) | | 1
[795] Matthew 23:21 (KJV) | | 1
[796] Matthew 23:22 (KJV) | | 1
[797] Matthew 23:23 (KJV) | | 1
[798] Matthew 23:24 (KJV) | | 1
[799] Matthew 23:25 (KJV) | | 1
[800] Matthew 23:26 (KJV) | | 1
[801] Matthew 23:27 (KJV) | | 1
[802] Matthew 23:28 (KJV) | | 1
[803] Matthew 23:29 (KJV) | | 1
[804] Matthew 23:30 (KJV) | | 1
[805] Matthew 23:31 (KJV) | | 1
[806] Matthew 23:32 (KJV) | | 1
[807] Matthew 23:33 (KJV) | | 1
[808] Matthew 23:34 (KJV) | | 1
[809] Matthew 23:35 (KJV) | | 1
[810] Matthew 23:36 (KJV) | | 1
[811] Matthew 23:37 (KJV) | | 1
[812] Matthew 23:38 (KJV) | | 1
[813] Matthew 23:39 (KJV) | | 1
[814] Matthew 24:1 (KJV) | | 1
[815] Matthew 24:2 (KJV) | | 1
[816] Matthew 24:3 (KJV) | | 1
[817] Matthew 24:4 (KJV) | | 1
[818] Matthew 24:5 (KJV) | | 1
[819] Matthew 24:6 (KJV) | | 1
[820] Matthew 24:7 (KJV) | | 1
[821] Matthew 24:8 (KJV) | | 1
[822] Matthew 24:9 (KJV) | | 1
[823] Matthew 24:10 (KJV) | | 1
[824] Matthew 24:11 (KJV) | | 1
[825] Matthew 24:12 (KJV) | | 1
[826] Matthew 24:13 (KJV) | | 1
[827] Matthew 24:14 (KJV) | | 1
[828] Matthew 24:15 (KJV) | | 1
[829] Matthew 24:16 (KJV) | | 1
[830] Matthew 24:17 (KJV) | | 1
[831] Matthew 24:18 (KJV) | | 1
[832] Matthew 24:19 (KJV) | | 1
[833] Matthew 24:20 (KJV) | | 1
[834] Matthew 24:21 (KJV) | | 1
[835] Matthew 24:22 (KJV) | | 1
[836] Matthew 24:23 (KJV) | | 1
[837] Matthew 24:24 (KJV) | | 1
[838] Matthew 24:25 (KJV) | | 1
[839] Matthew 24:26 (KJV) | | 1
[840] Matthew 24:27 (KJV) | | 1
[841] Matthew 24:28 (KJV) | | 1
[842] Matthew 24:29 (KJV) | | 1
[843] Matthew 24:30 (KJV) | | 1
[844] Matthew 24:31 (KJV) | | 1
[845] Matthew 24:32 (KJV) | | 1
[846] Matthew 24:33 (KJV) | | 1
[847] Matthew 24:34 (KJV) | | 1
[848] Matthew 24:35 (KJV) | | 1
[849] Matthew 24:36 (KJV) | | 1
[850] Matthew 24:37 (KJV) | | 1
[851] Matthew 24:38 (KJV) | | 1
[852] Matthew 24:39 (KJV) | | 1
[853] Matthew 24:40 (KJV) | | 1
[854] Matthew 24:41 (KJV) | | 1
[855] Matthew 24:42 (KJV) | | 1
[856] Matthew 24:43 (KJV) | | 1
[857] Matthew 24:44 (KJV) | | 1
[858] Matthew 24:45 (KJV) | | 1
[859] Matthew 24:46 (KJV) | | 1
[860] Matthew 24:47 (KJV) | | 1
[861] Matthew 24:48 (KJV) | | 1
[862] Matthew 24:49 (KJV) | | 1
[863] Matthew 24:50 (KJV) | | 1
[864] Matthew 24:51 (KJV) | | 1
[865] Matthew 25:1 (KJV) | | 1
[866] Matthew 25:2 (KJV) | | 1
[867] Matthew 25:3 (KJV) | | 1
[868] Matthew 25:4 (KJV) | | 1
[869] Matthew 25:5 (KJV) | | 1
[870] Matthew 25:6 (KJV) | | 1
[871] Matthew 25:7 (KJV) | | 1
[872] Matthew 25:8 (KJV) | | 1
[873] Matthew 25:9 (KJV) | | 1
[874] Matthew 25:10 (KJV) | | 1
[875] Matthew 25:11 (KJV) | | 1
[876] Matthew 25:12 (KJV) | | 1
[877] Matthew 25:13 (KJV) | | 1
[878] Matthew 25:14 (KJV) | | 1
[879] Matthew 25:15 (KJV) | | 1
[880] Matthew 25:16 (KJV) | | 1
[881] Matthew 25:17 (KJV) | | 1
[882] Matthew 25:18 (KJV) | | 1
[883] Matthew 25:19 (KJV) | | 1
[884] Matthew 25:20 (KJV) | | 1
[885] Matthew 25:21 (KJV) | | 1
[886] Matthew 25:22 (KJV) | | 1
[887] Matthew 25:23 (KJV) | | 1
[888] Matthew 25:24 (KJV) | | 1
[889] Matthew 25:25 (KJV) | | 1
[890] Matthew 25:26 (KJV) | | 1
[891] Matthew 25:27 (KJV) | | 1
[892] Matthew 25:28 (KJV) | | 1
[893] Matthew 25:29 (KJV) | | 1
[894] Matthew 25:30 (KJV) | | 1
[895] Matthew 25:31 (KJV) | | 1
[896] Matthew 25:32 (KJV) | | 1
[897] Matthew 25:33 (KJV) | | 1
[898] Matthew 25:34 (KJV) | | 1
[899] Matthew 25:35 (KJV) | | 1
[900] Matthew 25:36 (KJV) | | 1
[901] Matthew 25:37 (KJV) | | 1
[902] Matthew 25:38 (KJV) | | 1
[903] Matthew 25:39 (KJV) | | 1
[904] Matthew 25:40 (KJV) | | 1
[905] Matthew 25:41 (KJV) | | 1
[906] Matthew 25:42 (KJV) | | 1
[907] Matthew 25:43 (KJV) | | 1
[908] Matthew 25:44 (KJV) | | 1
[909] Matthew 25:45 (KJV) | | 1
[910] Matthew 25:46 (KJV) | | 1
[911] Matthew 26:1 (KJV) | | 1
[912] Matthew 26:2 (KJV) | | 1
[913] Matthew 26:3 (KJV) | | 1
[914] Matthew 26:4 (KJV) | | 1
[915] Matthew 26:5 (KJV) | | 1
[916] Matthew 26:6 (KJV) | | 1
[917] Matthew 26:7 (KJV) | | 1
[918] Matthew 26:8 (KJV) | | 1
[919] Matthew 26:9 (KJV) | | 1
[920] Matthew 26:10 (KJV) | | 1
[921] Matthew 26:11 (KJV) | | 1
[922] Matthew 26:12 (KJV) | | 1
[923] Matthew 26:13 (KJV) | | 1
[924] Matthew 26:14 (KJV) | | 1
[925] Matthew 26:15 (KJV) | | 1
[926] Matthew 26:16 (KJV) | | 1
[927] Matthew 26:17 (KJV) | | 1
[928] Matthew 26:18 (KJV) | | 1
[929] Matthew 26:19 (KJV) | | 1
[930] Matthew 26:20 (KJV) | | 1
[931] Matthew 26:21 (KJV) | | 1
[932] Matthew 26:22 (KJV) | | 1
[933] Matthew 26:23 (KJV) | | 1
[934] Matthew 26:24 (KJV) | | 1
[935] Matthew 26:25 (KJV) | | 1
[936] Matthew 26:26 (KJV) | | 1
[937] Matthew 26:27 (KJV) | | 1
[938] Matthew 26:28 (KJV) | | 1
[939] Matthew 26:29 (KJV) | | 1
[940] Matthew 26:30 (KJV) | | 1
[941] Matthew 26:31 (KJV) | | 1
[942] Matthew 26:32 (KJV) | | 1
[943] Matthew 26:33 (KJV) | | 1
[944] Matthew 26:34 (KJV) | | 1
[945] Matthew 26:35 (KJV) | | 1
[946] Matthew 26:36 (KJV) | | 1
[947] Matthew 26:37 (KJV) | | 1
[948] Matthew 26:38 (KJV) | | 1
[949] Matthew 26:39 (KJV) | | 1
[950] Matthew 26:40 (KJV) | | 1
[951] Matthew 26:41 (KJV) | | 1
[952] Matthew 26:42 (KJV) | | 1
[953] Matthew 26:43 (KJV) | | 1
[954] Matthew 26:44 (KJV) | | 1
[955] Matthew 26:45 (KJV) | | 1
[956] Matthew 26:46 (KJV) | | 1
[957] Matthew 26:47 (KJV) | | 1
[958] Matthew 26:48 (KJV) | | 1
[959] Matthew 26:49 (KJV) | | 1
[960] Matthew 26:50 (KJV) | | 1
[961] Matthew 26:51 (KJV) | | 1
[962] Matthew 26:52 (KJV) | | 1
[963] Matthew 26:53 (KJV) | | 1
[964] Matthew 26:54 (KJV) | | 1
[965] Matthew 26:55 (KJV) | | 1
[966] Matthew 26:56 (KJV) | | 1
[967] Matthew 26:57 (KJV) | | 1
[968] Matthew 26:58 (KJV) | | 1
[969] Matthew 26:59 (KJV) | | 1
[970] Matthew 26:60 (KJV) | | 1
[971] Matthew 26:61 (KJV) | | 1
[972] Matthew 26:62 (KJV) | | 1
[973] Matthew 26:63 (KJV) | | 1
[974] Matthew 26:64 (KJV) | | 1
[975] Matthew 26:65 (KJV) | | 1
[976] Matthew 26:66 (KJV) | | 1
[977] Matthew 26:67 (KJV) | | 1
[978] Matthew 26:68 (KJV) | | 1
[979] Matthew 26:69 (KJV) | | 1
[980] Matthew 26:70 (KJV) | | 1
[981] Matthew 26:71 (KJV) | | 1
[982] Matthew 26:72 (KJV) | | 1
[983] Matthew 26:73 (KJV) | | 1
[984] Matthew 26:74 (KJV) | | 1
[985] Matthew 26:75 (KJV) | | 1
[986] Matthew 27:1 (KJV) | | 1
[987] Matthew 27:2 (KJV) | | 1
[988] Matthew 27:3 (KJV) | | 1
[989] Matthew 27:4 (KJV) | | 1
[990] Matthew 27:5 (KJV) | | 1
[991] Matthew 27:6 (KJV) | | 1
[992] Matthew 27:7 (KJV) | | 1
[993] Matthew 27:8 (KJV) | | 1
[994] Matthew 27:9 (KJV) | | 1
[995] Matthew 27:10 (KJV) | | 1
[996] Matthew 27:11 (KJV) | | 1
[997] Matthew 27:12 (KJV) | | 1
[998] Matthew 27:13 (KJV) | | 1
[999] Matthew 27:14 (KJV) | | 1
[1000] Matthew 27:15 (KJV) | | 1
[1001] Matthew 27:16 (KJV) | | 1
[1002] Matthew 27:17 (KJV) | | 1
[1003] Matthew 27:18 (KJV) | | 1
[1004] Matthew 27:19 (KJV) | | 1
[1005] Matthew 27:20 (KJV) | | 1
[1006] Matthew 27:21 (KJV) | | 1
[1007] Matthew 27:22 (KJV) | | 1
[1008] Matthew 27:23 (KJV) | | 1
[1009] Matthew 27:24 (KJV) | | 1
[1010] Matthew 27:25 (KJV) | | 1
[1011] Matthew 27:26 (KJV) | | 1
[1012] Matthew 27:27 (KJV) | | 1
[1013] Matthew 27:28 (KJV) | | 1
[1014] Matthew 27:29 (KJV) | | 1
[1015] Matthew 27:30 (KJV) | | 1
[1016] Matthew 27:31 (KJV) | | 1
[1017] Matthew 27:32 (KJV) | | 1
[1018] Matthew 27:33 (KJV) | | 1
[1019] Matthew 27:34 (KJV) | | 1
[1020] Matthew 27:35 (KJV) | | 1
[1021] Matthew 27:36 (KJV) | | 1
[1022] Matthew 27:37 (KJV) | | 1
[1023] Matthew 27:38 (KJV) | | 1
[1024] Matthew 27:39 (KJV) | | 1
[1025] Matthew 27:40 (KJV) | | 1
[1026] Matthew 27:41 (KJV) | | 1
[1027] Matthew 27:42 (KJV) | | 1
[1028] Matthew 27:43 (KJV) | | 1
[1029] Matthew 27:44 (KJV) | | 1
[1030] Matthew 27:45 (KJV) | | 1
[1031] Matthew 27:46 (KJV) | | 1
[1032] Matthew 27:47 (KJV) | | 1
[1033] Matthew 27:48 (KJV) | | 1
[1034] Matthew 27:49 (KJV) | | 1
[1035] Matthew 27:50 (KJV) | | 1
[1036] Matthew 27:51 (KJV) | | 1
[1037] Matthew 27:52 (KJV) | | 1
[1038] Matthew 27:53 (KJV) | | 1
[1039] Matthew 27:54 (KJV) | | 1
[1040] Matthew 27:55 (KJV) | | 1
[1041] Matthew 27:56 (KJV) | | 1
[1042] Matthew 27:57 (KJV) | | 1
[1043] Matthew 27:58 (KJV) | | 1
[1044] Matthew 27:59 (KJV) | | 1
[1045] Matthew 27:60 (KJV) | | 1
[1046] Matthew 27:61 (KJV) | | 1
[1047] Matthew 27:62 (KJV) | | 1
[1048] Matthew 27:63 (KJV) | | 1
[1049] Matthew 27:64 (KJV) | | 1
[1050] Matthew 27:65 (KJV) | | 1
[1051] Matthew 27:66 (KJV) | | 1
[1052] Matthew 28:1 (KJV) | | 1
[1053] Matthew 28:2 (KJV) | | 1
[1054] Matthew 28:3 (KJV) | | 1
[1055] Matthew 28:4 (KJV) | | 1
[1056] Matthew 28:5 (KJV) | | 1
[1057] Matthew 28:6 (KJV) | | 1
[1058] Matthew 28:7 (KJV) | | 1
[1059] Matthew 28:8 (KJV) | | 1
[1060] Matthew 28:9 (KJV) | | 1
[1061] Matthew 28:10 (KJV) | | 1
[1062] Matthew 28:11 (KJV) | | 1
[1063] Matthew 28:12 (KJV) | | 1
[1064] Matthew 28:13 (KJV) | | 1
[1065] Matthew 28:14 (KJV) | | 1
[1066] Matthew 28:15 (KJV) | | 1
[1067] Matthew 28:16 (KJV) | | 1
[1068] Matthew 28:17 (KJV) | | 1
[1069] Matthew 28:18 (KJV) | | 1
[1070] Matthew 28:19 (KJV) | | 1
[1071] Matthew 28:20 (KJV) | | 1