title: The Gospel According to Luke (KJV)
url: https://www.gutenberg.org/cache/epub/8042/pg8042.txt
tier: 1
---
§ Luke 1

Forasmuch as many have taken in hand to set forth in order a declaration of those things which are most surely believed among us, [1]

Even as they delivered them unto us, which from the beginning were eyewitnesses, and ministers of the word; [2]

It seemed good to me also, having had perfect understanding of all things from the very first, to write unto thee in order, most excellent Theophilus, [3]

That thou mightest know the certainty of those things, wherein thou hast been instructed. [4]

THERE was in the days of Herod, the king of Judaea, a certain priest named Zacharias, of the course of Abia: and his wife was of the daughters of Aaron, and her name was Elisabeth. [5]

And they were both righteous before God, walking in all the commandments and ordinances of the Lord blameless. [6]

And they had no child, because that Elisabeth was barren, and they both were now well stricken in years. [7]

And it came to pass, that while he executed the priest's office before God in the order of his course, [8]

According to the custom of the priest's office, his lot was to burn incense when he went into the temple of the Lord. [9]

And the whole multitude of the people were praying without at the time of incense. [10]

And there appeared unto him an angel of the Lord standing on the right side of the altar of incense. [11]

And when Zacharias saw him, he was troubled, and fear fell upon him. [12]

But the angel said unto him, Fear not, Zacharias: for thy prayer is heard; and thy wife Elisabeth shall bear thee a son, and thou shalt call his name John. [13]

And thou shalt have joy and gladness; and many shall rejoice at his birth. [14]

For he shall be great in the sight of the Lord, and shall drink neither wine nor strong drink; and he shall be filled with the Holy Ghost, even from his mother's womb. [15]

And many of the children of Israel shall he turn to the Lord their God. [16]

And he shall go before him in the spirit and power of Elias, to turn the hearts of the fathers to the children, and the disobedient to the wisdom of the just; to make ready a people prepared for the Lord. [17]

And Zacharias said unto the angel, Whereby shall I know this? for I am an old man, and my wife well stricken in years. [18]

And the angel answering said unto him, I am Gabriel, that stand in the presence of God; and am sent to speak unto thee, and to shew thee these glad tidings. [19]

And, behold, thou shalt be dumb, and not able to speak, until the day that these things shall be performed, because thou believest not my words, which shall be fulfilled in their season. [20]

And the people waited for Zacharias, and marvelled that he tarried so long in the temple. [21]

And when he came out, he could not speak unto them: and they perceived that he had seen a vision in the temple: for he beckoned unto them, and remained speechless. [22]

And it came to pass, that, as soon as the days of his ministration were accomplished, he departed to his own house. [23]

And after those days his wife Elisabeth conceived, and hid herself five months, saying, [24]

Thus hath the Lord dealt with me in the days wherein he looked on me, to take away my reproach among men. [25]

And in the sixth month the angel Gabriel was sent from God unto a city of Galilee, named Nazareth, [26]

To a virgin espoused to a man whose name was Joseph, of the house of David; and the virgin's name was Mary. [27]

And the angel came in unto her, and said, Hail, thou that art highly favoured, the Lord is with thee: blessed art thou among women. [28]

And when she saw him, she was troubled at his saying, and cast in her mind what manner of salutation this should be. [29]

And the angel said unto her, Fear not, Mary: for thou hast found favour with God. [30]

And, behold, thou shalt conceive in thy womb, and bring forth a son, and shalt call his name JESUS. [31]

He shall be great, and shall be called the Son of the Highest: and the Lord God shall give unto him the throne of his father David: [32]

And he shall reign over the house of Jacob for ever; and of his kingdom there shall be no end. [33]

Then said Mary unto the angel, How shall this be, seeing I know not a man? [34]

And the angel answered and said unto her, The Holy Ghost shall come upon thee, and the power of the Highest shall overshadow thee: therefore also that holy thing which shall be born of thee shall be called the Son of God. [35]

And, behold, thy cousin Elisabeth, she hath also conceived a son in her old age: and this is the sixth month with her, who was called barren. [36]

For with God nothing shall be impossible. [37]

And Mary said, Behold the handmaid of the Lord; be it unto me according to thy word. And the angel departed from her. [38]

And Mary arose in those days, and went into the hill country with haste, into a city of Juda; [39]

And entered into the house of Zacharias, and saluted Elisabeth. [40]

And it came to pass, that, when Elisabeth heard the salutation of Mary, the babe leaped in her womb; and Elisabeth was filled with the Holy Ghost: [41]

And she spake out with a loud voice, and said, Blessed art thou among women, and blessed is the fruit of thy womb. [42]

And whence is this to me, that the mother of my Lord should come to me? [43]

For, lo, as soon as the voice of thy salutation sounded in mine ears, the babe leaped in my womb for joy. [44]

And blessed is she that believed: for there shall be a performance of those things which were told her from the Lord. [45]

And Mary said, My soul doth magnify the Lord, [46]

And my spirit hath rejoiced in God my Saviour. [47]

For he hath regarded the low estate of his handmaiden: for, behold, from henceforth all generations shall call me blessed. [48]

For he that is mighty hath done to me great things; and holy is his name. [49]

And his mercy is on them that fear him from generation to generation. [50]

He hath shewed strength with his arm; he hath scattered the proud in the imagination of their hearts. [51]

He hath put down the mighty from their seats, and exalted them of low degree. [52]

He hath filled the hungry with good things; and the rich he hath sent empty away. [53]

He hath holpen his servant Israel, in remembrance of his mercy; [54]

As he spake to our fathers, to Abraham, and to his seed for ever. [55]

And Mary abode with her about three months, and returned to her own house. [56]

Now Elisabeth's full time came that she should be delivered; and she brought forth a son. [57]

And her neighbours and her cousins heard how the Lord had shewed great mercy upon her; and they rejoiced with her. [58]

And it came to pass, that on the eighth day they came to circumcise the child; and they called him Zacharias, after the name of his father. [59]

And his mother answered and said, Not so; but he shall be called John. [60]

And they said unto her, There is none of thy kindred that is called by this name. [61]

And they made signs to his father, how he would have him called. [62]

And he asked for a writing table, and wrote, saying, His name is John. And they marvelled all. [63]

And his mouth was opened immediately, and his tongue loosed, and he spake, and praised God. [64]

And fear came on all that dwelt round about them: and all these sayings were noised abroad throughout all the hill country of Judaea. [65]

And all they that heard them laid them up in their hearts, saying, What manner of child shall this be! And the hand of the Lord was with him. [66]

And his father Zacharias was filled with the Holy Ghost, and prophesied, saying, [67]

Blessed be the Lord God of Israel; for he hath visited and redeemed his people, [68]

And hath raised up an horn of salvation for us in the house of his servant David; [69]

As he spake by the mouth of his holy prophets, which have been since the world began: [70]

That we should be saved from our enemies, and from the hand of all that hate us; [71]

To perform the mercy promised to our fathers, and to remember his holy covenant; [72]

The oath which he sware to our father Abraham, [73]

That he would grant unto us, that we being delivered out of the hand of our enemies might serve him without fear, [74]

In holiness and righteousness before him, all the days of our life. [75]

And thou, child, shalt be called the prophet of the Highest: for thou shalt go before the face of the Lord to prepare his ways; [76]

To give knowledge of salvation unto his people by the remission of their sins, [77]

Through the tender mercy of our God; whereby the dayspring from on high hath visited us, [78]

To give light to them that sit in darkness and in the shadow of death, to guide our feet into the way of peace. [79]

And the child grew, and waxed strong in spirit, and was in the deserts till the day of his shewing unto Israel. [80]

§ Luke 2

And it came to pass in those days, that there went out a decree from Caesar Augustus that all the world should be taxed. [81]

(And this taxing was first made when Cyrenius was governor of Syria.) [82]

And all went to be taxed, every one into his own city. [83]

And Joseph also went up from Galilee, out of the city of Nazareth, into Judaea, unto the city of David, which is called Bethlehem; (because he was of the house and lineage of David:) [84]

To be taxed with Mary his espoused wife, being great with child. [85]

And so it was, that, while they were there, the days were accomplished that she should be delivered. [86]

And she brought forth her firstborn son, and wrapped him in swaddling clothes, and laid him in a manger; because there was no room for them in the inn. [87]

And there were in the same country shepherds abiding in the field, keeping watch over their flock by night. [88]

And, lo, the angel of the Lord came upon them, and the glory of the Lord shone round about them: and they were sore afraid. [89]

And the angel said unto them, Fear not: for, behold, I bring you good tidings of great joy, which shall be to all people. [90]

For unto you is born this day in the city of David a Saviour, which is Christ the Lord. [91]

And this shall be a sign unto you; Ye shall find the babe wrapped in swaddling clothes, lying in a manger. [92]

And suddenly there was with the angel a multitude of the heavenly host praising God, and saying, [93]

Glory to God in the highest, and on earth peace, good will toward men. [94]

And it came to pass, as the angels were gone away from them into heaven, the shepherds said one to another, Let us now go even unto Bethlehem, and see this thing which is come to pass, which the Lord hath made known unto us. [95]

And they came with haste, and found Mary, and Joseph, and the babe lying in a manger. [96]

And when they had seen it, they made known abroad the saying which was told them concerning this child. [97]

And all they that heard it wondered at those things which were told them by the shepherds. [98]

But Mary kept all these things, and pondered them in her heart. [99]

And the shepherds returned, glorifying and praising God for all the things that they had heard and seen, as it was told unto them. [100]

And when eight days were accomplished for the circumcising of the child, his name was called JESUS, which was so named of the angel before he was conceived in the womb. [101]

And when the days of her purification according to the law of Moses were accomplished, they brought him to Jerusalem, to present him to the Lord; [102]

(As it is written in the law of the LORD, Every male that openeth the womb shall be called holy to the Lord;) [103]

And to offer a sacrifice according to that which is said in the law of the Lord, A pair of turtledoves, or two young pigeons. [104]

And, behold, there was a man in Jerusalem, whose name was Simeon; and the same man was just and devout, waiting for the consolation of Israel: and the Holy Ghost was upon him. [105]

And it was revealed unto him by the Holy Ghost, that he should not see death, before he had seen the Lord's Christ. [106]

And he came by the Spirit into the temple: and when the parents brought in the child Jesus, to do for him after the custom of the law, [107]

Then took he him up in his arms, and blessed God, and said, [108]

Lord, now lettest thou thy servant depart in peace, according to thy word: [109]

For mine eyes have seen thy salvation, [110]

Which thou hast prepared before the face of all people; [111]

A light to lighten the Gentiles, and the glory of thy people Israel. [112]

And Joseph and his mother marvelled at those things which were spoken of him. [113]

And Simeon blessed them, and said unto Mary his mother, Behold, this child is set for the fall and rising again of many in Israel; and for a sign which shall be spoken against; [114]

(Yea, a sword shall pierce through thy own soul also,) that the thoughts of many hearts may be revealed. [115]

And there was one Anna, a prophetess, the daughter of Phanuel, of the tribe of Aser: she was of a great age, and had lived with an husband seven years from her virginity; [116]

And she was a widow of about fourscore and four years, which departed not from the temple, but served God with fastings and prayers night and day. [117]

And she coming in that instant gave thanks likewise unto the Lord, and spake of him to all them that looked for redemption in Jerusalem. [118]

And when they had performed all things according to the law of the Lord, they returned into Galilee, to their own city Nazareth. [119]

And the child grew, and waxed strong in spirit, filled with wisdom: and the grace of God was upon him. [120]

Now his parents went to Jerusalem every year at the feast of the passover. [121]

And when he was twelve years old, they went up to Jerusalem after the custom of the feast. [122]

And when they had fulfilled the days, as they returned, the child Jesus tarried behind in Jerusalem; and Joseph and his mother knew not of it. [123]

But they, supposing him to have been in the company, went a day's journey; and they sought him among their kinsfolk and acquaintance. [124]

And when they found him not, they turned back again to Jerusalem, seeking him. [125]

And it came to pass, that after three days they found him in the temple, sitting in the midst of the doctors, both hearing them, and asking them questions. [126]

And all that heard him were astonished at his understanding and answers. [127]

And when they saw him, they were amazed: and his mother said unto him, Son, why hast thou thus dealt with us? behold, thy father and I have sought thee sorrowing. [128]

And he said unto them, How is it that ye sought me? wist ye not that I must be about my Father's business? [129]

And they understood not the saying which he spake unto them. [130]

And he went down with them, and came to Nazareth, and was subject unto them: but his mother kept all these sayings in her heart. [131]

And Jesus increased in wisdom and stature, and in favour with God and man. [132]

§ Luke 3

Now in the fifteenth year of the reign of Tiberius Caesar, Pontius Pilate being governor of Judaea, and Herod being tetrarch of Galilee, and his brother Philip tetrarch of Ituraea and of the region of Trachonitis, and Lysanias the tetrarch of Abilene, [133]

Annas and Caiaphas being the high priests, the word of God came unto John the son of Zacharias in the wilderness. [134]

And he came into all the country about Jordan, preaching the baptism of repentance for the remission of sins; [135]

As it is written in the book of the words of Esaias the prophet, saying, The voice of one crying in the wilderness, Prepare ye the way of the Lord, make his paths straight. [136]

Every valley shall be filled, and every mountain and hill shall be brought low; and the crooked shall be made straight, and the rough ways shall be made smooth; [137]

And all flesh shall see the salvation of God. [138]

Then said he to the multitude that came forth to be baptized of him, O generation of vipers, who hath warned you to flee from the wrath to come? [139]

Bring forth therefore fruits worthy of repentance, and begin not to say within yourselves, We have Abraham to our father: for I say unto you, That God is able of these stones to raise up children unto Abraham. [140]

And now also the axe is laid unto the root of the trees: every tree therefore which bringeth not forth good fruit is hewn down, and cast into the fire. [141]

And the people asked him, saying, What shall we do then? [142]

He answereth and saith unto them, He that hath two coats, let him impart to him that hath none; and he that hath meat, let him do likewise. [143]

Then came also publicans to be baptized, and said unto him, Master, what shall we do? [144]

And he said unto them, Exact no more than that which is appointed you. [145]

And the soldiers likewise demanded of him, saying, And what shall we do? And he said unto them, Do violence to no man, neither accuse any falsely; and be content with your wages. [146]

And as the people were in expectation, and all men mused in their hearts of John, whether he were the Christ, or not; [147]

John answered, saying unto them all, I indeed baptize you with water; but one mightier than I cometh, the latchet of whose shoes I am not worthy to unloose: he shall baptize you with the Holy Ghost and with fire: [148]

Whose fan is in his hand, and he will throughly purge his floor, and will gather the wheat into his garner; but the chaff he will burn with fire unquenchable. [149]

And many other things in his exhortation preached he unto the people. [150]

But Herod the tetrarch, being reproved by him for Herodias his brother Philip's wife, and for all the evils which Herod had done, [151]

Added yet this above all, that he shut up John in prison. [152]

Now when all the people were baptized, it came to pass, that Jesus also being baptized, and praying, the heaven was opened, [153]

And the Holy Ghost descended in a bodily shape like a dove upon him, and a voice came from heaven, which said, Thou art my beloved Son; in thee I am well pleased. [154]

And Jesus himself began to be about thirty years of age, being (as was supposed) the son of Joseph, which was the son of Heli, [155]

Which was the son of Matthat, which was the son of Levi, which was the son of Melchi, which was the son of Janna, which was the son of Joseph, [156]

Which was the son of Mattathias, which was the son of Amos, which was the son of Naum, which was the son of Esli, which was the son of Nagge, [157]

Which was the son of Maath, which was the son of Mattathias, which was the son of Semei, which was the son of Joseph, which was the son of Juda, [158]

Which was the son of Joanna, which was the son of Rhesa, which was the son of Zorobabel, which was the son of Salathiel, which was the son of Neri, [159]

Which was the son of Melchi, which was the son of Addi, which was the son of Cosam, which was the son of Elmodam, which was the son of Er, [160]

Which was the son of Jose, which was the son of Eliezer, which was the son of Jorim, which was the son of Matthat, which was the son of Levi, [161]

Which was the son of Simeon, which was the son of Juda, which was the son of Joseph, which was the son of Jonan, which was the son of Eliakim, [162]

Which was the son of Melea, which was the son of Menan, which was the son of Mattatha, which was the son of Nathan, which was the son of David, [163]

Which was the son of Jesse, which was the son of Obed, which was the son of Booz, which was the son of Salmon, which was the son of Naasson, [164]

Which was the son of Aminadab, which was the son of Aram, which was the son of Esrom, which was the son of Phares, which was the son of Juda, [165]

Which was the son of Jacob, which was the son of Isaac, which was the son of Abraham, which was the son of Thara, which was the son of Nachor, [166]

Which was the son of Saruch, which was the son of Ragau, which was the son of Phalec, which was the son of Heber, which was the son of Sala, [167]

Which was the son of Cainan, which was the son of Arphaxad, which was the son of Sem, which was the son of Noe, which was the son of Lamech, [168]

Which was the son of Mathusala, which was the son of Enoch, which was the son of Jared, which was the son of Maleleel, which was the son of Cainan, [169]

Which was the son of Enos, which was the son of Seth, which was the son of Adam, which was the son of God. [170]

§ Luke 4

And Jesus being full of the Holy Ghost returned from Jordan, and was led by the Spirit into the wilderness, [171]

Being forty days tempted of the devil. And in those days he did eat nothing: and when they were ended, he afterward hungered. [172]

And the devil said unto him, If thou be the Son of God, command this stone that it be made bread. [173]

And Jesus answered him, saying, It is written, That man shall not live by bread alone, but by every word of God. [174]

And the devil, taking him up into an high mountain, shewed unto him all the kingdoms of the world in a moment of time. [175]

And the devil said unto him, All this power will I give thee, and the glory of them: for that is delivered unto me; and to whomsoever I will I give it. [176]

If thou therefore wilt worship me, all shall be thine. [177]

And Jesus answered and said unto him, Get thee behind me, Satan: for it is written, Thou shalt worship the Lord thy God, and him only shalt thou serve. [178]

And he brought him to Jerusalem, and set him on a pinnacle of the temple, and said unto him, If thou be the Son of God, cast thyself down from hence: [179]

For it is written, He shall give his angels charge over thee, to keep thee: [180]

And in their hands they shall bear thee up, lest at any time thou dash thy foot against a stone. [181]

And Jesus answering said unto him, It is said, Thou shalt not tempt the Lord thy God. [182]

And when the devil had ended all the temptation, he departed from him for a season. [183]

And Jesus returned in the power of the Spirit into Galilee: and there went out a fame of him through all the region round about. [184]

And he taught in their synagogues, being glorified of all. [185]

And he came to Nazareth, where he had been brought up: and, as his custom was, he went into the synagogue on the sabbath day, and stood up for to read. [186]

And there was delivered unto him the book of the prophet Esaias. And when he had opened the book, he found the place where it was written, [187]

The Spirit of the Lord is upon me, because he hath anointed me to preach the gospel to the poor; he hath sent me to heal the brokenhearted, to preach deliverance to the captives, and recovering of sight to the blind, to set at liberty them that are bruised, [188]

To preach the acceptable year of the Lord. [189]

And he closed the book, and he gave it again to the minister, and sat down. And the eyes of all them that were in the synagogue were fastened on him. [190]

And he began to say unto them, This day is this scripture fulfilled in your ears. [191]

And all bare him witness, and wondered at the gracious words which proceeded out of his mouth. And they said, Is not this Joseph's son? [192]

And he said unto them, Ye will surely say unto me this proverb, Physician, heal thyself: whatsoever we have heard done in Capernaum, do also here in thy country. [193]

And he said, Verily I say unto you, No prophet is accepted in his own country. [194]

But I tell you of a truth, many widows were in Israel in the days of Elias, when the heaven was shut up three years and six months, when great famine was throughout all the land; [195]

But unto none of them was Elias sent, save unto Sarepta, a city of Sidon, unto a woman that was a widow. [196]

And many lepers were in Israel in the time of Eliseus the prophet; and none of them was cleansed, saving Naaman the Syrian. [197]

And all they in the synagogue, when they heard these things, were filled with wrath, [198]

And rose up, and thrust him out of the city, and led him unto the brow of the hill whereon their city was built, that they might cast him down headlong. [199]

But he passing through the midst of them went his way, [200]

And came down to Capernaum, a city of Galilee, and taught them on the sabbath days. [201]

And they were astonished at his doctrine: for his word was with power. [202]

And in the synagogue there was a man, which had a spirit of an unclean devil, and cried out with a loud voice, [203]

Saying, Let us alone; what have we to do with thee, thou Jesus of Nazareth? art thou come to destroy us? I know thee who thou art; the Holy One of God. [204]

And Jesus rebuked him, saying, Hold thy peace, and come out of him. And when the devil had thrown him in the midst, he came out of him, and hurt him not. [205]

And they were all amazed, and spake among themselves, saying, What a word is this! for with authority and power he commandeth the unclean spirits, and they come out. [206]

And the fame of him went out into every place of the country round about. [207]

And he arose out of the synagogue, and entered into Simon's house. And Simon's wife's mother was taken with a great fever; and they besought him for her. [208]

And he stood over her, and rebuked the fever; and it left her: and immediately she arose and ministered unto them. [209]

Now when the sun was setting, all they that had any sick with divers diseases brought them unto him; and he laid his hands on every one of them, and healed them. [210]

And devils also came out of many, crying out, and saying, Thou art Christ the Son of God. And he rebuking them suffered them not to speak: for they knew that he was Christ. [211]

And when it was day, he departed and went into a desert place: and the people sought him, and came unto him, and stayed him, that he should not depart from them. [212]

And he said unto them, I must preach the kingdom of God to other cities also: for therefore am I sent. [213]

And he preached in the synagogues of Galilee. [214]

§ Luke 5

And it came to pass, that, as the people pressed upon him to hear the word of God, he stood by the lake of Gennesaret, [215]

And saw two ships standing by the lake: but the fishermen were gone out of them, and were washing their nets. [216]

And he entered into one of the ships, which was Simon's, and prayed him that he would thrust out a little from the land. And he sat down, and taught the people out of the ship. [217]

Now when he had left speaking, he said unto Simon, Launch out into the deep, and let down your nets for a draught. [218]

And Simon answering said unto him, Master, we have toiled all the night, and have taken nothing: nevertheless at thy word I will let down the net. [219]

And when they had this done, they inclosed a great multitude of fishes: and their net brake. [220]

And they beckoned unto their partners, which were in the other ship, that they should come and help them. And they came, and filled both the ships, so that they began to sink. [221]

When Simon Peter saw it, he fell down at Jesus' knees, saying, Depart from me; for I am a sinful man, O Lord. [222]

For he was astonished, and all that were with him, at the draught of the fishes which they had taken: [223]

And so was also James, and John, the sons of Zebedee, which were partners with Simon. And Jesus said unto Simon, Fear not; from henceforth thou shalt catch men. [224]

And when they had brought their ships to land, they forsook all, and followed him. [225]

And it came to pass, when he was in a certain city, behold a man full of leprosy: who seeing Jesus fell on his face, and besought him, saying, Lord, if thou wilt, thou canst make me clean. [226]

And he put forth his hand, and touched him, saying, I will: be thou clean. And immediately the leprosy departed from him. [227]

And he charged him to tell no man: but go, and shew thyself to the priest, and offer for thy cleansing, according as Moses commanded, for a testimony unto them. [228]

But so much the more went there a fame abroad of him: and great multitudes came together to hear, and to be healed by him of their infirmities. [229]

And he withdrew himself into the wilderness, and prayed. [230]

And it came to pass on a certain day, as he was teaching, that there were Pharisees and doctors of the law sitting by, which were come out of every town of Galilee, and Judaea, and Jerusalem: and the power of the Lord was present to heal them. [231]

And, behold, men brought in a bed a man which was taken with a palsy: and they sought means to bring him in, and to lay him before him. [232]

And when they could not find by what way they might bring him in because of the multitude, they went upon the housetop, and let him down through the tiling with his couch into the midst before Jesus. [233]

And when he saw their faith, he said unto him, Man, thy sins are forgiven thee. [234]

And the scribes and the Pharisees began to reason, saying, Who is this which speaketh blasphemies? Who can forgive sins, but God alone? [235]

But when Jesus perceived their thoughts, he answering said unto them, What reason ye in your hearts? [236]

Whether is easier, to say, Thy sins be forgiven thee; or to say, Rise up and walk? [237]

But that ye may know that the Son of man hath power upon earth to forgive sins, (he said unto the sick of the palsy,) I say unto thee, Arise, and take up thy couch, and go into thine house. [238]

And immediately he rose up before them, and took up that whereon he lay, and departed to his own house, glorifying God. [239]

And they were all amazed, and they glorified God, and were filled with fear, saying, We have seen strange things to day. [240]

And after these things he went forth, and saw a publican, named Levi, sitting at the receipt of custom: and he said unto him, Follow me. [241]

And he left all, rose up, and followed him. [242]

And Levi made him a great feast in his own house: and there was a great company of publicans and of others that sat down with them. [243]

But their scribes and Pharisees murmured against his disciples, saying, Why do ye eat and drink with publicans and sinners? [244]

And Jesus answering said unto them, They that are whole need not a physician; but they that are sick. [245]

I came not to call the righteous, but sinners to repentance. [246]

And they said unto him, Why do the disciples of John fast often, and make prayers, and likewise the disciples of the Pharisees; but thine eat and drink? [247]

And he said unto them, Can ye make the children of the bridechamber fast, while the bridegroom is with them? [248]

But the days will come, when the bridegroom shall be taken away from them, and then shall they fast in those days. [249]

And he spake also a parable unto them; No man putteth a piece of a new garment upon an old; if otherwise, then both the new maketh a rent, and the piece that was taken out of the new agreeth not with the old. [250]

And no man putteth new wine into old bottles; else the new wine will burst the bottles, and be spilled, and the bottles shall perish. [251]

But new wine must be put into new bottles; and both are preserved. [252]

No man also having drunk old wine straightway desireth new: for he saith, The old is better. [253]

§ Luke 6

And it came to pass on the second sabbath after the first, that he went through the corn fields; and his disciples plucked the ears of corn, and did eat, rubbing them in their hands. [254]

And certain of the Pharisees said unto them, Why do ye that which is not lawful to do on the sabbath days? [255]

And Jesus answering them said, Have ye not read so much as this, what David did, when himself was an hungred, and they which were with him; [256]

How he went into the house of God, and did take and eat the shewbread, and gave also to them that were with him; which it is not lawful to eat but for the priests alone? [257]

And he said unto them, That the Son of man is Lord also of the sabbath. [258]

And it came to pass also on another sabbath, that he entered into the synagogue and taught: and there was a man whose right hand was withered. [259]

And the scribes and Pharisees watched him, whether he would heal on the sabbath day; that they might find an accusation against him. [260]

But he knew their thoughts, and said to the man which had the withered hand, Rise up, and stand forth in the midst. And he arose and stood forth. [261]

Then said Jesus unto them, I will ask you one thing; Is it lawful on the sabbath days to do good, or to do evil? to save life, or to destroy it? [262]

And looking round about upon them all, he said unto the man, Stretch forth thy hand. And he did so: and his hand was restored whole as the other. [263]

And they were filled with madness; and communed one with another what they might do to Jesus. [264]

And it came to pass in those days, that he went out into a mountain to pray, and continued all night in prayer to God. [265]

And when it was day, he called unto him his disciples: and of them he chose twelve, whom also he named apostles; [266]

Simon, (whom he also named Peter,) and Andrew his brother, James and John, Philip and Bartholomew, [267]

Matthew and Thomas, James the son of Alphaeus, and Simon called Zelotes, [268]

And Judas the brother of James, and Judas Iscariot, which also was the traitor. [269]

And he came down with them, and stood in the plain, and the company of his disciples, and a great multitude of people out of all Judaea and Jerusalem, and from the sea coast of Tyre and Sidon, which came to hear him, and to be healed of their diseases; [270]

And they that were vexed with unclean spirits: and they were healed. [271]

And the whole multitude sought to touch him: for there went virtue out of him, and healed them all. [272]

And he lifted up his eyes on his disciples, and said, Blessed be ye poor: for yours is the kingdom of God. [273]

Blessed are ye that hunger now: for ye shall be filled. Blessed are ye that weep now: for ye shall laugh. [274]

Blessed are ye, when men shall hate you, and when they shall separate you from their company, and shall reproach you, and cast out your name as evil, for the Son of man's sake. [275]

Rejoice ye in that day, and leap for joy: for, behold, your reward is great in heaven: for in the like manner did their fathers unto the prophets. [276]

But woe unto you that are rich! for ye have received your consolation. [277]

Woe unto you that are full! for ye shall hunger. Woe unto you that laugh now! for ye shall mourn and weep. [278]

Woe unto you, when all men shall speak well of you! for so did their fathers to the false prophets. [279]

But I say unto you which hear, Love your enemies, do good to them which hate you, [280]

Bless them that curse you, and pray for them which despitefully use you. [281]

And unto him that smiteth thee on the one cheek offer also the other; and him that taketh away thy cloak forbid not to take thy coat also. [282]

Give to every man that asketh of thee; and of him that taketh away thy goods ask them not again. [283]

And as ye would that men should do to you, do ye also to them likewise. [284]

For if ye love them which love you, what thank have ye? for sinners also love those that love them. [285]

And if ye do good to them which do good to you, what thank have ye? for sinners also do even the same. [286]

And if ye lend to them of whom ye hope to receive, what thank have ye? for sinners also lend to sinners, to receive as much again. [287]

But love ye your enemies, and do good, and lend, hoping for nothing again; and your reward shall be great, and ye shall be the children of the Highest: for he is kind unto the unthankful and to the evil. [288]

Be ye therefore merciful, as your Father also is merciful. [289]

Judge not, and ye shall not be judged: condemn not, and ye shall not be condemned: forgive, and ye shall be forgiven: [290]

Give, and it shall be given unto you; good measure, pressed down, and shaken together, and running over, shall men give into your bosom. For with the same measure that ye mete withal it shall be measured to you again. [291]

And he spake a parable unto them, Can the blind lead the blind? shall they not both fall into the ditch? [292]

The disciple is not above his master: but every one that is perfect shall be as his master. [293]

And why beholdest thou the mote that is in thy brother's eye, but perceivest not the beam that is in thine own eye? [294]

Either how canst thou say to thy brother, Brother, let me pull out the mote that is in thine eye, when thou thyself beholdest not the beam that is in thine own eye? Thou hypocrite, cast out first the beam out of thine own eye, and then shalt thou see clearly to pull out the mote that is in thy brother's eye. [295]

For a good tree bringeth not forth corrupt fruit; neither doth a corrupt tree bring forth good fruit. [296]

For every tree is known by his own fruit. For of thorns men do not gather figs, nor of a bramble bush gather they grapes. [297]

A good man out of the good treasure of his heart bringeth forth that which is good; and an evil man out of the evil treasure of his heart bringeth forth that which is evil: for of the abundance of the heart his mouth speaketh. [298]

And why call ye me, Lord, Lord, and do not the things which I say? [299]

Whosoever cometh to me, and heareth my sayings, and doeth them, I will shew you to whom he is like: [300]

He is like a man which built an house, and digged deep, and laid the foundation on a rock: and when the flood arose, the stream beat vehemently upon that house, and could not shake it: for it was founded upon a rock. [301]

But he that heareth, and doeth not, is like a man that without a foundation built an house upon the earth; against which the stream did beat vehemently, and immediately it fell; and the ruin of that house was great. [302]

§ Luke 7

Now when he had ended all his sayings in the audience of the people, he entered into Capernaum. [303]

And a certain centurion's servant, who was dear unto him, was sick, and ready to die. [304]

And when he heard of Jesus, he sent unto him the elders of the Jews, beseeching him that he would come and heal his servant. [305]

And when they came to Jesus, they besought him instantly, saying, That he was worthy for whom he should do this: [306]

For he loveth our nation, and he hath built us a synagogue. [307]

Then Jesus went with them. And when he was now not far from the house, the centurion sent friends to him, saying unto him, Lord, trouble not thyself: for I am not worthy that thou shouldest enter under my roof: [308]

Wherefore neither thought I myself worthy to come unto thee: but say in a word, and my servant shall be healed. [309]

For I also am a man set under authority, having under me soldiers, and I say unto one, Go, and he goeth; and to another, Come, and he cometh; and to my servant, Do this, and he doeth it. [310]

When Jesus heard these things, he marvelled at him, and turned him about, and said unto the people that followed him, I say unto you, I have not found so great faith, no, not in Israel. [311]

And they that were sent, returning to the house, found the servant whole that had been sick. [312]

And it came to pass the day after, that he went into a city called Nain; and many of his disciples went with him, and much people. [313]

Now when he came nigh to the gate of the city, behold, there was a dead man carried out, the only son of his mother, and she was a widow: and much people of the city was with her. [314]

And when the Lord saw her, he had compassion on her, and said unto her, Weep not. [315]

And he came and touched the bier: and they that bare him stood still. And he said, Young man, I say unto thee, Arise. [316]

And he that was dead sat up, and began to speak. And he delivered him to his mother. [317]

And there came a fear on all: and they glorified God, saying, That a great prophet is risen up among us; and, That God hath visited his people. [318]

And this rumour of him went forth throughout all Judaea, and throughout all the region round about. [319]

And the disciples of John shewed him of all these things. [320]

And John calling unto him two of his disciples sent them to Jesus, saying, Art thou he that should come? or look we for another? [321]

When the men were come unto him, they said, John Baptist hath sent us unto thee, saying, Art thou he that should come? or look we for another? [322]

And in that same hour he cured many of their infirmities and plagues, and of evil spirits; and unto many that were blind he gave sight. [323]

Then Jesus answering said unto them, Go your way, and tell John what things ye have seen and heard; how that the blind see, the lame walk, the lepers are cleansed, the deaf hear, the dead are raised, to the poor the gospel is preached. [324]

And blessed is he, whosoever shall not be offended in me. [325]

And when the messengers of John were departed, he began to speak unto the people concerning John, What went ye out into the wilderness for to see? A reed shaken with the wind? [326]

But what went ye out for to see? A man clothed in soft raiment? Behold, they which are gorgeously apparelled, and live delicately, are in kings' courts. [327]

But what went ye out for to see? A prophet? Yea, I say unto you, and much more than a prophet. [328]

This is he, of whom it is written, Behold, I send my messenger before thy face, which shall prepare thy way before thee. [329]

For I say unto you, Among those that are born of women there is not a greater prophet than John the Baptist: but he that is least in the kingdom of God is greater than he. [330]

And all the people that heard him, and the publicans, justified God, being baptized with the baptism of John. [331]

But the Pharisees and lawyers rejected the counsel of God against themselves, being not baptized of him. [332]

And the Lord said, Whereunto then shall I liken the men of this generation? and to what are they like? [333]

They are like unto children sitting in the marketplace, and calling one to another, and saying, We have piped unto you, and ye have not danced; we have mourned to you, and ye have not wept. [334]

For John the Baptist came neither eating bread nor drinking wine; and ye say, He hath a devil. [335]

The Son of man is come eating and drinking; and ye say, Behold a gluttonous man, and a winebibber, a friend of publicans and sinners! [336]

But wisdom is justified of all her children. [337]

And one of the Pharisees desired him that he would eat with him. And he went into the Pharisee's house, and sat down to meat. [338]

And, behold, a woman in the city, which was a sinner, when she knew that Jesus sat at meat in the Pharisee's house, brought an alabaster box of ointment, [339]

And stood at his feet behind him weeping, and began to wash his feet with tears, and did wipe them with the hairs of her head, and kissed his feet, and anointed them with the ointment. [340]

Now when the Pharisee which had bidden him saw it, he spake within himself, saying, This man, if he were a prophet, would have known who and what manner of woman this is that toucheth him: for she is a sinner. [341]

And Jesus answering said unto him, Simon, I have somewhat to say unto thee. And he saith, Master, say on. [342]

There was a certain creditor which had two debtors: the one owed five hundred pence, and the other fifty. [343]

And when they had nothing to pay, he frankly forgave them both. Tell me therefore, which of them will love him most? [344]

Simon answered and said, I suppose that he, to whom he forgave most. And he said unto him, Thou hast rightly judged. [345]

And he turned to the woman, and said unto Simon, Seest thou this woman? I entered into thine house, thou gavest me no water for my feet: but she hath washed my feet with tears, and wiped them with the hairs of her head. [346]

Thou gavest me no kiss: but this woman since the time I came in hath not ceased to kiss my feet. [347]

My head with oil thou didst not anoint: but this woman hath anointed my feet with ointment. [348]

Wherefore I say unto thee, Her sins, which are many, are forgiven; for she loved much: but to whom little is forgiven, the same loveth little. [349]

And he said unto her, Thy sins are forgiven. [350]

And they that sat at meat with him began to say within themselves, Who is this that forgiveth sins also? [351]

And he said to the woman, Thy faith hath saved thee; go in peace. [352]

§ Luke 8

And it came to pass afterward, that he went throughout every city and village, preaching and shewing the glad tidings of the kingdom of God: and the twelve were with him, [353]

And certain women, which had been healed of evil spirits and infirmities, Mary called Magdalene, out of whom went seven devils, [354]

And Joanna the wife of Chuza Herod's steward, and Susanna, and many others, which ministered unto him of their substance. [355]

And when much people were gathered together, and were come to him out of every city, he spake by a parable: [356]

A sower went out to sow his seed: and as he sowed, some fell by the way side; and it was trodden down, and the fowls of the air devoured it. [357]

And some fell upon a rock; and as soon as it was sprung up, it withered away, because it lacked moisture. [358]

And some fell among thorns; and the thorns sprang up with it, and choked it. [359]

And other fell on good ground, and sprang up, and bare fruit an hundredfold. And when he had said these things, he cried, He that hath ears to hear, let him hear. [360]

And his disciples asked him, saying, What might this parable be? [361]

And he said, Unto you it is given to know the mysteries of the kingdom of God: but to others in parables; that seeing they might not see, and hearing they might not understand. [362]

Now the parable is this: The seed is the word of God. [363]

Those by the way side are they that hear; then cometh the devil, and taketh away the word out of their hearts, lest they should believe and be saved. [364]

They on the rock are they, which, when they hear, receive the word with joy; and these have no root, which for a while believe, and in time of temptation fall away. [365]

And that which fell among thorns are they, which, when they have heard, go forth, and are choked with cares and riches and pleasures of this life, and bring no fruit to perfection. [366]

But that on the good ground are they, which in an honest and good heart, having heard the word, keep it, and bring forth fruit with patience. [367]

No man, when he hath lighted a candle, covereth it with a vessel, or putteth it under a bed; but setteth it on a candlestick, that they which enter in may see the light. [368]

For nothing is secret, that shall not be made manifest; neither any thing hid, that shall not be known and come abroad. [369]

Take heed therefore how ye hear: for whosoever hath, to him shall be given; and whosoever hath not, from him shall be taken even that which he seemeth to have. [370]

Then came to him his mother and his brethren, and could not come at him for the press. [371]

And it was told him by certain which said, Thy mother and thy brethren stand without, desiring to see thee. [372]

And he answered and said unto them, My mother and my brethren are these which hear the word of God, and do it. [373]

Now it came to pass on a certain day, that he went into a ship with his disciples: and he said unto them, Let us go over unto the other side of the lake. And they launched forth. [374]

But as they sailed he fell asleep: and there came down a storm of wind on the lake; and they were filled with water, and were in jeopardy. [375]

And they came to him, and awoke him, saying, Master, master, we perish. Then he arose, and rebuked the wind and the raging of the water: and they ceased, and there was a calm. [376]

And he said unto them, Where is your faith? And they being afraid wondered, saying one to another, What manner of man is this! for he commandeth even the winds and water, and they obey him. [377]

And they arrived at the country of the Gadarenes, which is over against Galilee. [378]

And when he went forth to land, there met him out of the city a certain man, which had devils long time, and ware no clothes, neither abode in any house, but in the tombs. [379]

When he saw Jesus, he cried out, and fell down before him, and with a loud voice said, What have I to do with thee, Jesus, thou Son of God most high? I beseech thee, torment me not. [380]

(For he had commanded the unclean spirit to come out of the man. For oftentimes it had caught him: and he was kept bound with chains and in fetters; and he brake the bands, and was driven of the devil into the wilderness.) [381]

And Jesus asked him, saying, What is thy name? And he said, Legion: because many devils were entered into him. [382]

And they besought him that he would not command them to go out into the deep. [383]

And there was there an herd of many swine feeding on the mountain: and they besought him that he would suffer them to enter into them. And he suffered them. [384]

Then went the devils out of the man, and entered into the swine: and the herd ran violently down a steep place into the lake, and were choked. [385]

When they that fed them saw what was done, they fled, and went and told it in the city and in the country. [386]

Then they went out to see what was done; and came to Jesus, and found the man, out of whom the devils were departed, sitting at the feet of Jesus, clothed, and in his right mind: and they were afraid. [387]

They also which saw it told them by what means he that was possessed of the devils was healed. [388]

Then the whole multitude of the country of the Gadarenes round about besought him to depart from them; for they were taken with great fear: and he went up into the ship, and returned back again. [389]

Now the man out of whom the devils were departed besought him that he might be with him: but Jesus sent him away, saying, [390]

Return to thine own house, and shew how great things God hath done unto thee. And he went his way, and published throughout the whole city how great things Jesus had done unto him. [391]

And it came to pass, that, when Jesus was returned, the people gladly received him: for they were all waiting for him. [392]

And, behold, there came a man named Jairus, and he was a ruler of the synagogue: and he fell down at Jesus' feet, and besought him that he would come into his house: [393]

For he had one only daughter, about twelve years of age, and she lay a dying. But as he went the people thronged him. [394]

And a woman having an issue of blood twelve years, which had spent all her living upon physicians, neither could be healed of any, [395]

Came behind him, and touched the border of his garment: and immediately her issue of blood stanched. [396]

And Jesus said, Who touched me? When all denied, Peter and they that were with him said, Master, the multitude throng thee and press thee, and sayest thou, Who touched me? [397]

And Jesus said, Somebody hath touched me: for I perceive that virtue is gone out of me. [398]

And when the woman saw that she was not hid, she came trembling, and falling down before him, she declared unto him before all the people for what cause she had touched him, and how she was healed immediately. [399]

And he said unto her, Daughter, be of good comfort: thy faith hath made thee whole; go in peace. [400]

While he yet spake, there cometh one from the ruler of the synagogue's house, saying to him, Thy daughter is dead; trouble not the Master. [401]

But when Jesus heard it, he answered him, saying, Fear not: believe only, and she shall be made whole. [402]

And when he came into the house, he suffered no man to go in, save Peter, and James, and John, and the father and the mother of the maiden. [403]

And all wept, and bewailed her: but he said, Weep not; she is not dead, but sleepeth. [404]

And they laughed him to scorn, knowing that she was dead. [405]

And he put them all out, and took her by the hand, and called, saying, Maid, arise. [406]

And her spirit came again, and she arose straightway: and he commanded to give her meat. [407]

And her parents were astonished: but he charged them that they should tell no man what was done. [408]

§ Luke 9

Then he called his twelve disciples together, and gave them power and authority over all devils, and to cure diseases. [409]

And he sent them to preach the kingdom of God, and to heal the sick. [410]

And he said unto them, Take nothing for your journey, neither staves, nor scrip, neither bread, neither money; neither have two coats apiece. [411]

And whatsoever house ye enter into, there abide, and thence depart. [412]

And whosoever will not receive you, when ye go out of that city, shake off the very dust from your feet for a testimony against them. [413]

And they departed, and went through the towns, preaching the gospel, and healing every where. [414]

Now Herod the tetrarch heard of all that was done by him: and he was perplexed, because that it was said of some, that John was risen from the dead; [415]

And of some, that Elias had appeared; and of others, that one of the old prophets was risen again. [416]

And Herod said, John have I beheaded: but who is this, of whom I hear such things? And he desired to see him. [417]

And the apostles, when they were returned, told him all that they had done. And he took them, and went aside privately into a desert place belonging to the city called Bethsaida. [418]

And the people, when they knew it, followed him: and he received them, and spake unto them of the kingdom of God, and healed them that had need of healing. [419]

And when the day began to wear away, then came the twelve, and said unto him, Send the multitude away, that they may go into the towns and country round about, and lodge, and get victuals: for we are here in a desert place. [420]

But he said unto them, Give ye them to eat. And they said, We have no more but five loaves and two fishes; except we should go and buy meat for all this people. [421]

For they were about five thousand men. And he said to his disciples, Make them sit down by fifties in a company. [422]

And they did so, and made them all sit down. [423]

Then he took the five loaves and the two fishes, and looking up to heaven, he blessed them, and brake, and gave to the disciples to set before the multitude. [424]

And they did eat, and were all filled: and there was taken up of fragments that remained to them twelve baskets. [425]

And it came to pass, as he was alone praying, his disciples were with him: and he asked them, saying, Whom say the people that I am? [426]

They answering said, John the Baptist; but some say, Elias; and others say, that one of the old prophets is risen again. [427]

He said unto them, But whom say ye that I am? Peter answering said, The Christ of God. [428]

And he straitly charged them, and commanded them to tell no man that thing; [429]

Saying, The Son of man must suffer many things, and be rejected of the elders and chief priests and scribes, and be slain, and be raised the third day. [430]

And he said to them all, If any man will come after me, let him deny himself, and take up his cross daily, and follow me. [431]

For whosoever will save his life shall lose it: but whosoever will lose his life for my sake, the same shall save it. [432]

For what is a man advantaged, if he gain the whole world, and lose himself, or be cast away? [433]

For whosoever shall be ashamed of me and of my words, of him shall the Son of man be ashamed, when he shall come in his own glory, and in his Father's, and of the holy angels. [434]

But I tell you of a truth, there be some standing here, which shall not taste of death, till they see the kingdom of God. [435]

And it came to pass about an eight days after these sayings, he took Peter and John and James, and went up into a mountain to pray. [436]

And as he prayed, the fashion of his countenance was altered, and his raiment was white and glistering. [437]

And, behold, there talked with him two men, which were Moses and Elias: [438]

Who appeared in glory, and spake of his decease which he should accomplish at Jerusalem. [439]

But Peter and they that were with him were heavy with sleep: and when they were awake, they saw his glory, and the two men that stood with him. [440]

And it came to pass, as they departed from him, Peter said unto Jesus, Master, it is good for us to be here: and let us make three tabernacles; one for thee, and one for Moses, and one for Elias: not knowing what he said. [441]

While he thus spake, there came a cloud, and overshadowed them: and they feared as they entered into the cloud. [442]

And there came a voice out of the cloud, saying, This is my beloved Son: hear him. [443]

And when the voice was past, Jesus was found alone. And they kept it close, and told no man in those days any of those things which they had seen. [444]

And it came to pass, that on the next day, when they were come down from the hill, much people met him. [445]

And, behold, a man of the company cried out, saying, Master, I beseech thee, look upon my son: for he is mine only child. [446]

And, lo, a spirit taketh him, and he suddenly crieth out; and it teareth him that he foameth again, and bruising him hardly departeth from him. [447]

And I besought thy disciples to cast him out; and they could not. [448]

And Jesus answering said, O faithless and perverse generation, how long shall I be with you, and suffer you? Bring thy son hither. [449]

And as he was yet a coming, the devil threw him down, and tare him. And Jesus rebuked the unclean spirit, and healed the child, and delivered him again to his father. [450]

And they were all amazed at the mighty power of God. But while they wondered every one at all things which Jesus did, he said unto his disciples, [451]

Let these sayings sink down into your ears: for the Son of man shall be delivered into the hands of men. [452]

But they understood not this saying, and it was hid from them, that they perceived it not: and they feared to ask him of that saying. [453]

Then there arose a reasoning among them, which of them should be greatest. [454]

And Jesus, perceiving the thought of their heart, took a child, and set him by him, [455]

And said unto them, Whosoever shall receive this child in my name receiveth me: and whosoever shall receive me receiveth him that sent me: for he that is least among you all, the same shall be great. [456]

And John answered and said, Master, we saw one casting out devils in thy name; and we forbad him, because he followeth not with us. [457]

And Jesus said unto him, Forbid him not: for he that is not against us is for us. [458]

And it came to pass, when the time was come that he should be received up, he stedfastly set his face to go to Jerusalem, [459]

And sent messengers before his face: and they went, and entered into a village of the Samaritans, to make ready for him. [460]

And they did not receive him, because his face was as though he would go to Jerusalem. [461]

And when his disciples James and John saw this, they said, Lord, wilt thou that we command fire to come down from heaven, and consume them, even as Elias did? [462]

But he turned, and rebuked them, and said, Ye know not what manner of spirit ye are of. [463]

For the Son of man is not come to destroy men's lives, but to save them. And they went to another village. [464]

And it came to pass, that, as they went in the way, a certain man said unto him, Lord, I will follow thee whithersoever thou goest. [465]

And Jesus said unto him, Foxes have holes, and birds of the air have nests; but the Son of man hath not where to lay his head. [466]

And he said unto another, Follow me. But he said, Lord, suffer me first to go and bury my father. [467]

Jesus said unto him, Let the dead bury their dead: but go thou and preach the kingdom of God. [468]

And another also said, Lord, I will follow thee; but let me first go bid them farewell, which are at home at my house. [469]

And Jesus said unto him, No man, having put his hand to the plough, and looking back, is fit for the kingdom of God. [470]

§ Luke 10

After these things the LORD appointed other seventy also, and sent them two and two before his face into every city and place, whither he himself would come. [471]

Therefore said he unto them, The harvest truly is great, but the labourers are few: pray ye therefore the Lord of the harvest, that he would send forth labourers into his harvest. [472]

Go your ways: behold, I send you forth as lambs among wolves. [473]

Carry neither purse, nor scrip, nor shoes: and salute no man by the way. [474]

And into whatsoever house ye enter, first say, Peace be to this house. [475]

And if the son of peace be there, your peace shall rest upon it: if not, it shall turn to you again. [476]

And in the same house remain, eating and drinking such things as they give: for the labourer is worthy of his hire. Go not from house to house. [477]

And into whatsoever city ye enter, and they receive you, eat such things as are set before you: [478]

And heal the sick that are therein, and say unto them, The kingdom of God is come nigh unto you. [479]

But into whatsoever city ye enter, and they receive you not, go your ways out into the streets of the same, and say, [480]

Even the very dust of your city, which cleaveth on us, we do wipe off against you: notwithstanding be ye sure of this, that the kingdom of God is come nigh unto you. [481]

But I say unto you, that it shall be more tolerable in that day for Sodom, than for that city. [482]

Woe unto thee, Chorazin! woe unto thee, Bethsaida! for if the mighty works had been done in Tyre and Sidon, which have been done in you, they had a great while ago repented, sitting in sackcloth and ashes. [483]

But it shall be more tolerable for Tyre and Sidon at the judgment, than for you. [484]

And thou, Capernaum, which art exalted to heaven, shalt be thrust down to hell. [485]

He that heareth you heareth me; and he that despiseth you despiseth me; and he that despiseth me despiseth him that sent me. [486]

And the seventy returned again with joy, saying, Lord, even the devils are subject unto us through thy name. [487]

And he said unto them, I beheld Satan as lightning fall from heaven. [488]

Behold, I give unto you power to tread on serpents and scorpions, and over all the power of the enemy: and nothing shall by any means hurt you. [489]

Notwithstanding in this rejoice not, that the spirits are subject unto you; but rather rejoice, because your names are written in heaven. [490]

In that hour Jesus rejoiced in spirit, and said, I thank thee, O Father, Lord of heaven and earth, that thou hast hid these things from the wise and prudent, and hast revealed them unto babes: even so, Father; for so it seemed good in thy sight. [491]

All things are delivered to me of my Father: and no man knoweth who the Son is, but the Father; and who the Father is, but the Son, and he to whom the Son will reveal him. [492]

And he turned him unto his disciples, and said privately, Blessed are the eyes which see the things that ye see: [493]

For I tell you, that many prophets and kings have desired to see those things which ye see, and have not seen them; and to hear those things which ye hear, and have not heard them. [494]

And, behold, a certain lawyer stood up, and tempted him, saying, Master, what shall I do to inherit eternal life? [495]

He said unto him, What is written in the law? how readest thou? [496]

And he answering said, Thou shalt love the Lord thy God with all thy heart, and with all thy soul, and with all thy strength, and with all thy mind; and thy neighbour as thyself. [497]

And he said unto him, Thou hast answered right: this do, and thou shalt live. [498]

But he, willing to justify himself, said unto Jesus, And who is my neighbour? [499]

And Jesus answering said, A certain man went down from Jerusalem to Jericho, and fell among thieves, which stripped him of his raiment, and wounded him, and departed, leaving him half dead. [500]

And by chance there came down a certain priest that way: and when he saw him, he passed by on the other side. [501]

And likewise a Levite, when he was at the place, came and looked on him, and passed by on the other side. [502]

But a certain Samaritan, as he journeyed, came where he was: and when he saw him, he had compassion on him, [503]

And went to him, and bound up his wounds, pouring in oil and wine, and set him on his own beast, and brought him to an inn, and took care of him. [504]

And on the morrow when he departed, he took out two pence, and gave them to the host, and said unto him, Take care of him; and whatsoever thou spendest more, when I come again, I will repay thee. [505]

Which now of these three, thinkest thou, was neighbour unto him that fell among the thieves? [506]

And he said, He that shewed mercy on him. Then said Jesus unto him, Go, and do thou likewise. [507]

Now it came to pass, as they went, that he entered into a certain village: and a certain woman named Martha received him into her house. [508]

And she had a sister called Mary, which also sat at Jesus' feet, and heard his word. [509]

But Martha was cumbered about much serving, and came to him, and said, Lord, dost thou not care that my sister hath left me to serve alone? bid her therefore that she help me. [510]

And Jesus answered and said unto her, Martha, Martha, thou art careful and troubled about many things: [511]

But one thing is needful: and Mary hath chosen that good part, which shall not be taken away from her. [512]

§ Luke 11

And it came to pass, that, as he was praying in a certain place, when he ceased, one of his disciples said unto him, Lord, teach us to pray, as John also taught his disciples. [513]

And he said unto them, When ye pray, say, Our Father which art in heaven, Hallowed be thy name. Thy kingdom come. Thy will be done, as in heaven, so in earth. [514]

Give us day by day our daily bread. [515]

And forgive us our sins; for we also forgive every one that is indebted to us. And lead us not into temptation; but deliver us from evil. [516]

And he said unto them, Which of you shall have a friend, and shall go unto him at midnight, and say unto him, Friend, lend me three loaves; [517]

For a friend of mine in his journey is come to me, and I have nothing to set before him? [518]

And he from within shall answer and say, Trouble me not: the door is now shut, and my children are with me in bed; I cannot rise and give thee. [519]

I say unto you, Though he will not rise and give him, because he is his friend, yet because of his importunity he will rise and give him as many as he needeth. [520]

And I say unto you, Ask, and it shall be given you; seek, and ye shall find; knock, and it shall be opened unto you. [521]

For every one that asketh receiveth; and he that seeketh findeth; and to him that knocketh it shall be opened. [522]

If a son shall ask bread of any of you that is a father, will he give him a stone? or if he ask a fish, will he for a fish give him a serpent? [523]

Or if he shall ask an egg, will he offer him a scorpion? [524]

If ye then, being evil, know how to give good gifts unto your children: how much more shall your heavenly Father give the Holy Spirit to them that ask him? [525]

And he was casting out a devil, and it was dumb. And it came to pass, when the devil was gone out, the dumb spake; and the people wondered. [526]

But some of them said, He casteth out devils through Beelzebub the chief of the devils. [527]

And others, tempting him, sought of him a sign from heaven. [528]

But he, knowing their thoughts, said unto them, Every kingdom divided against itself is brought to desolation; and a house divided against a house falleth. [529]

If Satan also be divided against himself, how shall his kingdom stand? because ye say that I cast out devils through Beelzebub. [530]

And if I by Beelzebub cast out devils, by whom do your sons cast them out? therefore shall they be your judges. [531]

But if I with the finger of God cast out devils, no doubt the kingdom of God is come upon you. [532]

When a strong man armed keepeth his palace, his goods are in peace: [533]

But when a stronger than he shall come upon him, and overcome him, he taketh from him all his armour wherein he trusted, and divideth his spoils. [534]

He that is not with me is against me: and he that gathereth not with me scattereth. [535]

When the unclean spirit is gone out of a man, he walketh through dry places, seeking rest; and finding none, he saith, I will return unto my house whence I came out. [536]

And when he cometh, he findeth it swept and garnished. [537]

Then goeth he, and taketh to him seven other spirits more wicked than himself; and they enter in, and dwell there: and the last state of that man is worse than the first. [538]

And it came to pass, as he spake these things, a certain woman of the company lifted up her voice, and said unto him, Blessed is the womb that bare thee, and the paps which thou hast sucked. [539]

But he said, Yea rather, blessed are they that hear the word of God, and keep it. [540]

And when the people were gathered thick together, he began to say, This is an evil generation: they seek a sign; and there shall no sign be given it, but the sign of Jonas the prophet. [541]

For as Jonas was a sign unto the Ninevites, so shall also the Son of man be to this generation. [542]

The queen of the south shall rise up in the judgment with the men of this generation, and condemn them: for she came from the utmost parts of the earth to hear the wisdom of Solomon; and, behold, a greater than Solomon is here. [543]

The men of Nineve shall rise up in the judgment with this generation, and shall condemn it: for they repented at the preaching of Jonas; and, behold, a greater than Jonas is here. [544]

No man, when he hath lighted a candle, putteth it in a secret place, neither under a bushel, but on a candlestick, that they which come in may see the light. [545]

The light of the body is the eye: therefore when thine eye is single, thy whole body also is full of light; but when thine eye is evil, thy body also is full of darkness. [546]

Take heed therefore that the light which is in thee be not darkness. [547]

If thy whole body therefore be full of light, having no part dark, the whole shall be full of light, as when the bright shining of a candle doth give thee light. [548]

And as he spake, a certain Pharisee besought him to dine with him: and he went in, and sat down to meat. [549]

And when the Pharisee saw it, he marvelled that he had not first washed before dinner. [550]

And the Lord said unto him, Now do ye Pharisees make clean the outside of the cup and the platter; but your inward part is full of ravening and wickedness. [551]

Ye fools, did not he that made that which is without make that which is within also? [552]

But rather give alms of such things as ye have; and, behold, all things are clean unto you. [553]

But woe unto you, Pharisees! for ye tithe mint and rue and all manner of herbs, and pass over judgment and the love of God: these ought ye to have done, and not to leave the other undone. [554]

Woe unto you, Pharisees! for ye love the uppermost seats in the synagogues, and greetings in the markets. [555]

Woe unto you, scribes and Pharisees, hypocrites! for ye are as graves which appear not, and the men that walk over them are not aware of them. [556]

Then answered one of the lawyers, and said unto him, Master, thus saying thou reproachest us also. [557]

And he said, Woe unto you also, ye lawyers! for ye lade men with burdens grievous to be borne, and ye yourselves touch not the burdens with one of your fingers. [558]

Woe unto you! for ye build the sepulchres of the prophets, and your fathers killed them. [559]

Truly ye bear witness that ye allow the deeds of your fathers: for they indeed killed them, and ye build their sepulchres. [560]

Therefore also said the wisdom of God, I will send them prophets and apostles, and some of them they shall slay and persecute: [561]

That the blood of all the prophets, which was shed from the foundation of the world, may be required of this generation; [562]

From the blood of Abel unto the blood of Zacharias which perished between the altar and the temple: verily I say unto you, It shall be required of this generation. [563]

Woe unto you, lawyers! for ye have taken away the key of knowledge: ye entered not in yourselves, and them that were entering in ye hindered. [564]

And as he said these things unto them, the scribes and the Pharisees began to urge him vehemently, and to provoke him to speak of many things: [565]

Laying wait for him, and seeking to catch something out of his mouth, that they might accuse him. [566]

§ Luke 12

In the mean time, when there were gathered together an innumerable multitude of people, insomuch that they trode one upon another, he began to say unto his disciples first of all, Beware ye of the leaven of the Pharisees, which is hypocrisy. [567]

For there is nothing covered, that shall not be revealed; neither hid, that shall not be known. [568]

Therefore whatsoever ye have spoken in darkness shall be heard in the light; and that which ye have spoken in the ear in closets shall be proclaimed upon the housetops. [569]

And I say unto you my friends, Be not afraid of them that kill the body, and after that have no more that they can do. [570]

But I will forewarn you whom ye shall fear: Fear him, which after he hath killed hath power to cast into hell; yea, I say unto you, Fear him. [571]

Are not five sparrows sold for two farthings, and not one of them is forgotten before God? [572]

But even the very hairs of your head are all numbered. Fear not therefore: ye are of more value than many sparrows. [573]

Also I say unto you, Whosoever shall confess me before men, him shall the Son of man also confess before the angels of God: [574]

But he that denieth me before men shall be denied before the angels of God. [575]

And whosoever shall speak a word against the Son of man, it shall be forgiven him: but unto him that blasphemeth against the Holy Ghost it shall not be forgiven. [576]

And when they bring you unto the synagogues, and unto magistrates, and powers, take ye no thought how or what thing ye shall answer, or what ye shall say: [577]

For the Holy Ghost shall teach you in the same hour what ye ought to say. [578]

And one of the company said unto him, Master, speak to my brother, that he divide the inheritance with me. [579]

And he said unto him, Man, who made me a judge or a divider over you? [580]

And he said unto them, Take heed, and beware of covetousness: for a man's life consisteth not in the abundance of the things which he possesseth. [581]

And he spake a parable unto them, saying, The ground of a certain rich man brought forth plentifully: [582]

And he thought within himself, saying, What shall I do, because I have no room where to bestow my fruits? [583]

And he said, This will I do: I will pull down my barns, and build greater; and there will I bestow all my fruits and my goods. [584]

And I will say to my soul, Soul, thou hast much goods laid up for many years; take thine ease, eat, drink, and be merry. [585]

But God said unto him, Thou fool, this night thy soul shall be required of thee: then whose shall those things be, which thou hast provided? [586]

So is he that layeth up treasure for himself, and is not rich toward God. [587]

And he said unto his disciples, Therefore I say unto you, Take no thought for your life, what ye shall eat; neither for the body, what ye shall put on. [588]

The life is more than meat, and the body is more than raiment. [589]

Consider the ravens: for they neither sow nor reap; which neither have storehouse nor barn; and God feedeth them: how much more are ye better than the fowls? [590]

And which of you with taking thought can add to his stature one cubit? [591]

If ye then be not able to do that thing which is least, why take ye thought for the rest? [592]

Consider the lilies how they grow: they toil not, they spin not; and yet I say unto you, that Solomon in all his glory was not arrayed like one of these. [593]

If then God so clothe the grass, which is to day in the field, and to morrow is cast into the oven; how much more will he clothe you, O ye of little faith? [594]

And seek not ye what ye shall eat, or what ye shall drink, neither be ye of doubtful mind. [595]

For all these things do the nations of the world seek after: and your Father knoweth that ye have need of these things. [596]

But rather seek ye the kingdom of God; and all these things shall be added unto you. [597]

Fear not, little flock; for it is your Father's good pleasure to give you the kingdom. [598]

Sell that ye have, and give alms; provide yourselves bags which wax not old, a treasure in the heavens that faileth not, where no thief approacheth, neither moth corrupteth. [599]

For where your treasure is, there will your heart be also. [600]

Let your loins be girded about, and your lights burning; [601]

And ye yourselves like unto men that wait for their lord, when he will return from the wedding; that when he cometh and knocketh, they may open unto him immediately. [602]

Blessed are those servants, whom the lord when he cometh shall find watching: verily I say unto you, that he shall gird himself, and make them to sit down to meat, and will come forth and serve them. [603]

And if he shall come in the second watch, or come in the third watch, and find them so, blessed are those servants. [604]

And this know, that if the goodman of the house had known what hour the thief would come, he would have watched, and not have suffered his house to be broken through. [605]

Be ye therefore ready also: for the Son of man cometh at an hour when ye think not. [606]

Then Peter said unto him, Lord, speakest thou this parable unto us, or even to all? [607]

And the Lord said, Who then is that faithful and wise steward, whom his lord shall make ruler over his household, to give them their portion of meat in due season? [608]

Blessed is that servant, whom his lord when he cometh shall find so doing. [609]

Of a truth I say unto you, that he will make him ruler over all that he hath. [610]

But and if that servant say in his heart, My lord delayeth his coming; and shall begin to beat the menservants and maidens, and to eat and drink, and to be drunken; [611]

The lord of that servant will come in a day when he looketh not for him, and at an hour when he is not aware, and will cut him in sunder, and will appoint him his portion with the unbelievers. [612]

And that servant, which knew his lord's will, and prepared not himself, neither did according to his will, shall be beaten with many stripes. [613]

But he that knew not, and did commit things worthy of stripes, shall be beaten with few stripes. For unto whomsoever much is given, of him shall be much required: and to whom men have committed much, of him they will ask the more. [614]

I am come to send fire on the earth; and what will I, if it be already kindled? [615]

But I have a baptism to be baptized with; and how am I straitened till it be accomplished! [616]

Suppose ye that I am come to give peace on earth? I tell you, Nay; but rather division: [617]

For from henceforth there shall be five in one house divided, three against two, and two against three. [618]

The father shall be divided against the son, and the son against the father; the mother against the daughter, and the daughter against the mother; the mother in law against her daughter in law, and the daughter in law against her mother in law. [619]

And he said also to the people, When ye see a cloud rise out of the west, straightway ye say, There cometh a shower; and so it is. [620]

And when ye see the south wind blow, ye say, There will be heat; and it cometh to pass. [621]

Ye hypocrites, ye can discern the face of the sky and of the earth; but how is it that ye do not discern this time? [622]

Yea, and why even of yourselves judge ye not what is right? [623]

When thou goest with thine adversary to the magistrate, as thou art in the way, give diligence that thou mayest be delivered from him; lest he hale thee to the judge, and the judge deliver thee to the officer, and the officer cast thee into prison. [624]

I tell thee, thou shalt not depart thence, till thou hast paid the very last mite. [625]

§ Luke 13

There were present at that season some that told him of the Galilaeans, whose blood Pilate had mingled with their sacrifices. [626]

And Jesus answering said unto them, Suppose ye that these Galilaeans were sinners above all the Galilaeans, because they suffered such things? [627]

I tell you, Nay: but, except ye repent, ye shall all likewise perish. [628]

Or those eighteen, upon whom the tower in Siloam fell, and slew them, think ye that they were sinners above all men that dwelt in Jerusalem? [629]

I tell you, Nay: but, except ye repent, ye shall all likewise perish. [630]

He spake also this parable; A certain man had a fig tree planted in his vineyard; and he came and sought fruit thereon, and found none. [631]

Then said he unto the dresser of his vineyard, Behold, these three years I come seeking fruit on this fig tree, and find none: cut it down; why cumbereth it the ground? [632]

And he answering said unto him, Lord, let it alone this year also, till I shall dig about it, and dung it: [633]

And if it bear fruit, well: and if not, then after that thou shalt cut it down. [634]

And he was teaching in one of the synagogues on the sabbath. [635]

And, behold, there was a woman which had a spirit of infirmity eighteen years, and was bowed together, and could in no wise lift up herself. [636]

And when Jesus saw her, he called her to him, and said unto her, Woman, thou art loosed from thine infirmity. [637]

And he laid his hands on her: and immediately she was made straight, and glorified God. [638]

And the ruler of the synagogue answered with indignation, because that Jesus had healed on the sabbath day, and said unto the people, There are six days in which men ought to work: in them therefore come and be healed, and not on the sabbath day. [639]

The Lord then answered him, and said, Thou hypocrite, doth not each one of you on the sabbath loose his ox or his ass from the stall, and lead him away to watering? [640]

And ought not this woman, being a daughter of Abraham, whom Satan hath bound, lo, these eighteen years, be loosed from this bond on the sabbath day? [641]

And when he had said these things, all his adversaries were ashamed: and all the people rejoiced for all the glorious things that were done by him. [642]

Then said he, Unto what is the kingdom of God like? and whereunto shall I resemble it? [643]

It is like a grain of mustard seed, which a man took, and cast into his garden; and it grew, and waxed a great tree; and the fowls of the air lodged in the branches of it. [644]

And again he said, Whereunto shall I liken the kingdom of God? [645]

It is like leaven, which a woman took and hid in three measures of meal, till the whole was leavened. [646]

And he went through the cities and villages, teaching, and journeying toward Jerusalem. [647]

Then said one unto him, Lord, are there few that be saved? And he said unto them, [648]

Strive to enter in at the strait gate: for many, I say unto you, will seek to enter in, and shall not be able. [649]

When once the master of the house is risen up, and hath shut to the door, and ye begin to stand without, and to knock at the door, saying, Lord, Lord, open unto us; and he shall answer and say unto you, I know you not whence ye are: [650]

Then shall ye begin to say, We have eaten and drunk in thy presence, and thou hast taught in our streets. [651]

But he shall say, I tell you, I know you not whence ye are; depart from me, all ye workers of iniquity. [652]

There shall be weeping and gnashing of teeth, when ye shall see Abraham, and Isaac, and Jacob, and all the prophets, in the kingdom of God, and you yourselves thrust out. [653]

And they shall come from the east, and from the west, and from the north, and from the south, and shall sit down in the kingdom of God. [654]

And, behold, there are last which shall be first, and there are first which shall be last. [655]

The same day there came certain of the Pharisees, saying unto him, Get thee out, and depart hence: for Herod will kill thee. [656]

And he said unto them, Go ye, and tell that fox, Behold, I cast out devils, and I do cures to day and to morrow, and the third day I shall be perfected. [657]

Nevertheless I must walk to day, and to morrow, and the day following: for it cannot be that a prophet perish out of Jerusalem. [658]

O Jerusalem, Jerusalem, which killest the prophets, and stonest them that are sent unto thee; how often would I have gathered thy children together, as a hen doth gather her brood under her wings, and ye would not! [659]

Behold, your house is left unto you desolate: and verily I say unto you, Ye shall not see me, until the time come when ye shall say, Blessed is he that cometh in the name of the Lord. [660]

§ Luke 14

And it came to pass, as he went into the house of one of the chief Pharisees to eat bread on the sabbath day, that they watched him. [661]

And, behold, there was a certain man before him which had the dropsy. [662]

And Jesus answering spake unto the lawyers and Pharisees, saying, Is it lawful to heal on the sabbath day? [663]

And they held their peace. And he took him, and healed him, and let him go; [664]

And answered them, saying, Which of you shall have an ass or an ox fallen into a pit, and will not straightway pull him out on the sabbath day? [665]

And they could not answer him again to these things. [666]

And he put forth a parable to those which were bidden, when he marked how they chose out the chief rooms; saying unto them. [667]

When thou art bidden of any man to a wedding, sit not down in the highest room; lest a more honourable man than thou be bidden of him; [668]

And he that bade thee and him come and say to thee, Give this man place; and thou begin with shame to take the lowest room. [669]

But when thou art bidden, go and sit down in the lowest room; that when he that bade thee cometh, he may say unto thee, Friend, go up higher: then shalt thou have worship in the presence of them that sit at meat with thee. [670]

For whosoever exalteth himself shall be abased; and he that humbleth himself shall be exalted. [671]

Then said he also to him that bade him, When thou makest a dinner or a supper, call not thy friends, nor thy brethren, neither thy kinsmen, nor thy rich neighbours; lest they also bid thee again, and a recompence be made thee. [672]

But when thou makest a feast, call the poor, the maimed, the lame, the blind: [673]

And thou shalt be blessed; for they cannot recompense thee: for thou shalt be recompensed at the resurrection of the just. [674]

And when one of them that sat at meat with him heard these things, he said unto him, Blessed is he that shall eat bread in the kingdom of God. [675]

Then said he unto him, A certain man made a great supper, and bade many: [676]

And sent his servant at supper time to say to them that were bidden, Come; for all things are now ready. [677]

And they all with one consent began to make excuse. The first said unto him, I have bought a piece of ground, and I must needs go and see it: I pray thee have me excused. [678]

And another said, I have bought five yoke of oxen, and I go to prove them: I pray thee have me excused. [679]

And another said, I have married a wife, and therefore I cannot come. [680]

So that servant came, and shewed his lord these things. Then the master of the house being angry said to his servant, Go out quickly into the streets and lanes of the city, and bring in hither the poor, and the maimed, and the halt, and the blind. [681]

And the servant said, Lord, it is done as thou hast commanded, and yet there is room. [682]

And the lord said unto the servant, Go out into the highways and hedges, and compel them to come in, that my house may be filled. [683]

For I say unto you, That none of those men which were bidden shall taste of my supper. [684]

And there went great multitudes with him: and he turned, and said unto them, [685]

If any man come to me, and hate not his father, and mother, and wife, and children, and brethren, and sisters, yea, and his own life also, he cannot be my disciple. [686]

And whosoever doth not bear his cross, and come after me, cannot be my disciple. [687]

For which of you, intending to build a tower, sitteth not down first, and counteth the cost, whether he have sufficient to finish it? [688]

Lest haply, after he hath laid the foundation, and is not able to finish it, all that behold it begin to mock him, [689]

Saying, This man began to build, and was not able to finish. [690]

Or what king, going to make war against another king, sitteth not down first, and consulteth whether he be able with ten thousand to meet him that cometh against him with twenty thousand? [691]

Or else, while the other is yet a great way off, he sendeth an ambassage, and desireth conditions of peace. [692]

So likewise, whosoever he be of you that forsaketh not all that he hath, he cannot be my disciple. [693]

Salt is good: but if the salt have lost his savour, wherewith shall it be seasoned? [694]

It is neither fit for the land, nor yet for the dunghill; but men cast it out. He that hath ears to hear, let him hear. [695]

§ Luke 15

Then drew near unto him all the publicans and sinners for to hear him. [696]

And the Pharisees and scribes murmured, saying, This man receiveth sinners, and eateth with them. [697]

And he spake this parable unto them, saying, [698]

What man of you, having an hundred sheep, if he lose one of them, doth not leave the ninety and nine in the wilderness, and go after that which is lost, until he find it? [699]

And when he hath found it, he layeth it on his shoulders, rejoicing. [700]

And when he cometh home, he calleth together his friends and neighbours, saying unto them, Rejoice with me; for I have found my sheep which was lost. [701]

I say unto you, that likewise joy shall be in heaven over one sinner that repenteth, more than over ninety and nine just persons, which need no repentance. [702]

Either what woman having ten pieces of silver, if she lose one piece, doth not light a candle, and sweep the house, and seek diligently till she find it? [703]

And when she hath found it, she calleth her friends and her neighbours together, saying, Rejoice with me; for I have found the piece which I had lost. [704]

Likewise, I say unto you, there is joy in the presence of the angels of God over one sinner that repenteth. [705]

And he said, A certain man had two sons: [706]

And the younger of them said to his father, Father, give me the portion of goods that falleth to me. And he divided unto them his living. [707]

And not many days after the younger son gathered all together, and took his journey into a far country, and there wasted his substance with riotous living. [708]

And when he had spent all, there arose a mighty famine in that land; and he began to be in want. [709]

And he went and joined himself to a citizen of that country; and he sent him into his fields to feed swine. [710]

And he would fain have filled his belly with the husks that the swine did eat: and no man gave unto him. [711]

And when he came to himself, he said, How many hired servants of my father's have bread enough and to spare, and I perish with hunger! [712]

I will arise and go to my father, and will say unto him, Father, I have sinned against heaven, and before thee, [713]

And am no more worthy to be called thy son: make me as one of thy hired servants. [714]

And he arose, and came to his father. But when he was yet a great way off, his father saw him, and had compassion, and ran, and fell on his neck, and kissed him. [715]

And the son said unto him, Father, I have sinned against heaven, and in thy sight, and am no more worthy to be called thy son. [716]

But the father said to his servants, Bring forth the best robe, and put it on him; and put a ring on his hand, and shoes on his feet: [717]

And bring hither the fatted calf, and kill it; and let us eat, and be merry: [718]

For this my son was dead, and is alive again; he was lost, and is found. And they began to be merry. [719]

Now his elder son was in the field: and as he came and drew nigh to the house, he heard musick and dancing. [720]

And he called one of the servants, and asked what these things meant. [721]

And he said unto him, Thy brother is come; and thy father hath killed the fatted calf, because he hath received him safe and sound. [722]

And he was angry, and would not go in: therefore came his father out, and intreated him. [723]

And he answering said to his father, Lo, these many years do I serve thee, neither transgressed I at any time thy commandment: and yet thou never gavest me a kid, that I might make merry with my friends: [724]

But as soon as this thy son was come, which hath devoured thy living with harlots, thou hast killed for him the fatted calf. [725]

And he said unto him, Son, thou art ever with me, and all that I have is thine. [726]

It was meet that we should make merry, and be glad: for this thy brother was dead, and is alive again; and was lost, and is found. [727]

§ Luke 16

And he said also unto his disciples, There was a certain rich man, which had a steward; and the same was accused unto him that he had wasted his goods. [728]

And he called him, and said unto him, How is it that I hear this of thee? give an account of thy stewardship; for thou mayest be no longer steward. [729]

Then the steward said within himself, What shall I do? for my lord taketh away from me the stewardship: I cannot dig; to beg I am ashamed. [730]

I am resolved what to do, that, when I am put out of the stewardship, they may receive me into their houses. [731]

So he called every one of his lord's debtors unto him, and said unto the first, How much owest thou unto my lord? [732]

And he said, An hundred measures of oil. And he said unto him, Take thy bill, and sit down quickly, and write fifty. [733]

Then said he to another, And how much owest thou? And he said, An hundred measures of wheat. And he said unto him, Take thy bill, and write fourscore. [734]

And the lord commended the unjust steward, because he had done wisely: for the children of this world are in their generation wiser than the children of light. [735]

And I say unto you, Make to yourselves friends of the mammon of unrighteousness; that, when ye fail, they may receive you into everlasting habitations. [736]

He that is faithful in that which is least is faithful also in much: and he that is unjust in the least is unjust also in much. [737]

If therefore ye have not been faithful in the unrighteous mammon, who will commit to your trust the true riches? [738]

And if ye have not been faithful in that which is another man's, who shall give you that which is your own? [739]

No servant can serve two masters: for either he will hate the one, and love the other; or else he will hold to the one, and despise the other. Ye cannot serve God and mammon. [740]

And the Pharisees also, who were covetous, heard all these things: and they derided him. [741]

And he said unto them, Ye are they which justify yourselves before men; but God knoweth your hearts: for that which is highly esteemed among men is abomination in the sight of God. [742]

The law and the prophets were until John: since that time the kingdom of God is preached, and every man presseth into it. [743]

And it is easier for heaven and earth to pass, than one tittle of the law to fail. [744]

Whosoever putteth away his wife, and marrieth another, committeth adultery: and whosoever marrieth her that is put away from her husband committeth adultery. [745]

There was a certain rich man, which was clothed in purple and fine linen, and fared sumptuously every day: [746]

And there was a certain beggar named Lazarus, which was laid at his gate, full of sores, [747]

And desiring to be fed with the crumbs which fell from the rich man's table: moreover the dogs came and licked his sores. [748]

And it came to pass, that the beggar died, and was carried by the angels into Abraham's bosom: the rich man also died, and was buried; [749]

And in hell he lift up his eyes, being in torments, and seeth Abraham afar off, and Lazarus in his bosom. [750]

And he cried and said, Father Abraham, have mercy on me, and send Lazarus, that he may dip the tip of his finger in water, and cool my tongue; for I am tormented in this flame. [751]

But Abraham said, Son, remember that thou in thy lifetime receivedst thy good things, and likewise Lazarus evil things: but now he is comforted, and thou art tormented. [752]

And beside all this, between us and you there is a great gulf fixed: so that they which would pass from hence to you cannot; neither can they pass to us, that would come from thence. [753]

Then he said, I pray thee therefore, father, that thou wouldest send him to my father's house: [754]

For I have five brethren; that he may testify unto them, lest they also come into this place of torment. [755]

Abraham saith unto him, They have Moses and the prophets; let them hear them. [756]

And he said, Nay, father Abraham: but if one went unto them from the dead, they will repent. [757]

And he said unto him, If they hear not Moses and the prophets, neither will they be persuaded, though one rose from the dead. [758]

§ Luke 17

Then said he unto the disciples, It is impossible but that offences will come: but woe unto him, through whom they come! [759]

It were better for him that a millstone were hanged about his neck, and he cast into the sea, than that he should offend one of these little ones. [760]

Take heed to yourselves: If thy brother trespass against thee, rebuke him; and if he repent, forgive him. [761]

And if he trespass against thee seven times in a day, and seven times in a day turn again to thee, saying, I repent; thou shalt forgive him. [762]

And the apostles said unto the Lord, Increase our faith. [763]

And the Lord said, If ye had faith as a grain of mustard seed, ye might say unto this sycamine tree, Be thou plucked up by the root, and be thou planted in the sea; and it should obey you. [764]

But which of you, having a servant plowing or feeding cattle, will say unto him by and by, when he is come from the field, Go and sit down to meat? [765]

And will not rather say unto him, Make ready wherewith I may sup, and gird thyself, and serve me, till I have eaten and drunken; and afterward thou shalt eat and drink? [766]

Doth he thank that servant because he did the things that were commanded him? I trow not. [767]

So likewise ye, when ye shall have done all those things which are commanded you, say, We are unprofitable servants: we have done that which was our duty to do. [768]

And it came to pass, as he went to Jerusalem, that he passed through the midst of Samaria and Galilee. [769]

And as he entered into a certain village, there met him ten men that were lepers, which stood afar off: [770]

And they lifted up their voices, and said, Jesus, Master, have mercy on us. [771]

And when he saw them, he said unto them, Go shew yourselves unto the priests. And it came to pass, that, as they went, they were cleansed. [772]

And one of them, when he saw that he was healed, turned back, and with a loud voice glorified God, [773]

And fell down on his face at his feet, giving him thanks: and he was a Samaritan. [774]

And Jesus answering said, Were there not ten cleansed? but where are the nine? [775]

There are not found that returned to give glory to God, save this stranger. [776]

And he said unto him, Arise, go thy way: thy faith hath made thee whole. [777]

And when he was demanded of the Pharisees, when the kingdom of God should come, he answered them and said, The kingdom of God cometh not with observation: [778]

Neither shall they say, Lo here! or, lo there! for, behold, the kingdom of God is within you. [779]

And he said unto the disciples, The days will come, when ye shall desire to see one of the days of the Son of man, and ye shall not see it. [780]

And they shall say to you, See here; or, see there: go not after them, nor follow them. [781]

For as the lightning, that lighteneth out of the one part under heaven, shineth unto the other part under heaven; so shall also the Son of man be in his day. [782]

But first must he suffer many things, and be rejected of this generation. [783]

And as it was in the days of Noe, so shall it be also in the days of the Son of man. [784]

They did eat, they drank, they married wives, they were given in marriage, until the day that Noe entered into the ark, and the flood came, and destroyed them all. [785]

Likewise also as it was in the days of Lot; they did eat, they drank, they bought, they sold, they planted, they builded; [786]

But the same day that Lot went out of Sodom it rained fire and brimstone from heaven, and destroyed them all. [787]

Even thus shall it be in the day when the Son of man is revealed. [788]

In that day, he which shall be upon the housetop, and his stuff in the house, let him not come down to take it away: and he that is in the field, let him likewise not return back. [789]

Remember Lot's wife. [790]

Whosoever shall seek to save his life shall lose it; and whosoever shall lose his life shall preserve it. [791]

I tell you, in that night there shall be two men in one bed; the one shall be taken, and the other shall be left. [792]

Two women shall be grinding together; the one shall be taken, and the other left. [793]

Two men shall be in the field; the one shall be taken, and the other left. [794]

And they answered and said unto him, Where, Lord? And he said unto them, Wheresoever the body is, thither will the eagles be gathered together. [795]

§ Luke 18

And he spake a parable unto them to this end, that men ought always to pray, and not to faint; [796]

Saying, There was in a city a judge, which feared not God, neither regarded man: [797]

And there was a widow in that city; and she came unto him, saying, Avenge me of mine adversary. [798]

And he would not for a while: but afterward he said within himself, Though I fear not God, nor regard man; [799]

Yet because this widow troubleth me, I will avenge her, lest by her continual coming she weary me. [800]

And the Lord said, Hear what the unjust judge saith. [801]

And shall not God avenge his own elect, which cry day and night unto him, though he bear long with them? [802]

I tell you that he will avenge them speedily. Nevertheless when the Son of man cometh, shall he find faith on the earth? [803]

And he spake this parable unto certain which trusted in themselves that they were righteous, and despised others: [804]

Two men went up into the temple to pray; the one a Pharisee, and the other a publican. [805]

The Pharisee stood and prayed thus with himself, God, I thank thee, that I am not as other men are, extortioners, unjust, adulterers, or even as this publican. [806]

I fast twice in the week, I give tithes of all that I possess. [807]

And the publican, standing afar off, would not lift up so much as his eyes unto heaven, but smote upon his breast, saying, God be merciful to me a sinner. [808]

I tell you, this man went down to his house justified rather than the other: for every one that exalteth himself shall be abased; and he that humbleth himself shall be exalted. [809]

And they brought unto him also infants, that he would touch them: but when his disciples saw it, they rebuked them. [810]

But Jesus called them unto him, and said, Suffer little children to come unto me, and forbid them not: for of such is the kingdom of God. [811]

Verily I say unto you, Whosoever shall not receive the kingdom of God as a little child shall in no wise enter therein. [812]

And a certain ruler asked him, saying, Good Master, what shall I do to inherit eternal life? [813]

And Jesus said unto him, Why callest thou me good? none is good, save one, that is, God. [814]

Thou knowest the commandments, Do not commit adultery, Do not kill, Do not steal, Do not bear false witness, Honour thy father and thy mother. [815]

And he said, All these have I kept from my youth up. [816]

Now when Jesus heard these things, he said unto him, Yet lackest thou one thing: sell all that thou hast, and distribute unto the poor, and thou shalt have treasure in heaven: and come, follow me. [817]

And when he heard this, he was very sorrowful: for he was very rich. [818]

And when Jesus saw that he was very sorrowful, he said, How hardly shall they that have riches enter into the kingdom of God! [819]

For it is easier for a camel to go through a needle's eye, than for a rich man to enter into the kingdom of God. [820]

And they that heard it said, Who then can be saved? [821]

And he said, The things which are impossible with men are possible with God. [822]

Then Peter said, Lo, we have left all, and followed thee. [823]

And he said unto them, Verily I say unto you, There is no man that hath left house, or parents, or brethren, or wife, or children, for the kingdom of God's sake, [824]

Who shall not receive manifold more in this present time, and in the world to come life everlasting. [825]

Then he took unto him the twelve, and said unto them, Behold, we go up to Jerusalem, and all things that are written by the prophets concerning the Son of man shall be accomplished. [826]

For he shall be delivered unto the Gentiles, and shall be mocked, and spitefully entreated, and spitted on: [827]

And they shall scourge him, and put him to death: and the third day he shall rise again. [828]

And they understood none of these things: and this saying was hid from them, neither knew they the things which were spoken. [829]

And it came to pass, that as he was come nigh unto Jericho, a certain blind man sat by the way side begging: [830]

And hearing the multitude pass by, he asked what it meant. [831]

And they told him, that Jesus of Nazareth passeth by. [832]

And he cried, saying, Jesus, thou son of David, have mercy on me. [833]

And they which went before rebuked him, that he should hold his peace: but he cried so much the more, Thou son of David, have mercy on me. [834]

And Jesus stood, and commanded him to be brought unto him: and when he was come near, he asked him, [835]

Saying, What wilt thou that I shall do unto thee? And he said, Lord, that I may receive my sight. [836]

And Jesus said unto him, Receive thy sight: thy faith hath saved thee. [837]

And immediately he received his sight, and followed him, glorifying God: and all the people, when they saw it, gave praise unto God. [838]

§ Luke 19

And Jesus entered and passed through Jericho. [839]

And, behold, there was a man named Zacchaeus, which was the chief among the publicans, and he was rich. [840]

And he sought to see Jesus who he was; and could not for the press, because he was little of stature. [841]

And he ran before, and climbed up into a sycomore tree to see him: for he was to pass that way. [842]

And when Jesus came to the place, he looked up, and saw him, and said unto him, Zacchaeus, make haste, and come down; for to day I must abide at thy house. [843]

And he made haste, and came down, and received him joyfully. [844]

And when they saw it, they all murmured, saying, That he was gone to be guest with a man that is a sinner. [845]

And Zacchaeus stood, and said unto the Lord: Behold, Lord, the half of my goods I give to the poor; and if I have taken any thing from any man by false accusation, I restore him fourfold. [846]

And Jesus said unto him, This day is salvation come to this house, forsomuch as he also is a son of Abraham. [847]

For the Son of man is come to seek and to save that which was lost. [848]

And as they heard these things, he added and spake a parable, because he was nigh to Jerusalem, and because they thought that the kingdom of God should immediately appear. [849]

He said therefore, A certain nobleman went into a far country to receive for himself a kingdom, and to return. [850]

And he called his ten servants, and delivered them ten pounds, and said unto them, Occupy till I come. [851]

But his citizens hated him, and sent a message after him, saying, We will not have this man to reign over us. [852]

And it came to pass, that when he was returned, having received the kingdom, then he commanded these servants to be called unto him, to whom he had given the money, that he might know how much every man had gained by trading. [853]

Then came the first, saying, Lord, thy pound hath gained ten pounds. [854]

And he said unto him, Well, thou good servant: because thou hast been faithful in a very little, have thou authority over ten cities. [855]

And the second came, saying, Lord, thy pound hath gained five pounds. [856]

And he said likewise to him, Be thou also over five cities. [857]

And another came, saying, Lord, behold, here is thy pound, which I have kept laid up in a napkin: [858]

For I feared thee, because thou art an austere man: thou takest up that thou layedst not down, and reapest that thou didst not sow. [859]

And he saith unto him, Out of thine own mouth will I judge thee, thou wicked servant. Thou knewest that I was an austere man, taking up that I laid not down, and reaping that I did not sow: [860]

Wherefore then gavest not thou my money into the bank, that at my coming I might have required mine own with usury? [861]

And he said unto them that stood by, Take from him the pound, and give it to him that hath ten pounds. [862]

(And they said unto him, Lord, he hath ten pounds.) [863]

For I say unto you, That unto every one which hath shall be given; and from him that hath not, even that he hath shall be taken away from him. [864]

But those mine enemies, which would not that I should reign over them, bring hither, and slay them before me. [865]

And when he had thus spoken, he went before, ascending up to Jerusalem. [866]

And it came to pass, when he was come nigh to Bethphage and Bethany, at the mount called the mount of Olives, he sent two of his disciples, [867]

Saying, Go ye into the village over against you; in the which at your entering ye shall find a colt tied, whereon yet never man sat: loose him, and bring him hither. [868]

And if any man ask you, Why do ye loose him? thus shall ye say unto him, Because the Lord hath need of him. [869]

And they that were sent went their way, and found even as he had said unto them. [870]

And as they were loosing the colt, the owners thereof said unto them, Why loose ye the colt? [871]

And they said, The Lord hath need of him. [872]

And they brought him to Jesus: and they cast their garments upon the colt, and they set Jesus thereon. [873]

And as he went, they spread their clothes in the way. [874]

And when he was come nigh, even now at the descent of the mount of Olives, the whole multitude of the disciples began to rejoice and praise God with a loud voice for all the mighty works that they had seen; [875]

Saying, Blessed be the King that cometh in the name of the Lord: peace in heaven, and glory in the highest. [876]

And some of the Pharisees from among the multitude said unto him, Master, rebuke thy disciples. [877]

And he answered and said unto them, I tell you that, if these should hold their peace, the stones would immediately cry out. [878]

And when he was come near, he beheld the city, and wept over it, [879]

Saying, If thou hadst known, even thou, at least in this thy day, the things which belong unto thy peace! but now they are hid from thine eyes. [880]

For the days shall come upon thee, that thine enemies shall cast a trench about thee, and compass thee round, and keep thee in on every side, [881]

And shall lay thee even with the ground, and thy children within thee; and they shall not leave in thee one stone upon another; because thou knewest not the time of thy visitation. [882]

And he went into the temple, and began to cast out them that sold therein, and them that bought; [883]

Saying unto them, It is written, My house is the house of prayer: but ye have made it a den of thieves. [884]

And he taught daily in the temple. But the chief priests and the scribes and the chief of the people sought to destroy him, [885]

And could not find what they might do: for all the people were very attentive to hear him. [886]

§ Luke 20

And it came to pass, that on one of those days, as he taught the people in the temple, and preached the gospel, the chief priests and the scribes came upon him with the elders, [887]

And spake unto him, saying, Tell us, by what authority doest thou these things? or who is he that gave thee this authority? [888]

And he answered and said unto them, I will also ask you one thing; and answer me: [889]

The baptism of John, was it from heaven, or of men? [890]

And they reasoned with themselves, saying, If we shall say, From heaven; he will say, Why then believed ye him not? [891]

But and if we say, Of men; all the people will stone us: for they be persuaded that John was a prophet. [892]

And they answered, that they could not tell whence it was. [893]

And Jesus said unto them, Neither tell I you by what authority I do these things. [894]

Then began he to speak to the people this parable; A certain man planted a vineyard, and let it forth to husbandmen, and went into a far country for a long time. [895]

And at the season he sent a servant to the husbandmen, that they should give him of the fruit of the vineyard: but the husbandmen beat him, and sent him away empty. [896]

And again he sent another servant: and they beat him also, and entreated him shamefully, and sent him away empty. [897]

And again he sent a third: and they wounded him also, and cast him out. [898]

Then said the lord of the vineyard, What shall I do? I will send my beloved son: it may be they will reverence him when they see him. [899]

But when the husbandmen saw him, they reasoned among themselves, saying, This is the heir: come, let us kill him, that the inheritance may be ours. [900]

So they cast him out of the vineyard, and killed him. What therefore shall the lord of the vineyard do unto them? [901]

He shall come and destroy these husbandmen, and shall give the vineyard to others. And when they heard it, they said, God forbid. [902]

And he beheld them, and said, What is this then that is written, The stone which the builders rejected, the same is become the head of the corner? [903]

Whosoever shall fall upon that stone shall be broken; but on whomsoever it shall fall, it will grind him to powder. [904]

And the chief priests and the scribes the same hour sought to lay hands on him; and they feared the people: for they perceived that he had spoken this parable against them. [905]

And they watched him, and sent forth spies, which should feign themselves just men, that they might take hold of his words, that so they might deliver him unto the power and authority of the governor. [906]

And they asked him, saying, Master, we know that thou sayest and teachest rightly, neither acceptest thou the person of any, but teachest the way of God truly: [907]

Is it lawful for us to give tribute unto Caesar, or no? [908]

But he perceived their craftiness, and said unto them, Why tempt ye me? [909]

Shew me a penny. Whose image and superscription hath it? They answered and said, Caesar's. [910]

And he said unto them, Render therefore unto Caesar the things which be Caesar's, and unto God the things which be God's. [911]

And they could not take hold of his words before the people: and they marvelled at his answer, and held their peace. [912]

Then came to him certain of the Sadducees, which deny that there is any resurrection; and they asked him, [913]

Saying, Master, Moses wrote unto us, If any man's brother die, having a wife, and he die without children, that his brother should take his wife, and raise up seed unto his brother. [914]

There were therefore seven brethren: and the first took a wife, and died without children. [915]

And the second took her to wife, and he died childless. [916]

And the third took her; and in like manner the seven also: and they left no children, and died. [917]

Last of all the woman died also. [918]

Therefore in the resurrection whose wife of them is she? for seven had her to wife. [919]

And Jesus answering said unto them, The children of this world marry, and are given in marriage: [920]

But they which shall be accounted worthy to obtain that world, and the resurrection from the dead, neither marry, nor are given in marriage: [921]

Neither can they die any more: for they are equal unto the angels; and are the children of God, being the children of the resurrection. [922]

Now that the dead are raised, even Moses shewed at the bush, when he calleth the Lord the God of Abraham, and the God of Isaac, and the God of Jacob. [923]

For he is not a God of the dead, but of the living: for all live unto him. [924]

Then certain of the scribes answering said, Master, thou hast well said. [925]

And after that they durst not ask him any question at all. [926]

And he said unto them, How say they that Christ is David's son? [927]

And David himself saith in the book of Psalms, The LORD said unto my Lord, Sit thou on my right hand, [928]

Till I make thine enemies thy footstool. [929]

David therefore calleth him Lord, how is he then his son? [930]

Then in the audience of all the people he said unto his disciples, [931]

Beware of the scribes, which desire to walk in long robes, and love greetings in the markets, and the highest seats in the synagogues, and the chief rooms at feasts; [932]

Which devour widows' houses, and for a shew make long prayers: the same shall receive greater damnation. [933]

§ Luke 21

And he looked up, and saw the rich men casting their gifts into the treasury. [934]

And he saw also a certain poor widow casting in thither two mites. [935]

And he said, Of a truth I say unto you, that this poor widow hath cast in more than they all: [936]

For all these have of their abundance cast in unto the offerings of God: but she of her penury hath cast in all the living that she had. [937]

And as some spake of the temple, how it was adorned with goodly stones and gifts, he said, [938]

As for these things which ye behold, the days will come, in the which there shall not be left one stone upon another, that shall not be thrown down. [939]

And they asked him, saying, Master, but when shall these things be? and what sign will there be when these things shall come to pass? [940]

And he said, Take heed that ye be not deceived: for many shall come in my name, saying, I am Christ; and the time draweth near: go ye not therefore after them. [941]

But when ye shall hear of wars and commotions, be not terrified: for these things must first come to pass; but the end is not by and by. [942]

Then said he unto them, Nation shall rise against nation, and kingdom against kingdom: [943]

And great earthquakes shall be in divers places, and famines, and pestilences; and fearful sights and great signs shall there be from heaven. [944]

But before all these, they shall lay their hands on you, and persecute you, delivering you up to the synagogues, and into prisons, being brought before kings and rulers for my name's sake. [945]

And it shall turn to you for a testimony. [946]

Settle it therefore in your hearts, not to meditate before what ye shall answer: [947]

For I will give you a mouth and wisdom, which all your adversaries shall not be able to gainsay nor resist. [948]

And ye shall be betrayed both by parents, and brethren, and kinsfolks, and friends; and some of you shall they cause to be put to death. [949]

And ye shall be hated of all men for my name's sake. [950]

But there shall not an hair of your head perish. [951]

In your patience possess ye your souls. [952]

And when ye shall see Jerusalem compassed with armies, then know that the desolation thereof is nigh. [953]

Then let them which are in Judaea flee to the mountains; and let them which are in the midst of it depart out; and let not them that are in the countries enter thereinto. [954]

For these be the days of vengeance, that all things which are written may be fulfilled. [955]

But woe unto them that are with child, and to them that give suck, in those days! for there shall be great distress in the land, and wrath upon this people. [956]

And they shall fall by the edge of the sword, and shall be led away captive into all nations: and Jerusalem shall be trodden down of the Gentiles, until the times of the Gentiles be fulfilled. [957]

And there shall be signs in the sun, and in the moon, and in the stars; and upon the earth distress of nations, with perplexity; the sea and the waves roaring; [958]

Men's hearts failing them for fear, and for looking after those things which are coming on the earth: for the powers of heaven shall be shaken. [959]

And then shall they see the Son of man coming in a cloud with power and great glory. [960]

And when these things begin to come to pass, then look up, and lift up your heads; for your redemption draweth nigh. [961]

And he spake to them a parable; Behold the fig tree, and all the trees; [962]

When they now shoot forth, ye see and know of your own selves that summer is now nigh at hand. [963]

So likewise ye, when ye see these things come to pass, know ye that the kingdom of God is nigh at hand. [964]

Verily I say unto you, This generation shall not pass away, till all be fulfilled. [965]

Heaven and earth shall pass away: but my words shall not pass away. [966]

And take heed to yourselves, lest at any time your hearts be overcharged with surfeiting, and drunkenness, and cares of this life, and so that day come upon you unawares. [967]

For as a snare shall it come on all them that dwell on the face of the whole earth. [968]

Watch ye therefore, and pray always, that ye may be accounted worthy to escape all these things that shall come to pass, and to stand before the Son of man. [969]

And in the day time he was teaching in the temple; and at night he went out, and abode in the mount that is called the mount of Olives. [970]

And all the people came early in the morning to him in the temple, for to hear him. [971]

§ Luke 22

Now the feast of unleavened bread drew nigh, which is called the Passover. [972]

And the chief priests and scribes sought how they might kill him; for they feared the people. [973]

Then entered Satan into Judas surnamed Iscariot, being of the number of the twelve. [974]

And he went his way, and communed with the chief priests and captains, how he might betray him unto them. [975]

And they were glad, and covenanted to give him money. [976]

And he promised, and sought opportunity to betray him unto them in the absence of the multitude. [977]

Then came the day of unleavened bread, when the passover must be killed. [978]

And he sent Peter and John, saying, Go and prepare us the passover, that we may eat. [979]

And they said unto him, Where wilt thou that we prepare? [980]

And he said unto them, Behold, when ye are entered into the city, there shall a man meet you, bearing a pitcher of water; follow him into the house where he entereth in. [981]

And ye shall say unto the goodman of the house, The Master saith unto thee, Where is the guestchamber, where I shall eat the passover with my disciples? [982]

And he shall shew you a large upper room furnished: there make ready. [983]

And they went, and found as he had said unto them: and they made ready the passover. [984]

And when the hour was come, he sat down, and the twelve apostles with him. [985]

And he said unto them, With desire I have desired to eat this passover with you before I suffer: [986]

For I say unto you, I will not any more eat thereof, until it be fulfilled in the kingdom of God. [987]

And he took the cup, and gave thanks, and said, Take this, and divide it among yourselves: [988]

For I say unto you, I will not drink of the fruit of the vine, until the kingdom of God shall come. [989]

And he took bread, and gave thanks, and brake it, and gave unto them, saying, This is my body which is given for you: this do in remembrance of me. [990]

Likewise also the cup after supper, saying, This cup is the new testament in my blood, which is shed for you. [991]

But, behold, the hand of him that betrayeth me is with me on the table. [992]

And truly the Son of man goeth, as it was determined: but woe unto that man by whom he is betrayed! [993]

And they began to enquire among themselves, which of them it was that should do this thing. [994]

And there was also a strife among them, which of them should be accounted the greatest. [995]

And he said unto them, The kings of the Gentiles exercise lordship over them; and they that exercise authority upon them are called benefactors. [996]

But ye shall not be so: but he that is greatest among you, let him be as the younger; and he that is chief, as he that doth serve. [997]

For whether is greater, he that sitteth at meat, or he that serveth? is not he that sitteth at meat? but I am among you as he that serveth. [998]

Ye are they which have continued with me in my temptations. [999]

And I appoint unto you a kingdom, as my Father hath appointed unto me; [1000]

That ye may eat and drink at my table in my kingdom, and sit on thrones judging the twelve tribes of Israel. [1001]

And the Lord said, Simon, Simon, behold, Satan hath desired to have you, that he may sift you as wheat: [1002]

But I have prayed for thee, that thy faith fail not: and when thou art converted, strengthen thy brethren. [1003]

And he said unto him, Lord, I am ready to go with thee, both into prison, and to death. [1004]

And he said, I tell thee, Peter, the cock shall not crow this day, before that thou shalt thrice deny that thou knowest me. [1005]

And he said unto them, When I sent you without purse, and scrip, and shoes, lacked ye any thing? And they said, Nothing. [1006]

Then said he unto them, But now, he that hath a purse, let him take it, and likewise his scrip: and he that hath no sword, let him sell his garment, and buy one. [1007]

For I say unto you, that this that is written must yet be accomplished in me, And he was reckoned among the transgressors: for the things concerning me have an end. [1008]

And they said, Lord, behold, here are two swords. And he said unto them, It is enough. [1009]

And he came out, and went, as he was wont, to the mount of Olives; and his disciples also followed him. [1010]

And when he was at the place, he said unto them, Pray that ye enter not into temptation. [1011]

And he was withdrawn from them about a stone's cast, and kneeled down, and prayed, [1012]

Saying, Father, if thou be willing, remove this cup from me: nevertheless not my will, but thine, be done. [1013]

And there appeared an angel unto him from heaven, strengthening him. [1014]

And being in an agony he prayed more earnestly: and his sweat was as it were great drops of blood falling down to the ground. [1015]

And when he rose up from prayer, and was come to his disciples, he found them sleeping for sorrow, [1016]

And said unto them, Why sleep ye? rise and pray, lest ye enter into temptation. [1017]

And while he yet spake, behold a multitude, and he that was called Judas, one of the twelve, went before them, and drew near unto Jesus to kiss him. [1018]

But Jesus said unto him, Judas, betrayest thou the Son of man with a kiss? [1019]

When they which were about him saw what would follow, they said unto him, Lord, shall we smite with the sword? [1020]

And one of them smote the servant of the high priest, and cut off his right ear. [1021]

And Jesus answered and said, Suffer ye thus far. And he touched his ear, and healed him. [1022]

Then Jesus said unto the chief priests, and captains of the temple, and the elders, which were come to him, Be ye come out, as against a thief, with swords and staves? [1023]

When I was daily with you in the temple, ye stretched forth no hands against me: but this is your hour, and the power of darkness. [1024]

Then took they him, and led him, and brought him into the high priest's house. And Peter followed afar off. [1025]

And when they had kindled a fire in the midst of the hall, and were set down together, Peter sat down among them. [1026]

But a certain maid beheld him as he sat by the fire, and earnestly looked upon him, and said, This man was also with him. [1027]

And he denied him, saying, Woman, I know him not. [1028]

And after a little while another saw him, and said, Thou art also of them. And Peter said, Man, I am not. [1029]

And about the space of one hour after another confidently affirmed, saying, Of a truth this fellow also was with him: for he is a Galilaean. [1030]

And Peter said, Man, I know not what thou sayest. And immediately, while he yet spake, the cock crew. [1031]

And the Lord turned, and looked upon Peter. And Peter remembered the word of the Lord, how he had said unto him, Before the cock crow, thou shalt deny me thrice. [1032]

And Peter went out, and wept bitterly. [1033]

And the men that held Jesus mocked him, and smote him. [1034]

And when they had blindfolded him, they struck him on the face, and asked him, saying, Prophesy, who is it that smote thee? [1035]

And many other things blasphemously spake they against him. [1036]

And as soon as it was day, the elders of the people and the chief priests and the scribes came together, and led him into their council, saying, [1037]

Art thou the Christ? tell us. And he said unto them, If I tell you, ye will not believe: [1038]

And if I also ask you, ye will not answer me, nor let me go. [1039]

Hereafter shall the Son of man sit on the right hand of the power of God. [1040]

Then said they all, Art thou then the Son of God? And he said unto them, Ye say that I am. [1041]

And they said, What need we any further witness? for we ourselves have heard of his own mouth. [1042]

§ Luke 23

And the whole multitude of them arose, and led him unto Pilate. [1043]

And they began to accuse him, saying, We found this fellow perverting the nation, and forbidding to give tribute to Caesar, saying that he himself is Christ a King. [1044]

And Pilate asked him, saying, Art thou the King of the Jews? And he answered him and said, Thou sayest it. [1045]

Then said Pilate to the chief priests and to the people, I find no fault in this man. [1046]

And they were the more fierce, saying, He stirreth up the people, teaching throughout all Jewry, beginning from Galilee to this place. [1047]

When Pilate heard of Galilee, he asked whether the man were a Galilaean. [1048]

And as soon as he knew that he belonged unto Herod's jurisdiction, he sent him to Herod, who himself also was at Jerusalem at that time. [1049]

And when Herod saw Jesus, he was exceeding glad: for he was desirous to see him of a long season, because he had heard many things of him; and he hoped to have seen some miracle done by him. [1050]

Then he questioned with him in many words; but he answered him nothing. [1051]

And the chief priests and scribes stood and vehemently accused him. [1052]

And Herod with his men of war set him at nought, and mocked him, and arrayed him in a gorgeous robe, and sent him again to Pilate. [1053]

And the same day Pilate and Herod were made friends together: for before they were at enmity between themselves. [1054]

And Pilate, when he had called together the chief priests and the rulers and the people, [1055]

Said unto them, Ye have brought this man unto me, as one that perverteth the people: and, behold, I, having examined him before you, have found no fault in this man touching those things whereof ye accuse him: [1056]

No, nor yet Herod: for I sent you to him; and, lo, nothing worthy of death is done unto him. [1057]

I will therefore chastise him, and release him. [1058]

(For of necessity he must release one unto them at the feast.) [1059]

And they cried out all at once, saying, Away with this man, and release unto us Barabbas: [1060]

(Who for a certain sedition made in the city, and for murder, was cast into prison.) [1061]

Pilate therefore, willing to release Jesus, spake again to them. [1062]

But they cried, saying, Crucify him, crucify him. [1063]

And he said unto them the third time, Why, what evil hath he done? I have found no cause of death in him: I will therefore chastise him, and let him go. [1064]

And they were instant with loud voices, requiring that he might be crucified. And the voices of them and of the chief priests prevailed. [1065]

And Pilate gave sentence that it should be as they required. [1066]

And he released unto them him that for sedition and murder was cast into prison, whom they had desired; but he delivered Jesus to their will. [1067]

And as they led him away, they laid hold upon one Simon, a Cyrenian, coming out of the country, and on him they laid the cross, that he might bear it after Jesus. [1068]

And there followed him a great company of people, and of women, which also bewailed and lamented him. [1069]

But Jesus turning unto them said, Daughters of Jerusalem, weep not for me, but weep for yourselves, and for your children. [1070]

For, behold, the days are coming, in the which they shall say, Blessed are the barren, and the wombs that never bare, and the paps which never gave suck. [1071]

Then shall they begin to say to the mountains, Fall on us; and to the hills, Cover us. [1072]

For if they do these things in a green tree, what shall be done in the dry? [1073]

And there were also two other, malefactors, led with him to be put to death. [1074]

And when they were come to the place, which is called Calvary, there they crucified him, and the malefactors, one on the right hand, and the other on the left. [1075]

Then said Jesus, Father, forgive them; for they know not what they do. And they parted his raiment, and cast lots. [1076]

And the people stood beholding. And the rulers also with them derided him, saying, He saved others; let him save himself, if he be Christ, the chosen of God. [1077]

And the soldiers also mocked him, coming to him, and offering him vinegar, [1078]

And saying, If thou be the king of the Jews, save thyself. [1079]

And a superscription also was written over him in letters of Greek, and Latin, and Hebrew, THIS IS THE KING OF THE JEWS. [1080]

And one of the malefactors which were hanged railed on him, saying, If thou be Christ, save thyself and us. [1081]

But the other answering rebuked him, saying, Dost not thou fear God, seeing thou art in the same condemnation? [1082]

And we indeed justly; for we receive the due reward of our deeds: but this man hath done nothing amiss. [1083]

And he said unto Jesus, Lord, remember me when thou comest into thy kingdom. [1084]

And Jesus said unto him, Verily I say unto thee, To day shalt thou be with me in paradise. [1085]

And it was about the sixth hour, and there was a darkness over all the earth until the ninth hour. [1086]

And the sun was darkened, and the veil of the temple was rent in the midst. [1087]

And when Jesus had cried with a loud voice, he said, Father, into thy hands I commend my spirit: and having said thus, he gave up the ghost. [1088]

Now when the centurion saw what was done, he glorified God, saying, Certainly this was a righteous man. [1089]

And all the people that came together to that sight, beholding the things which were done, smote their breasts, and returned. [1090]

And all his acquaintance, and the women that followed him from Galilee, stood afar off, beholding these things. [1091]

And, behold, there was a man named Joseph, a counsellor; and he was a good man, and a just: [1092]

(The same had not consented to the counsel and deed of them;) he was of Arimathaea, a city of the Jews: who also himself waited for the kingdom of God. [1093]

This man went unto Pilate, and begged the body of Jesus. [1094]

And he took it down, and wrapped it in linen, and laid it in a sepulchre that was hewn in stone, wherein never man before was laid. [1095]

And that day was the preparation, and the sabbath drew on. [1096]

And the women also, which came with him from Galilee, followed after, and beheld the sepulchre, and how his body was laid. [1097]

And they returned, and prepared spices and ointments; and rested the sabbath day according to the commandment. [1098]

§ Luke 24

Now upon the first day of the week, very early in the morning, they came unto the sepulchre, bringing the spices which they had prepared, and certain others with them. [1099]

And they found the stone rolled away from the sepulchre. [1100]

And they entered in, and found not the body of the Lord Jesus. [1101]

And it came to pass, as they were much perplexed thereabout, behold, two men stood by them in shining garments: [1102]

And as they were afraid, and bowed down their faces to the earth, they said unto them, Why seek ye the living among the dead? [1103]

He is not here, but is risen: remember how he spake unto you when he was yet in Galilee, [1104]

Saying, The Son of man must be delivered into the hands of sinful men, and be crucified, and the third day rise again. [1105]

And they remembered his words, [1106]

And returned from the sepulchre, and told all these things unto the eleven, and to all the rest. [1107]

It was Mary Magdalene and Joanna, and Mary the mother of James, and other women that were with them, which told these things unto the apostles. [1108]

And their words seemed to them as idle tales, and they believed them not. [1109]

Then arose Peter, and ran unto the sepulchre; and stooping down, he beheld the linen clothes laid by themselves, and departed, wondering in himself at that which was come to pass. [1110]

And, behold, two of them went that same day to a village called Emmaus, which was from Jerusalem about threescore furlongs. [1111]

And they talked together of all these things which had happened. [1112]

And it came to pass, that, while they communed together and reasoned, Jesus himself drew near, and went with them. [1113]

But their eyes were holden that they should not know him. [1114]

And he said unto them, What manner of communications are these that ye have one to another, as ye walk, and are sad? [1115]

And the one of them, whose name was Cleopas, answering said unto him, Art thou only a stranger in Jerusalem, and hast not known the things which are come to pass there in these days? [1116]

And he said unto them, What things? And they said unto him, Concerning Jesus of Nazareth, which was a prophet mighty in deed and word before God and all the people: [1117]

And how the chief priests and our rulers delivered him to be condemned to death, and have crucified him. [1118]

But we trusted that it had been he which should have redeemed Israel: and beside all this, to day is the third day since these things were done. [1119]

Yea, and certain women also of our company made us astonished, which were early at the sepulchre; [1120]

And when they found not his body, they came, saying, that they had also seen a vision of angels, which said that he was alive. [1121]

And certain of them which were with us went to the sepulchre, and found it even so as the women had said: but him they saw not. [1122]

Then he said unto them, O fools, and slow of heart to believe all that the prophets have spoken: [1123]

Ought not Christ to have suffered these things, and to enter into his glory? [1124]

And beginning at Moses and all the prophets, he expounded unto them in all the scriptures the things concerning himself. [1125]

And they drew nigh unto the village, whither they went: and he made as though he would have gone further. [1126]

But they constrained him, saying, Abide with us: for it is toward evening, and the day is far spent. And he went in to tarry with them. [1127]

And it came to pass, as he sat at meat with them, he took bread, and blessed it, and brake, and gave to them. [1128]

And their eyes were opened, and they knew him; and he vanished out of their sight. [1129]

And they said one to another, Did not our heart burn within us, while he talked with us by the way, and while he opened to us the scriptures? [1130]

And they rose up the same hour, and returned to Jerusalem, and found the eleven gathered together, and them that were with them, [1131]

Saying, The Lord is risen indeed, and hath appeared to Simon. [1132]

And they told what things were done in the way, and how he was known of them in breaking of bread. [1133]

And as they thus spake, Jesus himself stood in the midst of them, and saith unto them, Peace be unto you. [1134]

But they were terrified and affrighted, and supposed that they had seen a spirit. [1135]

And he said unto them, Why are ye troubled? and why do thoughts arise in your hearts? [1136]

Behold my hands and my feet, that it is I myself: handle me, and see; for a spirit hath not flesh and bones, as ye see me have. [1137]

And when he had thus spoken, he shewed them his hands and his feet. [1138]

And while they yet believed not for joy, and wondered, he said unto them, Have ye here any meat? [1139]

And they gave him a piece of a broiled fish, and of an honeycomb. [1140]

And he took it, and did eat before them. [1141]

And he said unto them, These are the words which I spake unto you, while I was yet with you, that all things must be fulfilled, which were written in the law of Moses, and in the prophets, and in the psalms, concerning me. [1142]

Then opened he their understanding, that they might understand the scriptures, [1143]

And said unto them, Thus it is written, and thus it behoved Christ to suffer, and to rise from the dead the third day: [1144]

And that repentance and remission of sins should be preached in his name among all nations, beginning at Jerusalem. [1145]

And ye are witnesses of these things. [1146]

And, behold, I send the promise of my Father upon you: but tarry ye in the city of Jerusalem, until ye be endued with power from on high. [1147]

And he led them out as far as to Bethany, and he lifted up his hands, and blessed them. [1148]

And it came to pass, while he blessed them, he was parted from them, and carried up into heaven. [1149]

And they worshipped him, and returned to Jerusalem with great joy: [1150]

And were continually in the temple, praising and blessing God. Amen. [1151]

=== citations ===
[1] Luke 1:1 (KJV) | | 1
[2] Luke 1:2 (KJV) | | 1
[3] Luke 1:3 (KJV) | | 1
[4] Luke 1:4 (KJV) | | 1
[5] Luke 1:5 (KJV) | | 1
[6] Luke 1:6 (KJV) | | 1
[7] Luke 1:7 (KJV) | | 1
[8] Luke 1:8 (KJV) | | 1
[9] Luke 1:9 (KJV) | | 1
[10] Luke 1:10 (KJV) | | 1
[11] Luke 1:11 (KJV) | | 1
[12] Luke 1:12 (KJV) | | 1
[13] Luke 1:13 (KJV) | | 1
[14] Luke 1:14 (KJV) | | 1
[15] Luke 1:15 (KJV) | | 1
[16] Luke 1:16 (KJV) | | 1
[17] Luke 1:17 (KJV) | | 1
[18] Luke 1:18 (KJV) | | 1
[19] Luke 1:19 (KJV) | | 1
[20] Luke 1:20 (KJV) | | 1
[21] Luke 1:21 (KJV) | | 1
[22] Luke 1:22 (KJV) | | 1
[23] Luke 1:23 (KJV) | | 1
[24] Luke 1:24 (KJV) | | 1
[25] Luke 1:25 (KJV) | | 1
[26] Luke 1:26 (KJV) | | 1
[27] Luke 1:27 (KJV) | | 1
[28] Luke 1:28 (KJV) | | 1
[29] Luke 1:29 (KJV) | | 1
[30] Luke 1:30 (KJV) | | 1
[31] Luke 1:31 (KJV) | | 1
[32] Luke 1:32 (KJV) | | 1
[33] Luke 1:33 (KJV) | | 1
[34] Luke 1:34 (KJV) | | 1
[35] Luke 1:35 (KJV) | | 1
[36] Luke 1:36 (KJV) | | 1
[37] Luke 1:37 (KJV) | | 1
[38] Luke 1:38 (KJV) | | 1
[39] Luke 1:39 (KJV) | | 1
[40] Luke 1:40 (KJV) | | 1
[41] Luke 1:41 (KJV) | | 1
[42] Luke 1:42 (KJV) | | 1
[43] Luke 1:43 (KJV) | | 1
[44] Luke 1:44 (KJV) | | 1
[45] Luke 1:45 (KJV) | | 1
[46] Luke 1:46 (KJV) | | 1
[47] Luke 1:47 (KJV) | | 1
[48] Luke 1:48 (KJV) | | 1
[49] Luke 1:49 (KJV) | | 1
[50] Luke 1:50 (KJV) | | 1
[51] Luke 1:51 (KJV) | | 1
[52] Luke 1:52 (KJV) | | 1
[53] Luke 1:53 (KJV) | | 1
[54] Luke 1:54 (KJV) | | 1
[55] Luke 1:55 (KJV) | | 1
[56] Luke 1:56 (KJV) | | 1
[57] Luke 1:57 (KJV) | | 1
[58] Luke 1:58 (KJV) | | 1
[59] Luke 1:59 (KJV) | | 1
[60] Luke 1:60 (KJV) | | 1
[61] Luke 1:61 (KJV) | | 1
[62] Luke 1:62 (KJV) | | 1
[63] Luke 1:63 (KJV) | | 1
[64] Luke 1:64 (KJV) | | 1
[65] Luke 1:65 (KJV) | | 1
[66] Luke 1:66 (KJV) | | 1
[67] Luke 1:67 (KJV) | | 1
[68] Luke 1:68 (KJV) | | 1
[69] Luke 1:69 (KJV) | | 1
[70] Luke 1:70 (KJV) | | 1
[71] Luke 1:71 (KJV) | | 1
[72] Luke 1:72 (KJV) | | 1
[73] Luke 1:73 (KJV) | | 1
[74] Luke 1:74 (KJV) | | 1
[75] Luke 1:75 (KJV) | | 1
[76] Luke 1:76 (KJV) | | 1
[77] Luke 1:77 (KJV) | | 1
[78] Luke 1:78 (KJV) | | 1
[79] Luke 1:79 (KJV) | | 1
[80] Luke 1:80 (KJV) | | 1
[81] Luke 2:1 (KJV) | | 1
[82] Luke 2:2 (KJV) | | 1
[83] Luke 2:3 (KJV) | | 1
[84] Luke 2:4 (KJV) | | 1
[85] Luke 2:5 (KJV) | | 1
[86] Luke 2:6 (KJV) | | 1
[87] Luke 2:7 (KJV) | | 1
[88] Luke 2:8 (KJV) | | 1
[89] Luke 2:9 (KJV) | | 1
[90] Luke 2:10 (KJV) | | 1
[91] Luke 2:11 (KJV) | | 1
[92] Luke 2:12 (KJV) | | 1
[93] Luke 2:13 (KJV) | | 1
[94] Luke 2:14 (KJV) | | 1
[95] Luke 2:15 (KJV) | | 1
[96] Luke 2:16 (KJV) | | 1
[97] Luke 2:17 (KJV) | | 1
[98] Luke 2:18 (KJV) | | 1
[99] Luke 2:19 (KJV) | | 1
[100] Luke 2:20 (KJV) | | 1
[101] Luke 2:21 (KJV) | | 1
[102] Luke 2:22 (KJV) | | 1
[103] Luke 2:23 (KJV) | | 1
[104] Luke 2:24 (KJV) | | 1
[105] Luke 2:25 (KJV) | | 1
[106] Luke 2:26 (KJV) | | 1
[107] Luke 2:27 (KJV) | | 1
[108] Luke 2:28 (KJV) | | 1
[109] Luke 2:29 (KJV) | | 1
[110] Luke 2:30 (KJV) | | 1
[111] Luke 2:31 (KJV) | | 1
[112] Luke 2:32 (KJV) | | 1
[113] Luke 2:33 (KJV) | | 1
[114] Luke 2:34 (KJV) | | 1
[115] Luke 2:35 (KJV) | | 1
[116] Luke 2:36 (KJV) | | 1
[117] Luke 2:37 (KJV) | | 1
[118] Luke 2:38 (KJV) | | 1
[119] Luke 2:39 (KJV) | | 1
[120] Luke 2:40 (KJV) | | 1
[121] Luke 2:41 (KJV) | | 1
[122] Luke 2:42 (KJV) | | 1
[123] Luke 2:43 (KJV) | | 1
[124] Luke 2:44 (KJV) | | 1
[125] Luke 2:45 (KJV) | | 1
[126] Luke 2:46 (KJV) | | 1
[127] Luke 2:47 (KJV) | | 1
[128] Luke 2:48 (KJV) | | 1
[129] Luke 2:49 (KJV) | | 1
[130] Luke 2:50 (KJV) | | 1
[131] Luke 2:51 (KJV) | | 1
[132] Luke 2:52 (KJV) | | 1
[133] Luke 3:1 (KJV) | | 1
[134] Luke 3:2 (KJV) | | 1
[135] Luke 3:3 (KJV) | | 1
[136] Luke 3:4 (KJV) | | 1
[137] Luke 3:5 (KJV) | | 1
[138] Luke 3:6 (KJV) | | 1
[139] Luke 3:7 (KJV) | | 1
[140] Luke 3:8 (KJV) | | 1
[141] Luke 3:9 (KJV) | | 1
[142] Luke 3:10 (KJV) | | 1
[143] Luke 3:11 (KJV) | | 1
[144] Luke 3:12 (KJV) | | 1
[145] Luke 3:13 (KJV) | | 1
[146] Luke 3:14 (KJV) | | 1
[147] Luke 3:15 (KJV) | | 1
[148] Luke 3:16 (KJV) | | 1
[149] Luke 3:17 (KJV) | | 1
[150] Luke 3:18 (KJV) | | 1
[151] Luke 3:19 (KJV) | | 1
[152] Luke 3:20 (KJV) | | 1
[153] Luke 3:21 (KJV) | | 1
[154] Luke 3:22 (KJV) | | 1
[155] Luke 3:23 (KJV) | | 1
[156] Luke 3:24 (KJV) | | 1
[157] Luke 3:25 (KJV) | | 1
[158] Luke 3:26 (KJV) | | 1
[159] Luke 3:27 (KJV) | | 1
[160] Luke 3:28 (KJV) | | 1
[161] Luke 3:29 (KJV) | | 1
[162] Luke 3:30 (KJV) | | 1
[163] Luke 3:31 (KJV) | | 1
[164] Luke 3:32 (KJV) | | 1
[165] Luke 3:33 (KJV) | | 1
[166] Luke 3:34 (KJV) | | 1
[167] Luke 3:35 (KJV) | | 1
[168] Luke 3:36 (KJV) | | 1
[169] Luke 3:37 (KJV) | | 1
[170] Luke 3:38 (KJV) | | 1
[171] Luke 4:1 (KJV) | | 1
[172] Luke 4:2 (KJV) | | 1
[173] Luke 4:3 (KJV) | | 1
[174] Luke 4:4 (KJV) | | 1
[175] Luke 4:5 (KJV) | | 1
[176] Luke 4:6 (KJV) | | 1
[177] Luke 4:7 (KJV) | | 1
[178] Luke 4:8 (KJV) | | 1
[179] Luke 4:9 (KJV) | | 1
[180] Luke 4:10 (KJV) | | 1
[181] Luke 4:11 (KJV) | | 1
[182] Luke 4:12 (KJV) | | 1
[183] Luke 4:13 (KJV) | | 1
[184] Luke 4:14 (KJV) | | 1
[185] Luke 4:15 (KJV) | | 1
[186] Luke 4:16 (KJV) | | 1
[187] Luke 4:17 (KJV) | | 1
[188] Luke 4:18 (KJV) | | 1
[189] Luke 4:19 (KJV) | | 1
[190] Luke 4:20 (KJV) | | 1
[191] Luke 4:21 (KJV) | | 1
[192] Luke 4:22 (KJV) | | 1
[193] Luke 4:23 (KJV) | | 1
[194] Luke 4:24 (KJV) | | 1
[195] Luke 4:25 (KJV) | | 1
[196] Luke 4:26 (KJV) | | 1
[197] Luke 4:27 (KJV) | | 1
[198] Luke 4:28 (KJV) | | 1
[199] Luke 4:29 (KJV) | | 1
[200] Luke 4:30 (KJV) | | 1
[201] Luke 4:31 (KJV) | | 1
[202] Luke 4:32 (KJV) | | 1
[203] Luke 4:33 (KJV) | | 1
[204] Luke 4:34 (KJV) | | 1
[205] Luke 4:35 (KJV) | | 1
[206] Luke 4:36 (KJV) | | 1
[207] Luke 4:37 (KJV) | | 1
[208] Luke 4:38 (KJV) | | 1
[209] Luke 4:39 (KJV) | | 1
[210] Luke 4:40 (KJV) | | 1
[211] Luke 4:41 (KJV) | | 1
[212] Luke 4:42 (KJV) | | 1
[213] Luke 4:43 (KJV) | | 1
[214] Luke 4:44 (KJV) | | 1
[215] Luke 5:1 (KJV) | | 1
[216] Luke 5:2 (KJV) | | 1
[217] Luke 5:3 (KJV) | | 1
[218] Luke 5:4 (KJV) | | 1
[219] Luke 5:5 (KJV) | | 1
[220] Luke 5:6 (KJV) | | 1
[221] Luke 5:7 (KJV) | | 1
[222] Luke 5:8 (KJV) | | 1
[223] Luke 5:9 (KJV) | | 1
[224] Luke 5:10 (KJV) | | 1
[225] Luke 5:11 (KJV) | | 1
[226] Luke 5:12 (KJV) | | 1
[227] Luke 5:13 (KJV) | | 1
[228] Luke 5:14 (KJV) | | 1
[229] Luke 5:15 (KJV) | | 1
[230] Luke 5:16 (KJV) | | 1
[231] Luke 5:17 (KJV) | | 1
[232] Luke 5:18 (KJV) | | 1
[233] Luke 5:19 (KJV) | | 1
[234] Luke 5:20 (KJV) | | 1
[235] Luke 5:21 (KJV) | | 1
[236] Luke 5:22 (KJV) | | 1
[237] Luke 5:23 (KJV) | | 1
[238] Luke 5:24 (KJV) | | 1
[239] Luke 5:25 (KJV) | | 1
[240] Luke 5:26 (KJV) | | 1
[241] Luke 5:27 (KJV) | | 1
[242] Luke 5:28 (KJV) | | 1
[243] Luke 5:29 (KJV) | | 1
[244] Luke 5:30 (KJV) | | 1
[245] Luke 5:31 (KJV) | | 1
[246] Luke 5:32 (KJV) | | 1
[247] Luke 5:33 (KJV) | | 1
[248] Luke 5:34 (KJV) | | 1
[249] Luke 5:35 (KJV) | | 1
[250] Luke 5:36 (KJV) | | 1
[251] Luke 5:37 (KJV) | | 1
[252] Luke 5:38 (KJV) | | 1
[253] Luke 5:39 (KJV) | | 1
[254] Luke 6:1 (KJV) | | 1
[255] Luke 6:2 (KJV) | | 1
[256] Luke 6:3 (KJV) | | 1
[257] Luke 6:4 (KJV) | | 1
[258] Luke 6:5 (KJV) | | 1
[259] Luke 6:6 (KJV) | | 1
[260] Luke 6:7 (KJV) | | 1
[261] Luke 6:8 (KJV) | | 1
[262] Luke 6:9 (KJV) | | 1
[263] Luke 6:10 (KJV) | | 1
[264] Luke 6:11 (KJV) | | 1
[265] Luke 6:12 (KJV) | | 1
[266] Luke 6:13 (KJV) | | 1
[267] Luke 6:14 (KJV) | | 1
[268] Luke 6:15 (KJV) | | 1
[269] Luke 6:16 (KJV) | | 1
[270] Luke 6:17 (KJV) | | 1
[271] Luke 6:18 (KJV) | | 1
[272] Luke 6:19 (KJV) | | 1
[273] Luke 6:20 (KJV) | | 1
[274] Luke 6:21 (KJV) | | 1
[275] Luke 6:22 (KJV) | | 1
[276] Luke 6:23 (KJV) | | 1
[277] Luke 6:24 (KJV) | | 1
[278] Luke 6:25 (KJV) | | 1
[279] Luke 6:26 (KJV) | | 1
[280] Luke 6:27 (KJV) | | 1
[281] Luke 6:28 (KJV) | | 1
[282] Luke 6:29 (KJV) | | 1
[283] Luke 6:30 (KJV) | | 1
[284] Luke 6:31 (KJV) | | 1
[285] Luke 6:32 (KJV) | | 1
[286] Luke 6:33 (KJV) | | 1
[287] Luke 6:34 (KJV) | | 1
[288] Luke 6:35 (KJV) | | 1
[289] Luke 6:36 (KJV) | | 1
[290] Luke 6:37 (KJV) | | 1
[291] Luke 6:38 (KJV) | | 1
[292] Luke 6:39 (KJV) | | 1
[293] Luke 6:40 (KJV) | | 1
[294] Luke 6:41 (KJV) | | 1
[295] Luke 6:42 (KJV) | | 1
[296] Luke 6:43 (KJV) | | 1
[297] Luke 6:44 (KJV) | | 1
[298] Luke 6:45 (KJV) | | 1
[299] Luke 6:46 (KJV) | | 1
[300] Luke 6:47 (KJV) | | 1
[301] Luke 6:48 (KJV) | | 1
[302] Luke 6:49 (KJV) | | 1
[303] Luke 7:1 (KJV) | | 1
[304] Luke 7:2 (KJV) | | 1
[305] Luke 7:3 (KJV) | | 1
[306] Luke 7:4 (KJV) | | 1
[307] Luke 7:5 (KJV) | | 1
[308] Luke 7:6 (KJV) | | 1
[309] Luke 7:7 (KJV) | | 1
[310] Luke 7:8 (KJV) | | 1
[311] Luke 7:9 (KJV) | | 1
[312] Luke 7:10 (KJV) | | 1
[313] Luke 7:11 (KJV) | | 1
[314] Luke 7:12 (KJV) | | 1
[315] Luke 7:13 (KJV) | | 1
[316] Luke 7:14 (KJV) | | 1
[317] Luke 7:15 (KJV) | | 1
[318] Luke 7:16 (KJV) | | 1
[319] Luke 7:17 (KJV) | | 1
[320] Luke 7:18 (KJV) | | 1
[321] Luke 7:19 (KJV) | | 1
[322] Luke 7:20 (KJV) | | 1
[323] Luke 7:21 (KJV) | | 1
[324] Luke 7:22 (KJV) | | 1
[325] Luke 7:23 (KJV) | | 1
[326] Luke 7:24 (KJV) | | 1
[327] Luke 7:25 (KJV) | | 1
[328] Luke 7:26 (KJV) | | 1
[329] Luke 7:27 (KJV) | | 1
[330] Luke 7:28 (KJV) | | 1
[331] Luke 7:29 (KJV) | | 1
[332] Luke 7:30 (KJV) | | 1
[333] Luke 7:31 (KJV) | | 1
[334] Luke 7:32 (KJV) | | 1
[335] Luke 7:33 (KJV) | | 1
[336] Luke 7:34 (KJV) | | 1
[337] Luke 7:35 (KJV) | | 1
[338] Luke 7:36 (KJV) | | 1
[339] Luke 7:37 (KJV) | | 1
[340] Luke 7:38 (KJV) | | 1
[341] Luke 7:39 (KJV) | | 1
[342] Luke 7:40 (KJV) | | 1
[343] Luke 7:41 (KJV) | | 1
[344] Luke 7:42 (KJV) | | 1
[345] Luke 7:43 (KJV) | | 1
[346] Luke 7:44 (KJV) | | 1
[347] Luke 7:45 (KJV) | | 1
[348] Luke 7:46 (KJV) | | 1
[349] Luke 7:47 (KJV) | | 1
[350] Luke 7:48 (KJV) | | 1
[351] Luke 7:49 (KJV) | | 1
[352] Luke 7:50 (KJV) | | 1
[353] Luke 8:1 (KJV) | | 1
[354] Luke 8:2 (KJV) | | 1
[355] Luke 8:3 (KJV) | | 1
[356] Luke 8:4 (KJV) | | 1
[357] Luke 8:5 (KJV) | | 1
[358] Luke 8:6 (KJV) | | 1
[359] Luke 8:7 (KJV) | | 1
[360] Luke 8:8 (KJV) | | 1
[361] Luke 8:9 (KJV) | | 1
[362] Luke 8:10 (KJV) | | 1
[363] Luke 8:11 (KJV) | | 1
[364] Luke 8:12 (KJV) | | 1
[365] Luke 8:13 (KJV) | | 1
[366] Luke 8:14 (KJV) | | 1
[367] Luke 8:15 (KJV) | | 1
[368] Luke 8:16 (KJV) | | 1
[369] Luke 8:17 (KJV) | | 1
[370] Luke 8:18 (KJV) | | 1
[371] Luke 8:19 (KJV) | | 1
[372] Luke 8:20 (KJV) | | 1
[373] Luke 8:21 (KJV) | | 1
[374] Luke 8:22 (KJV) | | 1
[375] Luke 8:23 (KJV) | | 1
[376] Luke 8:24 (KJV) | | 1
[377] Luke 8:25 (KJV) | | 1
[378] Luke 8:26 (KJV) | | 1
[379] Luke 8:27 (KJV) | | 1
[380] Luke 8:28 (KJV) | | 1
[381] Luke 8:29 (KJV) | | 1
[382] Luke 8:30 (KJV) | | 1
[383] Luke 8:31 (KJV) | | 1
[384] Luke 8:32 (KJV) | | 1
[385] Luke 8:33 (KJV) | | 1
[386] Luke 8:34 (KJV) | | 1
[387] Luke 8:35 (KJV) | | 1
[388] Luke 8:36 (KJV) | | 1
[389] Luke 8:37 (KJV) | | 1
[390] Luke 8:38 (KJV) | | 1
[391] Luke 8:39 (KJV) | | 1
[392] Luke 8:40 (KJV) | | 1
[393] Luke 8:41 (KJV) | | 1
[394] Luke 8:42 (KJV) | | 1
[395] Luke 8:43 (KJV) | | 1
[396] Luke 8:44 (KJV) | | 1
[397] Luke 8:45 (KJV) | | 1
[398] Luke 8:46 (KJV) | | 1
[399] Luke 8:47 (KJV) | | 1
[400] Luke 8:48 (KJV) | | 1
[401] Luke 8:49 (KJV) | | 1
[402] Luke 8:50 (KJV) | | 1
[403] Luke 8:51 (KJV) | | 1
[404] Luke 8:52 (KJV) | | 1
[405] Luke 8:53 (KJV) | | 1
[406] Luke 8:54 (KJV) | | 1
[407] Luke 8:55 (KJV) | | 1
[408] Luke 8:56 (KJV) | | 1
[409] Luke 9:1 (KJV) | | 1
[410] Luke 9:2 (KJV) | | 1
[411] Luke 9:3 (KJV) | | 1
[412] Luke 9:4 (KJV) | | 1
[413] Luke 9:5 (KJV) | | 1
[414] Luke 9:6 (KJV) | | 1
[415] Luke 9:7 (KJV) | | 1
[416] Luke 9:8 (KJV) | | 1
[417] Luke 9:9 (KJV) | | 1
[418] Luke 9:10 (KJV) | | 1
[419] Luke 9:11 (KJV) | | 1
[420] Luke 9:12 (KJV) | | 1
[421] Luke 9:13 (KJV) | | 1
[422] Luke 9:14 (KJV) | | 1
[423] Luke 9:15 (KJV) | | 1
[424] Luke 9:16 (KJV) | | 1
[425] Luke 9:17 (KJV) | | 1
[426] Luke 9:18 (KJV) | | 1
[427] Luke 9:19 (KJV) | | 1
[428] Luke 9:20 (KJV) | | 1
[429] Luke 9:21 (KJV) | | 1
[430] Luke 9:22 (KJV) | | 1
[431] Luke 9:23 (KJV) | | 1
[432] Luke 9:24 (KJV) | | 1
[433] Luke 9:25 (KJV) | | 1
[434] Luke 9:26 (KJV) | | 1
[435] Luke 9:27 (KJV) | | 1
[436] Luke 9:28 (KJV) | | 1
[437] Luke 9:29 (KJV) | | 1
[438] Luke 9:30 (KJV) | | 1
[439] Luke 9:31 (KJV) | | 1
[440] Luke 9:32 (KJV) | | 1
[441] Luke 9:33 (KJV) | | 1
[442] Luke 9:34 (KJV) | | 1
[443] Luke 9:35 (KJV) | | 1
[444] Luke 9:36 (KJV) | | 1
[445] Luke 9:37 (KJV) | | 1
[446] Luke 9:38 (KJV) | | 1
[447] Luke 9:39 (KJV) | | 1
[448] Luke 9:40 (KJV) | | 1
[449] Luke 9:41 (KJV) | | 1
[450] Luke 9:42 (KJV) | | 1
[451] Luke 9:43 (KJV) | | 1
[452] Luke 9:44 (KJV) | | 1
[453] Luke 9:45 (KJV) | | 1
[454] Luke 9:46 (KJV) | | 1
[455] Luke 9:47 (KJV) | | 1
[456] Luke 9:48 (KJV) | | 1
[457] Luke 9:49 (KJV) | | 1
[458] Luke 9:50 (KJV) | | 1
[459] Luke 9:51 (KJV) | | 1
[460] Luke 9:52 (KJV) | | 1
[461] Luke 9:53 (KJV) | | 1
[462] Luke 9:54 (KJV) | | 1
[463] Luke 9:55 (KJV) | | 1
[464] Luke 9:56 (KJV) | | 1
[465] Luke 9:57 (KJV) | | 1
[466] Luke 9:58 (KJV) | | 1
[467] Luke 9:59 (KJV) | | 1
[468] Luke 9:60 (KJV) | | 1
[469] Luke 9:61 (KJV) | | 1
[470] Luke 9:62 (KJV) | | 1
[471] Luke 10:1 (KJV) | | 1
[472] Luke 10:2 (KJV) | | 1
[473] Luke 10:3 (KJV) | | 1
[474] Luke 10:4 (KJV) | | 1
[475] Luke 10:5 (KJV) | | 1
[476] Luke 10:6 (KJV) | | 1
[477] Luke 10:7 (KJV) | | 1
[478] Luke 10:8 (KJV) | | 1
[479] Luke 10:9 (KJV) | | 1
[480] Luke 10:10 (KJV) | | 1
[481] Luke 10:11 (KJV) | | 1
[482] Luke 10:12 (KJV) | | 1
[483] Luke 10:13 (KJV) | | 1
[484] Luke 10:14 (KJV) | | 1
[485] Luke 10:15 (KJV) | | 1
[486] Luke 10:16 (KJV) | | 1
[487] Luke 10:17 (KJV) | | 1
[488] Luke 10:18 (KJV) | | 1
[489] Luke 10:19 (KJV) | | 1
[490] Luke 10:20 (KJV) | | 1
[491] Luke 10:21 (KJV) | | 1
[492] Luke 10:22 (KJV) | | 1
[493] Luke 10:23 (KJV) | | 1
[494] Luke 10:24 (KJV) | | 1
[495] Luke 10:25 (KJV) | | 1
[496] Luke 10:26 (KJV) | | 1
[497] Luke 10:27 (KJV) | | 1
[498] Luke 10:28 (KJV) | | 1
[499] Luke 10:29 (KJV) | | 1
[500] Luke 10:30 (KJV) | | 1
[501] Luke 10:31 (KJV) | | 1
[502] Luke 10:32 (KJV) | | 1
[503] Luke 10:33 (KJV) | | 1
[504] Luke 10:34 (KJV) | | 1
[505] Luke 10:35 (KJV) | | 1
[506] Luke 10:36 (KJV) | | 1
[507] Luke 10:37 (KJV) | | 1
[508] Luke 10:38 (KJV) | | 1
[509] Luke 10:39 (KJV) | | 1
[510] Luke 10:40 (KJV) | | 1
[511] Luke 10:41 (KJV) | | 1
[512] Luke 10:42 (KJV) | | 1
[513] Luke 11:1 (KJV) | | 1
[514] Luke 11:2 (KJV) | | 1
[515] Luke 11:3 (KJV) | | 1
[516] Luke 11:4 (KJV) | | 1
[517] Luke 11:5 (KJV) | | 1
[518] Luke 11:6 (KJV) | | 1
[519] Luke 11:7 (KJV) | | 1
[520] Luke 11:8 (KJV) | | 1
[521] Luke 11:9 (KJV) | | 1
[522] Luke 11:10 (KJV) | | 1
[523] Luke 11:11 (KJV) | | 1
[524] Luke 11:12 (KJV) | | 1
[525] Luke 11:13 (KJV) | | 1
[526] Luke 11:14 (KJV) | | 1
[527] Luke 11:15 (KJV) | | 1
[528] Luke 11:16 (KJV) | | 1
[529] Luke 11:17 (KJV) | | 1
[530] Luke 11:18 (KJV) | | 1
[531] Luke 11:19 (KJV) | | 1
[532] Luke 11:20 (KJV) | | 1
[533] Luke 11:21 (KJV) | | 1
[534] Luke 11:22 (KJV) | | 1
[535] Luke 11:23 (KJV) | | 1
[536] Luke 11:24 (KJV) | | 1
[537] Luke 11:25 (KJV) | | 1
[538] Luke 11:26 (KJV) | | 1
[539] Luke 11:27 (KJV) | | 1
[540] Luke 11:28 (KJV) | | 1
[541] Luke 11:29 (KJV) | | 1
[542] Luke 11:30 (KJV) | | 1
[543] Luke 11:31 (KJV) | | 1
[544] Luke 11:32 (KJV) | | 1
[545] Luke 11:33 (KJV) | | 1
[546] Luke 11:34 (KJV) | | 1
[547] Luke 11:35 (KJV) | | 1
[548] Luke 11:36 (KJV) | | 1
[549] Luke 11:37 (KJV) | | 1
[550] Luke 11:38 (KJV) | | 1
[551] Luke 11:39 (KJV) | | 1
[552] Luke 11:40 (KJV) | | 1
[553] Luke 11:41 (KJV) | | 1
[554] Luke 11:42 (KJV) | | 1
[555] Luke 11:43 (KJV) | | 1
[556] Luke 11:44 (KJV) | | 1
[557] Luke 11:45 (KJV) | | 1
[558] Luke 11:46 (KJV) | | 1
[559] Luke 11:47 (KJV) | | 1
[560] Luke 11:48 (KJV) | | 1
[561] Luke 11:49 (KJV) | | 1
[562] Luke 11:50 (KJV) | | 1
[563] Luke 11:51 (KJV) | | 1
[564] Luke 11:52 (KJV) | | 1
[565] Luke 11:53 (KJV) | | 1
[566] Luke 11:54 (KJV) | | 1
[567] Luke 12:1 (KJV) | | 1
[568] Luke 12:2 (KJV) | | 1
[569] Luke 12:3 (KJV) | | 1
[570] Luke 12:4 (KJV) | | 1
[571] Luke 12:5 (KJV) | | 1
[572] Luke 12:6 (KJV) | | 1
[573] Luke 12:7 (KJV) | | 1
[574] Luke 12:8 (KJV) | | 1
[575] Luke 12:9 (KJV) | | 1
[576] Luke 12:10 (KJV) | | 1
[577] Luke 12:11 (KJV) | | 1
[578] Luke 12:12 (KJV) | | 1
[579] Luke 12:13 (KJV) | | 1
[580] Luke 12:14 (KJV) | | 1
[581] Luke 12:15 (KJV) | | 1
[582] Luke 12:16 (KJV) | | 1
[583] Luke 12:17 (KJV) | | 1
[584] Luke 12:18 (KJV) | | 1
[585] Luke 12:19 (KJV) | | 1
[586] Luke 12:20 (KJV) | | 1
[587] Luke 12:21 (KJV) | | 1
[588] Luke 12:22 (KJV) | | 1
[589] Luke 12:23 (KJV) | | 1
[590] Luke 12:24 (KJV) | | 1
[591] Luke 12:25 (KJV) | | 1
[592] Luke 12:26 (KJV) | | 1
[593] Luke 12:27 (KJV) | | 1
[594] Luke 12:28 (KJV) | | 1
[595] Luke 12:29 (KJV) | | 1
[596] Luke 12:30 (KJV) | | 1
[597] Luke 12:31 (KJV) | | 1
[598] Luke 12:32 (KJV) | | 1
[599] Luke 12:33 (KJV) | | 1
[600] Luke 12:34 (KJV) | | 1
[601] Luke 12:35 (KJV) | | 1
[602] Luke 12:36 (KJV) | | 1
[603] Luke 12:37 (KJV) | | 1
[604] Luke 12:38 (KJV) | | 1
[605] Luke 12:39 (KJV) | | 1
[606] Luke 12:40 (KJV) | | 1
[607] Luke 12:41 (KJV) | | 1
[608] Luke 12:42 (KJV) | | 1
[609] Luke 12:43 (KJV) | | 1
[610] Luke 12:44 (KJV) | | 1
[611] Luke 12:45 (KJV) | | 1
[612] Luke 12:46 (KJV) | | 1
[613] Luke 12:47 (KJV) | | 1
[614] Luke 12:48 (KJV) | | 1
[615] Luke 12:49 (KJV) | | 1
[616] Luke 12:50 (KJV) | | 1
[617] Luke 12:51 (KJV) | | 1
[618] Luke 12:52 (KJV) | | 1
[619] Luke 12:53 (KJV) | | 1
[620] Luke 12:54 (KJV) | | 1
[621] Luke 12:55 (KJV) | | 1
[622] Luke 12:56 (KJV) | | 1
[623] Luke 12:57 (KJV) | | 1
[624] Luke 12:58 (KJV) | | 1
[625] Luke 12:59 (KJV) | | 1
[626] Luke 13:1 (KJV) | | 1
[627] Luke 13:2 (KJV) | | 1
[628] Luke 13:3 (KJV) | | 1
[629] Luke 13:4 (KJV) | | 1
[630] Luke 13:5 (KJV) | | 1
[631] Luke 13:6 (KJV) | | 1
[632] Luke 13:7 (KJV) | | 1
[633] Luke 13:8 (KJV) | | 1
[634] Luke 13:9 (KJV) | | 1
[635] Luke 13:10 (KJV) | | 1
[636] Luke 13:11 (KJV) | | 1
[637] Luke 13:12 (KJV) | | 1
[638] Luke 13:13 (KJV) | | 1
[639] Luke 13:14 (KJV) | | 1
[640] Luke 13:15 (KJV) | | 1
[641] Luke 13:16 (KJV) | | 1
[642] Luke 13:17 (KJV) | | 1
[643] Luke 13:18 (KJV) | | 1
[644] Luke 13:19 (KJV) | | 1
[645] Luke 13:20 (KJV) | | 1
[646] Luke 13:21 (KJV) | | 1
[647] Luke 13:22 (KJV) | | 1
[648] Luke 13:23 (KJV) | | 1
[649] Luke 13:24 (KJV) | | 1
[650] Luke 13:25 (KJV) | | 1
[651] Luke 13:26 (KJV) | | 1
[652] Luke 13:27 (KJV) | | 1
[653] Luke 13:28 (KJV) | | 1
[654] Luke 13:29 (KJV) | | 1
[655] Luke 13:30 (KJV) | | 1
[656] Luke 13:31 (KJV) | | 1
[657] Luke 13:32 (KJV) | | 1
[658] Luke 13:33 (KJV) | | 1
[659] Luke 13:34 (KJV) | | 1
[660] Luke 13:35 (KJV) | | 1
[661] Luke 14:1 (KJV) | | 1
[662] Luke 14:2 (KJV) | | 1
[663] Luke 14:3 (KJV) | | 1
[664] Luke 14:4 (KJV) | | 1
[665] Luke 14:5 (KJV) | | 1
[666] Luke 14:6 (KJV) | | 1
[667] Luke 14:7 (KJV) | | 1
[668] Luke 14:8 (KJV) | | 1
[669] Luke 14:9 (KJV) | | 1
[670] Luke 14:10 (KJV) | | 1
[671] Luke 14:11 (KJV) | | 1
[672] Luke 14:12 (KJV) | | 1
[673] Luke 14:13 (KJV) | | 1
[674] Luke 14:14 (KJV) | | 1
[675] Luke 14:15 (KJV) | | 1
[676] Luke 14:16 (KJV) | | 1
[677] Luke 14:17 (KJV) | | 1
[678] Luke 14:18 (KJV) | | 1
[679] Luke 14:19 (KJV) | | 1
[680] Luke 14:20 (KJV) | | 1
[681] Luke 14:21 (KJV) | | 1
[682] Luke 14:22 (KJV) | | 1
[683] Luke 14:23 (KJV) | | 1
[684] Luke 14:24 (KJV) | | 1
[685] Luke 14:25 (KJV) | | 1
[686] Luke 14:26 (KJV) | | 1
[687] Luke 14:27 (KJV) | | 1
[688] Luke 14:28 (KJV) | | 1
[689] Luke 14:29 (KJV) | | 1
[690] Luke 14:30 (KJV) | | 1
[691] Luke 14:31 (KJV) | | 1
[692] Luke 14:32 (KJV) | | 1
[693] Luke 14:33 (KJV) | | 1
[694] Luke 14:34 (KJV) | | 1
[695] Luke 14:35 (KJV) | | 1
[696] Luke 15:1 (KJV) | | 1
[697] Luke 15:2 (KJV) | | 1
[698] Luke 15:3 (KJV) | | 1
[699] Luke 15:4 (KJV) | | 1
[700] Luke 15:5 (KJV) | | 1
[701] Luke 15:6 (KJV) | | 1
[702] Luke 15:7 (KJV) | | 1
[703] Luke 15:8 (KJV) | | 1
[704] Luke 15:9 (KJV) | | 1
[705] Luke 15:10 (KJV) | | 1
[706] Luke 15:11 (KJV) | | 1
[707] Luke 15:12 (KJV) | | 1
[708] Luke 15:13 (KJV) | | 1
[709] Luke 15:14 (KJV) | | 1
[710] Luke 15:15 (KJV) | | 1
[711] Luke 15:16 (KJV) | | 1
[712] Luke 15:17 (KJV) | | 1
[713] Luke 15:18 (KJV) | | 1
[714] Luke 15:19 (KJV) | | 1
[715] Luke 15:20 (KJV) | | 1
[716] Luke 15:21 (KJV) | | 1
[717] Luke 15:22 (KJV) | | 1
[718] Luke 15:23 (KJV) | | 1
[719] Luke 15:24 (KJV) | | 1
[720] Luke 15:25 (KJV) | | 1
[721] Luke 15:26 (KJV) | | 1
[722] Luke 15:27 (KJV) | | 1
[723] Luke 15:28 (KJV) | | 1
[724] Luke 15:29 (KJV) | | 1
[725] Luke 15:30 (KJV) | | 1
[726] Luke 15:31 (KJV) | | 1
[727] Luke 15:32 (KJV) | | 1
[728] Luke 16:1 (KJV) | | 1
[729] Luke 16:2 (KJV) | | 1
[730] Luke 16:3 (KJV) | | 1
[731] Luke 16:4 (KJV) | | 1
[732] Luke 16:5 (KJV) | | 1
[733] Luke 16:6 (KJV) | | 1
[734] Luke 16:7 (KJV) | | 1
[735] Luke 16:8 (KJV) | | 1
[736] Luke 16:9 (KJV) | | 1
[737] Luke 16:10 (KJV) | | 1
[738] Luke 16:11 (KJV) | | 1
[739] Luke 16:12 (KJV) | | 1
[740] Luke 16:13 (KJV) | | 1
[741] Luke 16:14 (KJV) | | 1
[742] Luke 16:15 (KJV) | | 1
[743] Luke 16:16 (KJV) | | 1
[744] Luke 16:17 (KJV) | | 1
[745] Luke 16:18 (KJV) | | 1
[746] Luke 16:19 (KJV) | | 1
[747] Luke 16:20 (KJV) | | 1
[748] Luke 16:21 (KJV) | | 1
[749] Luke 16:22 (KJV) | | 1
[750] Luke 16:23 (KJV) | | 1
[751] Luke 16:24 (KJV) | | 1
[752] Luke 16:25 (KJV) | | 1
[753] Luke 16:26 (KJV) | | 1
[754] Luke 16:27 (KJV) | | 1
[755] Luke 16:28 (KJV) | | 1
[756] Luke 16:29 (KJV) | | 1
[757] Luke 16:30 (KJV) | | 1
[758] Luke 16:31 (KJV) | | 1
[759] Luke 17:1 (KJV) | | 1
[760] Luke 17:2 (KJV) | | 1
[761] Luke 17:3 (KJV) | | 1
[762] Luke 17:4 (KJV) | | 1
[763] Luke 17:5 (KJV) | | 1
[764] Luke 17:6 (KJV) | | 1
[765] Luke 17:7 (KJV) | | 1
[766] Luke 17:8 (KJV) | | 1
[767] Luke 17:9 (KJV) | | 1
[768] Luke 17:10 (KJV) | | 1
[769] Luke 17:11 (KJV) | | 1
[770] Luke 17:12 (KJV) | | 1
[771] Luke 17:13 (KJV) | | 1
[772] Luke 17:14 (KJV) | | 1
[773] Luke 17:15 (KJV) | | 1
[774] Luke 17:16 (KJV) | | 1
[775] Luke 17:17 (KJV) | | 1
[776] Luke 17:18 (KJV) | | 1
[777] Luke 17:19 (KJV) | | 1
[778] Luke 17:20 (KJV) | | 1
[779] Luke 17:21 (KJV) | | 1
[780] Luke 17:22 (KJV) | | 1
[781] Luke 17:23 (KJV) | | 1
[782] Luke 17:24 (KJV) | | 1
[783] Luke 17:25 (KJV) | | 1
[784] Luke 17:26 (KJV) | | 1
[785] Luke 17:27 (KJV) | | 1
[786] Luke 17:28 (KJV) | | 1
[787] Luke 17:29 (KJV) | | 1
[788] Luke 17:30 (KJV) | | 1
[789] Luke 17:31 (KJV) | | 1
[790] Luke 17:32 (KJV) | | 1
[791] Luke 17:33 (KJV) | | 1
[792] Luke 17:34 (KJV) | | 1
[793] Luke 17:35 (KJV) | | 1
[794] Luke 17:36 (KJV) | | 1
[795] Luke 17:37 (KJV) | | 1
[796] Luke 18:1 (KJV) | | 1
[797] Luke 18:2 (KJV) | | 1
[798] Luke 18:3 (KJV) | | 1
[799] Luke 18:4 (KJV) | | 1
[800] Luke 18:5 (KJV) | | 1
[801] Luke 18:6 (KJV) | | 1
[802] Luke 18:7 (KJV) | | 1
[803] Luke 18:8 (KJV) | | 1
[804] Luke 18:9 (KJV) | | 1
[805] Luke 18:10 (KJV) | | 1
[806] Luke 18:11 (KJV) | | 1
[807] Luke 18:12 (KJV) | | 1
[808] Luke 18:13 (KJV) | | 1
[809] Luke 18:14 (KJV) | | 1
[810] Luke 18:15 (KJV) | | 1
[811] Luke 18:16 (KJV) | | 1
[812] Luke 18:17 (KJV) | | 1
[813] Luke 18:18 (KJV) | | 1
[814] Luke 18:19 (KJV) | | 1
[815] Luke 18:20 (KJV) | | 1
[816] Luke 18:21 (KJV) | | 1
[817] Luke 18:22 (KJV) | | 1
[818] Luke 18:23 (KJV) | | 1
[819] Luke 18:24 (KJV) | | 1
[820] Luke 18:25 (KJV) | | 1
[821] Luke 18:26 (KJV) | | 1
[822] Luke 18:27 (KJV) | | 1
[823] Luke 18:28 (KJV) | | 1
[824] Luke 18:29 (KJV) | | 1
[825] Luke 18:30 (KJV) | | 1
[826] Luke 18:31 (KJV) | | 1
[827] Luke 18:32 (KJV) | | 1
[828] Luke 18:33 (KJV) | | 1
[829] Luke 18:34 (KJV) | | 1
[830] Luke 18:35 (KJV) | | 1
[831] Luke 18:36 (KJV) | | 1
[832] Luke 18:37 (KJV) | | 1
[833] Luke 18:38 (KJV) | | 1
[834] Luke 18:39 (KJV) | | 1
[835] Luke 18:40 (KJV) | | 1
[836] Luke 18:41 (KJV) | | 1
[837] Luke 18:42 (KJV) | | 1
[838] Luke 18:43 (KJV) | | 1
[839] Luke 19:1 (KJV) | | 1
[840] Luke 19:2 (KJV) | | 1
[841] Luke 19:3 (KJV) | | 1
[842] Luke 19:4 (KJV) | | 1
[843] Luke 19:5 (KJV) | | 1
[844] Luke 19:6 (KJV) | | 1
[845] Luke 19:7 (KJV) | | 1
[846] Luke 19:8 (KJV) | | 1
[847] Luke 19:9 (KJV) | | 1
[848] Luke 19:10 (KJV) | | 1
[849] Luke 19:11 (KJV) | | 1
[850] Luke 19:12 (KJV) | | 1
[851] Luke 19:13 (KJV) | | 1
[852] Luke 19:14 (KJV) | | 1
[853] Luke 19:15 (KJV) | | 1
[854] Luke 19:16 (KJV) | | 1
[855] Luke 19:17 (KJV) | | 1
[856] Luke 19:18 (KJV) | | 1
[857] Luke 19:19 (KJV) | | 1
[858] Luke 19:20 (KJV) | | 1
[859] Luke 19:21 (KJV) | | 1
[860] Luke 19:22 (KJV) | | 1
[861] Luke 19:23 (KJV) | | 1
[862] Luke 19:24 (KJV) | | 1
[863] Luke 19:25 (KJV) | | 1
[864] Luke 19:26 (KJV) | | 1
[865] Luke 19:27 (KJV) | | 1
[866] Luke 19:28 (KJV) | | 1
[867] Luke 19:29 (KJV) | | 1
[868] Luke 19:30 (KJV) | | 1
[869] Luke 19:31 (KJV) | | 1
[870] Luke 19:32 (KJV) | | 1
[871] Luke 19:33 (KJV) | | 1
[872] Luke 19:34 (KJV) | | 1
[873] Luke 19:35 (KJV) | | 1
[874] Luke 19:36 (KJV) | | 1
[875] Luke 19:37 (KJV) | | 1
[876] Luke 19:38 (KJV) | | 1
[877] Luke 19:39 (KJV) | | 1
[878] Luke 19:40 (KJV) | | 1
[879] Luke 19:41 (KJV) | | 1
[880] Luke 19:42 (KJV) | | 1
[881] Luke 19:43 (KJV) | | 1
[882] Luke 19:44 (KJV) | | 1
[883] Luke 19:45 (KJV) | | 1
[884] Luke 19:46 (KJV) | | 1
[885] Luke 19:47 (KJV) | | 1
[886] Luke 19:48 (KJV) | | 1
[887] Luke 20:1 (KJV) | | 1
[888] Luke 20:2 (KJV) | | 1
[889] Luke 20:3 (KJV) | | 1
[890] Luke 20:4 (KJV) | | 1
[891] Luke 20:5 (KJV) | | 1
[892] Luke 20:6 (KJV) | | 1
[893] Luke 20:7 (KJV) | | 1
[894] Luke 20:8 (KJV) | | 1
[895] Luke 20:9 (KJV) | | 1
[896] Luke 20:10 (KJV) | | 1
[897] Luke 20:11 (KJV) | | 1
[898] Luke 20:12 (KJV) | | 1
[899] Luke 20:13 (KJV) | | 1
[900] Luke 20:14 (KJV) | | 1
[901] Luke 20:15 (KJV) | | 1
[902] Luke 20:16 (KJV) | | 1
[903] Luke 20:17 (KJV) | | 1
[904] Luke 20:18 (KJV) | | 1
[905] Luke 20:19 (KJV) | | 1
[906] Luke 20:20 (KJV) | | 1
[907] Luke 20:21 (KJV) | | 1
[908] Luke 20:22 (KJV) | | 1
[909] Luke 20:23 (KJV) | | 1
[910] Luke 20:24 (KJV) | | 1
[911] Luke 20:25 (KJV) | | 1
[912] Luke 20:26 (KJV) | | 1
[913] Luke 20:27 (KJV) | | 1
[914] Luke 20:28 (KJV) | | 1
[915] Luke 20:29 (KJV) | | 1
[916] Luke 20:30 (KJV) | | 1
[917] Luke 20:31 (KJV) | | 1
[918] Luke 20:32 (KJV) | | 1
[919] Luke 20:33 (KJV) | | 1
[920] Luke 20:34 (KJV) | | 1
[921] Luke 20:35 (KJV) | | 1
[922] Luke 20:36 (KJV) | | 1
[923] Luke 20:37 (KJV) | | 1
[924] Luke 20:38 (KJV) | | 1
[925] Luke 20:39 (KJV) | | 1
[926] Luke 20:40 (KJV) | | 1
[927] Luke 20:41 (KJV) | | 1
[928] Luke 20:42 (KJV) | | 1
[929] Luke 20:43 (KJV) | | 1
[930] Luke 20:44 (KJV) | | 1
[931] Luke 20:45 (KJV) | | 1
[932] Luke 20:46 (KJV) | | 1
[933] Luke 20:47 (KJV) | | 1
[934] Luke 21:1 (KJV) | | 1
[935] Luke 21:2 (KJV) | | 1
[936] Luke 21:3 (KJV) | | 1
[937] Luke 21:4 (KJV) | | 1
[938] Luke 21:5 (KJV) | | 1
[939] Luke 21:6 (KJV) | | 1
[940] Luke 21:7 (KJV) | | 1
[941] Luke 21:8 (KJV) | | 1
[942] Luke 21:9 (KJV) | | 1
[943] Luke 21:10 (KJV) | | 1
[944] Luke 21:11 (KJV) | | 1
[945] Luke 21:12 (KJV) | | 1
[946] Luke 21:13 (KJV) | | 1
[947] Luke 21:14 (KJV) | | 1
[948] Luke 21:15 (KJV) | | 1
[949] Luke 21:16 (KJV) | | 1
[950] Luke 21:17 (KJV) | | 1
[951] Luke 21:18 (KJV) | | 1
[952] Luke 21:19 (KJV) | | 1
[953] Luke 21:20 (KJV) | | 1
[954] Luke 21:21 (KJV) | | 1
[955] Luke 21:22 (KJV) | | 1
[956] Luke 21:23 (KJV) | | 1
[957] Luke 21:24 (KJV) | | 1
[958] Luke 21:25 (KJV) | | 1
[959] Luke 21:26 (KJV) | | 1
[960] Luke 21:27 (KJV) | | 1
[961] Luke 21:28 (KJV) | | 1
[962] Luke 21:29 (KJV) | | 1
[963] Luke 21:30 (KJV) | | 1
[964] Luke 21:31 (KJV) | | 1
[965] Luke 21:32 (KJV) | | 1
[966] Luke 21:33 (KJV) | | 1
[967] Luke 21:34 (KJV) | | 1
[968] Luke 21:35 (KJV) | | 1
[969] Luke 21:36 (KJV) | | 1
[970] Luke 21:37 (KJV) | | 1
[971] Luke 21:38 (KJV) | | 1
[972] Luke 22:1 (KJV) | | 1
[973] Luke 22:2 (KJV) | | 1
[974] Luke 22:3 (KJV) | | 1
[975] Luke 22:4 (KJV) | | 1
[976] Luke 22:5 (KJV) | | 1
[977] Luke 22:6 (KJV) | | 1
[978] Luke 22:7 (KJV) | | 1
[979] Luke 22:8 (KJV) | | 1
[980] Luke 22:9 (KJV) | | 1
[981] Luke 22:10 (KJV) | | 1
[982] Luke 22:11 (KJV) | | 1
[983] Luke 22:12 (KJV) | | 1
[984] Luke 22:13 (KJV) | | 1
[985] Luke 22:14 (KJV) | | 1
[986] Luke 22:15 (KJV) | | 1
[987] Luke 22:16 (KJV) | | 1
[988] Luke 22:17 (KJV) | | 1
[989] Luke 22:18 (KJV) | | 1
[990] Luke 22:19 (KJV) | | 1
[991] Luke 22:20 (KJV) | | 1
[992] Luke 22:21 (KJV) | | 1
[993] Luke 22:22 (KJV) | | 1
[994] Luke 22:23 (KJV) | | 1
[995] Luke 22:24 (KJV) | | 1
[996] Luke 22:25 (KJV) | | 1
[997] Luke 22:26 (KJV) | | 1
[998] Luke 22:27 (KJV) | | 1
[999] Luke 22:28 (KJV) | | 1
[1000] Luke 22:29 (KJV) | | 1
[1001] Luke 22:30 (KJV) | | 1
[1002] Luke 22:31 (KJV) | | 1
[1003] Luke 22:32 (KJV) | | 1
[1004] Luke 22:33 (KJV) | | 1
[1005] Luke 22:34 (KJV) | | 1
[1006] Luke 22:35 (KJV) | | 1
[1007] Luke 22:36 (KJV) | | 1
[1008] Luke 22:37 (KJV) | | 1
[1009] Luke 22:38 (KJV) | | 1
[1010] Luke 22:39 (KJV) | | 1
[1011] Luke 22:40 (KJV) | | 1
[1012] Luke 22:41 (KJV) | | 1
[1013] Luke 22:42 (KJV) | | 1
[1014] Luke 22:43 (KJV) | | 1
[1015] Luke 22:44 (KJV) | | 1
[1016] Luke 22:45 (KJV) | | 1
[1017] Luke 22:46 (KJV) | | 1
[1018] Luke 22:47 (KJV) | | 1
[1019] Luke 22:48 (KJV) | | 1
[1020] Luke 22:49 (KJV) | | 1
[1021] Luke 22:50 (KJV) | | 1
[1022] Luke 22:51 (KJV) | | 1
[1023] Luke 22:52 (KJV) | | 1
[1024] Luke 22:53 (KJV) | | 1
[1025] Luke 22:54 (KJV) | | 1
[1026] Luke 22:55 (KJV) | | 1
[1027] Luke 22:56 (KJV) | | 1
[1028] Luke 22:57 (KJV) | | 1
[1029] Luke 22:58 (KJV) | | 1
[1030] Luke 22:59 (KJV) | | 1
[1031] Luke 22:60 (KJV) | | 1
[1032] Luke 22:61 (KJV) | | 1
[1033] Luke 22:62 (KJV) | | 1
[1034] Luke 22:63 (KJV) | | 1
[1035] Luke 22:64 (KJV) | | 1
[1036] Luke 22:65 (KJV) | | 1
[1037] Luke 22:66 (KJV) | | 1
[1038] Luke 22:67 (KJV) | | 1
[1039] Luke 22:68 (KJV) | | 1
[1040] Luke 22:69 (KJV) | | 1
[1041] Luke 22:70 (KJV) | | 1
[1042] Luke 22:71 (KJV) | | 1
[1043] Luke 23:1 (KJV) | | 1
[1044] Luke 23:2 (KJV) | | 1
[1045] Luke 23:3 (KJV) | | 1
[1046] Luke 23:4 (KJV) | | 1
[1047] Luke 23:5 (KJV) | | 1
[1048] Luke 23:6 (KJV) | | 1
[1049] Luke 23:7 (KJV) | | 1
[1050] Luke 23:8 (KJV) | | 1
[1051] Luke 23:9 (KJV) | | 1
[1052] Luke 23:10 (KJV) | | 1
[1053] Luke 23:11 (KJV) | | 1
[1054] Luke 23:12 (KJV) | | 1
[1055] Luke 23:13 (KJV) | | 1
[1056] Luke 23:14 (KJV) | | 1
[1057] Luke 23:15 (KJV) | | 1
[1058] Luke 23:16 (KJV) | | 1
[1059] Luke 23:17 (KJV) | | 1
[1060] Luke 23:18 (KJV) | | 1
[1061] Luke 23:19 (KJV) | | 1
[1062] Luke 23:20 (KJV) | | 1
[1063] Luke 23:21 (KJV) | | 1
[1064] Luke 23:22 (KJV) | | 1
[1065] Luke 23:23 (KJV) | | 1
[1066] Luke 23:24 (KJV) | | 1
[1067] Luke 23:25 (KJV) | | 1
[1068] Luke 23:26 (KJV) | | 1
[1069] Luke 23:27 (KJV) | | 1
[1070] Luke 23:28 (KJV) | | 1
[1071] Luke 23:29 (KJV) | | 1
[1072] Luke 23:30 (KJV) | | 1
[1073] Luke 23:31 (KJV) | | 1
[1074] Luke 23:32 (KJV) | | 1
[1075] Luke 23:33 (KJV) | | 1
[1076] Luke 23:34 (KJV) | | 1
[1077] Luke 23:35 (KJV) | | 1
[1078] Luke 23:36 (KJV) | | 1
[1079] Luke 23:37 (KJV) | | 1
[1080] Luke 23:38 (KJV) | | 1
[1081] Luke 23:39 (KJV) | | 1
[1082] Luke 23:40 (KJV) | | 1
[1083] Luke 23:41 (KJV) | | 1
[1084] Luke 23:42 (KJV) | | 1
[1085] Luke 23:43 (KJV) | | 1
[1086] Luke 23:44 (KJV) | | 1
[1087] Luke 23:45 (KJV) | | 1
[1088] Luke 23:46 (KJV) | | 1
[1089] Luke 23:47 (KJV) | | 1
[1090] Luke 23:48 (KJV) | | 1
[1091] Luke 23:49 (KJV) | | 1
[1092] Luke 23:50 (KJV) | | 1
[1093] Luke 23:51 (KJV) | | 1
[1094] Luke 23:52 (KJV) | | 1
[1095] Luke 23:53 (KJV) | | 1
[1096] Luke 23:54 (KJV) | | 1
[1097] Luke 23:55 (KJV) | | 1
[1098] Luke 23:56 (KJV) | | 1
[1099] Luke 24:1 (KJV) | | 1
[1100] Luke 24:2 (KJV) | | 1
[1101] Luke 24:3 (KJV) | | 1
[1102] Luke 24:4 (KJV) | | 1
[1103] Luke 24:5 (KJV) | | 1
[1104] Luke 24:6 (KJV) | | 1
[1105] Luke 24:7 (KJV) | | 1
[1106] Luke 24:8 (KJV) | | 1
[1107] Luke 24:9 (KJV) | | 1
[1108] Luke 24:10 (KJV) | | 1
[1109] Luke 24:11 (KJV) | | 1
[1110] Luke 24:12 (KJV) | | 1
[1111] Luke 24:13 (KJV) | | 1
[1112] Luke 24:14 (KJV) | | 1
[1113] Luke 24:15 (KJV) | | 1
[1114] Luke 24:16 (KJV) | | 1
[1115] Luke 24:17 (KJV) | | 1
[1116] Luke 24:18 (KJV) | | 1
[1117] Luke 24:19 (KJV) | | 1
[1118] Luke 24:20 (KJV) | | 1
[1119] Luke 24:21 (KJV) | | 1
[1120] Luke 24:22 (KJV) | | 1
[1121] Luke 24:23 (KJV) | | 1
[1122] Luke 24:24 (KJV) | | 1
[1123] Luke 24:25 (KJV) | | 1
[1124] Luke 24:26 (KJV) | | 1
[1125] Luke 24:27 (KJV) | | 1
[1126] Luke 24:28 (KJV) | | 1
[1127] Luke 24:29 (KJV) | | 1
[1128] Luke 24:30 (KJV) | | 1
[1129] Luke 24:31 (KJV) | | 1
[1130] Luke 24:32 (KJV) | | 1
[1131] Luke 24:33 (KJV) | | 1
[1132] Luke 24:34 (KJV) | | 1
[1133] Luke 24:35 (KJV) | | 1
[1134] Luke 24:36 (KJV) | | 1
[1135] Luke 24:37 (KJV) | | 1
[1136] Luke 24:38 (KJV) | | 1
[1137] Luke 24:39 (KJV) | | 1
[1138] Luke 24:40 (KJV) | | 1
[1139] Luke 24:41 (KJV) | | 1
[1140] Luke 24:42 (KJV) | | 1
[1141] Luke 24:43 (KJV) | | 1
[1142] Luke 24:44 (KJV) | | 1
[1143] Luke 24:45 (KJV) | | 1
[1144] Luke 24:46 (KJV) | | 1
[1145] Luke 24:47 (KJV) | | 1
[1146] Luke 24:48 (KJV) | | 1
[1147] Luke 24:49 (KJV) | | 1
[1148] Luke 24:50 (KJV) | | 1
[1149] Luke 24:51 (KJV) | | 1
[1150] Luke 24:52 (KJV) | | 1
[1151] Luke 24:53 (KJV) | | 1