title: The Gospel According to Mark (KJV)
url: https://www.gutenberg.org/cache/epub/8041/pg8041.txt
tier: 1
---
§ Mark 1

The beginning of the gospel of Jesus Christ, the Son of God; [1]

As it is written in the prophets, Behold, I send my messenger before thy face, which shall prepare thy way before thee. [2]

The voice of one crying in the wilderness, Prepare ye the way of the Lord, make his paths straight. [3]

John did baptize in the wilderness, and preach the baptism of repentance for the remission of sins. [4]

And there went out unto him all the land of Judaea, and they of Jerusalem, and were all baptized of him in the river of Jordan, confessing their sins. [5]

And John was clothed with camel's hair, and with a girdle of a skin about his loins; and he did eat locusts and wild honey; [6]

And preached, saying, There cometh one mightier than I after me, the latchet of whose shoes I am not worthy to stoop down and unloose. [7]

I indeed have baptized you with water: but he shall baptize you with the Holy Ghost. [8]

And it came to pass in those days, that Jesus came from Nazareth of Galilee, and was baptized of John in Jordan. [9]

And straightway coming up out of the water, he saw the heavens opened, and the Spirit like a dove descending upon him: [10]

And there came a voice from heaven, saying, Thou art my beloved Son, in whom I am well pleased. [11]

And immediately the spirit driveth him into the wilderness. [12]

And he was there in the wilderness forty days, tempted of Satan; and was with the wild beasts; and the angels ministered unto him. [13]

Now after that John was put in prison, Jesus came into Galilee, preaching the gospel of the kingdom of God, [14]

And saying, The time is fulfilled, and the kingdom of God is at hand: repent ye, and believe the gospel. [15]

Now as he walked by the sea of Galilee, he saw Simon and Andrew his brother casting a net into the sea: for they were fishers. [16]

And Jesus said unto them, Come ye after me, and I will make you to become fishers of men. [17]

And straightway they forsook their nets, and followed him. [18]

And when he had gone a little farther thence, he saw James the son of Zebedee, and John his brother, who also were in the ship mending their nets. [19]

And straightway he called them: and they left their father Zebedee in the ship with the hired servants, and went after him. [20]

And they went into Capernaum; and straightway on the sabbath day he entered into the synagogue, and taught. [21]

And they were astonished at his doctrine: for he taught them as one that had authority, and not as the scribes. [22]

And there was in their synagogue a man with an unclean spirit; and he cried out, [23]

Saying, Let us alone; what have we to do with thee, thou Jesus of Nazareth? art thou come to destroy us? I know thee who thou art, the Holy One of God. [24]

And Jesus rebuked him, saying, Hold thy peace, and come out of him. [25]

And when the unclean spirit had torn him, and cried with a loud voice, he came out of him. [26]

And they were all amazed, insomuch that they questioned among themselves, saying, What thing is this? what new doctrine is this? for with authority commandeth he even the unclean spirits, and they do obey him. [27]

And immediately his fame spread abroad throughout all the region round about Galilee. [28]

And forthwith, when they were come out of the synagogue, they entered into the house of Simon and Andrew, with James and John. [29]

But Simon's wife's mother lay sick of a fever, and anon they tell him of her. [30]

And he came and took her by the hand, and lifted her up; and immediately the fever left her, and she ministered unto them. [31]

And at even, when the sun did set, they brought unto him all that were diseased, and them that were possessed with devils. [32]

And all the city was gathered together at the door. [33]

And he healed many that were sick of divers diseases, and cast out many devils; and suffered not the devils to speak, because they knew him. [34]

And in the morning, rising up a great while before day, he went out, and departed into a solitary place, and there prayed. [35]

And Simon and they that were with him followed after him. [36]

And when they had found him, they said unto him, All men seek for thee. [37]

And he said unto them, Let us go into the next towns, that I may preach there also: for therefore came I forth. [38]

And he preached in their synagogues throughout all Galilee, and cast out devils. [39]

And there came a leper to him, beseeching him, and kneeling down to him, and saying unto him, If thou wilt, thou canst make me clean. [40]

And Jesus, moved with compassion, put forth his hand, and touched him, and saith unto him, I will; be thou clean. [41]

And as soon as he had spoken, immediately the leprosy departed from him, and he was cleansed. [42]

And he straitly charged him, and forthwith sent him away; [43]

And saith unto him, See thou say nothing to any man: but go thy way, shew thyself to the priest, and offer for thy cleansing those things which Moses commanded, for a testimony unto them. [44]

But he went out, and began to publish it much, and to blaze abroad the matter, insomuch that Jesus could no more openly enter into the city, but was without in desert places: and they came to him from every quarter. [45]

§ Mark 2

And again he entered into Capernaum after some days; and it was noised that he was in the house. [46]

And straightway many were gathered together, insomuch that there was no room to receive them, no, not so much as about the door: and he preached the word unto them. [47]

And they come unto him, bringing one sick of the palsy, which was borne of four. [48]

And when they could not come nigh unto him for the press, they uncovered the roof where he was: and when they had broken it up, they let down the bed wherein the sick of the palsy lay. [49]

When Jesus saw their faith, he said unto the sick of the palsy, Son, thy sins be forgiven thee. [50]

But there was certain of the scribes sitting there, and reasoning in their hearts, [51]

Why doth this man thus speak blasphemies? who can forgive sins but God only? [52]

And immediately when Jesus perceived in his spirit that they so reasoned within themselves, he said unto them, Why reason ye these things in your hearts? [53]

Whether is it easier to say to the sick of the palsy, Thy sins be forgiven thee; or to say, Arise, and take up thy bed, and walk? [54]

But that ye may know that the Son of man hath power on earth to forgive sins, (he saith to the sick of the palsy,) [55]

I say unto thee, Arise, and take up thy bed, and go thy way into thine house. [56]

And immediately he arose, took up the bed, and went forth before them all; insomuch that they were all amazed, and glorified God, saying, We never saw it on this fashion. [57]

And he went forth again by the sea side; and all the multitude resorted unto him, and he taught them. [58]

And as he passed by, he saw Levi the son of Alphaeus sitting at the receipt of custom, and said unto him, Follow me. And he arose and followed him. [59]

And it came to pass, that, as Jesus sat at meat in his house, many publicans and sinners sat also together with Jesus and his disciples: for there were many, and they followed him. [60]

And when the scribes and Pharisees saw him eat with publicans and sinners, they said unto his disciples, How is it that he eateth and drinketh with publicans and sinners? [61]

When Jesus heard it, he saith unto them, They that are whole have no need of the physician, but they that are sick: I came not to call the righteous, but sinners to repentance. [62]

And the disciples of John and of the Pharisees used to fast: and they come and say unto him, Why do the disciples of John and of the Pharisees fast, but thy disciples fast not? [63]

And Jesus said unto them, Can the children of the bridechamber fast, while the bridegroom is with them? as long as they have the bridegroom with them, they cannot fast. [64]

But the days will come, when the bridegroom shall be taken away from them, and then shall they fast in those days. [65]

No man also seweth a piece of new cloth on an old garment: else the new piece that filled it up taketh away from the old, and the rent is made worse. [66]

And no man putteth new wine into old bottles: else the new wine doth burst the bottles, and the wine is spilled, and the bottles will be marred: but new wine must be put into new bottles. [67]

And it came to pass, that he went through the corn fields on the sabbath day; and his disciples began, as they went, to pluck the ears of corn. [68]

And the Pharisees said unto him, Behold, why do they on the sabbath day that which is not lawful? [69]

And he said unto them, Have ye never read what David did, when he had need, and was an hungred, he, and they that were with him? [70]

How he went into the house of God in the days of Abiathar the high priest, and did eat the shewbread, which is not lawful to eat but for the priests, and gave also to them which were with him? [71]

And he said unto them, The sabbath was made for man, and not man for the sabbath: [72]

Therefore the Son of man is Lord also of the sabbath. [73]

§ Mark 3

And he entered again into the synagogue; and there was a man there which had a withered hand. [74]

And they watched him, whether he would heal him on the sabbath day; that they might accuse him. [75]

And he saith unto the man which had the withered hand, Stand forth. [76]

And he saith unto them, Is it lawful to do good on the sabbath days, or to do evil? to save life, or to kill? But they held their peace. [77]

And when he had looked round about on them with anger, being grieved for the hardness of their hearts, he saith unto the man, Stretch forth thine hand. And he stretched it out: and his hand was restored whole as the other. [78]

And the Pharisees went forth, and straightway took counsel with the Herodians against him, how they might destroy him. [79]

But Jesus withdrew himself with his disciples to the sea: and a great multitude from Galilee followed him, and from Judaea, [80]

And from Jerusalem, and from Idumaea, and from beyond Jordan; and they about Tyre and Sidon, a great multitude, when they had heard what great things he did, came unto him. [81]

And he spake to his disciples, that a small ship should wait on him because of the multitude, lest they should throng him. [82]

For he had healed many; insomuch that they pressed upon him for to touch him, as many as had plagues. [83]

And unclean spirits, when they saw him, fell down before him, and cried, saying, Thou art the Son of God. [84]

And he straitly charged them that they should not make him known. [85]

And he goeth up into a mountain, and calleth unto him whom he would: and they came unto him. [86]

And he ordained twelve, that they should be with him, and that he might send them forth to preach, [87]

And to have power to heal sicknesses, and to cast out devils: [88]

And Simon he surnamed Peter; [89]

And James the son of Zebedee, and John the brother of James; and he surnamed them Boanerges, which is, The sons of thunder: [90]

And Andrew, and Philip, and Bartholomew, and Matthew, and Thomas, and James the son of Alphaeus, and Thaddaeus, and Simon the Canaanite, [91]

And Judas Iscariot, which also betrayed him: and they went into an house. [92]

And the multitude cometh together again, so that they could not so much as eat bread. [93]

And when his friends heard of it, they went out to lay hold on him: for they said, He is beside himself. [94]

And the scribes which came down from Jerusalem said, He hath Beelzebub, and by the prince of the devils casteth he out devils. [95]

And he called them unto him, and said unto them in parables, How can Satan cast out Satan? [96]

And if a kingdom be divided against itself, that kingdom cannot stand. [97]

And if a house be divided against itself, that house cannot stand. [98]

And if Satan rise up against himself, and be divided, he cannot stand, but hath an end. [99]

No man can enter into a strong man's house, and spoil his goods, except he will first bind the strong man; and then he will spoil his house. [100]

Verily I say unto you, All sins shall be forgiven unto the sons of men, and blasphemies wherewith soever they shall blaspheme: [101]

But he that shall blaspheme against the Holy Ghost hath never forgiveness, but is in danger of eternal damnation. [102]

Because they said, He hath an unclean spirit. [103]

There came then his brethren and his mother, and, standing without, sent unto him, calling him. [104]

And the multitude sat about him, and they said unto him, Behold, thy mother and thy brethren without seek for thee. [105]

And he answered them, saying, Who is my mother, or my brethren? [106]

And he looked round about on them which sat about him, and said, Behold my mother and my brethren! [107]

For whosoever shall do the will of God, the same is my brother, and my sister, and mother. [108]

§ Mark 4

And he began again to teach by the sea side: and there was gathered unto him a great multitude, so that he entered into a ship, and sat in the sea; and the whole multitude was by the sea on the land. [109]

And he taught them many things by parables, and said unto them in his doctrine, [110]

Hearken; Behold, there went out a sower to sow: [111]

And it came to pass, as he sowed, some fell by the way side, and the fowls of the air came and devoured it up. [112]

And some fell on stony ground, where it had not much earth; and immediately it sprang up, because it had no depth of earth: [113]

But when the sun was up, it was scorched; and because it had no root, it withered away. [114]

And some fell among thorns, and the thorns grew up, and choked it, and it yielded no fruit. [115]

And other fell on good ground, and did yield fruit that sprang up and increased; and brought forth, some thirty, and some sixty, and some an hundred. [116]

And he said unto them, He that hath ears to hear, let him hear. [117]

And when he was alone, they that were about him with the twelve asked of him the parable. [118]

And he said unto them, Unto you it is given to know the mystery of the kingdom of God: but unto them that are without, all these things are done in parables: [119]

That seeing they may see, and not perceive; and hearing they may hear, and not understand; lest at any time they should be converted, and their sins should be forgiven them. [120]

And he said unto them, Know ye not this parable? and how then will ye know all parables? [121]

The sower soweth the word. [122]

And these are they by the way side, where the word is sown; but when they have heard, Satan cometh immediately, and taketh away the word that was sown in their hearts. [123]

And these are they likewise which are sown on stony ground; who, when they have heard the word, immediately receive it with gladness; [124]

And have no root in themselves, and so endure but for a time: afterward, when affliction or persecution ariseth for the word's sake, immediately they are offended. [125]

And these are they which are sown among thorns; such as hear the word, [126]

And the cares of this world, and the deceitfulness of riches, and the lusts of other things entering in, choke the word, and it becometh unfruitful. [127]

And these are they which are sown on good ground; such as hear the word, and receive it, and bring forth fruit, some thirtyfold, some sixty, and some an hundred. [128]

And he said unto them, Is a candle brought to be put under a bushel, or under a bed? and not to be set on a candlestick? [129]

For there is nothing hid, which shall not be manifested; neither was any thing kept secret, but that it should come abroad. [130]

If any man have ears to hear, let him hear. [131]

And he said unto them, Take heed what ye hear: with what measure ye mete, it shall be measured to you: and unto you that hear shall more be given. [132]

For he that hath, to him shall be given: and he that hath not, from him shall be taken even that which he hath. [133]

And he said, So is the kingdom of God, as if a man should cast seed into the ground; [134]

And should sleep, and rise night and day, and the seed should spring and grow up, he knoweth not how. [135]

For the earth bringeth forth fruit of herself; first the blade, then the ear, after that the full corn in the ear. [136]

But when the fruit is brought forth, immediately he putteth in the sickle, because the harvest is come. [137]

And he said, Whereunto shall we liken the kingdom of God? or with what comparison shall we compare it? [138]

It is like a grain of mustard seed, which, when it is sown in the earth, is less than all the seeds that be in the earth: [139]

But when it is sown, it groweth up, and becometh greater than all herbs, and shooteth out great branches; so that the fowls of the air may lodge under the shadow of it. [140]

And with many such parables spake he the word unto them, as they were able to hear it. [141]

But without a parable spake he not unto them: and when they were alone, he expounded all things to his disciples. [142]

And the same day, when the even was come, he saith unto them, Let us pass over unto the other side. [143]

And when they had sent away the multitude, they took him even as he was in the ship. And there were also with him other little ships. [144]

And there arose a great storm of wind, and the waves beat into the ship, so that it was now full. [145]

And he was in the hinder part of the ship, asleep on a pillow: and they awake him, and say unto him, Master, carest thou not that we perish? [146]

And he arose, and rebuked the wind, and said unto the sea, Peace, be still. And the wind ceased, and there was a great calm. [147]

And he said unto them, Why are ye so fearful? how is it that ye have no faith? [148]

And they feared exceedingly, and said one to another, What manner of man is this, that even the wind and the sea obey him? [149]

§ Mark 5

And they came over unto the other side of the sea, into the country of the Gadarenes. [150]

And when he was come out of the ship, immediately there met him out of the tombs a man with an unclean spirit, [151]

Who had his dwelling among the tombs; and no man could bind him, no, not with chains: [152]

Because that he had been often bound with fetters and chains, and the chains had been plucked asunder by him, and the fetters broken in pieces: neither could any man tame him. [153]

And always, night and day, he was in the mountains, and in the tombs, crying, and cutting himself with stones. [154]

But when he saw Jesus afar off, he ran and worshipped him, [155]

And cried with a loud voice, and said, What have I to do with thee, Jesus, thou Son of the most high God? I adjure thee by God, that thou torment me not. [156]

For he said unto him, Come out of the man, thou unclean spirit. [157]

And he asked him, What is thy name? And he answered, saying, My name is Legion: for we are many. [158]

And he besought him much that he would not send them away out of the country. [159]

Now there was there nigh unto the mountains a great herd of swine feeding. [160]

And all the devils besought him, saying, Send us into the swine, that we may enter into them. [161]

And forthwith Jesus gave them leave. And the unclean spirits went out, and entered into the swine: and the herd ran violently down a steep place into the sea, (they were about two thousand;) and were choked in the sea. [162]

And they that fed the swine fled, and told it in the city, and in the country. And they went out to see what it was that was done. [163]

And they come to Jesus, and see him that was possessed with the devil, and had the legion, sitting, and clothed, and in his right mind: and they were afraid. [164]

And they that saw it told them how it befell to him that was possessed with the devil, and also concerning the swine. [165]

And they began to pray him to depart out of their coasts. [166]

And when he was come into the ship, he that had been possessed with the devil prayed him that he might be with him. [167]

Howbeit Jesus suffered him not, but saith unto him, Go home to thy friends, and tell them how great things the Lord hath done for thee, and hath had compassion on thee. [168]

And he departed, and began to publish in Decapolis how great things Jesus had done for him: and all men did marvel. [169]

And when Jesus was passed over again by ship unto the other side, much people gathered unto him: and he was nigh unto the sea. [170]

And, behold, there cometh one of the rulers of the synagogue, Jairus by name; and when he saw him, he fell at his feet, [171]

And besought him greatly, saying, My little daughter lieth at the point of death: I pray thee, come and lay thy hands on her, that she may be healed; and she shall live. [172]

And Jesus went with him; and much people followed him, and thronged him. [173]

And a certain woman, which had an issue of blood twelve years, [174]

And had suffered many things of many physicians, and had spent all that she had, and was nothing bettered, but rather grew worse, [175]

When she had heard of Jesus, came in the press behind, and touched his garment. [176]

For she said, If I may touch but his clothes, I shall be whole. [177]

And straightway the fountain of her blood was dried up; and she felt in her body that she was healed of that plague. [178]

And Jesus, immediately knowing in himself that virtue had gone out of him, turned him about in the press, and said, Who touched my clothes? [179]

And his disciples said unto him, Thou seest the multitude thronging thee, and sayest thou, Who touched me? [180]

And he looked round about to see her that had done this thing. [181]

But the woman fearing and trembling, knowing what was done in her, came and fell down before him, and told him all the truth. [182]

And he said unto her, Daughter, thy faith hath made thee whole; go in peace, and be whole of thy plague. [183]

While he yet spake, there came from the ruler of the synagogue's house certain which said, Thy daughter is dead: why troublest thou the Master any further? [184]

As soon as Jesus heard the word that was spoken, he saith unto the ruler of the synagogue, Be not afraid, only believe. [185]

And he suffered no man to follow him, save Peter, and James, and John the brother of James. [186]

And he cometh to the house of the ruler of the synagogue, and seeth the tumult, and them that wept and wailed greatly. [187]

And when he was come in, he saith unto them, Why make ye this ado, and weep? the damsel is not dead, but sleepeth. [188]

And they laughed him to scorn. But when he had put them all out, he taketh the father and the mother of the damsel, and them that were with him, and entereth in where the damsel was lying. [189]

And he took the damsel by the hand, and said unto her, Talitha cumi; which is, being interpreted, Damsel, I say unto thee, arise. [190]

And straightway the damsel arose, and walked; for she was of the age of twelve years. And they were astonished with a great astonishment. [191]

And he charged them straitly that no man should know it; and commanded that something should be given her to eat. [192]

§ Mark 6

And he went out from thence, and came into his own country; and his disciples follow him. [193]

And when the sabbath day was come, he began to teach in the synagogue: and many hearing him were astonished, saying, From whence hath this man these things? and what wisdom is this which is given unto him, that even such mighty works are wrought by his hands? [194]

Is not this the carpenter, the son of Mary, the brother of James, and Joses, and of Juda, and Simon? and are not his sisters here with us? And they were offended at him. [195]

But Jesus, said unto them, A prophet is not without honour, but in his own country, and among his own kin, and in his own house. [196]

And he could there do no mighty work, save that he laid his hands upon a few sick folk, and healed them. [197]

And he marvelled because of their unbelief. And he went round about the villages, teaching. [198]

And he called unto him the twelve, and began to send them forth by two and two; and gave them power over unclean spirits; [199]

And commanded them that they should take nothing for their journey, save a staff only; no scrip, no bread, no money in their purse: [200]

But be shod with sandals; and not put on two coats. [201]

And he said unto them, In what place soever ye enter into an house, there abide till ye depart from that place. [202]

And whosoever shall not receive you, nor hear you, when ye depart thence, shake off the dust under your feet for a testimony against them. Verily I say unto you, It shall be more tolerable for Sodom and Gomorrha in the day of judgment, than for that city. [203]

And they went out, and preached that men should repent. [204]

And they cast out many devils, and anointed with oil many that were sick, and healed them. [205]

And king Herod heard of him; (for his name was spread abroad:) and he said, That John the Baptist was risen from the dead, and therefore mighty works do shew forth themselves in him. [206]

Others said, That it is Elias. And others said, That it is a prophet, or as one of the prophets. [207]

But when Herod heard thereof, he said, It is John, whom I beheaded: he is risen from the dead. [208]

For Herod himself had sent forth and laid hold upon John, and bound him in prison for Herodias' sake, his brother Philip's wife: for he had married her. [209]

For John had said unto Herod, It is not lawful for thee to have thy brother's wife. [210]

Therefore Herodias had a quarrel against him, and would have killed him; but she could not: [211]

For Herod feared John, knowing that he was a just man and an holy, and observed him; and when he heard him, he did many things, and heard him gladly. [212]

And when a convenient day was come, that Herod on his birthday made a supper to his lords, high captains, and chief estates of Galilee; [213]

And when the daughter of the said Herodias came in, and danced, and pleased Herod and them that sat with him, the king said unto the damsel, Ask of me whatsoever thou wilt, and I will give it thee. [214]

And he sware unto her, Whatsoever thou shalt ask of me, I will give it thee, unto the half of my kingdom. [215]

And she went forth, and said unto her mother, What shall I ask? And she said, The head of John the Baptist. [216]

And she came in straightway with haste unto the king, and asked, saying, I will that thou give me by and by in a charger the head of John the Baptist. [217]

And the king was exceeding sorry; yet for his oath's sake, and for their sakes which sat with him, he would not reject her. [218]

And immediately the king sent an executioner, and commanded his head to be brought: and he went and beheaded him in the prison, [219]

And brought his head in a charger, and gave it to the damsel: and the damsel gave it to her mother. [220]

And when his disciples heard of it, they came and took up his corpse, and laid it in a tomb. [221]

And the apostles gathered themselves together unto Jesus, and told him all things, both what they had done, and what they had taught. [222]

And he said unto them, Come ye yourselves apart into a desert place, and rest a while: for there were many coming and going, and they had no leisure so much as to eat. [223]

And they departed into a desert place by ship privately. [224]

And the people saw them departing, and many knew him, and ran afoot thither out of all cities, and outwent them, and came together unto him. [225]

And Jesus, when he came out, saw much people, and was moved with compassion toward them, because they were as sheep not having a shepherd: and he began to teach them many things. [226]

And when the day was now far spent, his disciples came unto him, and said, This is a desert place, and now the time is far passed: [227]

Send them away, that they may go into the country round about, and into the villages, and buy themselves bread: for they have nothing to eat. [228]

He answered and said unto them, Give ye them to eat. And they say unto him, Shall we go and buy two hundred pennyworth of bread, and give them to eat? [229]

He saith unto them, How many loaves have ye? go and see. And when they knew, they say, Five, and two fishes. [230]

And he commanded them to make all sit down by companies upon the green grass. [231]

And they sat down in ranks, by hundreds, and by fifties. [232]

And when he had taken the five loaves and the two fishes, he looked up to heaven, and blessed, and brake the loaves, and gave them to his disciples to set before them; and the two fishes divided he among them all. [233]

And they did all eat, and were filled. [234]

And they took up twelve baskets full of the fragments, and of the fishes. [235]

And they that did eat of the loaves were about five thousand men. [236]

And straightway he constrained his disciples to get into the ship, and to go to the other side before unto Bethsaida, while he sent away the people. [237]

And when he had sent them away, he departed into a mountain to pray. [238]

And when even was come, the ship was in the midst of the sea, and he alone on the land. [239]

And he saw them toiling in rowing; for the wind was contrary unto them: and about the fourth watch of the night he cometh unto them, walking upon the sea, and would have passed by them. [240]

But when they saw him walking upon the sea, they supposed it had been a spirit, and cried out: [241]

For they all saw him, and were troubled. And immediately he talked with them, and saith unto them, Be of good cheer: it is I; be not afraid. [242]

And he went up unto them into the ship; and the wind ceased: and they were sore amazed in themselves beyond measure, and wondered. [243]

For they considered not the miracle of the loaves: for their heart was hardened. [244]

And when they had passed over, they came into the land of Gennesaret, and drew to the shore. [245]

And when they were come out of the ship, straightway they knew him, [246]

And ran through that whole region round about, and began to carry about in beds those that were sick, where they heard he was. [247]

And whithersoever he entered, into villages, or cities, or country, they laid the sick in the streets, and besought him that they might touch if it were but the border of his garment: and as many as touched him were made whole. [248]

§ Mark 7

Then came together unto him the Pharisees, and certain of the scribes, which came from Jerusalem. [249]

And when they saw some of his disciples eat bread with defiled, that is to say, with unwashen, hands, they found fault. [250]

For the Pharisees, and all the Jews, except they wash their hands oft, eat not, holding the tradition of the elders. [251]

And when they come from the market, except they wash, they eat not. And many other things there be, which they have received to hold, as the washing of cups, and pots, brasen vessels, and of tables. [252]

Then the Pharisees and scribes asked him, Why walk not thy disciples according to the tradition of the elders, but eat bread with unwashen hands? [253]

He answered and said unto them, Well hath Esaias prophesied of you hypocrites, as it is written, This people honoureth me with their lips, but their heart is far from me. [254]

Howbeit in vain do they worship me, teaching for doctrines the commandments of men. [255]

For laying aside the commandment of God, ye hold the tradition of men, as the washing of pots and cups: and many other such like things ye do. [256]

And he said unto them, Full well ye reject the commandment of God, that ye may keep your own tradition. [257]

For Moses said, Honour thy father and thy mother; and, Whoso curseth father or mother, let him die the death: [258]

But ye say, If a man shall say to his father or mother, It is Corban, that is to say, a gift, by whatsoever thou mightest be profited by me; he shall be free. [259]

And ye suffer him no more to do ought for his father or his mother; [260]

Making the word of God of none effect through your tradition, which ye have delivered: and many such like things do ye. [261]

And when he had called all the people unto him, he said unto them, Hearken unto me every one of you, and understand: [262]

There is nothing from without a man, that entering into him can defile him: but the things which come out of him, those are they that defile the man. [263]

If any man have ears to hear, let him hear. [264]

And when he was entered into the house from the people, his disciples asked him concerning the parable. [265]

And he saith unto them, Are ye so without understanding also? Do ye not perceive, that whatsoever thing from without entereth into the man, it cannot defile him; [266]

Because it entereth not into his heart, but into the belly, and goeth out into the draught, purging all meats? [267]

And he said, That which cometh out of the man, that defileth the man. [268]

For from within, out of the heart of men, proceed evil thoughts, adulteries, fornications, murders, [269]

Thefts, covetousness, wickedness, deceit, lasciviousness, an evil eye, blasphemy, pride, foolishness: [270]

All these evil things come from within, and defile the man. [271]

And from thence he arose, and went into the borders of Tyre and Sidon, and entered into an house, and would have no man know it: but he could not be hid. [272]

For a certain woman, whose young daughter had an unclean spirit, heard of him, and came and fell at his feet: [273]

The woman was a Greek, a Syrophenician by nation; and she besought him that he would cast forth the devil out of her daughter. [274]

But Jesus said unto her, Let the children first be filled: for it is not meet to take the children's bread, and to cast it unto the dogs. [275]

And she answered and said unto him, Yes, Lord: yet the dogs under the table eat of the children's crumbs. [276]

And he said unto her, For this saying go thy way; the devil is gone out of thy daughter. [277]

And when she was come to her house, she found the devil gone out, and her daughter laid upon the bed. [278]

And again, departing from the coasts of Tyre and Sidon, he came unto the sea of Galilee, through the midst of the coasts of Decapolis. [279]

And they bring unto him one that was deaf, and had an impediment in his speech; and they beseech him to put his hand upon him. [280]

And he took him aside from the multitude, and put his fingers into his ears, and he spit, and touched his tongue; [281]

And looking up to heaven, he sighed, and saith unto him, Ephphatha, that is, Be opened. [282]

And straightway his ears were opened, and the string of his tongue was loosed, and he spake plain. [283]

And he charged them that they should tell no man: but the more he charged them, so much the more a great deal they published it; [284]

And were beyond measure astonished, saying, He hath done all things well: he maketh both the deaf to hear, and the dumb to speak. [285]

§ Mark 8

In those days the multitude being very great, and having nothing to eat, Jesus called his disciples unto him, and saith unto them, [286]

I have compassion on the multitude, because they have now been with me three days, and have nothing to eat: [287]

And if I send them away fasting to their own houses, they will faint by the way: for divers of them came from far. [288]

And his disciples answered him, From whence can a man satisfy these men with bread here in the wilderness? [289]

And he asked them, How many loaves have ye? And they said, Seven. [290]

And he commanded the people to sit down on the ground: and he took the seven loaves, and gave thanks, and brake, and gave to his disciples to set before them; and they did set them before the people. [291]

And they had a few small fishes: and he blessed, and commanded to set them also before them. [292]

So they did eat, and were filled: and they took up of the broken meat that was left seven baskets. [293]

And they that had eaten were about four thousand: and he sent them away. [294]

And straightway he entered into a ship with his disciples, and came into the parts of Dalmanutha. [295]

And the Pharisees came forth, and began to question with him, seeking of him a sign from heaven, tempting him. [296]

And he sighed deeply in his spirit, and saith, Why doth this generation seek after a sign? verily I say unto you, There shall no sign be given unto this generation. [297]

And he left them, and entering into the ship again departed to the other side. [298]

Now the disciples had forgotten to take bread, neither had they in the ship with them more than one loaf. [299]

And he charged them, saying, Take heed, beware of the leaven of the Pharisees, and of the leaven of Herod. [300]

And they reasoned among themselves, saying, It is because we have no bread. [301]

And when Jesus knew it, he saith unto them, Why reason ye, because ye have no bread? perceive ye not yet, neither understand? have ye your heart yet hardened? [302]

Having eyes, see ye not? and having ears, hear ye not? and do ye not remember? [303]

When I brake the five loaves among five thousand, how many baskets full of fragments took ye up? They say unto him, Twelve. [304]

And when the seven among four thousand, how many baskets full of fragments took ye up? And they said, Seven. [305]

And he said unto them, How is it that ye do not understand? [306]

And he cometh to Bethsaida; and they bring a blind man unto him, and besought him to touch him. [307]

And he took the blind man by the hand, and led him out of the town; and when he had spit on his eyes, and put his hands upon him, he asked him if he saw ought. [308]

And he looked up, and said, I see men as trees, walking. [309]

After that he put his hands again upon his eyes, and made him look up: and he was restored, and saw every man clearly. [310]

And he sent him away to his house, saying, Neither go into the town, nor tell it to any in the town. [311]

And Jesus went out, and his disciples, into the towns of Caesarea Philippi: and by the way he asked his disciples, saying unto them, Whom do men say that I am? [312]

And they answered, John the Baptist; but some say, Elias; and others, One of the prophets. [313]

And he saith unto them, But whom say ye that I am? And Peter answereth and saith unto him, Thou art the Christ. [314]

And he charged them that they should tell no man of him. [315]

And he began to teach them, that the Son of man must suffer many things, and be rejected of the elders, and of the chief priests, and scribes, and be killed, and after three days rise again. [316]

And he spake that saying openly. And Peter took him, and began to rebuke him. [317]

But when he had turned about and looked on his disciples, he rebuked Peter, saying, Get thee behind me, Satan: for thou savourest not the things that be of God, but the things that be of men. [318]

And when he had called the people unto him with his disciples also, he said unto them, Whosoever will come after me, let him deny himself, and take up his cross, and follow me. [319]

For whosoever will save his life shall lose it; but whosoever shall lose his life for my sake and the gospel's, the same shall save it. [320]

For what shall it profit a man, if he shall gain the whole world, and lose his own soul? [321]

Or what shall a man give in exchange for his soul? [322]

Whosoever therefore shall be ashamed of me and of my words in this adulterous and sinful generation; of him also shall the Son of man be ashamed, when he cometh in the glory of his Father with the holy angels. [323]

§ Mark 9

And he said unto them, Verily I say unto you, That there be some of them that stand here, which shall not taste of death, till they have seen the kingdom of God come with power. [324]

And after six days Jesus taketh with him Peter, and James, and John, and leadeth them up into an high mountain apart by themselves: and he was transfigured before them. [325]

And his raiment became shining, exceeding white as snow; so as no fuller on earth can white them. [326]

And there appeared unto them Elias with Moses: and they were talking with Jesus. [327]

And Peter answered and said to Jesus, Master, it is good for us to be here: and let us make three tabernacles; one for thee, and one for Moses, and one for Elias. [328]

For he wist not what to say; for they were sore afraid. [329]

And there was a cloud that overshadowed them: and a voice came out of the cloud, saying, This is my beloved Son: hear him. [330]

And suddenly, when they had looked round about, they saw no man any more, save Jesus only with themselves. [331]

And as they came down from the mountain, he charged them that they should tell no man what things they had seen, till the Son of man were risen from the dead. [332]

And they kept that saying with themselves, questioning one with another what the rising from the dead should mean. [333]

And they asked him, saying, Why say the scribes that Elias must first come? [334]

And he answered and told them, Elias verily cometh first, and restoreth all things; and how it is written of the Son of man, that he must suffer many things, and be set at nought. [335]

But I say unto you, That Elias is indeed come, and they have done unto him whatsoever they listed, as it is written of him. [336]

And when he came to his disciples, he saw a great multitude about them, and the scribes questioning with them. [337]

And straightway all the people, when they beheld him, were greatly amazed, and running to him saluted him. [338]

And he asked the scribes, What question ye with them? [339]

And one of the multitude answered and said, Master, I have brought unto thee my son, which hath a dumb spirit; [340]

And wheresoever he taketh him, he teareth him: and he foameth, and gnasheth with his teeth, and pineth away: and I spake to thy disciples that they should cast him out; and they could not. [341]

He answereth him, and saith, O faithless generation, how long shall I be with you? how long shall I suffer you? bring him unto me. [342]

And they brought him unto him: and when he saw him, straightway the spirit tare him; and he fell on the ground, and wallowed foaming. [343]

And he asked his father, How long is it ago since this came unto him? And he said, Of a child. [344]

And ofttimes it hath cast him into the fire, and into the waters, to destroy him: but if thou canst do any thing, have compassion on us, and help us. [345]

Jesus said unto him, If thou canst believe, all things are possible to him that believeth. [346]

And straightway the father of the child cried out, and said with tears, Lord, I believe; help thou mine unbelief. [347]

When Jesus saw that the people came running together, he rebuked the foul spirit, saying unto him, Thou dumb and deaf spirit, I charge thee, come out of him, and enter no more into him. [348]

And the spirit cried, and rent him sore, and came out of him: and he was as one dead; insomuch that many said, He is dead. [349]

But Jesus took him by the hand, and lifted him up; and he arose. [350]

And when he was come into the house, his disciples asked him privately, Why could not we cast him out? [351]

And he said unto them, This kind can come forth by nothing, but by prayer and fasting. [352]

And they departed thence, and passed through Galilee; and he would not that any man should know it. [353]

For he taught his disciples, and said unto them, The Son of man is delivered into the hands of men, and they shall kill him; and after that he is killed, he shall rise the third day. [354]

But they understood not that saying, and were afraid to ask him. [355]

And he came to Capernaum: and being in the house he asked them, What was it that ye disputed among yourselves by the way? [356]

But they held their peace: for by the way they had disputed among themselves, who should be the greatest. [357]

And he sat down, and called the twelve, and saith unto them, If any man desire to be first, the same shall be last of all, and servant of all. [358]

And he took a child, and set him in the midst of them: and when he had taken him in his arms, he said unto them, [359]

Whosoever shall receive one of such children in my name, receiveth me: and whosoever shall receive me, receiveth not me, but him that sent me. [360]

And John answered him, saying, Master, we saw one casting out devils in thy name, and he followeth not us: and we forbad him, because he followeth not us. [361]

But Jesus said, Forbid him not: for there is no man which shall do a miracle in my name, that can lightly speak evil of me. [362]

For he that is not against us is on our part. [363]

For whosoever shall give you a cup of water to drink in my name, because ye belong to Christ, verily I say unto you, he shall not lose his reward. [364]

And whosoever shall offend one of these little ones that believe in me, it is better for him that a millstone were hanged about his neck, and he were cast into the sea. [365]

And if thy hand offend thee, cut it off: it is better for thee to enter into life maimed, than having two hands to go into hell, into the fire that never shall be quenched: [366]

Where their worm dieth not, and the fire is not quenched. [367]

And if thy foot offend thee, cut it off: it is better for thee to enter halt into life, than having two feet to be cast into hell, into the fire that never shall be quenched: [368]

Where their worm dieth not, and the fire is not quenched. [369]

And if thine eye offend thee, pluck it out: it is better for thee to enter into the kingdom of God with one eye, than having two eyes to be cast into hell fire: [370]

Where their worm dieth not, and the fire is not quenched. [371]

For every one shall be salted with fire, and every sacrifice shall be salted with salt. [372]

Salt is good: but if the salt have lost his saltness, wherewith will ye season it? Have salt in yourselves, and have peace one with another. [373]

§ Mark 10

And he arose from thence, and cometh into the coasts of Judaea by the farther side of Jordan: and the people resort unto him again; and, as he was wont, he taught them again. [374]

And the Pharisees came to him, and asked him, Is it lawful for a man to put away his wife? tempting him. [375]

And he answered and said unto them, What did Moses command you? [376]

And they said, Moses suffered to write a bill of divorcement, and to put her away. [377]

And Jesus answered and said unto them, For the hardness of your heart he wrote you this precept. [378]

But from the beginning of the creation God made them male and female. [379]

For this cause shall a man leave his father and mother, and cleave to his wife; [380]

And they twain shall be one flesh: so then they are no more twain, but one flesh. [381]

What therefore God hath joined together, let not man put asunder. [382]

And in the house his disciples asked him again of the same matter. [383]

And he saith unto them, Whosoever shall put away his wife, and marry another, committeth adultery against her. [384]

And if a woman shall put away her husband, and be married to another, she committeth adultery. [385]

And they brought young children to him, that he should touch them: and his disciples rebuked those that brought them. [386]

But when Jesus saw it, he was much displeased, and said unto them, Suffer the little children to come unto me, and forbid them not: for of such is the kingdom of God. [387]

Verily I say unto you, Whosoever shall not receive the kingdom of God as a little child, he shall not enter therein. [388]

And he took them up in his arms, put his hands upon them, and blessed them. [389]

And when he was gone forth into the way, there came one running, and kneeled to him, and asked him, Good Master, what shall I do that I may inherit eternal life? [390]

And Jesus said unto him, Why callest thou me good? there is none good but one, that is, God. [391]

Thou knowest the commandments, Do not commit adultery, Do not kill, Do not steal, Do not bear false witness, Defraud not, Honour thy father and mother. [392]

And he answered and said unto him, Master, all these have I observed from my youth. [393]

Then Jesus beholding him loved him, and said unto him, One thing thou lackest: go thy way, sell whatsoever thou hast, and give to the poor, and thou shalt have treasure in heaven: and come, take up the cross, and follow me. [394]

And he was sad at that saying, and went away grieved: for he had great possessions. [395]

And Jesus looked round about, and saith unto his disciples, How hardly shall they that have riches enter into the kingdom of God! [396]

And the disciples were astonished at his words. But Jesus answereth again, and saith unto them, Children, how hard is it for them that trust in riches to enter into the kingdom of God! [397]

It is easier for a camel to go through the eye of a needle, than for a rich man to enter into the kingdom of God. [398]

And they were astonished out of measure, saying among themselves, Who then can be saved? [399]

And Jesus looking upon them saith, With men it is impossible, but not with God: for with God all things are possible. [400]

Then Peter began to say unto him, Lo, we have left all, and have followed thee. [401]

And Jesus answered and said, Verily I say unto you, There is no man that hath left house, or brethren, or sisters, or father, or mother, or wife, or children, or lands, for my sake, and the gospel's, [402]

But he shall receive an hundredfold now in this time, houses, and brethren, and sisters, and mothers, and children, and lands, with persecutions; and in the world to come eternal life. [403]

But many that are first shall be last; and the last first. [404]

And they were in the way going up to Jerusalem; and Jesus went before them: and they were amazed; and as they followed, they were afraid. And he took again the twelve, and began to tell them what things should happen unto him, [405]

Saying, Behold, we go up to Jerusalem; and the Son of man shall be delivered unto the chief priests, and unto the scribes; and they shall condemn him to death, and shall deliver him to the Gentiles: [406]

And they shall mock him, and shall scourge him, and shall spit upon him, and shall kill him: and the third day he shall rise again. [407]

And James and John, the sons of Zebedee, come unto him, saying, Master, we would that thou shouldest do for us whatsoever we shall desire. [408]

And he said unto them, What would ye that I should do for you? [409]

They said unto him, Grant unto us that we may sit, one on thy right hand, and the other on thy left hand, in thy glory. [410]

But Jesus said unto them, Ye know not what ye ask: can ye drink of the cup that I drink of? and be baptized with the baptism that I am baptized with? [411]

And they said unto him, We can. And Jesus said unto them, Ye shall indeed drink of the cup that I drink of; and with the baptism that I am baptized withal shall ye be baptized: [412]

But to sit on my right hand and on my left hand is not mine to give; but it shall be given to them for whom it is prepared. [413]

And when the ten heard it, they began to be much displeased with James and John. [414]

But Jesus called them to him, and saith unto them, Ye know that they which are accounted to rule over the Gentiles exercise lordship over them; and their great ones exercise authority upon them. [415]

But so shall it not be among you: but whosoever will be great among you, shall be your minister: [416]

And whosoever of you will be the chiefest, shall be servant of all. [417]

For even the Son of man came not to be ministered unto, but to minister, and to give his life a ransom for many. [418]

And they came to Jericho: and as he went out of Jericho with his disciples and a great number of people, blind Bartimaeus, the son of Timaeus, sat by the highway side begging. [419]

And when he heard that it was Jesus of Nazareth, he began to cry out, and say, Jesus, thou son of David, have mercy on me. [420]

And many charged him that he should hold his peace: but he cried the more a great deal, Thou son of David, have mercy on me. [421]

And Jesus stood still, and commanded him to be called. And they call the blind man, saying unto him, Be of good comfort, rise; he calleth thee. [422]

And he, casting away his garment, rose, and came to Jesus. [423]

And Jesus answered and said unto him, What wilt thou that I should do unto thee? The blind man said unto him, Lord, that I might receive my sight. [424]

And Jesus said unto him, Go thy way; thy faith hath made thee whole. And immediately he received his sight, and followed Jesus in the way. [425]

§ Mark 11

And when they came nigh to Jerusalem, unto Bethphage and Bethany, at the mount of Olives, he sendeth forth two of his disciples, [426]

And saith unto them, Go your way into the village over against you: and as soon as ye be entered into it, ye shall find a colt tied, whereon never man sat; loose him, and bring him. [427]

And if any man say unto you, Why do ye this? say ye that the Lord hath need of him; and straightway he will send him hither. [428]

And they went their way, and found the colt tied by the door without in a place where two ways met; and they loose him. [429]

And certain of them that stood there said unto them, What do ye, loosing the colt? [430]

And they said unto them even as Jesus had commanded: and they let them go. [431]

And they brought the colt to Jesus, and cast their garments on him; and he sat upon him. [432]

And many spread their garments in the way: and others cut down branches off the trees, and strawed them in the way. [433]

And they that went before, and they that followed, cried, saying, Hosanna; Blessed is he that cometh in the name of the Lord: [434]

Blessed be the kingdom of our father David, that cometh in the name of the Lord: Hosanna in the highest. [435]

And Jesus entered into Jerusalem, and into the temple: and when he had looked round about upon all things, and now the eventide was come, he went out unto Bethany with the twelve. [436]

And on the morrow, when they were come from Bethany, he was hungry: [437]

And seeing a fig tree afar off having leaves, he came, if haply he might find any thing thereon: and when he came to it, he found nothing but leaves; for the time of figs was not yet. [438]

And Jesus answered and said unto it, No man eat fruit of thee hereafter for ever. And his disciples heard it. [439]

And they come to Jerusalem: and Jesus went into the temple, and began to cast out them that sold and bought in the temple, and overthrew the tables of the moneychangers, and the seats of them that sold doves; [440]

And would not suffer that any man should carry any vessel through the temple. [441]

And he taught, saying unto them, Is it not written, My house shall be called of all nations the house of prayer? but ye have made it a den of thieves. [442]

And the scribes and chief priests heard it, and sought how they might destroy him: for they feared him, because all the people was astonished at his doctrine. [443]

And when even was come, he went out of the city. [444]

And in the morning, as they passed by, they saw the fig tree dried up from the roots. [445]

And Peter calling to remembrance saith unto him, Master, behold, the fig tree which thou cursedst is withered away. [446]

And Jesus answering saith unto them, Have faith in God. [447]

For verily I say unto you, That whosoever shall say unto this mountain, Be thou removed, and be thou cast into the sea; and shall not doubt in his heart, but shall believe that those things which he saith shall come to pass; he shall have whatsoever he saith. [448]

Therefore I say unto you, What things soever ye desire, when ye pray, believe that ye receive them, and ye shall have them. [449]

And when ye stand praying, forgive, if ye have ought against any: that your Father also which is in heaven may forgive you your trespasses. [450]

But if ye do not forgive, neither will your Father which is in heaven forgive your trespasses. [451]

And they come again to Jerusalem: and as he was walking in the temple, there come to him the chief priests, and the scribes, and the elders, [452]

And say unto him, By what authority doest thou these things? and who gave thee this authority to do these things? [453]

And Jesus answered and said unto them, I will also ask of you one question, and answer me, and I will tell you by what authority I do these things. [454]

The baptism of John, was it from heaven, or of men? answer me. [455]

And they reasoned with themselves, saying, If we shall say, From heaven; he will say, Why then did ye not believe him? [456]

But if we shall say, Of men; they feared the people: for all men counted John, that he was a prophet indeed. [457]

And they answered and said unto Jesus, We cannot tell. And Jesus answering saith unto them, Neither do I tell you by what authority I do these things. [458]

§ Mark 12

And he began to speak unto them by parables. A certain man planted a vineyard, and set an hedge about it, and digged a place for the winefat, and built a tower, and let it out to husbandmen, and went into a far country. [459]

And at the season he sent to the husbandmen a servant, that he might receive from the husbandmen of the fruit of the vineyard. [460]

And they caught him, and beat him, and sent him away empty. [461]

And again he sent unto them another servant; and at him they cast stones, and wounded him in the head, and sent him away shamefully handled. [462]

And again he sent another; and him they killed, and many others; beating some, and killing some. [463]

Having yet therefore one son, his wellbeloved, he sent him also last unto them, saying, They will reverence my son. [464]

But those husbandmen said among themselves, This is the heir; come, let us kill him, and the inheritance shall be our's. [465]

And they took him, and killed him, and cast him out of the vineyard. [466]

What shall therefore the lord of the vineyard do? he will come and destroy the husbandmen, and will give the vineyard unto others. [467]

And have ye not read this scripture; The stone which the builders rejected is become the head of the corner: [468]

This was the Lord's doing, and it is marvellous in our eyes? [469]

And they sought to lay hold on him, but feared the people: for they knew that he had spoken the parable against them: and they left him, and went their way. [470]

And they send unto him certain of the Pharisees and of the Herodians, to catch him in his words. [471]

And when they were come, they say unto him, Master, we know that thou art true, and carest for no man: for thou regardest not the person of men, but teachest the way of God in truth: Is it lawful to give tribute to Caesar, or not? [472]

Shall we give, or shall we not give? But he, knowing their hypocrisy, said unto them, Why tempt ye me? bring me a penny, that I may see it. [473]

And they brought it. And he saith unto them, Whose is this image and superscription? And they said unto him, Caesar's. [474]

And Jesus answering said unto them, Render to Caesar the things that are Caesar's, and to God the things that are God's. And they marvelled at him. [475]

Then come unto him the Sadducees, which say there is no resurrection; and they asked him, saying, [476]

Master, Moses wrote unto us, If a man's brother die, and leave his wife behind him, and leave no children, that his brother should take his wife, and raise up seed unto his brother. [477]

Now there were seven brethren: and the first took a wife, and dying left no seed. [478]

And the second took her, and died, neither left he any seed: and the third likewise. [479]

And the seven had her, and left no seed: last of all the woman died also. [480]

In the resurrection therefore, when they shall rise, whose wife shall she be of them? for the seven had her to wife. [481]

And Jesus answering said unto them, Do ye not therefore err, because ye know not the scriptures, neither the power of God? [482]

For when they shall rise from the dead, they neither marry, nor are given in marriage; but are as the angels which are in heaven. [483]

And as touching the dead, that they rise: have ye not read in the book of Moses, how in the bush God spake unto him, saying, I am the God of Abraham, and the God of Isaac, and the God of Jacob? [484]

He is not the God of the dead, but the God of the living: ye therefore do greatly err. [485]

And one of the scribes came, and having heard them reasoning together, and perceiving that he had answered them well, asked him, Which is the first commandment of all? [486]

And Jesus answered him, The first of all the commandments is, Hear, O Israel; The Lord our God is one Lord: [487]

And thou shalt love the Lord thy God with all thy heart, and with all thy soul, and with all thy mind, and with all thy strength: this is the first commandment. [488]

And the second is like, namely this, Thou shalt love thy neighbour as thyself. There is none other commandment greater than these. [489]

And the scribe said unto him, Well, Master, thou hast said the truth: for there is one God; and there is none other but he: [490]

And to love him with all the heart, and with all the understanding, and with all the soul, and with all the strength, and to love his neighbour as himself, is more than all whole burnt offerings and sacrifices. [491]

And when Jesus saw that he answered discreetly, he said unto him, Thou art not far from the kingdom of God. And no man after that durst ask him any question. [492]

And Jesus answered and said, while he taught in the temple, How say the scribes that Christ is the son of David? [493]

For David himself said by the Holy Ghost, The LORD said to my Lord, Sit thou on my right hand, till I make thine enemies thy footstool. [494]

David therefore himself calleth him Lord; and whence is he then his son? And the common people heard him gladly. [495]

And he said unto them in his doctrine, Beware of the scribes, which love to go in long clothing, and love salutations in the marketplaces, [496]

And the chief seats in the synagogues, and the uppermost rooms at feasts: [497]

Which devour widows' houses, and for a pretence make long prayers: these shall receive greater damnation. [498]

And Jesus sat over against the treasury, and beheld how the people cast money into the treasury: and many that were rich cast in much. [499]

And there came a certain poor widow, and she threw in two mites, which make a farthing. [500]

And he called unto him his disciples, and saith unto them, Verily I say unto you, That this poor widow hath cast more in, than all they which have cast into the treasury: [501]

For all they did cast in of their abundance; but she of her want did cast in all that she had, even all her living. [502]

§ Mark 13

And as he went out of the temple, one of his disciples saith unto him, Master, see what manner of stones and what buildings are here! [503]

And Jesus answering said unto him, Seest thou these great buildings? there shall not be left one stone upon another, that shall not be thrown down. [504]

And as he sat upon the mount of Olives over against the temple, Peter and James and John and Andrew asked him privately, [505]

Tell us, when shall these things be? and what shall be the sign when all these things shall be fulfilled? [506]

And Jesus answering them began to say, Take heed lest any man deceive you: [507]

For many shall come in my name, saying, I am Christ; and shall deceive many. [508]

And when ye shall hear of wars and rumours of wars, be ye not troubled: for such things must needs be; but the end shall not be yet. [509]

For nation shall rise against nation, and kingdom against kingdom: and there shall be earthquakes in divers places, and there shall be famines and troubles: these are the beginnings of sorrows. [510]

But take heed to yourselves: for they shall deliver you up to councils; and in the synagogues ye shall be beaten: and ye shall be brought before rulers and kings for my sake, for a testimony against them. [511]

And the gospel must first be published among all nations. [512]

But when they shall lead you, and deliver you up, take no thought beforehand what ye shall speak, neither do ye premeditate: but whatsoever shall be given you in that hour, that speak ye: for it is not ye that speak, but the Holy Ghost. [513]

Now the brother shall betray the brother to death, and the father the son; and children shall rise up against their parents, and shall cause them to be put to death. [514]

And ye shall be hated of all men for my name's sake: but he that shall endure unto the end, the same shall be saved. [515]

But when ye shall see the abomination of desolation, spoken of by Daniel the prophet, standing where it ought not, (let him that readeth understand,) then let them that be in Judaea flee to the mountains: [516]

And let him that is on the housetop not go down into the house, neither enter therein, to take any thing out of his house: [517]

And let him that is in the field not turn back again for to take up his garment. [518]

But woe to them that are with child, and to them that give suck in those days! [519]

And pray ye that your flight be not in the winter. [520]

For in those days shall be affliction, such as was not from the beginning of the creation which God created unto this time, neither shall be. [521]

And except that the Lord had shortened those days, no flesh should be saved: but for the elect's sake, whom he hath chosen, he hath shortened the days. [522]

And then if any man shall say to you, Lo, here is Christ; or, lo, he is there; believe him not: [523]

For false Christs and false prophets shall rise, and shall shew signs and wonders, to seduce, if it were possible, even the elect. [524]

But take ye heed: behold, I have foretold you all things. [525]

But in those days, after that tribulation, the sun shall be darkened, and the moon shall not give her light, [526]

And the stars of heaven shall fall, and the powers that are in heaven shall be shaken. [527]

And then shall they see the Son of man coming in the clouds with great power and glory. [528]

And then shall he send his angels, and shall gather together his elect from the four winds, from the uttermost part of the earth to the uttermost part of heaven. [529]

Now learn a parable of the fig tree; When her branch is yet tender, and putteth forth leaves, ye know that summer is near: [530]

So ye in like manner, when ye shall see these things come to pass, know that it is nigh, even at the doors. [531]

Verily I say unto you, that this generation shall not pass, till all these things be done. [532]

Heaven and earth shall pass away: but my words shall not pass away. [533]

But of that day and that hour knoweth no man, no, not the angels which are in heaven, neither the Son, but the Father. [534]

Take ye heed, watch and pray: for ye know not when the time is. [535]

For the Son of Man is as a man taking a far journey, who left his house, and gave authority to his servants, and to every man his work, and commanded the porter to watch. [536]

Watch ye therefore: for ye know not when the master of the house cometh, at even, or at midnight, or at the cockcrowing, or in the morning: [537]

Lest coming suddenly he find you sleeping. [538]

And what I say unto you I say unto all, Watch. [539]

§ Mark 14

After two days was the feast of the passover, and of unleavened bread: and the chief priests and the scribes sought how they might take him by craft, and put him to death. [540]

But they said, Not on the feast day, lest there be an uproar of the people. [541]

And being in Bethany in the house of Simon the leper, as he sat at meat, there came a woman having an alabaster box of ointment of spikenard very precious; and she brake the box, and poured it on his head. [542]

And there were some that had indignation within themselves, and said, Why was this waste of the ointment made? [543]

For it might have been sold for more than three hundred pence, and have been given to the poor. And they murmured against her. [544]

And Jesus said, Let her alone; why trouble ye her? she hath wrought a good work on me. [545]

For ye have the poor with you always, and whensoever ye will ye may do them good: but me ye have not always. [546]

She hath done what she could: she is come aforehand to anoint my body to the burying. [547]

Verily I say unto you, Wheresoever this gospel shall be preached throughout the whole world, this also that she hath done shall be spoken of for a memorial of her. [548]

And Judas Iscariot, one of the twelve, went unto the chief priests, to betray him unto them. [549]

And when they heard it, they were glad, and promised to give him money. And he sought how he might conveniently betray him. [550]

And the first day of unleavened bread, when they killed the passover, his disciples said unto him, Where wilt thou that we go and prepare that thou mayest eat the passover? [551]

And he sendeth forth two of his disciples, and saith unto them, Go ye into the city, and there shall meet you a man bearing a pitcher of water: follow him. [552]

And wheresoever he shall go in, say ye to the goodman of the house, The Master saith, Where is the guestchamber, where I shall eat the passover with my disciples? [553]

And he will shew you a large upper room furnished and prepared: there make ready for us. [554]

And his disciples went forth, and came into the city, and found as he had said unto them: and they made ready the passover. [555]

And in the evening he cometh with the twelve. [556]

And as they sat and did eat, Jesus said, Verily I say unto you, One of you which eateth with me shall betray me. [557]

And they began to be sorrowful, and to say unto him one by one, Is it I? and another said, Is it I? [558]

And he answered and said unto them, It is one of the twelve, that dippeth with me in the dish. [559]

The Son of man indeed goeth, as it is written of him: but woe to that man by whom the Son of man is betrayed! good were it for that man if he had never been born. [560]

And as they did eat, Jesus took bread, and blessed, and brake it, and gave to them, and said, Take, eat: this is my body. [561]

And he took the cup, and when he had given thanks, he gave it to them: and they all drank of it. [562]

And he said unto them, This is my blood of the new testament, which is shed for many. [563]

Verily I say unto you, I will drink no more of the fruit of the vine, until that day that I drink it new in the kingdom of God. [564]

And when they had sung an hymn, they went out into the mount of Olives. [565]

And Jesus saith unto them, All ye shall be offended because of me this night: for it is written, I will smite the shepherd, and the sheep shall be scattered. [566]

But after that I am risen, I will go before you into Galilee. [567]

But Peter said unto him, Although all shall be offended, yet will not I. [568]

And Jesus saith unto him, Verily I say unto thee, That this day, even in this night, before the cock crow twice, thou shalt deny me thrice. [569]

But he spake the more vehemently, If I should die with thee, I will not deny thee in any wise. Likewise also said they all. [570]

And they came to a place which was named Gethsemane: and he saith to his disciples, Sit ye here, while I shall pray. [571]

And he taketh with him Peter and James and John, and began to be sore amazed, and to be very heavy; [572]

And saith unto them, My soul is exceeding sorrowful unto death: tarry ye here, and watch. [573]

And he went forward a little, and fell on the ground, and prayed that, if it were possible, the hour might pass from him. [574]

And he said, Abba, Father, all things are possible unto thee; take away this cup from me: nevertheless not what I will, but what thou wilt. [575]

And he cometh, and findeth them sleeping, and saith unto Peter, Simon, sleepest thou? couldest not thou watch one hour? [576]

Watch ye and pray, lest ye enter into temptation. The spirit truly is ready, but the flesh is weak. [577]

And again he went away, and prayed, and spake the same words. [578]

And when he returned, he found them asleep again, (for their eyes were heavy,) neither wist they what to answer him. [579]

And he cometh the third time, and saith unto them, Sleep on now, and take your rest: it is enough, the hour is come; behold, the Son of man is betrayed into the hands of sinners. [580]

Rise up, let us go; lo, he that betrayeth me is at hand. [581]

And immediately, while he yet spake, cometh Judas, one of the twelve, and with him a great multitude with swords and staves, from the chief priests and the scribes and the elders. [582]

And he that betrayed him had given them a token, saying, Whomsoever I shall kiss, that same is he; take him, and lead him away safely. [583]

And as soon as he was come, he goeth straightway to him, and saith, Master, master; and kissed him. [584]

And they laid their hands on him, and took him. [585]

And one of them that stood by drew a sword, and smote a servant of the high priest, and cut off his ear. [586]

And Jesus answered and said unto them, Are ye come out, as against a thief, with swords and with staves to take me? [587]

I was daily with you in the temple teaching, and ye took me not: but the scriptures must be fulfilled. [588]

And they all forsook him, and fled. [589]

And there followed him a certain young man, having a linen cloth cast about his naked body; and the young men laid hold on him: [590]

And he left the linen cloth, and fled from them naked. [591]

And they led Jesus away to the high priest: and with him were assembled all the chief priests and the elders and the scribes. [592]

And Peter followed him afar off, even into the palace of the high priest: and he sat with the servants, and warmed himself at the fire. [593]

And the chief priests and all the council sought for witness against Jesus to put him to death; and found none. [594]

For many bare false witness against him, but their witness agreed not together. [595]

And there arose certain, and bare false witness against him, saying, [596]

We heard him say, I will destroy this temple that is made with hands, and within three days I will build another made without hands. [597]

But neither so did their witness agree together. [598]

And the high priest stood up in the midst, and asked Jesus, saying, Answerest thou nothing? what is it which these witness against thee? [599]

But he held his peace, and answered nothing. Again the high priest asked him, and said unto him, Art thou the Christ, the Son of the Blessed? [600]

And Jesus said, I am: and ye shall see the Son of man sitting on the right hand of power, and coming in the clouds of heaven. [601]

Then the high priest rent his clothes, and saith, What need we any further witnesses? [602]

Ye have heard the blasphemy: what think ye? And they all condemned him to be guilty of death. [603]

And some began to spit on him, and to cover his face, and to buffet him, and to say unto him, Prophesy: and the servants did strike him with the palms of their hands. [604]

And as Peter was beneath in the palace, there cometh one of the maids of the high priest: [605]

And when she saw Peter warming himself, she looked upon him, and said, And thou also wast with Jesus of Nazareth. [606]

But he denied, saying, I know not, neither understand I what thou sayest. And he went out into the porch; and the cock crew. [607]

And a maid saw him again, and began to say to them that stood by, This is one of them. [608]

And he denied it again. And a little after, they that stood by said again to Peter, Surely thou art one of them: for thou art a Galilaean, and thy speech agreeth thereto. [609]

But he began to curse and to swear, saying, I know not this man of whom ye speak. [610]

And the second time the cock crew. And Peter called to mind the word that Jesus said unto him, Before the cock crow twice, thou shalt deny me thrice. And when he thought thereon, he wept. [611]

§ Mark 15

And straightway in the morning the chief priests held a consultation with the elders and scribes and the whole council, and bound Jesus, and carried him away, and delivered him to Pilate. [612]

And Pilate asked him, Art thou the King of the Jews? And he answering said unto them, Thou sayest it. [613]

And the chief priests accused him of many things: but he answered nothing. [614]

And Pilate asked him again, saying, Answerest thou nothing? behold how many things they witness against thee. [615]

But Jesus yet answered nothing; so that Pilate marvelled. [616]

Now at that feast he released unto them one prisoner, whomsoever they desired. [617]

And there was one named Barabbas, which lay bound with them that had made insurrection with him, who had committed murder in the insurrection. [618]

And the multitude crying aloud began to desire him to do as he had ever done unto them. [619]

But Pilate answered them, saying, Will ye that I release unto you the King of the Jews? [620]

For he knew that the chief priests had delivered him for envy. [621]

But the chief priests moved the people, that he should rather release Barabbas unto them. [622]

And Pilate answered and said again unto them, What will ye then that I shall do unto him whom ye call the King of the Jews? [623]

And they cried out again, Crucify him. [624]

Then Pilate said unto them, Why, what evil hath he done? And they cried out the more exceedingly, Crucify him. [625]

And so Pilate, willing to content the people, released Barabbas unto them, and delivered Jesus, when he had scourged him, to be crucified. [626]

And the soldiers led him away into the hall, called Praetorium; and they call together the whole band. [627]

And they clothed him with purple, and platted a crown of thorns, and put it about his head, [628]

And began to salute him, Hail, King of the Jews! [629]

And they smote him on the head with a reed, and did spit upon him, and bowing their knees worshipped him. [630]

And when they had mocked him, they took off the purple from him, and put his own clothes on him, and led him out to crucify him. [631]

And they compel one Simon a Cyrenian, who passed by, coming out of the country, the father of Alexander and Rufus, to bear his cross. [632]

And they bring him unto the place Golgotha, which is, being interpreted, The place of a skull. [633]

And they gave him to drink wine mingled with myrrh: but he received it not. [634]

And when they had crucified him, they parted his garments, casting lots upon them, what every man should take. [635]

And it was the third hour, and they crucified him. [636]

And the superscription of his accusation was written over, THE KING OF THE JEWS. [637]

And with him they crucify two thieves; the one on his right hand, and the other on his left. [638]

And the scripture was fulfilled, which saith, And he was numbered with the transgressors. [639]

And they that passed by railed on him, wagging their heads, and saying, Ah, thou that destroyest the temple, and buildest it in three days, [640]

Save thyself, and come down from the cross. [641]

Likewise also the chief priests mocking said among themselves with the scribes, He saved others; himself he cannot save. [642]

Let Christ the King of Israel descend now from the cross, that we may see and believe. And they that were crucified with him reviled him. [643]

And when the sixth hour was come, there was darkness over the whole land until the ninth hour. [644]

And at the ninth hour Jesus cried with a loud voice, saying, Eloi, Eloi, lama sabachthani? which is, being interpreted, My God, my God, why hast thou forsaken me? [645]

And some of them that stood by, when they heard it, said, Behold, he calleth Elias. [646]

And one ran and filled a spunge full of vinegar, and put it on a reed, and gave him to drink, saying, Let alone; let us see whether Elias will come to take him down. [647]

And Jesus cried with a loud voice, and gave up the ghost. [648]

And the veil of the temple was rent in twain from the top to the bottom. [649]

And when the centurion, which stood over against him, saw that he so cried out, and gave up the ghost, he said, Truly this man was the Son of God. [650]

There were also women looking on afar off: among whom was Mary Magdalene, and Mary the mother of James the less and of Joses, and Salome; [651]

(Who also, when he was in Galilee, followed him, and ministered unto him;) and many other women which came up with him unto Jerusalem. [652]

And now when the even was come, because it was the preparation, that is, the day before the sabbath, [653]

Joseph of Arimathaea, an honourable counsellor, which also waited for the kingdom of God, came, and went in boldly unto Pilate, and craved the body of Jesus. [654]

And Pilate marvelled if he were already dead: and calling unto him the centurion, he asked him whether he had been any while dead. [655]

And when he knew it of the centurion, he gave the body to Joseph. [656]

And he bought fine linen, and took him down, and wrapped him in the linen, and laid him in a sepulchre which was hewn out of a rock, and rolled a stone unto the door of the sepulchre. [657]

And Mary Magdalene and Mary the mother of Joses beheld where he was laid. [658]

§ Mark 16

And when the sabbath was past, Mary Magdalene, and Mary the mother of James, and Salome, had bought sweet spices, that they might come and anoint him. [659]

And very early in the morning the first day of the week, they came unto the sepulchre at the rising of the sun. [660]

And they said among themselves, Who shall roll us away the stone from the door of the sepulchre? [661]

And when they looked, they saw that the stone was rolled away: for it was very great. [662]

And entering into the sepulchre, they saw a young man sitting on the right side, clothed in a long white garment; and they were affrighted. [663]

And he saith unto them, Be not affrighted: Ye seek Jesus of Nazareth, which was crucified: he is risen; he is not here: behold the place where they laid him. [664]

But go your way, tell his disciples and Peter that he goeth before you into Galilee: there shall ye see him, as he said unto you. [665]

And they went out quickly, and fled from the sepulchre; for they trembled and were amazed: neither said they any thing to any man; for they were afraid. [666]

Now when Jesus was risen early the first day of the week, he appeared first to Mary Magdalene, out of whom he had cast seven devils. [667]

And she went and told them that had been with him, as they mourned and wept. [668]

And they, when they had heard that he was alive, and had been seen of her, believed not. [669]

After that he appeared in another form unto two of them, as they walked, and went into the country. [670]

And they went and told it unto the residue: neither believed they them. [671]

Afterward he appeared unto the eleven as they sat at meat, and upbraided them with their unbelief and hardness of heart, because they believed not them which had seen him after he was risen. [672]

And he said unto them, Go ye into all the world, and preach the gospel to every creature. [673]

He that believeth and is baptized shall be saved; but he that believeth not shall be damned. [674]

And these signs shall follow them that believe; In my name shall they cast out devils; they shall speak with new tongues; [675]

They shall take up serpents; and if they drink any deadly thing, it shall not hurt them; they shall lay hands on the sick, and they shall recover. [676]

So then after the Lord had spoken unto them, he was received up into heaven, and sat on the right hand of God. [677]

And they went forth, and preached every where, the Lord working with them, and confirming the word with signs following. Amen. [678]

=== citations ===
[1] Mark 1:1 (KJV) | | 1
[2] Mark 1:2 (KJV) | | 1
[3] Mark 1:3 (KJV) | | 1
[4] Mark 1:4 (KJV) | | 1
[5] Mark 1:5 (KJV) | | 1
[6] Mark 1:6 (KJV) | | 1
[7] Mark 1:7 (KJV) | | 1
[8] Mark 1:8 (KJV) | | 1
[9] Mark 1:9 (KJV) | | 1
[10] Mark 1:10 (KJV) | | 1
[11] Mark 1:11 (KJV) | | 1
[12] Mark 1:12 (KJV) | | 1
[13] Mark 1:13 (KJV) | | 1
[14] Mark 1:14 (KJV) | | 1
[15] Mark 1:15 (KJV) | | 1
[16] Mark 1:16 (KJV) | | 1
[17] Mark 1:17 (KJV) | | 1
[18] Mark 1:18 (KJV) | | 1
[19] Mark 1:19 (KJV) | | 1
[20] Mark 1:20 (KJV) | | 1
[21] Mark 1:21 (KJV) | | 1
[22] Mark 1:22 (KJV) | | 1
[23] Mark 1:23 (KJV) | | 1
[24] Mark 1:24 (KJV) | | 1
[25] Mark 1:25 (KJV) | | 1
[26] Mark 1:26 (KJV) | | 1
[27] Mark 1:27 (KJV) | | 1
[28] Mark 1:28 (KJV) | | 1
[29] Mark 1:29 (KJV) | | 1
[30] Mark 1:30 (KJV) | | 1
[31] Mark 1:31 (KJV) | | 1
[32] Mark 1:32 (KJV) | | 1
[33] Mark 1:33 (KJV) | | 1
[34] Mark 1:34 (KJV) | | 1
[35] Mark 1:35 (KJV) | | 1
[36] Mark 1:36 (KJV) | | 1
[37] Mark 1:37 (KJV) | | 1
[38] Mark 1:38 (KJV) | | 1
[39] Mark 1:39 (KJV) | | 1
[40] Mark 1:40 (KJV) | | 1
[41] Mark 1:41 (KJV) | | 1
[42] Mark 1:42 (KJV) | | 1
[43] Mark 1:43 (KJV) | | 1
[44] Mark 1:44 (KJV) | | 1
[45] Mark 1:45 (KJV) | | 1
[46] Mark 2:1 (KJV) | | 1
[47] Mark 2:2 (KJV) | | 1
[48] Mark 2:3 (KJV) | | 1
[49] Mark 2:4 (KJV) | | 1
[50] Mark 2:5 (KJV) | | 1
[51] Mark 2:6 (KJV) | | 1
[52] Mark 2:7 (KJV) | | 1
[53] Mark 2:8 (KJV) | | 1
[54] Mark 2:9 (KJV) | | 1
[55] Mark 2:10 (KJV) | | 1
[56] Mark 2:11 (KJV) | | 1
[57] Mark 2:12 (KJV) | | 1
[58] Mark 2:13 (KJV) | | 1
[59] Mark 2:14 (KJV) | | 1
[60] Mark 2:15 (KJV) | | 1
[61] Mark 2:16 (KJV) | | 1
[62] Mark 2:17 (KJV) | | 1
[63] Mark 2:18 (KJV) | | 1
[64] Mark 2:19 (KJV) | | 1
[65] Mark 2:20 (KJV) | | 1
[66] Mark 2:21 (KJV) | | 1
[67] Mark 2:22 (KJV) | | 1
[68] Mark 2:23 (KJV) | | 1
[69] Mark 2:24 (KJV) | | 1
[70] Mark 2:25 (KJV) | | 1
[71] Mark 2:26 (KJV) | | 1
[72] Mark 2:27 (KJV) | | 1
[73] Mark 2:28 (KJV) | | 1
[74] Mark 3:1 (KJV) | | 1
[75] Mark 3:2 (KJV) | | 1
[76] Mark 3:3 (KJV) | | 1
[77] Mark 3:4 (KJV) | | 1
[78] Mark 3:5 (KJV) | | 1
[79] Mark 3:6 (KJV) | | 1
[80] Mark 3:7 (KJV) | | 1
[81] Mark 3:8 (KJV) | | 1
[82] Mark 3:9 (KJV) | | 1
[83] Mark 3:10 (KJV) | | 1
[84] Mark 3:11 (KJV) | | 1
[85] Mark 3:12 (KJV) | | 1
[86] Mark 3:13 (KJV) | | 1
[87] Mark 3:14 (KJV) | | 1
[88] Mark 3:15 (KJV) | | 1
[89] Mark 3:16 (KJV) | | 1
[90] Mark 3:17 (KJV) | | 1
[91] Mark 3:18 (KJV) | | 1
[92] Mark 3:19 (KJV) | | 1
[93] Mark 3:20 (KJV) | | 1
[94] Mark 3:21 (KJV) | | 1
[95] Mark 3:22 (KJV) | | 1
[96] Mark 3:23 (KJV) | | 1
[97] Mark 3:24 (KJV) | | 1
[98] Mark 3:25 (KJV) | | 1
[99] Mark 3:26 (KJV) | | 1
[100] Mark 3:27 (KJV) | | 1
[101] Mark 3:28 (KJV) | | 1
[102] Mark 3:29 (KJV) | | 1
[103] Mark 3:30 (KJV) | | 1
[104] Mark 3:31 (KJV) | | 1
[105] Mark 3:32 (KJV) | | 1
[106] Mark 3:33 (KJV) | | 1
[107] Mark 3:34 (KJV) | | 1
[108] Mark 3:35 (KJV) | | 1
[109] Mark 4:1 (KJV) | | 1
[110] Mark 4:2 (KJV) | | 1
[111] Mark 4:3 (KJV) | | 1
[112] Mark 4:4 (KJV) | | 1
[113] Mark 4:5 (KJV) | | 1
[114] Mark 4:6 (KJV) | | 1
[115] Mark 4:7 (KJV) | | 1
[116] Mark 4:8 (KJV) | | 1
[117] Mark 4:9 (KJV) | | 1
[118] Mark 4:10 (KJV) | | 1
[119] Mark 4:11 (KJV) | | 1
[120] Mark 4:12 (KJV) | | 1
[121] Mark 4:13 (KJV) | | 1
[122] Mark 4:14 (KJV) | | 1
[123] Mark 4:15 (KJV) | | 1
[124] Mark 4:16 (KJV) | | 1
[125] Mark 4:17 (KJV) | | 1
[126] Mark 4:18 (KJV) | | 1
[127] Mark 4:19 (KJV) | | 1
[128] Mark 4:20 (KJV) | | 1
[129] Mark 4:21 (KJV) | | 1
[130] Mark 4:22 (KJV) | | 1
[131] Mark 4:23 (KJV) | | 1
[132] Mark 4:24 (KJV) | | 1
[133] Mark 4:25 (KJV) | | 1
[134] Mark 4:26 (KJV) | | 1
[135] Mark 4:27 (KJV) | | 1
[136] Mark 4:28 (KJV) | | 1
[137] Mark 4:29 (KJV) | | 1
[138] Mark 4:30 (KJV) | | 1
[139] Mark 4:31 (KJV) | | 1
[140] Mark 4:32 (KJV) | | 1
[141] Mark 4:33 (KJV) | | 1
[142] Mark 4:34 (KJV) | | 1
[143] Mark 4:35 (KJV) | | 1
[144] Mark 4:36 (KJV) | | 1
[145] Mark 4:37 (KJV) | | 1
[146] Mark 4:38 (KJV) | | 1
[147] Mark 4:39 (KJV) | | 1
[148] Mark 4:40 (KJV) | | 1
[149] Mark 4:41 (KJV) | | 1
[150] Mark 5:1 (KJV) | | 1
[151] Mark 5:2 (KJV) | | 1
[152] Mark 5:3 (KJV) | | 1
[153] Mark 5:4 (KJV) | | 1
[154] Mark 5:5 (KJV) | | 1
[155] Mark 5:6 (KJV) | | 1
[156] Mark 5:7 (KJV) | | 1
[157] Mark 5:8 (KJV) | | 1
[158] Mark 5:9 (KJV) | | 1
[159] Mark 5:10 (KJV) | | 1
[160] Mark 5:11 (KJV) | | 1
[161] Mark 5:12 (KJV) | | 1
[162] Mark 5:13 (KJV) | | 1
[163] Mark 5:14 (KJV) | | 1
[164] Mark 5:15 (KJV) | | 1
[165] Mark 5:16 (KJV) | | 1
[166] Mark 5:17 (KJV) | | 1
[167] Mark 5:18 (KJV) | | 1
[168] Mark 5:19 (KJV) | | 1
[169] Mark 5:20 (KJV) | | 1
[170] Mark 5:21 (KJV) | | 1
[171] Mark 5:22 (KJV) | | 1
[172] Mark 5:23 (KJV) | | 1
[173] Mark 5:24 (KJV) | | 1
[174] Mark 5:25 (KJV) | | 1
[175] Mark 5:26 (KJV) | | 1
[176] Mark 5:27 (KJV) | | 1
[177] Mark 5:28 (KJV) | | 1
[178] Mark 5:29 (KJV) | | 1
[179] Mark 5:30 (KJV) | | 1
[180] Mark 5:31 (KJV) | | 1
[181] Mark 5:32 (KJV) | | 1
[182] Mark 5:33 (KJV) | | 1
[183] Mark 5:34 (KJV) | | 1
[184] Mark 5:35 (KJV) | | 1
[185] Mark 5:36 (KJV) | | 1
[186] Mark 5:37 (KJV) | | 1
[187] Mark 5:38 (KJV) | | 1
[188] Mark 5:39 (KJV) | | 1
[189] Mark 5:40 (KJV) | | 1
[190] Mark 5:41 (KJV) | | 1
[191] Mark 5:42 (KJV) | | 1
[192] Mark 5:43 (KJV) | | 1
[193] Mark 6:1 (KJV) | | 1
[194] Mark 6:2 (KJV) | | 1
[195] Mark 6:3 (KJV) | | 1
[196] Mark 6:4 (KJV) | | 1
[197] Mark 6:5 (KJV) | | 1
[198] Mark 6:6 (KJV) | | 1
[199] Mark 6:7 (KJV) | | 1
[200] Mark 6:8 (KJV) | | 1
[201] Mark 6:9 (KJV) | | 1
[202] Mark 6:10 (KJV) | | 1
[203] Mark 6:11 (KJV) | | 1
[204] Mark 6:12 (KJV) | | 1
[205] Mark 6:13 (KJV) | | 1
[206] Mark 6:14 (KJV) | | 1
[207] Mark 6:15 (KJV) | | 1
[208] Mark 6:16 (KJV) | | 1
[209] Mark 6:17 (KJV) | | 1
[210] Mark 6:18 (KJV) | | 1
[211] Mark 6:19 (KJV) | | 1
[212] Mark 6:20 (KJV) | | 1
[213] Mark 6:21 (KJV) | | 1
[214] Mark 6:22 (KJV) | | 1
[215] Mark 6:23 (KJV) | | 1
[216] Mark 6:24 (KJV) | | 1
[217] Mark 6:25 (KJV) | | 1
[218] Mark 6:26 (KJV) | | 1
[219] Mark 6:27 (KJV) | | 1
[220] Mark 6:28 (KJV) | | 1
[221] Mark 6:29 (KJV) | | 1
[222] Mark 6:30 (KJV) | | 1
[223] Mark 6:31 (KJV) | | 1
[224] Mark 6:32 (KJV) | | 1
[225] Mark 6:33 (KJV) | | 1
[226] Mark 6:34 (KJV) | | 1
[227] Mark 6:35 (KJV) | | 1
[228] Mark 6:36 (KJV) | | 1
[229] Mark 6:37 (KJV) | | 1
[230] Mark 6:38 (KJV) | | 1
[231] Mark 6:39 (KJV) | | 1
[232] Mark 6:40 (KJV) | | 1
[233] Mark 6:41 (KJV) | | 1
[234] Mark 6:42 (KJV) | | 1
[235] Mark 6:43 (KJV) | | 1
[236] Mark 6:44 (KJV) | | 1
[237] Mark 6:45 (KJV) | | 1
[238] Mark 6:46 (KJV) | | 1
[239] Mark 6:47 (KJV) | | 1
[240] Mark 6:48 (KJV) | | 1
[241] Mark 6:49 (KJV) | | 1
[242] Mark 6:50 (KJV) | | 1
[243] Mark 6:51 (KJV) | | 1
[244] Mark 6:52 (KJV) | | 1
[245] Mark 6:53 (KJV) | | 1
[246] Mark 6:54 (KJV) | | 1
[247] Mark 6:55 (KJV) | | 1
[248] Mark 6:56 (KJV) | | 1
[249] Mark 7:1 (KJV) | | 1
[250] Mark 7:2 (KJV) | | 1
[251] Mark 7:3 (KJV) | | 1
[252] Mark 7:4 (KJV) | | 1
[253] Mark 7:5 (KJV) | | 1
[254] Mark 7:6 (KJV) | | 1
[255] Mark 7:7 (KJV) | | 1
[256] Mark 7:8 (KJV) | | 1
[257] Mark 7:9 (KJV) | | 1
[258] Mark 7:10 (KJV) | | 1
[259] Mark 7:11 (KJV) | | 1
[260] Mark 7:12 (KJV) | | 1
[261] Mark 7:13 (KJV) | | 1
[262] Mark 7:14 (KJV) | | 1
[263] Mark 7:15 (KJV) | | 1
[264] Mark 7:16 (KJV) | | 1
[265] Mark 7:17 (KJV) | | 1
[266] Mark 7:18 (KJV) | | 1
[267] Mark 7:19 (KJV) | | 1
[268] Mark 7:20 (KJV) | | 1
[269] Mark 7:21 (KJV) | | 1
[270] Mark 7:22 (KJV) | | 1
[271] Mark 7:23 (KJV) | | 1
[272] Mark 7:24 (KJV) | | 1
[273] Mark 7:25 (KJV) | | 1
[274] Mark 7:26 (KJV) | | 1
[275] Mark 7:27 (KJV) | | 1
[276] Mark 7:28 (KJV) | | 1
[277] Mark 7:29 (KJV) | | 1
[278] Mark 7:30 (KJV) | | 1
[279] Mark 7:31 (KJV) | | 1
[280] Mark 7:32 (KJV) | | 1
[281] Mark 7:33 (KJV) | | 1
[282] Mark 7:34 (KJV) | | 1
[283] Mark 7:35 (KJV) | | 1
[284] Mark 7:36 (KJV) | | 1
[285] Mark 7:37 (KJV) | | 1
[286] Mark 8:1 (KJV) | | 1
[287] Mark 8:2 (KJV) | | 1
[288] Mark 8:3 (KJV) | | 1
[289] Mark 8:4 (KJV) | | 1
[290] Mark 8:5 (KJV) | | 1
[291] Mark 8:6 (KJV) | | 1
[292] Mark 8:7 (KJV) | | 1
[293] Mark 8:8 (KJV) | | 1
[294] Mark 8:9 (KJV) | | 1
[295] Mark 8:10 (KJV) | | 1
[296] Mark 8:11 (KJV) | | 1
[297] Mark 8:12 (KJV) | | 1
[298] Mark 8:13 (KJV) | | 1
[299] Mark 8:14 (KJV) | | 1
[300] Mark 8:15 (KJV) | | 1
[301] Mark 8:16 (KJV) | | 1
[302] Mark 8:17 (KJV) | | 1
[303] Mark 8:18 (KJV) | | 1
[304] Mark 8:19 (KJV) | | 1
[305] Mark 8:20 (KJV) | | 1
[306] Mark 8:21 (KJV) | | 1
[307] Mark 8:22 (KJV) | | 1
[308] Mark 8:23 (KJV) | | 1
[309] Mark 8:24 (KJV) | | 1
[310] Mark 8:25 (KJV) | | 1
[311] Mark 8:26 (KJV) | | 1
[312] Mark 8:27 (KJV) | | 1
[313] Mark 8:28 (KJV) | | 1
[314] Mark 8:29 (KJV) | | 1
[315] Mark 8:30 (KJV) | | 1
[316] Mark 8:31 (KJV) | | 1
[317] Mark 8:32 (KJV) | | 1
[318] Mark 8:33 (KJV) | | 1
[319] Mark 8:34 (KJV) | | 1
[320] Mark 8:35 (KJV) | | 1
[321] Mark 8:36 (KJV) | | 1
[322] Mark 8:37 (KJV) | | 1
[323] Mark 8:38 (KJV) | | 1
[324] Mark 9:1 (KJV) | | 1
[325] Mark 9:2 (KJV) | | 1
[326] Mark 9:3 (KJV) | | 1
[327] Mark 9:4 (KJV) | | 1
[328] Mark 9:5 (KJV) | | 1
[329] Mark 9:6 (KJV) | | 1
[330] Mark 9:7 (KJV) | | 1
[331] Mark 9:8 (KJV) | | 1
[332] Mark 9:9 (KJV) | | 1
[333] Mark 9:10 (KJV) | | 1
[334] Mark 9:11 (KJV) | | 1
[335] Mark 9:12 (KJV) | | 1
[336] Mark 9:13 (KJV) | | 1
[337] Mark 9:14 (KJV) | | 1
[338] Mark 9:15 (KJV) | | 1
[339] Mark 9:16 (KJV) | | 1
[340] Mark 9:17 (KJV) | | 1
[341] Mark 9:18 (KJV) | | 1
[342] Mark 9:19 (KJV) | | 1
[343] Mark 9:20 (KJV) | | 1
[344] Mark 9:21 (KJV) | | 1
[345] Mark 9:22 (KJV) | | 1
[346] Mark 9:23 (KJV) | | 1
[347] Mark 9:24 (KJV) | | 1
[348] Mark 9:25 (KJV) | | 1
[349] Mark 9:26 (KJV) | | 1
[350] Mark 9:27 (KJV) | | 1
[351] Mark 9:28 (KJV) | | 1
[352] Mark 9:29 (KJV) | | 1
[353] Mark 9:30 (KJV) | | 1
[354] Mark 9:31 (KJV) | | 1
[355] Mark 9:32 (KJV) | | 1
[356] Mark 9:33 (KJV) | | 1
[357] Mark 9:34 (KJV) | | 1
[358] Mark 9:35 (KJV) | | 1
[359] Mark 9:36 (KJV) | | 1
[360] Mark 9:37 (KJV) | | 1
[361] Mark 9:38 (KJV) | | 1
[362] Mark 9:39 (KJV) | | 1
[363] Mark 9:40 (KJV) | | 1
[364] Mark 9:41 (KJV) | | 1
[365] Mark 9:42 (KJV) | | 1
[366] Mark 9:43 (KJV) | | 1
[367] Mark 9:44 (KJV) | | 1
[368] Mark 9:45 (KJV) | | 1
[369] Mark 9:46 (KJV) | | 1
[370] Mark 9:47 (KJV) | | 1
[371] Mark 9:48 (KJV) | | 1
[372] Mark 9:49 (KJV) | | 1
[373] Mark 9:50 (KJV) | | 1
[374] Mark 10:1 (KJV) | | 1
[375] Mark 10:2 (KJV) | | 1
[376] Mark 10:3 (KJV) | | 1
[377] Mark 10:4 (KJV) | | 1
[378] Mark 10:5 (KJV) | | 1
[379] Mark 10:6 (KJV) | | 1
[380] Mark 10:7 (KJV) | | 1
[381] Mark 10:8 (KJV) | | 1
[382] Mark 10:9 (KJV) | | 1
[383] Mark 10:10 (KJV) | | 1
[384] Mark 10:11 (KJV) | | 1
[385] Mark 10:12 (KJV) | | 1
[386] Mark 10:13 (KJV) | | 1
[387] Mark 10:14 (KJV) | | 1
[388] Mark 10:15 (KJV) | | 1
[389] Mark 10:16 (KJV) | | 1
[390] Mark 10:17 (KJV) | | 1
[391] Mark 10:18 (KJV) | | 1
[392] Mark 10:19 (KJV) | | 1
[393] Mark 10:20 (KJV) | | 1
[394] Mark 10:21 (KJV) | | 1
[395] Mark 10:22 (KJV) | | 1
[396] Mark 10:23 (KJV) | | 1
[397] Mark 10:24 (KJV) | | 1
[398] Mark 10:25 (KJV) | | 1
[399] Mark 10:26 (KJV) | | 1
[400] Mark 10:27 (KJV) | | 1
[401] Mark 10:28 (KJV) | | 1
[402] Mark 10:29 (KJV) | | 1
[403] Mark 10:30 (KJV) | | 1
[404] Mark 10:31 (KJV) | | 1
[405] Mark 10:32 (KJV) | | 1
[406] Mark 10:33 (KJV) | | 1
[407] Mark 10:34 (KJV) | | 1
[408] Mark 10:35 (KJV) | | 1
[409] Mark 10:36 (KJV) | | 1
[410] Mark 10:37 (KJV) | | 1
[411] Mark 10:38 (KJV) | | 1
[412] Mark 10:39 (KJV) | | 1
[413] Mark 10:40 (KJV) | | 1
[414] Mark 10:41 (KJV) | | 1
[415] Mark 10:42 (KJV) | | 1
[416] Mark 10:43 (KJV) | | 1
[417] Mark 10:44 (KJV) | | 1
[418] Mark 10:45 (KJV) | | 1
[419] Mark 10:46 (KJV) | | 1
[420] Mark 10:47 (KJV) | | 1
[421] Mark 10:48 (KJV) | | 1
[422] Mark 10:49 (KJV) | | 1
[423] Mark 10:50 (KJV) | | 1
[424] Mark 10:51 (KJV) | | 1
[425] Mark 10:52 (KJV) | | 1
[426] Mark 11:1 (KJV) | | 1
[427] Mark 11:2 (KJV) | | 1
[428] Mark 11:3 (KJV) | | 1
[429] Mark 11:4 (KJV) | | 1
[430] Mark 11:5 (KJV) | | 1
[431] Mark 11:6 (KJV) | | 1
[432] Mark 11:7 (KJV) | | 1
[433] Mark 11:8 (KJV) | | 1
[434] Mark 11:9 (KJV) | | 1
[435] Mark 11:10 (KJV) | | 1
[436] Mark 11:11 (KJV) | | 1
[437] Mark 11:12 (KJV) | | 1
[438] Mark 11:13 (KJV) | | 1
[439] Mark 11:14 (KJV) | | 1
[440] Mark 11:15 (KJV) | | 1
[441] Mark 11:16 (KJV) | | 1
[442] Mark 11:17 (KJV) | | 1
[443] Mark 11:18 (KJV) | | 1
[444] Mark 11:19 (KJV) | | 1
[445] Mark 11:20 (KJV) | | 1
[446] Mark 11:21 (KJV) | | 1
[447] Mark 11:22 (KJV) | | 1
[448] Mark 11:23 (KJV) | | 1
[449] Mark 11:24 (KJV) | | 1
[450] Mark 11:25 (KJV) | | 1
[451] Mark 11:26 (KJV) | | 1
[452] Mark 11:27 (KJV) | | 1
[453] Mark 11:28 (KJV) | | 1
[454] Mark 11:29 (KJV) | | 1
[455] Mark 11:30 (KJV) | | 1
[456] Mark 11:31 (KJV) | | 1
[457] Mark 11:32 (KJV) | | 1
[458] Mark 11:33 (KJV) | | 1
[459] Mark 12:1 (KJV) | | 1
[460] Mark 12:2 (KJV) | | 1
[461] Mark 12:3 (KJV) | | 1
[462] Mark 12:4 (KJV) | | 1
[463] Mark 12:5 (KJV) | | 1
[464] Mark 12:6 (KJV) | | 1
[465] Mark 12:7 (KJV) | | 1
[466] Mark 12:8 (KJV) | | 1
[467] Mark 12:9 (KJV) | | 1
[468] Mark 12:10 (KJV) | | 1
[469] Mark 12:11 (KJV) | | 1
[470] Mark 12:12 (KJV) | | 1
[471] Mark 12:13 (KJV) | | 1
[472] Mark 12:14 (KJV) | | 1
[473] Mark 12:15 (KJV) | | 1
[474] Mark 12:16 (KJV) | | 1
[475] Mark 12:17 (KJV) | | 1
[476] Mark 12:18 (KJV) | | 1
[477] Mark 12:19 (KJV) | | 1
[478] Mark 12:20 (KJV) | | 1
[479] Mark 12:21 (KJV) | | 1
[480] Mark 12:22 (KJV) | | 1
[481] Mark 12:23 (KJV) | | 1
[482] Mark 12:24 (KJV) | | 1
[483] Mark 12:25 (KJV) | | 1
[484] Mark 12:26 (KJV) | | 1
[485] Mark 12:27 (KJV) | | 1
[486] Mark 12:28 (KJV) | | 1
[487] Mark 12:29 (KJV) | | 1
[488] Mark 12:30 (KJV) | | 1
[489] Mark 12:31 (KJV) | | 1
[490] Mark 12:32 (KJV) | | 1
[491] Mark 12:33 (KJV) | | 1
[492] Mark 12:34 (KJV) | | 1
[493] Mark 12:35 (KJV) | | 1
[494] Mark 12:36 (KJV) | | 1
[495] Mark 12:37 (KJV) | | 1
[496] Mark 12:38 (KJV) | | 1
[497] Mark 12:39 (KJV) | | 1
[498] Mark 12:40 (KJV) | | 1
[499] Mark 12:41 (KJV) | | 1
[500] Mark 12:42 (KJV) | | 1
[501] Mark 12:43 (KJV) | | 1
[502] Mark 12:44 (KJV) | | 1
[503] Mark 13:1 (KJV) | | 1
[504] Mark 13:2 (KJV) | | 1
[505] Mark 13:3 (KJV) | | 1
[506] Mark 13:4 (KJV) | | 1
[507] Mark 13:5 (KJV) | | 1
[508] Mark 13:6 (KJV) | | 1
[509] Mark 13:7 (KJV) | | 1
[510] Mark 13:8 (KJV) | | 1
[511] Mark 13:9 (KJV) | | 1
[512] Mark 13:10 (KJV) | | 1
[513] Mark 13:11 (KJV) | | 1
[514] Mark 13:12 (KJV) | | 1
[515] Mark 13:13 (KJV) | | 1
[516] Mark 13:14 (KJV) | | 1
[517] Mark 13:15 (KJV) | | 1
[518] Mark 13:16 (KJV) | | 1
[519] Mark 13:17 (KJV) | | 1
[520] Mark 13:18 (KJV) | | 1
[521] Mark 13:19 (KJV) | | 1
[522] Mark 13:20 (KJV) | | 1
[523] Mark 13:21 (KJV) | | 1
[524] Mark 13:22 (KJV) | | 1
[525] Mark 13:23 (KJV) | | 1
[526] Mark 13:24 (KJV) | | 1
[527] Mark 13:25 (KJV) | | 1
[528] Mark 13:26 (KJV) | | 1
[529] Mark 13:27 (KJV) | | 1
[530] Mark 13:28 (KJV) | | 1
[531] Mark 13:29 (KJV) | | 1
[532] Mark 13:30 (KJV) | | 1
[533] Mark 13:31 (KJV) | | 1
[534] Mark 13:32 (KJV) | | 1
[535] Mark 13:33 (KJV) | | 1
[536] Mark 13:34 (KJV) | | 1
[537] Mark 13:35 (KJV) | | 1
[538] Mark 13:36 (KJV) | | 1
[539] Mark 13:37 (KJV) | | 1
[540] Mark 14:1 (KJV) | | 1
[541] Mark 14:2 (KJV) | | 1
[542] Mark 14:3 (KJV) | | 1
[543] Mark 14:4 (KJV) | | 1
[544] Mark 14:5 (KJV) | | 1
[545] Mark 14:6 (KJV) | | 1
[546] Mark 14:7 (KJV) | | 1
[547] Mark 14:8 (KJV) | | 1
[548] Mark 14:9 (KJV) | | 1
[549] Mark 14:10 (KJV) | | 1
[550] Mark 14:11 (KJV) | | 1
[551] Mark 14:12 (KJV) | | 1
[552] Mark 14:13 (KJV) | | 1
[553] Mark 14:14 (KJV) | | 1
[554] Mark 14:15 (KJV) | | 1
[555] Mark 14:16 (KJV) | | 1
[556] Mark 14:17 (KJV) | | 1
[557] Mark 14:18 (KJV) | | 1
[558] Mark 14:19 (KJV) | | 1
[559] Mark 14:20 (KJV) | | 1
[560] Mark 14:21 (KJV) | | 1
[561] Mark 14:22 (KJV) | | 1
[562] Mark 14:23 (KJV) | | 1
[563] Mark 14:24 (KJV) | | 1
[564] Mark 14:25 (KJV) | | 1
[565] Mark 14:26 (KJV) | | 1
[566] Mark 14:27 (KJV) | | 1
[567] Mark 14:28 (KJV) | | 1
[568] Mark 14:29 (KJV) | | 1
[569] Mark 14:30 (KJV) | | 1
[570] Mark 14:31 (KJV) | | 1
[571] Mark 14:32 (KJV) | | 1
[572] Mark 14:33 (KJV) | | 1
[573] Mark 14:34 (KJV) | | 1
[574] Mark 14:35 (KJV) | | 1
[575] Mark 14:36 (KJV) | | 1
[576] Mark 14:37 (KJV) | | 1
[577] Mark 14:38 (KJV) | | 1
[578] Mark 14:39 (KJV) | | 1
[579] Mark 14:40 (KJV) | | 1
[580] Mark 14:41 (KJV) | | 1
[581] Mark 14:42 (KJV) | | 1
[582] Mark 14:43 (KJV) | | 1
[583] Mark 14:44 (KJV) | | 1
[584] Mark 14:45 (KJV) | | 1
[585] Mark 14:46 (KJV) | | 1
[586] Mark 14:47 (KJV) | | 1
[587] Mark 14:48 (KJV) | | 1
[588] Mark 14:49 (KJV) | | 1
[589] Mark 14:50 (KJV) | | 1
[590] Mark 14:51 (KJV) | | 1
[591] Mark 14:52 (KJV) | | 1
[592] Mark 14:53 (KJV) | | 1
[593] Mark 14:54 (KJV) | | 1
[594] Mark 14:55 (KJV) | | 1
[595] Mark 14:56 (KJV) | | 1
[596] Mark 14:57 (KJV) | | 1
[597] Mark 14:58 (KJV) | | 1
[598] Mark 14:59 (KJV) | | 1
[599] Mark 14:60 (KJV) | | 1
[600] Mark 14:61 (KJV) | | 1
[601] Mark 14:62 (KJV) | | 1
[602] Mark 14:63 (KJV) | | 1
[603] Mark 14:64 (KJV) | | 1
[604] Mark 14:65 (KJV) | | 1
[605] Mark 14:66 (KJV) | | 1
[606] Mark 14:67 (KJV) | | 1
[607] Mark 14:68 (KJV) | | 1
[608] Mark 14:69 (KJV) | | 1
[609] Mark 14:70 (KJV) | | 1
[610] Mark 14:71 (KJV) | | 1
[611] Mark 14:72 (KJV) | | 1
[612] Mark 15:1 (KJV) | | 1
[613] Mark 15:2 (KJV) | | 1
[614] Mark 15:3 (KJV) | | 1
[615] Mark 15:4 (KJV) | | 1
[616] Mark 15:5 (KJV) | | 1
[617] Mark 15:6 (KJV) | | 1
[618] Mark 15:7 (KJV) | | 1
[619] Mark 15:8 (KJV) | | 1
[620] Mark 15:9 (KJV) | | 1
[621] Mark 15:10 (KJV) | | 1
[622] Mark 15:11 (KJV) | | 1
[623] Mark 15:12 (KJV) | | 1
[624] Mark 15:13 (KJV) | | 1
[625] Mark 15:14 (KJV) | | 1
[626] Mark 15:15 (KJV) | | 1
[627] Mark 15:16 (KJV) | | 1
[628] Mark 15:17 (KJV) | | 1
[629] Mark 15:18 (KJV) | | 1
[630] Mark 15:19 (KJV) | | 1
[631] Mark 15:20 (KJV) | | 1
[632] Mark 15:21 (KJV) | | 1
[633] Mark 15:22 (KJV) | | 1
[634] Mark 15:23 (KJV) | | 1
[635] Mark 15:24 (KJV) | | 1
[636] Mark 15:25 (KJV) | | 1
[637] Mark 15:26 (KJV) | | 1
[638] Mark 15:27 (KJV) | | 1
[639] Mark 15:28 (KJV) | | 1
[640] Mark 15:29 (KJV) | | 1
[641] Mark 15:30 (KJV) | | 1
[642] Mark 15:31 (KJV) | | 1
[643] Mark 15:32 (KJV) | | 1
[644] Mark 15:33 (KJV) | | 1
[645] Mark 15:34 (KJV) | | 1
[646] Mark 15:35 (KJV) | | 1
[647] Mark 15:36 (KJV) | | 1
[648] Mark 15:37 (KJV) | | 1
[649] Mark 15:38 (KJV) | | 1
[650] Mark 15:39 (KJV) | | 1
[651] Mark 15:40 (KJV) | | 1
[652] Mark 15:41 (KJV) | | 1
[653] Mark 15:42 (KJV) | | 1
[654] Mark 15:43 (KJV) | | 1
[655] Mark 15:44 (KJV) | | 1
[656] Mark 15:45 (KJV) | | 1
[657] Mark 15:46 (KJV) | | 1
[658] Mark 15:47 (KJV) | | 1
[659] Mark 16:1 (KJV) | | 1
[660] Mark 16:2 (KJV) | | 1
[661] Mark 16:3 (KJV) | | 1
[662] Mark 16:4 (KJV) | | 1
[663] Mark 16:5 (KJV) | | 1
[664] Mark 16:6 (KJV) | | 1
[665] Mark 16:7 (KJV) | | 1
[666] Mark 16:8 (KJV) | | 1
[667] Mark 16:9 (KJV) | | 1
[668] Mark 16:10 (KJV) | | 1
[669] Mark 16:11 (KJV) | | 1
[670] Mark 16:12 (KJV) | | 1
[671] Mark 16:13 (KJV) | | 1
[672] Mark 16:14 (KJV) | | 1
[673] Mark 16:15 (KJV) | | 1
[674] Mark 16:16 (KJV) | | 1
[675] Mark 16:17 (KJV) | | 1
[676] Mark 16:18 (KJV) | | 1
[677] Mark 16:19 (KJV) | | 1
[678] Mark 16:20 (KJV) | | 1